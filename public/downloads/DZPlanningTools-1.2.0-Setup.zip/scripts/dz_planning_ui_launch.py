"""Open the DZ Planning Tools window from Revit-hosted Rhino.

Run this from the Rhino command line inside Rhino.Inside.Revit:

    _-RunPythonScript "C:\\...\\MCP\\scripts\\dz_planning_ui_launch.py"

Phase 8C is a read-only prototype. This launcher opens a window that can read
the active document and render a Change Plan; it cannot publish, and it never
opens a Revit transaction.
"""

import os
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, "src")
if SRC not in sys.path:
    sys.path.insert(0, SRC)

#: Every package whose modules must be re-read on each launch.
DZ_PACKAGES = ("dz_planning_ui", "dz_planning_app", "dz_revit_publisher",
               "dz_revit_integration")


def purge():
    """Drop every cached DZ module, submodules included, before importing.

    A Rhino session is long-lived and caches imports. During the Phase 8A.1
    probe a new window ran against a stale core and produced a verdict that
    described neither revision; a failed 8C launch leaves a half-imported
    ``main_window`` behind in exactly the same way. Purging by top-level
    package name catches ``dz_planning_ui.main_window`` and ``.app`` along with
    everything else.
    """
    stale = sorted(name for name in list(sys.modules)
                   if name.split(".")[0] in DZ_PACKAGES)
    for name in stale:
        del sys.modules[name]
    return stale


def main():
    purged = purge()
    if purged:
        print("Purged %d cached DZ module(s): %s"
              % (len(purged), ", ".join(purged)))

    from dz_planning_app import settings as dz_settings
    from dz_planning_ui import main_window
    from dz_planning_ui.app import launch
    from dz_revit_publisher.revit_bridge import Bridge

    #: The generated .NET window type belongs to the purged module. Forget it
    #: too, or this launch reuses a type built against the old code.
    main_window.reset_window_type()

    bridge = Bridge()
    if not bridge.available:
        print("Rhino.Inside.Revit is not available: %s" % bridge.error)
        print("The window will still open, with no live snapshot.")

    #: One resolution layer, one answer. `settings.load` finds the
    #: installation from its own location and layers any configuration file
    #: over it; `apply` points the publish engine at the result. Nothing here
    #: knows where the product was installed, and no path is edited by hand.
    settings = dz_settings.load()
    dz_settings.apply(settings)
    dz_settings.ensure_user_dirs(settings)
    print(settings.describe())
    #: Where the code actually came from, not where it was resolved to. On a
    #: machine that also has a developer checkout these can differ, and only
    #: this answers the question.
    print("")
    for name, where in dz_settings.module_origins():
        print("%-26s %s" % (name, where))
    stray = dz_settings.loaded_outside(ROOT)
    if stray:
        print("")
        print("WARNING: package(s) loaded from outside this installation:")
        for name, where in stray:
            print("  %s <- %s" % (name, where))
    if not settings.ok:
        print("")
        print("=" * 70)
        print("CONFIGURATION PROBLEM - the window will open, but publishing")
        print("requires the files listed above. Nothing has been read or")
        print("written.")
        print("=" * 70)

    #: The controller reads snake_case keys. `config.as_dict()` is the
    #: PascalCase reporting dict the Grasshopper component displays, and is
    #: deliberately not the same thing.
    config = settings.as_config()
    window = launch(bridge, config)

    #: Wire the publish channel *after* the window exists, so results can be
    #: routed back into it. This is the only place Revit objects are made.
    from dz_revit_integration import event_wiring

    def on_result(result):
        #: Both calls matter and neither may be swallowed: landing the state
        #: machine without redrawing leaves the operator looking at a stale
        #: window, which is how the first live failure showed a ticked
        #: Confirm Publish box beside "Tick Confirm Publish".
        window.app.on_publish_result(result)
        window.refresh()

    #: `window.post` marshals that callback onto the Eto UI thread. Revit
    #: calls Execute on its own main thread; in Rhino.Inside.Revit that is the
    #: same thread, so Invoke is a no-op - but it is correct either way.
    wiring = event_wiring.wire(bridge, config, on_result, window.post)
    window.app.wiring = wiring
    window.app.dispatcher = wiring.dispatcher
    #: Held on the window too, so neither handler nor event is collected.
    window._publish_wiring = wiring
    window.refresh()

    print("DZ Planning Tools opened. Publishing is armed; every write "
          "is confirmed, revalidated and transactional.")
    print("Publish channel available: %s" % wiring.available)
    print("Publish channel: %s" % wiring.describe())
    if not wiring.available:
        print("")
        print("PUBLISH IS NOT AVAILABLE. Confirming a publish would fail at "
              "the ExternalEvent with the reason above.")
        print("Reading, analysing and planning still work; nothing can be "
              "written.")
    return window


def run():
    """Report a startup failure clearly instead of raising into Rhino.

    A raw pythonnet exception dialog says nothing useful about which control
    failed. Nothing has been analysed or written when this path is taken.
    """
    try:
        return main()
    except Exception as exc:
        print("=" * 70)
        print("DZ PLANNING TOOLS - STARTUP FAILED")
        print("=" * 70)
        report = getattr(exc, "report", None)
        if callable(report):
            #: A StartupError already names the checkpoint, the expression,
            #: the control type and the original traceback.
            print(report())
        else:
            print("%s: %s" % (type(exc).__name__, exc))
            print("")
            print("No model was read, no Change Plan was produced, no Revit")
            print("transaction was opened. The active document is untouched.")
            print("")
            print(traceback.format_exc())
        return None


WINDOW = run()
