"""Install, verify, update or remove DZ Planning Tools.

Why this and not an MSI, WiX or Inno package
--------------------------------------------
The payload is Python source, two configuration files and one launcher script.
There is no compiled binary, no DLL, no COM registration, no service, no
registry key and no shared runtime to install: Rhino 8 supplies the Python
interpreter, and Rhino.Inside.Revit supplies the Revit binding. Installation is
therefore a verified file copy into a per-user folder.

An MSI or Inno package would add a build toolchain and a signing story that
this repository does not have, cannot exercise under the internal validation
policy, and that would buy nothing over a copy. It would also need
administrator rights for a product that does not require them. A Revit ribbon
button would need a compiled add-in, which the roadmap defers to Phase 9+ as
the "C# add-in shell".

So: a plain script, runnable by any Python 3 - including the one already on the
machine to run Rhino.

    python install/install.py                 install to the default location
    python install/install.py --target DIR    install somewhere specific
    python install/install.py --verify        check an existing installation
    python install/install.py --uninstall     remove the application files
    python install/install.py --list          print the payload and exit

Uninstall removes only the application tree. Per-user data - configuration,
exports, reports, logs - is left alone unless ``--purge`` is given, because
deleting an operator's exported packages to uninstall a tool would be
indefensible.
"""

import hashlib
import io
import json
import os
import shutil
import sys

APP_NAME = "DZPlanningTools"
MANIFEST_NAME = "install_manifest.json"
#: The **product** version, recorded in `install_manifest.json`. The publisher
#: engine is versioned separately in `dz_revit_publisher.__version__`, appears
#: in every log entry as `PublisherVersion`, and gates log schema
#: compatibility - so it is deliberately not synchronised with this number.
VERSION = "1.2.0"

#: Packages the product needs at runtime. `dz_report` is optional - it is the
#: Phase 6B planning-report generator and needs ReportLab, which the product
#: does not require.
REQUIRED_PACKAGES = ("dz_planning_app", "dz_planning_ui", "dz_revit_publisher",
                     "dz_revit_integration")
OPTIONAL_PACKAGES = ("dz_report",)

#: The launcher, and nothing else from `scripts/`. The Grasshopper components
#: and one-off probes are development tools, not product.
SCRIPTS = ("dz_planning_ui_launch.py",)

#: Application data. Without the first two the publish engine cannot bind its
#: shared parameters, so they are required.
CONFIG_FILES = ("DZ_Planning_SharedParameters.txt",
                "dz_shared_parameters.json",
                "dz_planning_app.json")

DOCS = ("PHASE08_INSTALL_GUIDE.md", "PHASE07_OPERATOR_RUNBOOK.md")

#: The Revit launcher add-in, prebuilt. It is committed rather than compiled
#: at install time so an operator never needs the .NET SDK - the product's
#: whole premise is that Rhino already supplies its runtime.
#:
#: `deps.json` travels with the DLL because the assembly is loaded dynamically
#: by Revit; the pdb and runtimeconfig are development artefacts and are not
#: shipped.
#:
#: **The shell is deployed flat, in the Revit add-ins folder itself**, beside
#: the manifest that names it. Phase 9A needed two live attempts to arrive
#: here. The first put the shell under `%LOCALAPPDATA%`; Revit read the
#: manifest and reported the assembly did not exist. The second moved it to a
#: `DZPlanningTools\` subfolder of the add-ins directory, which was still two
#: directories where one would do.
#:
#: Flat means the manifest and the assembly are the same directory entry that
#: Revit already had to read to find the manifest at all. If Revit can see the
#: manifest it can see the DLL; there is no second location left to be wrong
#: about. The Python product stays under `%LOCALAPPDATA%` and the shell finds
#: it through `SpecialFolder.LocalApplicationData` - shell location and
#: product location are independent concerns.
ADDIN_FILES = ("DZPlanningTools.Revit.dll", "DZPlanningTools.Revit.deps.json")
ADDIN_ASSEMBLY = "DZPlanningTools.Revit.dll"
ADDIN_MANIFEST = "DZPlanningTools.addin"
ADDIN_TEMPLATE = "DZPlanningTools.addin.template"

#: Everything the product owns inside the Revit add-ins folder, and the only
#: entries uninstall may remove from it. The folder belongs to Revit and is
#: shared with every other vendor, so it is never removed as a directory.
ADDIN_OWNED = (ADDIN_MANIFEST,) + ADDIN_FILES

#: The layout this replaced. Removed on sight so no verification can ever
#: pass against a file Revit is not reading.
LEGACY_SHELL_FOLDER = "DZPlanningTools"

#: Revit only scans its own add-ins folders, so the manifest is the one file
#: the product writes outside its installation root.
REVIT_YEARS = ("2025",)

#: Never copied. Build artefacts, tests, fixtures and the developer venv have
#: no place in an installation, and `__pycache__` would carry compiled
#: references to the build machine's paths.
EXCLUDE_DIRS = ("__pycache__", ".git", ".venv", "tests", "Fixtures",
                "Exports", "probes")
EXCLUDE_SUFFIXES = (".pyc", ".pyo", ".rvt", ".3dm", ".gh")


def source_root(start=None):
    """The repository or staging root this installer was run from."""
    here = os.path.abspath(start or __file__)
    return os.path.dirname(os.path.dirname(here))


def default_target():
    """Per-user, no administrator rights, no shared state."""
    base = (os.environ.get("LOCALAPPDATA")
            or os.environ.get("XDG_DATA_HOME")
            or os.path.expanduser("~"))
    return os.path.join(base, APP_NAME)


def user_data_root():
    base = (os.environ.get("APPDATA")
            or os.environ.get("XDG_CONFIG_HOME")
            or os.path.expanduser("~"))
    return os.path.join(base, APP_NAME)


# -- Phase 14B: prerequisites ------------------------------------------------
#
# The product ships no runtime. Rhino 8 supplies the Python interpreter and
# Eto; Rhino.Inside.Revit supplies the Revit binding; Revit 2025 supplies the
# .NET 8 host. None of that is installed here, so the honest thing an
# installer can do is say whether it is present before writing anything.

FOUND = "FOUND"
NOT_FOUND = "NOT FOUND"
UNCONFIRMED = "UNCONFIRMED"

#: One supported configuration. Claiming Revit 2024 or 2026 without testing
#: either version would be a compatibility promise nobody has earned.
SUPPORTED_WINDOWS = "Windows 11 64-bit"
SUPPORTED_REVIT = "Revit 2025"
SUPPORTED_RHINO = "Rhino 8"

#: The Rhino.Inside build this product has actually been exercised against.
#: Deliberately **not** called a minimum: the shell touches only
#: `RhinoApp.Version` and `RhinoApp.RunScript`, both stable since Rhino 5, so
#: no API-derived floor exists to defend. A number invented here would read as
#: a tested guarantee and would not be one.
VALIDATED_RHINO_INSIDE = "1.33.9347.9430"


class Finding(object):
    """One prerequisite, its state, and the evidence for that state."""

    def __init__(self, name, state, detail, required=True, advice=None):
        self.name = name
        self.state = state
        self.detail = detail
        self.required = required
        self.advice = advice

    @property
    def blocking(self):
        #: Only positive evidence of absence blocks. UNCONFIRMED never does -
        #: the Phase 10A rule, applied to prerequisites: "cannot tell" is not
        #: "not installed", and an installer that refused on an unreadable
        #: directory would refuse on machines where everything is fine.
        return self.required and self.state == NOT_FOUND

    def __repr__(self):
        return "Finding(%r, %r)" % (self.name, self.state)


def _look(paths):
    """Does any of these exist? Returns (state, evidence).

    A path that cannot be examined at all - permissions, a disconnected drive,
    an exotic filesystem - yields UNCONFIRMED rather than NOT_FOUND.
    """
    unreadable = []
    for path in paths:
        try:
            if os.path.exists(path):
                return FOUND, path
        except Exception as exc:
            unreadable.append("%s (%s)" % (path, type(exc).__name__))
    if unreadable:
        return UNCONFIRMED, "could not examine " + "; ".join(unreadable)
    return NOT_FOUND, "looked in: " + "; ".join(paths)


def _program_files(environ):
    roots = []
    for key in ("ProgramFiles", "ProgramW6432", "ProgramFiles(x86)"):
        value = environ.get(key)
        if value and value not in roots:
            roots.append(value)
    return roots or ["C:\\Program Files"]


def revit_finding(environ=None):
    environ = os.environ if environ is None else environ
    paths = [os.path.join(root, "Autodesk", "Revit %s" % REVIT_YEARS[0],
                          "Revit.exe")
             for root in _program_files(environ)]
    state, evidence = _look(paths)
    return Finding(
        SUPPORTED_REVIT, state, evidence,
        advice="Install Autodesk Revit %s." % REVIT_YEARS[0])


def rhino_finding(environ=None):
    environ = os.environ if environ is None else environ
    paths = [os.path.join(root, "Rhino 8", "System", "Rhino.exe")
             for root in _program_files(environ)]
    state, evidence = _look(paths)
    return Finding(
        SUPPORTED_RHINO, state, evidence,
        advice="Install Rhino 8 (it supplies the Python interpreter and the "
               "window toolkit this product runs on).")


def rhino_inside_finding(environ=None):
    """Rhino.Inside.Revit, looked for where it is actually registered.

    It installs **machine-wide**, under `%PROGRAMDATA%`, not in the per-user
    add-ins folder. Phase 14A guessed the per-user location; the machine it
    was checked on has it only under ProgramData. Both are searched, because
    either is a legitimate Revit add-in location.
    """
    environ = os.environ if environ is None else environ
    year = REVIT_YEARS[0]
    roots = [environ.get("PROGRAMDATA") or "C:\\ProgramData",
             environ.get("APPDATA") or ""]
    paths = []
    for root in roots:
        if not root:
            continue
        paths.append(os.path.join(root, "Autodesk", "Revit", "Addins", year,
                                  "RhinoInside.Revit.addin"))
    state, evidence = _look(paths)
    return Finding(
        "Rhino.Inside.Revit", state, evidence,
        advice="Install Rhino.Inside.Revit for Revit %s. Validated with %s."
               % (year, VALIDATED_RHINO_INSIDE))


def preflight(environ=None):
    """Every prerequisite, in the order an operator would fix them."""
    return [revit_finding(environ), rhino_finding(environ),
            rhino_inside_finding(environ)]


def preflight_problems(findings):
    """Blocking messages only. UNCONFIRMED is reported elsewhere, as a note."""
    problems = []
    for finding in findings:
        if finding.blocking:
            problems.append("%s could not be found. %s"
                            % (finding.name, finding.advice or ""))
    return problems


def preflight_notes(findings):
    """Non-blocking observations, so an unconfirmable check is still said."""
    return ["%s could not be confirmed (%s). Installation continued."
            % (finding.name, finding.detail)
            for finding in findings if finding.state == UNCONFIRMED]


# -- Phase 14B: version ordering ---------------------------------------------

def parse_version(text):
    """`"1.2.0"` -> `(1, 2, 0)`, or None when it is not a version at all.

    Deliberately strict and small. An unparseable string is not treated as
    zero, because "unknown" and "oldest possible" are different claims and
    only one of them is safe to act on.
    """
    if not text:
        return None
    parts = str(text).strip().split(".")
    if not 1 <= len(parts) <= 4:
        return None
    numbers = []
    for part in parts:
        if not part.isdigit():
            return None
        numbers.append(int(part))
    while len(numbers) < 3:
        numbers.append(0)
    return tuple(numbers)


#: What an existing installation looks like when its manifest is unreadable.
LEGACY = "legacy"


def installed_version(target):
    """The version recorded by the installation at `target`.

    Returns (text, state) where state is one of "none" (nothing installed),
    "known" (a version was read) or LEGACY (a product tree exists but its
    version cannot be established).
    """
    manifest_path = os.path.join(target, MANIFEST_NAME)
    looks_installed = os.path.isdir(os.path.join(target, "src"))
    if not os.path.exists(manifest_path):
        return (None, LEGACY if looks_installed else "none")
    try:
        with io.open(manifest_path, "r", encoding="utf-8") as handle:
            recorded = json.load(handle)
    except Exception:
        return (None, LEGACY)
    version = recorded.get("version")
    if parse_version(version) is None:
        return (version, LEGACY)
    return (version, "known")


DOWNGRADE_REFUSED = (
    "DZ Planning Tools %s is already installed.\n"
    "  This package contains %s.\n"
    "  Downgrade was refused. Uninstall the newer version first, or re-run\n"
    "  with --allow-downgrade if that is genuinely what you intend.")


def downgrade_problem(target, package_version, allow=False):
    """A blocking message when the installed product is newer, else None.

    An installation whose version cannot be read is **never** treated as
    newer. Refusing to upgrade a 0.8.x tree because its manifest predates the
    version field would strand exactly the installations that most need
    replacing.
    """
    if allow:
        return None
    installed, state = installed_version(target)
    if state != "known":
        return None
    current = parse_version(installed)
    incoming = parse_version(package_version)
    if current is None or incoming is None:
        return None
    if current > incoming:
        return DOWNGRADE_REFUSED % (installed, package_version)
    return None


def upgrade_note(target, package_version):
    """What this install will do to what is already there. Never blocking."""
    installed, state = installed_version(target)
    if state == "none":
        return "Clean install of %s." % package_version
    if state == LEGACY:
        return ("An existing installation was found but its version could "
                "not be read. Treating it as older and replacing it with %s."
                % package_version)
    current, incoming = parse_version(installed), parse_version(package_version)
    if current == incoming:
        return "Reinstalling %s over the same version (repair)." % installed
    if current < incoming:
        return "Upgrading %s to %s." % (installed, package_version)
    return "Installed %s is newer than %s." % (installed, package_version)



def final_path(path):
    """Where Windows says this path *really* is, resolved from a handle.

    `GetFinalPathNameByHandleW` reports the canonical location of the object a
    handle refers to. Under MSIX/AppContainer package redirection the answer
    differs from the path that was opened: a packaged process asking for
    `%LOCALAPPDATA%\\X` transparently gets
    `%LOCALAPPDATA%\\Packages\\<pkg>\\LocalCache\\Local\\X` instead, and never
    learns it happened.

    Returns the resolved path, or None where it cannot be determined - a
    non-Windows host, an unreadable path, or a Python without ctypes. Unknown
    is not evidence of redirection, so callers treat None as "no finding".
    """
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes
    except Exception:
        return None
    if not os.path.exists(path):
        return None

    GENERIC_READ = 0x80000000
    FILE_SHARE_ALL = 0x00000001 | 0x00000002 | 0x00000004
    OPEN_EXISTING = 3
    BACKUP_SEMANTICS = 0x02000000          # required to open a directory
    INVALID_HANDLE = ctypes.c_void_p(-1).value

    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateFileW.restype = wintypes.HANDLE
        handle = kernel32.CreateFileW(
            ctypes.c_wchar_p(os.path.abspath(path)), GENERIC_READ,
            FILE_SHARE_ALL, None, OPEN_EXISTING, BACKUP_SEMANTICS, None)
        if not handle or handle == INVALID_HANDLE:
            return None
        try:
            size = kernel32.GetFinalPathNameByHandleW(handle, None, 0, 0)
            if not size:
                return None
            buffer = ctypes.create_unicode_buffer(size)
            written = kernel32.GetFinalPathNameByHandleW(
                handle, buffer, size, 0)
            if not written:
                return None
            resolved = buffer.value
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        return None

    #: `\\?\\` and the UNC form are spellings, not relocations.
    for prefix in ("\\\\?\\UNC\\", "\\\\?\\"):
        if resolved.startswith(prefix):
            resolved = resolved[len(prefix):]
            if prefix.endswith("UNC\\"):
                resolved = "\\\\" + resolved
            break
    return resolved


#: Said in full when an installation cannot reach the application that has to
#: read it. Naming the real location matters: without it the operator sees an
#: installer that succeeded and an application that disagrees, which is the
#: hardest kind of failure to act on.
REDIRECTED = (
    "This process's writes to %s are being redirected by Windows to %s.\n"
    "  Revit and Rhino are not packaged, so they read the real location and\n"
    "  will not see anything installed from here. Run the installer from an\n"
    "  ordinary command prompt - not from inside a sandboxed or packaged\n"
    "  application - and install again.")


def probe_file(target):
    """A real file under `target` to resolve. Directories are not enough.

    A packaged process opening the *directory* `%LOCALAPPDATA%\\DZPlanningTools`
    gets the unredirected path back, because the directory exists in both
    namespaces. Opening a *file* inside it returns the overlay. So the
    question has to be asked of something actually written.
    """
    manifest = os.path.join(target, MANIFEST_NAME)
    if os.path.isfile(manifest):
        return manifest
    for folder, dirs, names in os.walk(target):
        for name in sorted(names):
            return os.path.join(folder, name)
    return None


def redirection_problem(target):
    """A blocking message when writes to `target` are virtualized, else None.

    Phase 8G documented that installer-local verification re-reads through the
    installing process's own filesystem view, and that a redirected view makes
    a pass meaningless. This turns that caveat into a refusal: an installer
    that cannot see where it actually wrote must not report success.

    The V1.1 deployment failure is the case it exists for. A sandboxed process
    installed 66 files, verified every hash against itself, and reported
    success - into `LocalCache\\Local\\DZPlanningTools`, a private overlay.
    Revit, unpackaged, went on reading a two-week-old payload at the same
    printed path. Both readings were correct; they were different files.
    """
    probe = probe_file(target)
    if not probe:
        return None
    resolved = final_path(probe)
    if not resolved:
        return None
    inside = os.path.normcase(os.path.abspath(target))
    landed = os.path.normcase(os.path.abspath(resolved))
    if landed.startswith(inside):
        return None
    return REDIRECTED % (probe, resolved)


def sha256(path):
    digest = hashlib.sha256()
    with io.open(path, "rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def wanted(name):
    return not name.lower().endswith(EXCLUDE_SUFFIXES)


def package_files(root, package):
    """Every shippable file of one package, as (source, relative) pairs."""
    base = os.path.join(root, "src", package)
    found = []
    for folder, dirs, names in os.walk(base):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for name in sorted(names):
            if not wanted(name):
                continue
            full = os.path.join(folder, name)
            found.append((full, os.path.relpath(full, root)))
    return sorted(found, key=lambda pair: pair[1])


def payload(root, optional=True):
    """Everything to install, as (source, relative-destination) pairs.

    Missing optional items are skipped; a missing required item is reported by
    :func:`plan`, never silently dropped.
    """
    items, missing = [], []
    for package in REQUIRED_PACKAGES:
        found = package_files(root, package)
        if not found:
            missing.append(os.path.join("src", package))
        items.extend(found)
    if optional:
        for package in OPTIONAL_PACKAGES:
            items.extend(package_files(root, package))
    for name in SCRIPTS:
        full = os.path.join(root, "scripts", name)
        if os.path.isfile(full):
            items.append((full, os.path.join("scripts", name)))
        else:
            missing.append(os.path.join("scripts", name))
    for name in CONFIG_FILES:
        full = os.path.join(root, "config", name)
        if os.path.isfile(full):
            items.append((full, os.path.join("config", name)))
        elif name != "dz_planning_app.json":
            missing.append(os.path.join("config", name))
    for name in DOCS:
        full = os.path.join(root, "docs", name)
        if os.path.isfile(full):
            items.append((full, os.path.join("docs", name)))
    return items, missing


def install(root, target, optional=True, quiet=False, register=True):
    """Copy the payload and write a manifest. Returns (manifest, problems)."""
    items, missing = payload(root, optional)
    if missing:
        return None, ["Missing from the source tree: %s" % m for m in missing]

    problems = []
    records = []
    for source, relative in items:
        destination = os.path.join(target, relative)
        folder = os.path.dirname(destination)
        try:
            if not os.path.isdir(folder):
                os.makedirs(folder)
            shutil.copy2(source, destination)
        except Exception as exc:
            problems.append("Could not install %s (%s: %s)"
                            % (relative, type(exc).__name__, exc))
            continue
        records.append({"path": relative.replace("\\", "/"),
                        "sha256": sha256(destination),
                        "bytes": os.path.getsize(destination)})

    manifest = {
        "product": APP_NAME,
        "version": VERSION,
        "files": records,
        "entry_point": "scripts/dz_planning_ui_launch.py",
        "user_data_root": user_data_root(),
    }
    try:
        with io.open(os.path.join(target, MANIFEST_NAME), "w",
                     encoding="utf-8") as handle:
            handle.write(json.dumps(manifest, indent=2, sort_keys=True))
    except Exception as exc:
        problems.append("Could not write the install manifest (%s: %s)"
                        % (type(exc).__name__, exc))

    for folder in ("Exports", "Reports", "Logs"):
        path = os.path.join(user_data_root(), folder)
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
        except Exception as exc:
            problems.append("Could not create %s (%s: %s)"
                            % (path, type(exc).__name__, exc))

    if register:
        written, addin_problems = register_addin(root, target)
        problems.extend(addin_problems)
    else:
        #: A staging install must not touch the machine's Revit registration.
        #: The shell always loads the product from the well-known per-user
        #: root, so registering a `--target` install would point Revit at one
        #: product while the files went to another.
        written = []
    manifest["addin_manifests"] = written

    #: Last, and blocking. Everything above may have "succeeded" into a
    #: private overlay the host cannot read.
    redirected = redirection_problem(target)
    if redirected:
        problems.append(redirected)

    if not quiet:
        print("Installed %d file(s) to %s" % (len(records), target))
        for path in written:
            print("Registered Revit add-in: %s" % path)
    manifest["payload_written"] = bool(records) and not [
        p for p in problems if "add-in" not in p]
    return manifest, problems


#: The three outcomes an installer may report, and nothing in between.
#: Before Phase 14B a shell-registration failure printed "Installed 66
#: file(s)" and then a PROBLEMS list, which reads to a hurried operator as a
#: success with a footnote. It is not: the payload is on disk and Revit will
#: not show a ribbon.
OK = "OK"
PARTIAL = "PARTIAL"
FAILED = "FAILED"

STATUS_LINES = {
    OK: "INSTALLATION COMPLETE",
    PARTIAL: ("PAYLOAD INSTALLED - ADD-IN REGISTRATION FAILED\n"
              "  DZ Planning Tools will not appear in the Revit ribbon until\n"
              "  registration succeeds. Close Revit and install again."),
    FAILED: "INSTALLATION FAILED",
}


def should_register(argv):
    """Whether this run may touch the machine's Revit registration.

    A custom `--target` is a staging install by definition - an image being
    prepared, or a check being run. Registering it would repoint the live
    Revit add-in while the payload went somewhere else, which is how a test
    run silently rewrote the machine's manifest during Phase 14B.

    Extracted so the decision can be asserted directly. Reaching it through
    `main()` would mean running a real install to find out, and the only way
    to observe the wrong answer would be to let it happen.
    """
    if "--target" not in argv:
        return True
    return "--register" in argv


def classify(problems, payload_written):
    """One unambiguous outcome from the problems collected."""
    if not problems:
        return OK
    if payload_written and all("add-in" in p for p in problems):
        return PARTIAL
    return FAILED


def revit_addins_dir(year, environ=None):
    """The per-user Revit add-ins folder for one release year."""
    environ = os.environ if environ is None else environ
    base = environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, "Autodesk", "Revit", "Addins", year)


def render_manifest(template, assembly_path):
    """Fill the manifest template with the installed assembly's real path."""
    return template.replace("{ASSEMBLY}", assembly_path)


def shell_dir(year, environ=None):
    """Where the Revit shell assembly lives: the add-ins folder itself.

    Not a subfolder of it. The manifest names an absolute path in this exact
    directory, so the assembly sits in the one place Revit has already proven
    it can read - it found the manifest there.
    """
    return revit_addins_dir(year, environ)


def register_addin(root, target=None, environ=None, years=None):
    """Install the shell beside its manifest and register it with Revit.

    Returns (written, problems). The manifest names an absolute path, so it
    must be written by whoever installed, and it can only ever name a file in
    the folder written alongside it - which is the whole point of co-locating
    them.

    ``target`` is accepted and unused: the shell no longer lives inside the
    product root. It stays in the signature so existing callers do not break.
    """
    template_path = os.path.join(root, "addin", ADDIN_TEMPLATE)
    written, problems = [], []

    if not os.path.isfile(template_path):
        return written, ["Add-in manifest template missing: %s"
                         % template_path]

    source_dir = os.path.join(root, "addin", "dist")
    if not os.path.isfile(os.path.join(source_dir, ADDIN_ASSEMBLY)):
        return written, ["Add-in assembly missing from the distribution: %s"
                         % os.path.join(source_dir, ADDIN_ASSEMBLY)]

    try:
        with io.open(template_path, "r", encoding="utf-8-sig") as handle:
            template = handle.read()
    except Exception as exc:
        return written, ["Could not read the manifest template (%s: %s)"
                         % (type(exc).__name__, exc)]

    for year in (years or REVIT_YEARS):
        folder = revit_addins_dir(year, environ)
        assembly = os.path.join(folder, ADDIN_ASSEMBLY)
        try:
            if not os.path.isdir(folder):
                os.makedirs(folder)
            #: Clear the previous layout first. A stale subfolder shell would
            #: survive as a plausible-looking file that Revit never loads.
            legacy = os.path.join(folder, LEGACY_SHELL_FOLDER)
            if os.path.isdir(legacy):
                shutil.rmtree(legacy, ignore_errors=True)
            for name in ADDIN_FILES:
                origin = os.path.join(source_dir, name)
                if os.path.isfile(origin):
                    shutil.copy2(origin, os.path.join(folder, name))
            #: The assembly path is written absolute and fully expanded. Revit
            #: does not expand environment variables in this element, and a
            #: relative path would resolve against Revit's own directory.
            with io.open(os.path.join(folder, ADDIN_MANIFEST), "w",
                         encoding="utf-8") as handle:
                handle.write(render_manifest(template,
                                             os.path.abspath(assembly)))
            written.append(os.path.join(folder, ADDIN_MANIFEST))
        except Exception as exc:
            problems.append("Could not register the add-in for Revit %s "
                            "(%s: %s)" % (year, type(exc).__name__, exc))

    #: A shell left in the old product-root location would let a later
    #: verification pass against a stale file. Two layouts is worse than none.
    if target:
        stale = os.path.join(target, "addin")
        if os.path.isdir(stale):
            shutil.rmtree(stale, ignore_errors=True)

    return written, problems


def unregister_addin(environ=None, years=None):
    """Remove the DZ manifest and shell files. Touches no other vendor.

    The shell is now flat in a directory Revit shares with every other add-in,
    so removal is by name - the three files the product wrote. The directory
    itself is never removed, and neither is anything the product did not put
    there.
    """
    removed = []
    for year in (years or REVIT_YEARS):
        folder = revit_addins_dir(year, environ)
        for name in ADDIN_OWNED:
            path = os.path.join(folder, name)
            if os.path.isfile(path):
                try:
                    os.remove(path)
                    removed.append(path)
                except Exception:
                    pass
        legacy = os.path.join(folder, LEGACY_SHELL_FOLDER)
        if os.path.isdir(legacy):
            try:
                shutil.rmtree(legacy)
                removed.append(legacy)
            except Exception:
                pass
    return removed


def verify(target):
    """Check an installation against its own manifest. Returns problems.

    **This is installer-local verification, not host-visible verification.**
    It re-reads the files through whatever filesystem view the *installing*
    process has. If that view is redirected - a sandbox, an overlay, a
    container mount - this reports success for an installation the host
    application cannot see. Phase 8G's live acceptance found exactly that.

    A pass here is necessary and not sufficient. Host visibility is
    established by `host_bootstrap.py`, which installs and verifies from
    inside the real Rhino process.

    Since the V1.1 deployment failure this caveat is **enforced**, not merely
    documented: a redirected target is reported as a problem before any hash
    is compared. The old behaviour let a packaged process install 66 files
    into a private overlay, verify them against themselves, and report
    success, while Revit went on reading a two-week-old payload at the same
    printed path.
    """
    #: Before anything is compared. Every hash below would otherwise be read
    #: back through the same redirected view that wrote it, and agree with
    #: itself no matter what the host can see.
    redirected = redirection_problem(target)
    if redirected:
        return [redirected]

    manifest_path = os.path.join(target, MANIFEST_NAME)
    if not os.path.isfile(manifest_path):
        return ["No install manifest at %s" % manifest_path]
    try:
        with io.open(manifest_path, "r", encoding="utf-8") as handle:
            manifest = json.load(handle)
    except Exception as exc:
        return ["Install manifest unreadable (%s: %s)"
                % (type(exc).__name__, exc)]

    problems = []
    for record in manifest.get("files", []):
        path = os.path.join(target, record["path"].replace("/", os.sep))
        if not os.path.isfile(path):
            problems.append("Missing: %s" % record["path"])
        elif sha256(path) != record["sha256"]:
            problems.append("Modified since install: %s" % record["path"])
    entry = os.path.join(target, manifest.get("entry_point", "").replace(
        "/", os.sep))
    if manifest.get("entry_point") and not os.path.isfile(entry):
        problems.append("Entry point missing: %s" % manifest["entry_point"])
    return problems


def uninstall(target, purge=False):
    """Remove the application tree. User data survives unless purged."""
    removed = []
    #: The manifest first: leaving it behind would point Revit at an assembly
    #: that is about to disappear, and Revit would report a load error on
    #: every start.
    removed.extend(unregister_addin())
    if os.path.isdir(target):
        shutil.rmtree(target, ignore_errors=True)
        removed.append(target)
    if purge:
        data = user_data_root()
        if os.path.isdir(data):
            shutil.rmtree(data, ignore_errors=True)
            removed.append(data)
    return removed


def launch_command(target):
    entry = os.path.join(target, "scripts", "dz_planning_ui_launch.py")
    return '_-RunPythonScript "%s"' % entry


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    target = default_target()
    if "--target" in argv:
        target = os.path.abspath(argv[argv.index("--target") + 1])
    root = source_root()

    if "--list" in argv:
        items, missing = payload(root)
        for _source, relative in items:
            print(relative)
        print("%d file(s); missing: %s" % (len(items), missing or "none"))
        return 0

    if "--uninstall" in argv:
        removed = uninstall(target, purge="--purge" in argv)
        print("Removed: %s" % (removed or "nothing"))
        return 0

    if "--verify" in argv:
        problems = verify(target)
        print("\n".join(problems) if problems
              else "Installation verified: %s" % target)
        return 1 if problems else 0

    # -- 1. prerequisites ---------------------------------------------
    #
    # Before anything is written. An install onto a machine that cannot run
    # the product is not a success that the operator discovers later at the
    # ribbon; it is a failure that should be said now.
    findings = preflight()
    print("Prerequisites")
    for finding in findings:
        print("  %-22s %s" % (finding.name, finding.state))
    blocking = preflight_problems(findings)
    for note in preflight_notes(findings):
        print("  NOTE: %s" % note)
    if blocking and "--force" not in argv:
        print("")
        print("PROBLEMS:")
        for problem in blocking:
            print("  - %s" % problem)
        print("")
        print("Install the missing prerequisites and try again. To stage the")
        print("files anyway - for an offline machine, or an image being")
        print("prepared - re-run with --force.")
        print(STATUS_LINES[FAILED])
        return 1
    if blocking:
        #: `--force` is narrow on purpose. It permits *staging without proven
        #: prerequisites* and nothing else: it does not touch the redirection
        #: check, the hash verification or the downgrade guard below.
        print("  --force: continuing without confirmed prerequisites.")

    # -- 2. what is already there --------------------------------------
    allow_downgrade = "--allow-downgrade" in argv
    refusal = downgrade_problem(target, VERSION, allow=allow_downgrade)
    if refusal:
        print("")
        print(refusal)
        print(STATUS_LINES[FAILED])
        return 1
    print("")
    print(upgrade_note(target, VERSION))
    if allow_downgrade:
        print("  --allow-downgrade: version ordering was not enforced.")

    # -- 3. write, register, verify ------------------------------------
    #
    # The redirection check lives inside `install()` and `verify()` rather
    # than here, and it necessarily runs *after* the first file is written:
    # resolving a handle needs a file to resolve, and a packaged process
    # opening the target *directory* is handed the unredirected path back.
    print("")
    staging = "--target" in argv
    register = should_register(argv)
    if staging and not register:
        print("  --target: Revit add-in registration skipped "
              "(pass --register to force it).")
    manifest, problems = install(root, target, optional="--no-optional"
                                 not in argv, register=register)
    if problems:
        print("PROBLEMS:")
        for problem in problems:
            print("  - %s" % problem)
        status = classify(problems, (manifest or {}).get("payload_written"))
        print("")
        print(STATUS_LINES[status])
        return 1

    problems = verify(target)
    if problems:
        print("VERIFICATION FAILED:")
        for problem in problems:
            print("  - %s" % problem)
        print("")
        print(STATUS_LINES[FAILED])
        return 1

    print("Verified %d file(s)." % len(manifest["files"]))
    print("")
    print(STATUS_LINES[OK])
    print("")
    print("Start Revit %s, start Rhino.Inside, then use the DZ Planning "
          "Tools ribbon button." % REVIT_YEARS[0])
    print("The Rhino command line equivalent is:")
    print("  %s" % launch_command(target))
    return 0


if __name__ == "__main__":
    sys.exit(main())
