# Phase 7 Operator Runbook

How to publish DZ planning data into Revit, safely, in normal use.

---

## A. Normal publish against an existing saved Revit model

1. **Open the RVT** you intend to change. Confirm the path, not the title —
   working copies are byte-identical clones and Revit shows the same title for
   all of them.
2. **Start Rhino.Inside.Revit** from the Revit ribbon.
3. **Open the current publish definition** in the Revit-hosted Grasshopper.
4. **Confirm the safe defaults** on the canvas:
   - Publish Mode = `Preview Only`
   - Obsolete Element Action = `Mark Only`
   - Confirm Publish = `False`
   - Confirm Delete Obsolete = `False`
   - Force Fail At Stage = blank
   - `ExpectedRvtPath` = the exact path of the open model
5. **Run Preview Only** (F5) and **read the Change Plan**. Check:
   - the per-floor actions are what you expect
   - `CREATE`, `OBSOLETE` and `CONFLICT` counts are what you expect
   - `Plan Valid: YES`
   - `Errors: OK`
   - for a geometry change, `Floor: REPLACE (controlled, new ElementId)` —
     ElementIds *will* change
6. **Arm deliberately**: set Publish Mode = `Create or Update`, leave Obsolete
   Element Action = `Mark Only` and Confirm Delete Obsolete = `False`, set
   Confirm Publish = `True`.
7. **Press F5 once** and wait for the validation solution to finish. Confirm
   `Publish Status: VALIDATED` and `Publish Ready: YES`.
8. **Click Publish exactly once.**
9. **Verify from the log, not the panels.** Open
   `<package>/revit_publish/phase07c_publish_log.json`, take the newest entry
   with a non-null `UserClickTimestamp`, and confirm:
   - `TransactionResult: assimilated`
   - all nine `StageResults` are `OK`
   - `Errors: []`
   - `rollbackOccurred: false`
   - the `Results` counters match what the Preview proposed
10. **Save the RVT.**

> Grasshopper runs a **second solution when the button is released**. The panels
> you see after clicking show that later, non-writing solution. They are not
> evidence of what happened.

---

## B. Claude-assisted development or diagnosis

1. **Start the MCP router first**, then Revit. If the router restarts after
   Revit, the Rhino.Inside plugin's registration is lost.
2. **Start Revit and Rhino.Inside**, and open the target model.
3. **Run `MCPStart`** in the Revit-hosted Rhino. If it reports "already started"
   against a dead router, run `MCPStop` first.
4. **Verify the slot belongs to Revit.exe** — check the slot PID against the
   running `Revit.exe` process, not just that a slot exists.
5. **Verify `ActiveDBDocument.PathName`** before anything else. **Never rely on
   the Revit window title**: byte-identical working copies all show the same
   title, and the path is the only discriminator.
6. **Expect the slot to disappear** when the Rhino.Inside session or the Revit
   document closes. A mid-call `rhino_closed` error means exactly that. The slot
   usually returns on a **different port** after `MCPStart` — that port change is
   itself evidence of a genuine document reopen.
7. **Never call `spawn_slot`** when no slot is present. It starts a standalone
   Rhino with no Revit attached, and that process will answer subsequent calls.

---

## C. Safety rules

- **Never publish without `ExpectedRvtPath` set** to the exact model you intend
  to change. It is the only thing that stops a fixture run reaching production.
- **Never test against `Project1.rvt`.** Copy it to a clearly named disposable
  working model and point `ExpectedRvtPath` at the copy.
- **Keep `Confirm Delete Obsolete = False`** unless you are explicitly testing
  deletion. Deletion additionally requires `Obsolete Element Action = Delete`.
- **Preview Only must never start a Transaction.** If a preview log entry shows
  anything other than `TransactionResult: not started` and empty `StageResults`,
  stop and investigate.
- **Genuine Revit writes require a manual user click.** Rhino.Inside grants an
  API context only on real canvas interaction. Nothing driven through MCP can
  write, and no automation should try.
- **Verify the Grasshopper solver is enabled before clicking.** Every MCP call
  leaves all Grasshopper documents with `Enabled = False`. A click on a disabled
  document runs **no solution and writes nothing** — this silently consumed two
  publish clicks during Phase 7C. Press **F5** first and confirm a new log entry
  appears. If F5 does nothing, toggle Solution → Disable Solver and back.
- **Back up before a geometry change.** Take a timestamped copy of the model and
  record its SHA-256 first.
- **Read the log, never the panels**, for any claim about what happened.

---

## D. Deleting obsolete elements — destructive

A **managed Floor** is one this product published and still tracks. When the
source no longer contains a floor that a managed element was published from,
that element becomes **obsolete**.

Obsolete elements are handled in one of two modes. Only one of them destroys
anything.

| Obsolete Element Action | Effect |
|---|---|
| **Mark Only** — the default | Marks the element obsolete. Deletes nothing. |
| **Delete** | **Permanently deletes.** See below. |

`Archive` was retired in 1.1.0. It never had behaviour of its own — it did
exactly what Mark Only does — so a third choice that appeared to mean
something different was a hazard rather than a feature. Choosing it is now
refused by name rather than quietly treated as Mark Only. Older log entries
that record it stay readable.

### What Delete actually removes

For each obsolete managed Floor:

* the **Floor is permanently deleted**, and
* its **paired managed Area, if one exists, is also deleted automatically**.

The Area deletion is not optional and is not a separate confirmation. An Area
that outlived its Floor would be an orphan, so the two go together.

**One obsolete row can therefore destroy two Revit elements.** N obsolete
Floors delete between **N and 2N** elements — N if none of them has a paired
Area, 2N if all of them do.

### Why the confirmation shows a range

The confirmation dialog names every Floor it will delete, with its ElementId
and stable key. It does **not** name the Areas.

It cannot: the paired Area is identified by the publisher during publishing,
and no Area identity exists at the moment you confirm. Rather than print a
number it cannot stand behind, the dialog states the truthful range and says
where the exact answer comes from. The elements actually deleted are recorded
in the publish result and the log.

### The four safeguards

Deletion is refused unless all four hold:

1. **Obsolete Element Action** is explicitly set to **Delete**. Mark Only is
   the default everywhere; a destructive mode is never reached by leaving
   something alone.
2. The **delete confirmation control** is enabled.
3. The typed confirmation is **exactly `DELETE`** — uppercase, no spaces.
   `delete`, `Delete` and `DELETE ` are all refused.
4. The publisher **re-checks the authorisation** immediately before executing,
   inside the transaction. It does not rely on the earlier checks having held.

If any one is missing the plan is blocked, no transaction opens, and nothing
is deleted.

### Recovery

**Deletion is not undone by anything this tool does.** Only Revit's own undo
can recover it, and only within the same session. If the publish fails partway
through, the whole operation rolls back as one transaction group and nothing
is assimilated — but a *successful* delete is final.

Take a timestamped copy of the model, and record its SHA-256, before running a
delete against anything you care about.

### Validation status of this feature

```
LIVE DESTRUCTIVE REVIT ACCEPTANCE = DEFERRED
```

The decision path — which elements are selected, what is refused, what is
disclosed, what is counted — is validated internally and in depth. **The
destructive execution itself has not been independently validated against a
real Revit model.** Delete is available and guarded; it is not proven by live
acceptance. Treat a first use as a first use: disposable copy, backup, and
check the log afterwards.

---

## E. Projects with more than one building

```
MULTI-BUILDING PROJECT REVIEW              SUPPORTED
MULTI-BUILDING SIMULTANEOUS LIVE ANALYSIS  NOT SUPPORTED
MULTI-BUILDING PUBLISH / PUBLISH ALL       NOT SUPPORTED
```

### One RVT per building

Each building lives in its own Revit model:

```
B001 -> Building_A.rvt
B002 -> Building_B.rvt
B003 -> Building_C.rvt
```

Each building remembers its own Expected RVT path. Setting B002's model does
not disturb B001's, and selecting a building again shows the model it is
bound to.

### The workflow is accumulated review, not simultaneous analysis

There is no button that analyses every building at once, because there is no
way to analyse a model nobody has opened. You visit each building's model in
turn, and the Project Review table on the **Planning Summary** tab keeps what
each visit found.

```
open Building_A.rvt
  -> select B001
  -> Use Active RVT as Expected Path
  -> Refresh
  -> Analyse
  -> Generate Change Plan

later:

open Building_B.rvt
  -> select B002
  -> repeat
```

After the second visit the table holds both. Nothing you did to B002 discarded
B001's result.

### Plan result and freshness are two different things

The table shows them in two separate columns, and you must read both.

**PLAN RESULT** is the verdict the Change Plan reached — VALID or BLOCKED —
*at the moment it was generated*.

**FRESHNESS** is how much of that is still known to be true *now*.

```
Building  Expected RVT      Freshness                Plan    Last Analysed
B001      Building_A.rvt    CACHED - RVT NOT OPEN    VALID   10:31:07
B002      Building_B.rvt    CURRENT                  VALID   10:44:52
B003      (not set)         NOT ANALYSED             -       -
```

| Freshness | What it means |
|---|---|
| **CURRENT** | The model is open, it is the one this building is bound to, the source .3dm is unchanged, and the snapshot has not been re-read since. This is the only state that describes the model as it is now. |
| **CACHED — RVT NOT OPEN** | A result from an earlier visit. Its model is not open, so the current state of that model is **unknown**. |
| **STALE — SNAPSHOT REREAD** | The model may still be the same, but you pressed Refresh after this result was generated, so it may have changed since. |
| **STALE — SOURCE CHANGED** | The source .3dm changed after this result was generated. The result describes different geometry. |
| **WRONG MODEL FOR THIS BUILDING** | An Expected RVT is assigned, and the model situation contradicts it — a different document is active, or the binding was re-pointed away from the model the result came from. |
| **RVT NOT ASSIGNED** | No Expected RVT has been assigned to this building. Nothing is wrong; you have not yet said which model it is. Assign the active RVT as the expected model. |
| **NOT ANALYSED** | No result for this building in this session. |

### The rule that matters most

> **A cached VALID plan does NOT mean the unopened RVT is currently valid.**

B001's plan really was VALID when it was generated, and the table still says
so. It is saying what *was* true, not what *is*. While that model is closed,
nobody — including this product — knows what state it is in.

Project Review data is **review only**. It cannot authorise a publish, and it
never becomes an approval. Selecting a row in the table selects that building
and shows its last Change Plan for inspection; it also discards any approval
and both confirmations, exactly as changing the building selection always
does.

**Before publishing a building, all of this still applies, every time:**

1. the correct RVT is the active Revit document
2. Refresh
3. Analyse
4. Generate Change Plan
5. read the plan
6. the normal approval and confirmation

Nothing about the project table shortens that list.

### One building per model

> One RVT model should contain one DZ building ownership context.

A model containing elements published under more than one `DZ_Building_ID`
will **block planning** under the current safety rules: every foreign element
raises an identity conflict, and the plan is refused. That is deliberate, and
it is not a bug to work around — do not publish two buildings into one model.

Shared-RVT multi-building planning is **not supported**.

---

## F. Quick reference — what each counter means

| Counter | Zero means |
|---|---|
| `identityMigrated` | no legacy keys remained |
| `parametersUpdated` | no DZ parameter value differed |
| `bindingsWritten` | all 26 bindings were already correct |
| `projectValuesUpdated` | Project Information already matched |
| `levelsUpdated` | no level elevation moved |
| `levelParametersUpdated` | level DZ values already matched |
| `floorsReplaced` / `floorsGeometryEditedInPlace` | no floor geometry changed |
| `boundarySetsDeleted` / `boundarySetsCreated` | no DZ loop was rebuilt |
| `areasReassociated` / `areasReplaced` | no Area was moved or recreated |
| `obsoleteMarked` / `obsoleteDeleted` | nothing was orphaned |
| `parametersNotTransferred` (empty) | no replacement occurred |
| `rollbackOccurred` (false) | the group assimilated |

A same-source re-publish should report **every one of these at zero** with
`skipped` equal to the tracked floor count. That is the definition of strict
idempotency.
