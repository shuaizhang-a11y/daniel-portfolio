# DZ Planning Tools - installation and launch

For an operator installing on a clean machine, and for anyone who needs to know
where the product puts things.

---

## What you need first

| Requirement | Why |
|---|---|
| **Revit 2025** | The product publishes into a Revit model. |
| **Rhino 8** | Supplies the Python interpreter the product runs on. |
| **Rhino.Inside.Revit** 1.33 or later | Hosts Rhino inside Revit. Without it the window opens read-only and cannot publish. |
| **Python 3** (any) | Runs the installer once. Rhino's own Python works. |

Nothing else is installed. There is no MSI, no service, no registry change and
no administrator rights. The payload is Python source, two shared-parameter
files, a launcher, a configuration file, and one small compiled add-in that
does nothing but put a button on the Revit ribbon.

---

## Install

From an unpacked copy of the product:

```
python install\install.py
```

That installs to `%LOCALAPPDATA%\DZPlanningTools`, verifies every copied file
against a SHA-256 manifest, creates the per-user data folders and prints the
launch command.

To install somewhere else:

```
python install\install.py --target "D:\Tools\DZ Planning Tools"
```

Paths containing spaces and non-ASCII characters are supported.

### Other installer commands

| Command | Effect |
|---|---|
| `--list` | Print the payload and exit. Installs nothing. |
| `--verify` | Re-hash an installation against its manifest. Reports missing or modified files. |
| `--uninstall` | Remove the application. **Your data is kept.** |
| `--uninstall --purge` | Remove the application *and* the per-user data folder. |
| `--no-optional` | Skip `dz_report`, the Phase 6B planning-report generator. |

Updating is re-running the installer over the same target.

---

## Where things live

Application files are immutable and separate from anything the product writes,
so the installation can sit somewhere the user cannot write to.

```
%LOCALAPPDATA%\DZPlanningTools\          application root
    src\
        dz_planning_app\                 application layer, path resolution
        dz_planning_ui\                  the Eto window
        dz_revit_publisher\              the Phase 7 publish engine
        dz_revit_integration\            the ExternalEvent boundary
        dz_report\                       optional planning-report generator
    scripts\
        dz_planning_ui_launch.py         the entry point
    config\
        DZ_Planning_SharedParameters.txt required
        dz_shared_parameters.json        required
        dz_planning_app.json             shipped defaults
    docs\
    install_manifest.json                every file, with its SHA-256

%APPDATA%\Autodesk\Revit\Addins\2025\
    DZPlanningTools.addin                registers the ribbon
    DZPlanningTools.Revit.dll            the Revit shell, flat, in the same
    DZPlanningTools.Revit.deps.json      folder as the manifest naming it

%APPDATA%\DZPlanningTools\               per-user data, written by the product
    dz_planning_app.json                 your configuration, if you make one
    Exports\                             default manifest search root
    Reports\                             default report destination
    Logs\
```

Publish logs are **not** here. They are append-only and live beside the
manifest they belong to, in that package's `revit_publish\` folder. The product
never writes into that folder except through the Phase 7 publish engine, and
report export into it is refused.

---

## Launch

### Normal daily use - the ribbon

```
Open Revit
  -> make sure Rhino.Inside is running
  -> DZ Planning > Tools > Launch Planning Tools
```

No typing. The installer registers a Revit add-in that adds a **DZ Planning**
tab, and the button starts the installed product.

**After a first install, restart Revit once.** Revit reads its add-in manifests
at startup and does not load new ones into a running session, so the tab
appears on the next launch.

The shell sits directly in the Revit add-ins folder, flat, in the same
directory as the manifest that names it - not in the application root, and not
in a subfolder. That is deliberate. Revit resolves the manifest's assembly
path at startup and refuses to load the add-in if it cannot reach it, so the
assembly goes in the one directory Revit has already proven it can read: the
one it just read the manifest from.

The Python product stays under `%LOCALAPPDATA%`, and the shell finds it
through the user's local application-data folder. Shell location and product
location are independent of each other.

**Rhino.Inside must already be running.** The button does not start it: Rhino
publishes no supported API for another add-in to do that, and this product
will not use an undocumented one. If Rhino is not running the button says so
and does nothing.

To make this genuinely one click, set Rhino.Inside to load when Revit starts,
from its own Add-In Options. Rhino is then always ready and the button works
from the first press of the day.

### The command line still works

Unchanged, and useful when the ribbon is unavailable - a manifest that has not
loaded yet, or a machine where the add-in was not installed:

```
_-RunPythonScript "%LOCALAPPDATA%\DZPlanningTools\scripts\dz_planning_ui_launch.py"
```

Use the full expanded path - the Rhino command line does not expand
`%LOCALAPPDATA%`. The installer prints the exact command to use.

On launch the product prints where it resolved everything from. Read that
block: it is the fastest way to see which configuration is in force.

```
Application root           C:\Users\you\AppData\Local\DZPlanningTools
Configuration source       installed configuration
Shared parameter file      ...\config\DZ_Planning_SharedParameters.txt
Exports root               C:\Users\you\AppData\Roaming\DZPlanningTools\Exports
```

---

## Before you use Delete

The product can permanently delete Revit elements. It is guarded, and it is
off by default, but it is worth knowing before you meet it.

When a managed Floor no longer has a source, it becomes **obsolete**. The
**Obsolete Element Action** setting decides what happens to it, and the default
— **Mark Only** — deletes nothing.

Setting it to **Delete** permanently removes each obsolete Floor **and its
paired Area**, automatically. One obsolete row can destroy two Revit elements.
Deletion requires the action set to Delete, the confirmation control enabled,
and the word `DELETE` typed exactly; the publisher re-checks before executing.
Nothing this tool does will undo it.

```
LIVE DESTRUCTIVE REVIT ACCEPTANCE = DEFERRED
```

Delete is guarded and internally validated, but its destructive execution has
**not** been independently validated against a real Revit model.

**Full operating detail is in `PHASE07_OPERATOR_RUNBOOK.md`, section D.** Read
it before deleting anything.

---

## Configuration

**A normal installation needs no configuration.** Every path is derived from
where the application is.

To change something, create `%APPDATA%\DZPlanningTools\dz_planning_app.json`:

```json
{
  "exports_root": "D:\\Projects\\DZ\\Exports",
  "reports_root": "D:\\Projects\\DZ\\Reports"
}
```

| Key | Meaning |
|---|---|
| `shared_parameter_file` | Revit shared-parameter definitions. Required. |
| `shared_parameter_registry` | GUID registry for those parameters. Required. |
| `exports_root` | Where Detect Inputs looks for manifests. |
| `reports_root` | Default folder for exported reports. |
| `logs_root` | Diagnostic logs. |
| `default_source_3dm` | A source model to offer by default. |

Paths may be absolute, or relative to the configuration file's own folder. Any
key you omit or leave empty falls back to the application default.

### Where configuration is read from

Highest priority first:

1. a path passed directly to `settings.load()`
2. the `DZ_PLANNING_CONFIG` environment variable
3. `%APPDATA%\DZPlanningTools\dz_planning_app.json`
4. `<application root>\config\dz_planning_app.json`
5. defaults derived from the application root

The first file that exists and parses wins outright; settings are not merged
across sources, so one file always describes the whole configuration.

**A file you name that does not exist is an error, not a fallback.** If you set
`DZ_PLANNING_CONFIG` and misspell it, the product says so rather than quietly
using something else.

`DZ_PLANNING_HOME` overrides the detected application root. It exists for
running from a source checkout; a normal installation should not set it.

---

## When something is wrong

The product never guesses a path. A file it cannot find is reported, with where
it looked.

| Message | Meaning |
|---|---|
| `shared_parameter_file does not exist: ...` | The installation is incomplete or a config points at the wrong place. Run `--verify`. |
| `Configuration file not found (DZ_PLANNING_CONFIG ...)` | The environment variable names a file that is not there. |
| `Configuration file could not be read` | Invalid JSON. The product falls back to defaults and tells you. |
| `Unknown config keys` | A key was misspelled and had no effect. |
| `CONFIGURATION PROBLEM` at launch | The window opens, but publishing is unavailable until the listed files exist. Nothing has been read or written. |
| `Rhino.Inside.Revit is not available` | The window opens read-only with no live snapshot. |
| `Rhino.Inside.Revit required` from the ribbon button | Rhino is not running in this Revit session. Start it, or set it to load at startup. |
| `DZ Planning Tools not found` from the ribbon button | The manifest points at an assembly that is not there. Reinstall and restart Revit. |
| `Add-in Assembly Not Found` at Revit startup | Revit read the manifest but could not reach the DLL it names. Run the shell repair below, then restart Revit. |
| No **DZ Planning** tab after installing | Revit reads manifests at startup only. Restart Revit. |
| `Publish channel: ...` not `ExternalEvent created and retained.` | Publishing will refuse. The reason is on that line. |

### Repairing the ribbon registration

If Revit reports **Add-in Assembly Not Found** at startup, the manifest and
the assembly have ended up in different places. From the Rhino command line,
inside Revit:

```
_-RunPythonScript "<repo>\install\host_shell_repair_final.py"
```

That prints the complete state before touching anything - every DZ manifest
in every location Revit reads, with the exact repr() of each Assembly value so
hidden whitespace, quotes or newlines are visible - then removes stale
duplicates, installs the shell flat beside the manifest, and verifies by
reopening the file from disk. It writes a fresh manifest rather than patching
the old one, so nothing is inherited from whatever wrote it before.

It touches no other vendor's add-in, opens no document and writes nothing to
any model. Restart Revit afterwards: manifests are read once, at startup.

To check an installation has not been altered:

```
python install\install.py --verify --target "<application root>"
```

That re-hashes every file against the manifest and names anything missing or
modified.

---

## What the installer deliberately does not do

* **It does not start Rhino.Inside.** No supported API exists for one add-in to
  start another, and the product will not use an undocumented one. Rhino
  running is a prerequisite.
* **No machine-wide install.** Per-user only, so no administrator rights.
* **No Python or Rhino installation.** Both are prerequisites.
* **No data migration on uninstall.** Your exports, reports and configuration
  survive an uninstall unless you pass `--purge`.
