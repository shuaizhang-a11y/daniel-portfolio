@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM  DZ Planning Tools - uninstaller entry point.
REM
REM  Removes the application and the Revit ribbon button. Your logs, reports
REM  and exports are KEPT. Pass --purge to remove those as well.
REM
REM  The interpreter probe is the same one Install.cmd uses, for the same
REM  reason: no Python is guaranteed present on a machine that has only the
REM  documented prerequisites.

set "HERE=%~dp0"

REM  Works whether this sits beside install.py or one level above it, so the
REM  download can put it at the top where a user will find it.
set "INSTALLER=%HERE%install.py"
if not exist "%INSTALLER%" set "INSTALLER=%HERE%install\install.py"

if not exist "%INSTALLER%" (
    echo.
    echo   This package is incomplete: install.py is missing.
    echo.
    exit /b 1
)

set "PYTHON="

py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=py -3"
    goto :found
)

python -c "import sys; raise SystemExit(0 if sys.version_info[0]==3 else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=python"
    goto :found
)

for /d %%D in ("%USERPROFILE%\.rhinocode\py*-rh8") do (
    if exist "%%D\python.exe" (
        set "PYTHON="%%D\python.exe""
        goto :found
    )
)

if exist "%ProgramFiles%\Rhino 8\System\python.exe" (
    set "PYTHON="%ProgramFiles%\Rhino 8\System\python.exe""
    goto :found
)

echo.
echo   No Python 3 was found, so the uninstaller cannot run.
echo   Start Rhino 8 once, or install Python 3, and try again.
echo.
exit /b 2

:found
echo Using: %PYTHON%
echo.
%PYTHON% "%INSTALLER%" --uninstall %*
exit /b %ERRORLEVEL%
