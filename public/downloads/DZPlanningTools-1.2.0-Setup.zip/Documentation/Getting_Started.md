# Getting started

Fifteen minutes, using the sample project that ships alongside the product. By
the end you will have published six floors into a Revit model and watched the
product decline to do it twice.

Check [System requirements](System_Requirements.md) first.

---

## 1. Install

Unpack the download, and from that folder run:

```
Install.cmd
```

It checks that Revit 2025, Rhino 8 and Rhino.Inside.Revit are present, installs
the application to `%LOCALAPPDATA%\DZPlanningTools`, re-reads every file it
wrote and compares it against a checksum, and registers the Revit ribbon button.

It ends with one line, and only one of these three:

```
INSTALLATION COMPLETE
PAYLOAD INSTALLED - ADD-IN REGISTRATION FAILED
INSTALLATION FAILED
```

Anything other than the first means the product will not appear in Revit. The
usual cause of the second is Revit being open while installing — close it and
run the installer again.

## 2. Unpack the sample

Extract the sample archive anywhere you like — your desktop is fine. It stores
no paths, so it works wherever you put it. You should have:

```
DZ_PlanningTools_Sample\
    Planning_Source.3dm            the Rhino source geometry
    project_manifest.json          what was exported from it
    Sample_Tower.rvt               a clean Revit model to publish into
    SAMPLE_EXPECTED_RESULT.json    what this walkthrough should produce
    README.md
```

Keep `Planning_Source.3dm` and `project_manifest.json` in the same folder. The
product finds the source as *the only `.3dm` beside the manifest*.

## 3. Open the model and start Rhino.Inside

1. Open `Sample_Tower.rvt` in Revit 2025.
2. On the Revit ribbon, start **Rhino.Inside.Revit**. Wait for it to finish
   loading.
3. Click **DZ Planning → Tools → Launch Planning Tools**.

The window opens on the **Project Setup** page.

## 4. Load the sample

Click **Browse Manifest** and choose `project_manifest.json` from the sample
folder.

The window fills in. Under **PROJECT SOURCE** you should see the manifest and
the source model, with the source read as `CURRENT`. The **BUILDINGS** table
shows one row:

```
B001    Sample Tower    Residential    6 floors
```

If the source reads anything other than `CURRENT`, the **NEXT ACTION** panel
says what to do about it. It is worth reading before clicking anything else —
it is specific, and it changes as the state changes.

## 5. Analyse

Select the **B001** row, then click **Analyse**.

This reads the Revit model and compares it with the manifest. It writes
nothing.

## 6. Read the Change Plan

Click **Generate Change Plan**. You should see exactly this:

```
CREATE     6
UPDATE     0
SKIP       0
OBSOLETE   0

Plan valid    YES
Blockers      0
Conflicts     0
```

Six floors to create, nothing to change, nothing to remove. **This is the whole
point of the first run: publishing into a model that knows nothing about the
product is purely additive.** Nothing is deleted, and nothing needs to be.

Six is small enough to check by eye. Do check it — the plan is the thing you
are approving, and reading it is the habit worth forming.

## 7. Publish

1. Tick **Confirm Publish**.
2. Click **Publish**, once.

The product opens one Revit transaction group, works through its stages, and
either completes them all or rolls the whole thing back. There is no partial
result.

When it finishes, look in the Revit Project Browser. You will find levels for
the sample's six storeys, each carrying a floor.

**Save the Revit model.**

## 8. The part worth seeing

Click **Analyse** again, then **Generate Change Plan**. Change nothing else.

```
CREATE     0
UPDATE     0
SKIP       6
OBSOLETE   0
```

Six SKIP. The same source published twice does nothing the second time. The
product recognises the floors it created, by an identity stored on the elements
themselves rather than by Revit ElementIds — which is why it survives Revit
reassigning those ids.

That is the behaviour the whole design protects, and it is why a re-publish is
safe.

---

## Two things about levels that are normal

The sample's first storey sits at 0.000 m, and so does the level a new Revit
project starts with. The product **reuses** that level rather than making a
second one at the same height, and it keeps the level's existing name. The plan
tells you it did.

If the Revit template supplied a second level higher up, it is left alone. It
sits at an elevation the sample does not use, so the product neither moves nor
touches it.

Neither affects the six floors.

## When something looks wrong

Read the **NEXT ACTION** panel. It is generated from the current state and says
one specific thing to do — assign a Revit model, re-analyse after the source
changed, resolve a blocker, and so on.

For anything it does not cover, see the [Operator guide](Operator_Guide.md).

## Next

Point the product at your own export. The workflow is identical: browse to the
manifest, select a building, analyse, read the plan, publish.
