# Operator guide

Day-to-day use, and what the product does when things are not simple.

If you have not run the sample through once, start with
[Getting started](Getting_Started.md).

---

## The shape of the thing

You have a Rhino model with planning geometry, and an export from it: a
`project_manifest.json` describing buildings and floors, beside the `.3dm` the
geometry came from. You have a Revit model. The product's job is to make the
Revit model agree with the export, and to tell you exactly what it intends to
do before it does any of it.

**One building at a time, into one Revit model.** A project with three
buildings is three separate publishes into three separate Revit models. This is
deliberate — see [Known limitations](Known_Limitations.md).

## The window

**Project Setup** is where you load a project and choose a building.

| Control | What it does |
|---|---|
| **Browse Manifest** | Choose the `project_manifest.json` to publish from. |
| **Browse Source 3DM** | Choose the source model explicitly, when the automatic choice is wrong or ambiguous. |
| **Detect Inputs** | Look again for the manifest and source. |
| **Analyse** | Compare the export with the open Revit model. Writes nothing. |
| **Generate Change Plan** | Turn that comparison into the list of actions you approve. |
| **Export Preview Report** | Write the current plan out as a file. |
| **Open Log Folder** | Open `%APPDATA%\DZPlanningTools\Logs`. |
| **Refresh History** | Re-read the publish log. |

**STATUS** is what is true now. **NEXT ACTION** is one specific thing to do
about it. Next Action never performs anything and is never consulted when
deciding whether publishing is allowed — it advises, and the permission is
decided separately. A recommendation can never become a permission.

## Source status

| Reads | Means |
|---|---|
| `CURRENT` | The source file is present and unchanged since it was read. |
| `CHANGED` | It has been modified. Analyse again before trusting a plan. |
| `MISSING` | It is not where it was. |
| `UNREADABLE` | It was opened and could not be read. |
| `UNCONFIRMED` | It could not be checked. **Not the same as a problem.** |
| `NOT SELECTED` | No source has been chosen yet. |

`UNCONFIRMED` deserves a note. When the product cannot establish something, it
says so instead of guessing. Rhino not being available, or a hash not having
been computed yet, reads `UNCONFIRMED` — not "bad". Only positive evidence of a
problem is reported as one.

## Freshness

Each building carries a freshness state, which is the product's answer to *can
I trust the last analysis?*

| State | Means | What to do |
|---|---|---|
| `NOT ANALYSED` | No analysis has been run for this building. | Analyse. |
| `STALE - SOURCE CHANGED` | The source changed since the analysis. | Analyse again. |
| `RVT NOT ASSIGNED` | No Revit model is associated with this building. | Assign one. |
| `WRONG MODEL FOR THIS BUILDING` | The open Revit model is not this building's. | Open the right model. |
| `CACHED - RVT NOT OPEN` | The analysis is valid but its model is not open. | Open that model. |
| `STALE - SNAPSHOT REREAD` | The model snapshot was re-read since the analysis. | Analyse again. |
| `CURRENT` | Analysis, source and model all agree. | Publish. |

`CURRENT` requires positive confirmation of all three. Anything the product
cannot confirm is one of the other six.

## Reading a Change Plan

Every floor gets one action.

| Action | Means |
|---|---|
| `CREATE` | No such floor exists yet. One will be made. |
| `UPDATE` | The floor exists and something about it differs. |
| `SKIP` | The floor exists and matches. Nothing happens. |
| `OBSOLETE` | A published floor no longer appears in the export. |

Below the list: **Plan valid**, **Blockers**, **Conflicts**. A plan with
blockers cannot be published, and each blocker says what it is.

**Read the plan.** It is the thing you are approving, and it is written to be
read. A plan that surprises you is telling you something.

### Geometry changes replace elements

When a floor's footprint changes, the product replaces the Revit element rather
than editing its boundary in place. **The Revit ElementId changes.** Parameters
and project data are carried across, and anything that could not be transferred
is reported by name rather than dropped silently.

If you have external references keyed to Revit ElementIds, this matters. The
product's own identity does not depend on them.

## Obsolete floors

A floor that was published and no longer appears in the export is `OBSOLETE`.
What happens next is yours to decide.

**Mark Only** is the default, and it changes no geometry. The floor is marked
as obsolete and stays in the model. This is the right answer almost always: it
is reversible, and it makes the situation visible without acting on it.

**Delete** removes the floor. It is never the default, it requires a separate
explicit confirmation, and the dialog tells you what will be removed —
including that deleting a floor also deletes the Area paired with it, so the
number of removed elements is larger than the number of floors.

If you are unsure, Mark Only. You can always delete later; you cannot undelete.

## Publishing

1. The plan must be valid, with no blockers.
2. Tick **Confirm Publish**.
3. Click **Publish**, once.

The publish runs as a single Revit transaction group. Either every stage
succeeds and the whole group is committed, or the group is rolled back and the
model is exactly as it was. There is no half-published state.

**Approval is checked against the world, not remembered.** At the moment you
click Publish, the product re-reads the manifest and the source from disk and
re-hashes both. If either changed since you approved the plan, the publish is
refused. An approval is not a token that stays valid — it is a claim about
files, re-checked when it matters.

Selecting a different building, or browsing to a different source, discards an
approval for the same reason.

**Save the Revit model afterwards.** The product writes into your open
document; making that permanent is Revit's business and yours.

## The log

Every publish appends to `%APPDATA%\DZPlanningTools\Logs`. The log is the
record — more so than anything on screen after the fact.

Each entry carries what was published, which building and model, the counts,
the per-stage results, and whether a rollback occurred. **Open Log Folder**
takes you there.

## Working with several buildings

Each building publishes into its own Revit model.

1. Assign each building its Revit model.
2. Open one of those models.
3. Select that building, analyse, read the plan, publish.
4. Save, close, open the next model, repeat.

The product tracks each building's freshness independently, so the table shows
you which are done and which are not. Approval never carries from one building
to another: selecting a different building discards it.

## When a publish fails

The transaction group is rolled back and the model is unchanged. The log entry
records which stage failed and why.

Fix the cause, analyse again, read the new plan. Do not re-approve the old one
— it no longer describes the situation.

## Getting a report

**Export Preview Report** writes the current plan to a file you can keep or
send. It is a copy of what is on screen, not a new computation.
