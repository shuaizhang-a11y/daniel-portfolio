# Known limitations

What this release does not do, and why. Every item here is a deliberate
boundary or a stated gap — not a defect list, and not a roadmap.

---

## One building at a time, one Revit model each

A project with several buildings publishes one building into one Revit model at
a time. There is no "publish all" and no queue.

This is a design decision, not an omission. Publishing several buildings into
one model was investigated and rejected: it makes obsolete-detection ambiguous,
because a floor missing from the export cannot be distinguished from a floor
belonging to a building you did not publish. One model per building keeps that
question answerable.

## Revit 2025 only

Not tested against 2024 or 2026, and no support for them is claimed. The
product checks for Revit 2025 specifically.

## Rhino.Inside version

Validated against **1.33.9347.9430**. That is what was tested, not a minimum.
The product touches only two Rhino.Inside entry points, both long stable, so
other versions are likely to work — but likely is not tested, and no floor is
claimed that has not been measured.

## Geometry changes replace elements

When a floor's footprint changes, the Revit element is replaced rather than
edited in place, and **its ElementId changes**. Parameters and project data are
carried across, and anything that could not be transferred is reported by name.

Editing the boundary in place would preserve ElementIds and is a real
improvement, but it is a new write path into Revit and would need its own
validation campaign before it could be trusted with your models.

If you have external systems keyed to Revit ElementIds, this is the item to
know about. The product's own identity does not depend on them — that is why a
re-publish is safe.

## Deleting obsolete floors is not the default

Obsolete floors are marked, not deleted, unless you explicitly ask. Deletion
requires a separate confirmation and tells you that paired Areas go with the
floors.

The confirmation names the number of elements involved but not the individual
Area ids. Showing those would mean changing code this release line deliberately
holds still, so it waits for a release that can carry that change safely.

**Deletion has been validated offline and in controlled runs, but destructive
deletion against a real project model has not been through an independent
acceptance campaign.** Mark Only is the default for that reason among others.

## No progress detail during a publish

A publish runs as one transaction group and reports when it is done. There is
no live stage-by-stage progress, because providing it would mean changing the
code that performs the publish - the part of the product this release line
deliberately holds still, because every change to it costs a full validation
campaign against real models.

Publishes are quick. If one appears to hang, the log records where it stopped.

## Archiving is not implemented

There is no archive function. The word was removed from the interface rather
than left on a button that did not do anything well-defined. If archiving is
wanted it needs a product definition first — what it means, what it does to
identity, and what it does on a later publish.

## The sample is not a reporting example

The sample project exercises publishing: analyse, plan, publish, re-publish. It
does not carry the compliance, setback, open-space, parking or solar data the
PDF report needs, because inventing planning analysis results for a fictional
site would be worse than not shipping them.

The sample is a publishing example. It is not a report example.

## Fresh-machine installation is not yet independently validated

This release was developed and validated on its development machine.
Installation on a clean machine, by someone who has not seen the product
before, following only the published documentation, **has not yet been carried
out**.

This is the most honest thing in this document. Everything else here is a
boundary that was chosen; this is a gap that has not been closed. It is stated
rather than assumed away, and it is scheduled.

## What the product will not do to your model

For completeness, since limitations cut both ways:

- it never writes outside a Revit transaction group, so a failure leaves the
  model exactly as it was
- it never deletes anything without a separate explicit confirmation
- it never touches elements it did not create — foreign content on a level it
  would otherwise move stops the publish rather than being relocated
- it never publishes against an approval whose files have changed since you
  approved them
