# System requirements

DZ Planning Tools publishes planning geometry from Rhino into a Revit model. It
runs inside Revit, through Rhino.Inside.Revit.

## What you need

| Software | Version | Why |
|---|---|---|
| **Revit 2025** | exactly this version | The product publishes Levels and Floors into a Revit model. |
| **Rhino 8** | exactly this version | Supplies the Python interpreter the product runs on. |
| **Rhino.Inside.Revit** | **1.33.9347.9430** — the version this release was validated against | Hosts Rhino inside Revit. Without it the window opens read-only and cannot publish. |
| **Python 3** | any | Runs the installer, once. Rhino's own Python works. |

All four must be installed before you install DZ Planning Tools. The installer
checks for the first three and tells you which is missing.

### About the Rhino.Inside version

**1.33.9347.9430 is what this release was tested with, not a minimum.** The
product uses only two Rhino.Inside entry points, both stable across many
versions, so newer builds are very likely to work — but "likely" is not
"tested", and no floor is claimed that has not been measured.

### Revit versions

**Revit 2025 only.** Nothing here has been tested against 2024 or 2026, and the
product does not claim to support them.

## Operating system

Windows, 64-bit — whatever Revit 2025 itself requires. The product is a
Windows application because Revit is.

## What gets installed

| Location | Contents |
|---|---|
| `%LOCALAPPDATA%\DZPlanningTools` | The application. |
| `%APPDATA%\Autodesk\Revit\Addins\2025` | One small add-in that puts a button on the Revit ribbon. |
| `%APPDATA%\DZPlanningTools\Logs` | Publish logs. |
| `%APPDATA%\DZPlanningTools\Reports` | Reports you export. |
| `%APPDATA%\DZPlanningTools\Exports` | Working exports. |

**No administrator rights, no MSI, no Windows service, no registry change.** The
payload is Python source, two shared-parameter files, a launcher, a
configuration file, and one small compiled add-in whose only job is the ribbon
button.

Uninstalling removes the application and the ribbon button. **Your logs,
reports and exports are kept** unless you explicitly ask for them to be removed.

## Disk and memory

The application is a few megabytes. Practical limits come from Revit and Rhino,
not from this product: if the two of them run comfortably together on your
machine, so will this.

## Not yet independently validated

This release has been developed and validated on its development machine.
**Installation on a clean machine by someone other than its author has not yet
been carried out.** That is stated plainly rather than assumed away, and it is
the next thing scheduled.
