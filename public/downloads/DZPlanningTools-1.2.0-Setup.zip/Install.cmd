@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM  DZ Planning Tools - installer entry point.
REM
REM  Finds a Python 3 and runs install.py. It probes rather than assuming,
REM  because no interpreter is guaranteed on a machine that has only the
REM  documented prerequisites: Rhino 8 does not ship a python.exe under
REM  Program Files, and materialises its CPython per-user under .rhinocode
REM  instead. If nothing is found it says so and what to do, rather than
REM  failing with a message about a missing file.
REM
REM  Arguments are passed straight through, so --verify, --list, --target and
REM  --allow-downgrade all work from here.

set "HERE=%~dp0"

REM  Works whether this sits beside install.py or one level above it, so the
REM  download can put it at the top where a user will find it.
set "INSTALLER=%HERE%install.py"
if not exist "%INSTALLER%" set "INSTALLER=%HERE%install\install.py"

if not exist "%INSTALLER%" (
    echo.
    echo   This package is incomplete: install.py is missing.
    echo   Expected it at:
    echo       %INSTALLER%
    echo.
    exit /b 1
)

set "PYTHON="

REM  1. The Python launcher. Guarantees a 3.x when it answers.
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=py -3"
    goto :found
)

REM  2. Whatever `python` is on PATH, but only if it is a 3.
python -c "import sys; raise SystemExit(0 if sys.version_info[0]==3 else 1)" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON=python"
    goto :found
)

REM  3. Rhino 8's own CPython. Per-user, created when Rhino first needs it,
REM     so it exists on a machine where Rhino has been run at least once.
for /d %%D in ("%USERPROFILE%\.rhinocode\py*-rh8") do (
    if exist "%%D\python.exe" (
        set "PYTHON="%%D\python.exe""
        goto :found
    )
)

REM  4. Last resort, in case a future Rhino does ship one.
if exist "%ProgramFiles%\Rhino 8\System\python.exe" (
    set "PYTHON="%ProgramFiles%\Rhino 8\System\python.exe""
    goto :found
)

echo.
echo   No Python 3 was found, so the installer cannot run.
echo.
echo   The product itself does not need a separate Python - it runs on the
echo   one inside Rhino. This is only needed to install it, once.
echo.
echo   Either:
echo.
echo     * Start Rhino 8 once and close it again. Rhino creates its own
echo       Python the first time it runs, and this installer will find it.
echo.
echo     * Or install Python 3 from python.org and run Install.cmd again.
echo.
exit /b 2

:found
echo Using: %PYTHON%
echo.
%PYTHON% "%INSTALLER%" %*
set "RESULT=%ERRORLEVEL%"

echo.
if not "%RESULT%"=="0" (
    echo   Installation did not complete. The lines above say why.
)
exit /b %RESULT%
