"""Creating the ExternalEvent and holding it alive.

This is the only module that constructs Revit objects. Everything it builds is
retained on the returned :class:`Wiring`, because an ``ExternalEvent`` or
handler that is collected leaves a Publish button that raises nothing and
reports nothing - the same failure mode as an unretained event delegate, and
harder to notice.
"""

from dz_planning_app.dispatch import PublishDispatcher

from .publish_handler import PublishRunner, make_handler, revit_ui


class Wiring(object):
    """The live objects, kept alive for the lifetime of the window."""

    def __init__(self, dispatcher, runner, handler=None, event=None):
        self.dispatcher = dispatcher
        self.runner = runner
        self.handler = handler
        self.event = event
        #: Why there is no event, when there is none. The first live publish
        #: failed because this was discarded: `wire` swallowed the import
        #: error, `available` went quietly False, and the operator learned
        #: nothing until Publish raised a bare RuntimeError.
        self.error = None

    @property
    def available(self):
        """True when a real ExternalEvent exists to raise."""
        return self.event is not None

    def describe(self):
        """One line on the state of the publish channel."""
        if self.available:
            return "ExternalEvent created and retained."
        return self.error or "No Revit ExternalEvent was created."

    def raise_event(self):
        if self.event is None:
            raise RuntimeError(
                "No Revit ExternalEvent is available, so Publish cannot be "
                "dispatched. %s" % self.describe())
        return self.event.Raise()


def wire(bridge, config, on_result=None, post=None):
    """Build dispatcher, runner, handler and ExternalEvent, in that order.

    The dispatcher is constructed first with a placeholder raiser and rebound
    once the event exists, because the two genuinely refer to each other: the
    dispatcher raises the event, and the event's handler drives the dispatcher.
    """
    holder = {}

    def raise_event():
        wiring = holder.get("wiring")
        if wiring is None:
            raise RuntimeError("Publish wiring is incomplete.")
        return wiring.raise_event()

    def run_publish(approved):
        return holder["wiring"].runner.run(approved)

    dispatcher = PublishDispatcher(raise_event, run_publish)
    runner = PublishRunner(bridge, config, dispatcher)
    wiring = Wiring(dispatcher, runner)
    holder["wiring"] = wiring

    try:
        UI = revit_ui()
    except Exception as exc:
        #: No Revit: the dispatcher and runner still exist and are testable.
        #: The reason is *kept*, so the launcher can print it and Publish can
        #: quote it, rather than the channel going quietly unavailable.
        wiring.error = ("Autodesk.Revit.UI could not be loaded (%s: %s). "
                        "Publishing requires Rhino.Inside.Revit."
                        % (type(exc).__name__, exc))
        return wiring

    try:
        wiring.handler = make_handler(runner, on_result, post)
        wiring.event = UI.ExternalEvent.Create(wiring.handler)
    except Exception as exc:
        wiring.handler = None
        wiring.event = None
        wiring.error = ("ExternalEvent.Create failed (%s: %s)."
                        % (type(exc).__name__, exc))
    return wiring
