"""The only place in the product that calls ``controller.publish()``.

Nothing in ``dz_planning_ui`` or ``dz_planning_app`` may import it; a test
asserts that, and asserts that the call appears here and nowhere else.

Two layers, split so the decision path stays testable:

:class:`PublishRunner`
    Pure orchestration - gate, re-derive, compare, publish. Imports the
    controller, which is Revit-free, and no Revit API at all.

:func:`make_handler`
    Builds the ``IExternalEventHandler`` subclass, importing
    ``Autodesk.Revit.UI`` lazily inside the function so this module remains
    importable on a machine without Revit.
"""

from dz_planning_app import controller, to_json_safe
#: Pure Python - the approved-plan model and the diagnostic trace. No Eto.
from dz_planning_ui import publish as pub

from . import safety_gate

BLOCKED = "BLOCKED"
FAILED = "FAILED"

NO_EXECUTABLE = (
    "The approved record carries no executable plan. Nothing was written. "
    "Generate a Change Plan again and confirm it.")

DIGEST_MISMATCH = (
    "The frozen plan no longer matches the approved digest. Nothing was "
    "written. Run Analyse and Generate Change Plan again, review the new "
    "plan, and confirm it deliberately.")


class PublishRunner(object):
    """Gate, re-derive, compare, publish. In that order, always.

    Nothing is re-planned here. The confirmation froze two things: a canonical
    projection sealed with a digest, and the executable ``ChangePlan`` itself.
    This runner checks the first and executes the second. It never calls
    ``plan()`` or ``analyse()``, because a plan produced at execution time is
    a plan the operator never reviewed.
    """

    def __init__(self, bridge, config, dispatcher):
        self.bridge = bridge
        self.config = config or {}
        self.dispatcher = dispatcher
        self.last_result = None

    # -- the write path ----------------------------------------------------

    def run(self, approved):
        """Execute one approved publish. Returns a result payload.

        The plan is **not** re-derived here. `plan()` and `analyse()` are
        never called: the frozen executable ChangePlan sealed at confirmation
        is handed straight to `controller.publish`. Context drift is handled
        by blocking, never by replanning - a plan generated at execution time
        is a plan nobody reviewed.
        """
        if approved is None:
            return self._blocked("No approved plan to publish.")

        trace = getattr(approved, "trace", None)
        if trace is not None:
            trace.step(pub.SAFETY_GATE, "entered")
        context = safety_gate.context_from(self.bridge)
        gate = safety_gate.check(
            approved, context,
            dispatcher_state=getattr(self.dispatcher, "state", None),
            pending_token=self._pending_token(),
            second_request=self._second_request())
        if trace is not None:
            trace.step(pub.SAFETY_GATE,
                       "passed" if gate.ok else "refused",
                       None if gate.ok else "; ".join(gate.failed))
        if not gate.ok:
            #: No transaction, no executor, no controller.publish.
            return self._blocked(gate.reason, gate=gate)

        if not approved.has_executable:
            return self._blocked(NO_EXECUTABLE, gate=gate)

        #: The sealed projection and the frozen executable plan must still
        #: describe each other. Checked against stored data only.
        if not approved.verify_executable():
            return self._blocked(DIGEST_MISMATCH, gate=gate)

        #: Second, independent check - the first was before the raise. The
        #: request crossed a dispatcher and a Revit event boundary since then,
        #: and a validation session that arrives here unarmed would perform a
        #: real six-floor write while everyone believed it was about to roll
        #: back. Refuse; never downgrade to a normal publish.
        validation = getattr(approved, "validation", None)
        if validation is not None and validation.active:
            request = approved.as_request()
            armed = validation.request_is_armed(request)
            if trace is not None:
                trace.step(pub.HANDLER, "Rollback validation: ACTIVE")
                trace.step(pub.HANDLER, "ForceFailAtStage received",
                           request.get(pub.FORCE_FAIL_KEY, "(absent)"))
            if not armed:
                return self._blocked(pub.NOT_ARMED_DETAIL, gate=gate)

        planned = approved.executable
        if planned.get("Status") == controller.BLOCKED:
            return self._blocked(
                "The approved plan is blocked: %s"
                % "; ".join(planned.get("Errors") or ["(no reason given)"]),
                gate=gate)

        if trace is not None:
            trace.step(pub.CONTROLLER, "entered",
                       "controller.publish(planned=frozen ChangePlan)")
        try:
            result = controller.publish(approved.as_request(), self.bridge,
                                        self.config, planned=planned)
        except Exception as exc:
            if trace is not None:
                trace.fail(pub.CONTROLLER, exc)
            return self._failed("Publish failed", exc, layer=pub.CONTROLLER)

        self.last_result = to_json_safe(result)
        if trace is not None:
            trace.step(pub.CONTROLLER, "returned",
                       "%s / %s" % (self.last_result.get("Status"),
                                    self.last_result.get("TransactionResult")))
        return self.last_result

    # -- helpers -----------------------------------------------------------

    def pending_trace(self):
        """The trace of the request the dispatcher is holding, if any."""
        return getattr(getattr(self.dispatcher, "pending", None), "trace", None)

    def _pending_token(self):
        pending = getattr(self.dispatcher, "pending", None)
        if isinstance(pending, dict):
            return pending.get("Token")
        return getattr(pending, "token", None)

    def _second_request(self):
        return bool(getattr(self.dispatcher, "second_request", False))

    def _blocked(self, reason, gate=None):
        payload = {
            "Status": BLOCKED,
            "TransactionResult": "not started",
            "StageResults": [],
            "Results": None,
            "Errors": [reason],
            "Warnings": [],
            "Plan": None,
            "GateFailed": list(gate.failed) if gate else [reason],
            "GatePassed": list(gate.passed) if gate else [],
            "FailureLayer": pub.SAFETY_GATE,
        }
        self.last_result = payload
        return payload

    def _failed(self, what, exc, layer=None):
        detail = pub.exception_detail(exc)
        payload = {
            "Status": FAILED,
            "TransactionResult": "not started",
            "StageResults": [],
            "Results": None,
            "Errors": ["%s: %s: %s" % (what, detail["Type"],
                                       detail["Message"])],
            "Warnings": [],
            "Plan": None,
            "FailureLayer": layer,
            "Exception": detail,
        }
        self.last_result = payload
        return payload


def revit_ui():
    """Import ``Autodesk.Revit.UI``, the way the 8A.1 probe proved works.

    ``Autodesk.Revit.UI`` lives in **RevitAPIUI.dll**, a different assembly
    from the RevitAPI.dll that ``revit_bridge`` references. A bare
    ``import Autodesk.Revit.UI`` finds nothing unless that assembly has been
    referenced first, and that omission is what made the first live publish
    fail: the import raised, `wire` swallowed it, and the Publish button had
    no ExternalEvent to raise.

    Both references are taken, in the 8A.1 order, so this does not depend on
    another module happening to have loaded RevitAPI already.
    """
    import clr
    clr.AddReference("RevitAPI")
    clr.AddReference("RevitAPIUI")
    import Autodesk.Revit.UI as UI
    return UI


def make_handler(runner, on_result=None, post=None):
    """Build the ``IExternalEventHandler``. Requires Revit; imported lazily.

    Revit calls ``Execute`` on its own event loop, which is the only context
    in which a Transaction may be started - the finding of checkpoint 8A.1.

    ``post`` marshals the result callback onto the UI thread. Revit dispatches
    ``Execute`` on its main thread, which in Rhino.Inside.Revit is also the
    thread that owns the Eto window, so a direct call is normally correct -
    but "normally" is not a guarantee to build a write path on, and
    ``Application.Instance.Invoke`` is a no-op when already on that thread.
    """
    UI = revit_ui()

    class DzPublishHandler(UI.IExternalEventHandler):

        def Execute(self, application):
            #: `dispatcher.execute()` is the frozen 8B contract: it hands the
            #: pending payload to `run_publish` and lands the state machine.
            #: The dispatcher is wired to `runner.run`, so this is the whole
            #: of the write path from Revit's side.
            trace = runner.pending_trace()
            if trace is not None:
                trace.step(pub.HANDLER, "Execute entered",
                           "UIApplication %s"
                           % type(application).__name__)
            try:
                result = runner.dispatcher.execute()
            except Exception as exc:
                if trace is not None:
                    trace.fail(pub.HANDLER, exc)
                result = runner._failed("Publish handler failed", exc,
                                        layer=pub.HANDLER)
            if on_result is None:
                return
            #: A reporting failure must not be reported as a publish failure -
            #: by this point the model's state is already decided - but it
            #: must not vanish either. It is recorded and printed.
            def report():
                try:
                    on_result(result)
                except Exception as exc:
                    if trace is not None:
                        trace.fail(pub.CALLBACK, exc,
                                   "The publish itself already completed; "
                                   "this failure is in reporting it.")
                    print("DZ publish: the result callback failed: %s: %s"
                          % (type(exc).__name__, exc))
            if post is None:
                report()
            else:
                post(report)

        def GetName(self):
            return "DZ Planning Tools publish"

    return DzPublishHandler()
