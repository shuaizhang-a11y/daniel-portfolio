"""Revit integration: the only package permitted to touch Autodesk.Revit.

The write path proved in checkpoint 8A.1 lives here:

    Eto callback -> PlanningApp -> PublishDispatcher.request()
                 -> ExternalEvent.Raise()
                 -> IExternalEventHandler.Execute()
                 -> safety gate -> controller.publish()
                 -> the validated Phase 7 nine-stage executor

Two rules hold this boundary:

- ``dz_planning_ui`` and ``dz_planning_app`` never import Autodesk.Revit, and
  never import ``controller.publish``. Both are asserted by tests.
- Only :mod:`publish_handler` calls ``controller.publish``, and only from
  inside ``Execute``, where a writable API context exists.

Importing this package does not require Revit. ``safety_gate`` and
``PublishRunner`` are pure and fully testable offline; the Revit import is
deferred to :func:`publish_handler.make_handler` and :func:`event_wiring.wire`.
"""

from . import safety_gate
from .event_wiring import Wiring, wire
from .publish_handler import PublishRunner, make_handler

__all__ = ["safety_gate", "PublishRunner", "make_handler", "wire", "Wiring"]
