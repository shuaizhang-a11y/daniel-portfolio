"""The last check before anything is written.

Evaluated inside ``IExternalEventHandler.Execute()``, before
``controller.publish()`` and before any ``TransactionGroup`` exists. Every
check compares the *approved* record against the world as it is at execution
time - not as it was when the operator clicked.

Deliberately pure: it takes a plain context snapshot rather than a Revit
document, so the whole decision path is exercised offline. Nothing here writes,
opens a transaction, or touches Revit.

A failure is a refusal, never a repair. The gate does not re-plan, re-hash into
agreement, or downgrade the request; it returns BLOCKED and the model is left
exactly as it was.
"""

import hashlib
import os

DOCUMENT_PRESENT = "an active Revit document exists"
PATH_MATCHES = "the active document is the approved model"
MANIFEST_MATCHES = "the manifest is unchanged since approval"
SOURCE_MATCHES = "the source 3DM is unchanged since approval"
BUILDING_MATCHES = "the approved building is still selected"
TOKEN_CURRENT = "this is the request that was approved"
DIGEST_INTACT = "the approved plan has not been altered"
DISPATCHER_IN_FLIGHT = "the dispatcher is executing this request"
NO_SECOND_REQUEST = "no second publish is in flight"

CHECKS = (DOCUMENT_PRESENT, PATH_MATCHES, MANIFEST_MATCHES, SOURCE_MATCHES,
          BUILDING_MATCHES, TOKEN_CURRENT, DIGEST_INTACT,
          DISPATCHER_IN_FLIGHT, NO_SECOND_REQUEST)


class GateResult(object):
    """Whether the write may proceed, and every reason it may not."""

    def __init__(self, passed=None, failed=None):
        self.passed = list(passed or [])
        self.failed = list(failed or [])

    def __repr__(self):
        return "GateResult(ok=%r, failed=%r)" % (self.ok, self.failed)

    @property
    def ok(self):
        return not self.failed

    @property
    def reason(self):
        if self.ok:
            return None
        return ("Publish was blocked at the execution-time safety gate. "
                "The model was not modified. %s" % " ".join(self.failed))


def file_sha256(path):
    """The digest of a file as it is now, or None when it is unreadable."""
    if not path or not os.path.isfile(path):
        return None
    digest = hashlib.sha256()
    handle = open(path, "rb")
    try:
        while True:
            chunk = handle.read(65536)
            if not chunk:
                break
            digest.update(chunk)
    finally:
        handle.close()
    return digest.hexdigest()


def _same_path(left, right):
    if not left or not right:
        return False
    return (os.path.normcase(os.path.abspath(str(left)))
            == os.path.normcase(os.path.abspath(str(right))))


def context_from(bridge):
    """A plain snapshot of the live document. The only Revit read here.

    Returned as primitives so the gate itself never holds a Revit object.
    """
    if bridge is None or not getattr(bridge, "available", False):
        return {"DocumentPresent": False, "ActiveRvtPath": None}
    try:
        context = bridge.context()
    except Exception as exc:
        return {"DocumentPresent": False, "ActiveRvtPath": None,
                "Error": "%s: %s" % (type(exc).__name__, exc)}
    path = getattr(context, "document_path", None)
    return {"DocumentPresent": bool(path is not None or context.available),
            "ActiveRvtPath": path}


def check(approved, context, dispatcher_state=None, pending_token=None,
          second_request=False):
    """Run every gate. Returns a :class:`GateResult`; never raises."""
    passed, failed = [], []

    def record(name, ok, detail=None):
        if ok:
            passed.append(name)
        else:
            failed.append(detail or ("Failed: %s." % name))

    context = context or {}

    record(DOCUMENT_PRESENT, bool(context.get("DocumentPresent")),
           "No active Revit document at execution time.")

    expected = approved.get("ExpectedRvtPath")
    active = context.get("ActiveRvtPath")
    record(PATH_MATCHES, _same_path(active, expected),
           "The active document is %s but the approved model is %s."
           % (active or "(none)", expected or "(unset)"))

    manifest_now = file_sha256(approved.get("ManifestPath"))
    record(MANIFEST_MATCHES,
           bool(manifest_now) and manifest_now == approved.get(
               "ManifestSha256"),
           "The manifest has changed since approval (now %s, approved %s)."
           % (manifest_now or "(unreadable)",
              approved.get("ManifestSha256") or "(none)"))

    source_now = file_sha256(approved.get("SourcePath"))
    record(SOURCE_MATCHES,
           bool(source_now) and source_now == approved.get("SourceModelHash"),
           "The source 3DM has changed since approval (now %s, approved %s)."
           % (source_now or "(unreadable)",
              approved.get("SourceModelHash") or "(none)"))

    plan_building = (approved.get("Plan") or {}).get("BuildingId")
    record(BUILDING_MATCHES,
           plan_building is None
           or plan_building == approved.get("BuildingId"),
           "The approved plan is for building %s but %s was approved."
           % (plan_building, approved.get("BuildingId")))

    record(TOKEN_CURRENT,
           pending_token is not None and pending_token == approved.token,
           "This is not the approved request; its token no longer matches.")

    record(DIGEST_INTACT, approved.verify(),
           "The approved plan no longer matches its digest.")

    record(DISPATCHER_IN_FLIGHT, dispatcher_state == "in-flight",
           "The dispatcher is %r, not executing this request."
           % dispatcher_state)

    record(NO_SECOND_REQUEST, not second_request,
           "A second publish request is already active.")

    return GateResult(passed, failed)
