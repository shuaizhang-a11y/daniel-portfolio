"""The text of the two confirmation modals.

Pure functions returning lines. Keeping the wording out of the widget code
means it can be asserted offline - and this is the one screen where the exact
words matter, because it is the last thing between the operator and a write.

Nothing here depends on colour. A reader with no colour perception, or reading
a pasted transcript, must get the identical warning.
"""

from . import formatting as fmt

DELETE_WORD = "DELETE"

PENDING_APPROVAL = "pending operator confirmation"

WRITE_WARNING = "THIS ACTION WILL MODIFY THE REVIT MODEL."
ONE_TRANSACTION = ("The whole operation runs as one controlled transaction "
                   "group.")
ROLLBACK_NOTE = ("If any stage fails, the entire operation is rolled back and "
                 "no change is assimilated.")


def typed_delete_correctly(text):
    """Exact match only: no trimming, no case folding.

    A confirmation that accepts `delete ` is not a confirmation.
    """
    return text == DELETE_WORD


def _counts(approved):
    expected = approved.get("Expected") or {}
    return (expected.get("created", 0), expected.get("updated", 0),
            len(approved.get("ReplacementElementIds") or []),
            expected.get("obsolete", 0))


DEVELOPMENT_HEADER = "DEVELOPMENT VALIDATION"


def development_warning(validation):
    """The forced-failure disclosure. Empty for a production confirmation."""
    if validation is None or not validation.active:
        return []
    from . import publish as pub
    return [
        "!" * 70,
        DEVELOPMENT_HEADER,
        "!" * 70,
        "This publish will deliberately fail at Stage %d."
        % pub.REQUIRED_STAGE,
        "The Revit TransactionGroup is expected to roll back.",
        "ForceFailAtStage = %s" % (validation.force_fail_at_stage
                                   if validation.armed else pub.NOT_ARMED),
        "!" * 70,
        "",
    ]


def publish_confirmation(approved, validation=None):
    """Everything the operator must see before a write. Returns lines.

    ``validation`` prepends the development disclosure. A production
    confirmation passes nothing and therefore contains none of it.
    """
    created, updated, replaced, obsolete = _counts(approved)
    plan = approved.get("Plan") or {}
    building = approved.get("BuildingId")
    name = None
    for row in (plan.get("Changes") or []):
        name = name or row.get("Building")

    lines = development_warning(validation) + [
        "PUBLISH TO THE REVIT MODEL",
        "=" * 70,
        "",
        "Target model",
        "  %s" % fmt.full_path(approved.get("ExpectedRvtPath")),
        "",
        "Building",
        "  %s%s" % (building, "  (%s)" % name if name and name != building
                   else ""),
        "",
        "Source 3DM",
        "  %s" % fmt.full_path(approved.get("SourcePath")),
        "  SHA-256 %s" % fmt.full_hash(approved.get("SourceModelHash")),
        "",
        "Manifest",
        "  %s" % fmt.full_path(approved.get("ManifestPath")),
        "  SHA-256 %s" % fmt.full_hash(approved.get("ManifestSha256")),
        "",
        "What will happen",
        "  Create   %d" % created,
        "  Update   %d" % updated,
        "  Replace  %d" % replaced,
        "  Obsolete %d   (action: %s)" % (obsolete,
                                          approved.get("ObsoleteAction")),
        "",
    ]

    ids = approved.get("ReplacementElementIds") or []
    if ids:
        lines.append("These existing elements will be REPLACED. Their "
                     "ElementIds will change:")
        for element_id in ids:
            lines.append("    %s" % element_id)
        lines.append("")
        lines.append("  Their DZ boundary loops will be deleted and rebuilt.")
        lines.append("  Their Areas will be re-associated in place where "
                     "possible;")
        lines.append("  where that is not possible they are replaced under "
                     "the same control.")
        lines.append("  The stable FloorKey and SourceId ownership do not "
                     "change.")
    else:
        lines.append("No element will be physically replaced.")
    lines.extend([
        "",
        "  %s" % ONE_TRANSACTION,
        "  %s" % ROLLBACK_NOTE,
        "",
        WRITE_WARNING,
        "",
        "Publish mode  : %s" % approved.get("PublishMode"),
        #: Before sealing there is no approval, so claiming one is
        #: unavailable is a false statement about a decision the operator has
        #: not yet made. The timestamp is generated when Confirm is clicked.
        ("Approval      : %s" % PENDING_APPROVAL
         if approved.get("ConfirmedAt") is None else
         "Approved at   : %s" % approved.get("ConfirmedAt")),
    ])
    return lines


def delete_confirmation(approved):
    """The second gate, shown only when the obsolete action is Delete.

    Discloses the *complete* destructive effect, not just the Floors.

    The executor deletes each obsolete Floor and, when one exists, the Area
    paired to it by migrated stable key - so one obsolete row can destroy two
    Revit elements. The earlier version of this dialog listed only the Floor
    ids, and an operator confirmed a list of one while two elements went.

    The paired Area's ElementId is deliberately **not** stated. It cannot be:
    `observe_areas()` is called only inside `executor.py`, within the
    transaction group, and no Area identity exists anywhere in the plan before
    then. Printing an id here would mean re-implementing the executor's
    pairing rule in the UI - a second copy of destructive business logic in a
    layer that cannot be kept in step with the frozen original. So the bound
    is disclosed honestly instead: how many Floors, how many Areas *may*
    accompany them, and where the exact answer comes from.

    The range is real, not caution. `executor.py` appends the paired Area
    only `if paired`, so an obsolete Floor with no Area deletes one element.
    N Floors delete between N and 2N elements.
    """
    plan = approved.get("Plan") or {}
    rows = [row for row in (plan.get("Obsolete") or [])
            if row.get("ElementId") is not None]
    floors = len(rows)

    lines = [
        "PERMANENT DELETION",
        "=" * 70,
        "",
        "Obsolete Element Action is set to Delete.",
        "",
        #: Which model. Removing this to shorten the dialog would trade one
        #: disclosure gap for another.
        "Target model:",
        "  %s" % fmt.full_path(approved.get("ExpectedRvtPath")),
        "",
    ]

    if not floors:
        lines.extend([
            "Obsolete Floors to delete: 0",
            "",
            "    (none currently classified obsolete)",
            "",
            "Deletion is not undone by anything this tool does; only Revit's",
            "own undo can recover it, and only within this session.",
            "",
            "Type %s exactly to confirm permanent deletion." % DELETE_WORD,
        ])
        return lines

    lines.extend([
        "Obsolete Floors to delete: %d" % floors,
        "",
        "For each obsolete Floor, its paired managed Area, if one exists,",
        "will also be permanently deleted automatically.",
        "",
        "Additional paired Areas that may be deleted: 0-%d" % floors,
        "Total Revit elements that may be deleted: %d-%d"
        % (floors, floors * 2),
        "",
        "The exact paired Area elements are resolved during publishing.",
        "",
        "Floors scheduled for deletion:",
    ])

    for row in rows:
        lines.append("- Floor ElementId: %s" % row.get("ElementId"))
        key = row.get("StableKey")
        #: The key is what identity is actually keyed on; the ElementId alone
        #: is meaningless once the element is gone.
        lines.append("  Floor Key: %s" % (key if key else "(none recorded)"))

    lines.extend([
        "",
        "Deletion is not undone by anything this tool does; only Revit's own",
        "undo can recover it, and only within this session.",
        "",
        "Type %s exactly to confirm permanent deletion." % DELETE_WORD,
    ])
    return lines


def confirmation_text(approved):
    return "\n".join(publish_confirmation(approved))


def delete_text(approved):
    return "\n".join(delete_confirmation(approved))
