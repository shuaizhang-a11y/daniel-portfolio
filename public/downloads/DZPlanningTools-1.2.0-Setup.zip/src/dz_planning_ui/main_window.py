"""The Eto window. Widgets only.

Every decision this file makes about *what* to show comes from
:mod:`dz_planning_ui.view_models`, and every button forwards to
:class:`dz_planning_ui.app.PlanningApp`. Nothing here reaches Revit, and
nothing here opens a Revit transaction.

Eto is imported inside :func:`load_eto` so that importing this module offline -
in a test, or on a machine without Rhino - still succeeds.

Three host-runtime rules govern this file. The window must build under **both**
Rhino 8 runtimes: IronPython 2.7 (what ``_-RunPythonScript`` uses) and CPython
3 with pythonnet (the ScriptEditor). Each rule below cost one failed launch.

1. **No keyword arguments to any .NET constructor.** IronPython passes them as
   an ``IronPython.Runtime.PythonDictionary`` and Eto's constructors reject it
   with ``SystemError: Unsupported param dictionary type``. Every control is
   built parameterless and configured by property assignment. There is a test
   that walks this file's syntax tree and fails if a keyword argument to ``EF``
   or ``ED`` ever reappears.

2. **No constructor arguments to a Python subclass of an Eto widget.**
   pythonnet routes the arguments of the type call to a base .NET constructor.
   ``Eto.Forms.Form`` declares ``Form()`` and ``Form(Form.IHandler)``, so one
   positional argument selects the ``IHandler`` overload and fails with
   ``expected IHandler, got Object_2$2``. The application object is attached by
   :meth:`bind` after construction.

3. **Event delegates are explicit and retained.** The delegate type is read
   from the event by reflection, and every delegate is kept alive on the
   window. A delegate created only for the duration of ``+=`` can be
   collected, after which the control silently stops responding.
"""

import sys
import traceback

from . import confirm as cf
from . import history_view as hv
from . import publish as pub
from . import view_models as vm
from .app import PUBLISH_LABEL
from .state import FOOTER_NOTE, WINDOW_TITLE

MONOSPACE = "Consolas"

#: The confirmation dialog's opening size, in pixels.
#:
#: Set explicitly, and that is the whole point. A ``Dialog`` whose
#: ``ClientSize`` is never assigned auto-sizes around its content, and a
#: ``TextArea`` reports no natural size, so the window collapsed to a few
#: unusable pixels around a scrollbar. The window itself has always set
#: ``ClientSize``; the modal never did.
MODAL_WIDTH = 880
MODAL_HEIGHT = 740

CONFIRM_LABEL = "Confirm Publish"
CANCEL_LABEL = "Cancel"

#: Column layout for the Change Plan grid: (heading, row key, width).
PLAN_COLUMNS = (
    ("Bldg", "Building", 60),
    ("Flr", "FloorIndex", 40),
    ("Action", "ActionText", 170),
    ("Current ElementId", "CurrentElementId", 130),
    ("New ElementId", "NewElementId", 160),
    ("Level", "LevelAction", 150),
    ("Floor", "FloorAction", 230),
    ("Boundary", "BoundaryAction", 150),
    ("Area", "AreaAction", 200),
    ("Area Plan", "AreaPlanAction", 150),
    ("Elev was", "PreviousElevation", 90),
    ("Elev proposed", "ProposedElevation", 100),
    ("Area was", "PreviousArea", 100),
    ("Area proposed", "ProposedArea", 105),
    ("Boundary was", "PreviousBoundaryHash", 150),
    ("Boundary proposed", "ProposedBoundaryHash", 150),
    ("Reason", "Reason", 320),
)

#: Every event this window attaches, as (attribute, event name, handler name).
#: The runtime harness walks this list, so an event added below without a
#: matching binding - or with the wrong signature - fails a test rather than a
#: live launch.
EVENT_BINDINGS = (
    ("browse_source_button", "Click", "on_browse_source"),
    ("browse_manifest_button", "Click", "on_browse_manifest"),
    ("detect_button", "Click", "on_detect"),
    ("buildings", "SelectedIndexChanged", "on_building_selected"),
    ("use_active_button", "Click", "on_use_active"),
    ("refresh_button", "Click", "on_refresh_snapshot"),
    ("analyse_button", "Click", "on_analyse"),
    ("plan_button", "Click", "on_plan"),
    ("open_logs_button", "Click", "on_open_logs"),
    ("refresh_history_button", "Click", "on_refresh_history"),
    ("export_report_button", "Click", "on_export_report"),
    ("export_button", "Click", "on_export"),
    ("grid", "SelectedRowsChanged", "on_row_selected"),
    ("history_grid", "SelectedRowsChanged", "on_history_row_selected"),
    ("project_grid", "SelectedRowsChanged", "on_project_row_selected"),
    ("tabs", "SelectedIndexChanged", "on_tab_changed"),
    ("browse_expected_button", "Click", "on_browse_expected"),
    ("publish_mode", "SelectedIndexChanged", "on_publish_mode"),
    ("obsolete_action", "SelectedIndexChanged", "on_obsolete_action"),
    ("confirm_publish_box", "CheckedChanged", "on_confirm_publish"),
    ("confirm_delete_box", "CheckedChanged", "on_confirm_delete"),
    ("publish", "Click", "on_publish"),
)

#: Attached on the window itself rather than on a child control.
FORM_EVENT_BINDINGS = (
    ("Shown", "on_shown"),
    ("Closed", "on_closed"),
)

#: Named construction stages, in the order :meth:`bind` runs them. A failure
#: reports which one was in progress, so the next launch names the control
#: instead of pointing at the end of `create_window`.
CHECKPOINTS = (
    "create Form",
    "create buttons",
    "create safety strip",
    "create detail panel",
    "create GridView columns",
    "create Project Setup tab",
    "create Planning Summary tab",
    "create Change Plan tab",
    "create History tab",
    "create Publish tab",
    "set Form.Content",
    "attach events",
    "initial render",
)


def runtime_name():
    """Which Python is hosting this window. Shown in Diagnostics."""
    if sys.platform == "cli":
        return "IronPython %s (Rhino _-RunPythonScript)" % (
            ".".join(str(p) for p in sys.version_info[:3]))
    return "CPython %s" % ".".join(str(p) for p in sys.version_info[:3])


class StartupError(Exception):
    """The window could not be built.

    Carries the checkpoint, the exact expression, the control type and the
    full original traceback. Raised instead of letting a raw Eto, pythonnet or
    IronPython error reach Rhino's exception dialog.

    Nothing has been analysed and nothing has been written when this is
    raised: construction happens before any controller call.
    """

    def __init__(self, checkpoint, expression, control_type, cause, detail):
        self.checkpoint = checkpoint
        self.expression = expression
        self.control_type = control_type
        self.cause = cause
        self.detail = detail
        Exception.__init__(self, self.report())

    def report(self):
        return "\n".join([
            "The DZ Planning Tools window could not be built.",
            "  checkpoint   : %s" % self.checkpoint,
            "  expression   : %s" % self.expression,
            "  control type : %s" % self.control_type,
            "  runtime      : %s" % runtime_name(),
            "  cause        : %s: %s" % (type(self.cause).__name__,
                                         self.cause),
            "",
            "Nothing was analysed and nothing was written. No Revit",
            "transaction was opened; the active document is untouched.",
            "",
            "Original traceback:",
            self.detail or "(unavailable)",
        ])


class Checkpoint(object):
    """Names the construction stage in progress, and what it was building.

    A context manager rather than one ``try`` around the whole of
    :meth:`bind`, so a failure identifies the control instead of the function.
    """

    def __init__(self, name):
        self.name = name
        self.expression = "(entering %s)" % name
        self.control_type = "(none)"

    def building(self, expression, control_type="(none)"):
        """Record what is about to be constructed."""
        self.expression = expression
        self.control_type = control_type
        return self

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc_type is None:
            return False
        if exc_type is StartupError:
            return False
        #: Formatted from the three arguments, never from `format_exc()`.
        #: `__exit__` runs outside the `except` block, so under IronPython 2.7
        #: the exception context is already cleared and `format_exc()` returns
        #: the string "None" - which is exactly what the last report showed.
        detail = "".join(traceback.format_exception(exc_type, exc, tb))
        #: Carried in the message rather than chained: IronPython 2.7 has no
        #: `raise ... from`, so chaining is not available in both hosts.
        raise StartupError(self.name, self.expression, self.control_type,
                           exc, detail)


def _pairs_text(rows, width=24):
    return "\n".join("%-*s %s" % (width, label, value) for label, value in rows)


def _sections_text(sections):
    blocks = []
    for title, rows in sections:
        blocks.append(title.upper())
        blocks.append("-" * 62)
        blocks.append(_pairs_text(rows))
        blocks.append("")
    return "\n".join(blocks)


def _blocks_text(blocks):
    """Titled blocks of plain lines. Used for PROJECT SOURCE, where the
    operator message must be readable before the diagnostics under it."""
    lines = []
    for title, entries in blocks:
        lines.append(title)
        lines.extend("  " + str(entry) for entry in entries)
        lines.append("")
    return "\n".join(lines).rstrip()


def _detail_text(row, app=None):
    """The full, untruncated values for one selected Change Plan row.

    Three blocks: the documented fields, the snapshot diff showing only what
    differs, and - for a physical replacement only - the identity change.
    """
    if not row:
        return "Select a row to see its full values."
    if app is None:
        return _pairs_text([("Action", row.get("ActionText")),
                            ("Current ElementId",
                             row.get("CurrentElementId"))])
    detail = app.element_detail(row)
    blocks = [_pairs_text(detail["Rows"], 26)]
    blocks.append("")
    if detail["Diff"]:
        blocks.append("CHANGED FIELDS  ([+] added  [-] removed  [~] changed)")
        blocks.append("-" * 62)
        blocks.extend("  " + entry["Text"] for entry in detail["Diff"])
    else:
        blocks.append("CHANGED FIELDS: none - this element matches the source.")
    if detail["Identity"]:
        blocks.append("")
        blocks.append("IDENTITY CHANGE")
        blocks.append("-" * 62)
        blocks.append(_pairs_text(detail["Identity"], 26))
    return "\n".join(blocks)


def _issues_text(sections):
    """Blocking Errors, then Conflicts, then Warnings. Errors open by default."""
    blocks = []
    for section in sections:
        items = section["Items"]
        header = "%s (%d)" % (section["Title"], len(items))
        if not section["Expanded"] and items:
            header += "  [collapsed - expand to read]"
        blocks.append(header)
        blocks.append("-" * 62)
        if not items:
            blocks.append("  none")
        elif section["Expanded"]:
            blocks.extend("  - " + str(item) for item in items)
        else:
            blocks.extend("  - " + str(item) for item in items)
        blocks.append("")
    return "\n".join(blocks)


def _history_text(entries):
    if not entries:
        return "No publish history for this package yet."
    blocks = []
    for entry in entries:
        blocks.append("=" * 78)
        blocks.append(_pairs_text([
            ("Timestamp", entry["Timestamp"]),
            ("User click", entry["UserClickTimestamp"]),
            ("RVT path", entry["RvtPath"]),
            ("Manifest SHA-256", entry["ManifestSha256"]),
            ("Source model hash", entry["SourceModelHash"]),
            ("Result", entry["Status"]),
            ("Transaction", entry["TransactionResult"]),
        ]))
        if entry["ElementIdMap"]:
            blocks.append("")
            blocks.append("ElementId mapping (old -> new):")
            for old, new in entry["ElementIdMap"]:
                blocks.append("    %-12s -> %s" % (old, new))
        if entry["CsvDisagreement"]:
            blocks.append("")
            blocks.append("!! JSON / CSV DISAGREEMENT - authoritative source: "
                          + entry["AuthoritativeSource"])
            blocks.append("   " + entry["CsvWarning"])
        blocks.append("")
        blocks.append("Counters (zeros included - an all-zero run is the "
                      "proof of idempotency):")
        for name, value in entry["Counters"]:
            blocks.append("    %-28s %s" % (name, value))
        for warning in entry["Warnings"]:
            blocks.append("    ! %s" % warning)
        for error in entry["Errors"]:
            blocks.append("    X %s" % error)
        blocks.append("")
    return "\n".join(blocks)


def _publish_text(app):
    """The terminal result, or what the session is waiting for."""
    session = app.session
    blocks = [_pairs_text(app.publish_result_rows(), 30)]
    stages = vm.stage_rows(session)
    if stages:
        blocks.append("")
        blocks.append("STAGES")
        blocks.append("-" * 62)
        for number, name, status, detail in stages:
            blocks.append("  %-3s %-38s %-9s %s"
                          % (number, name, status, detail))
    rows = app.replacement_map_rows()
    if rows:
        blocks.append("")
        blocks.append("REPLACED ELEMENTS - old -> new (mandatory disclosure)")
        blocks.append("-" * 62)
        for kind, old_id, new_id in rows:
            blocks.append("  %-6s %-12s -> %s" % (kind, old_id, new_id))
    #: The path the attempt actually took. Shown whenever it did not simply
    #: succeed, so a failure never has to be diagnosed from source code.
    trace = session.trace
    if trace is not None and trace.steps and session.state != pub.DONE:
        blocks.append("")
        blocks.append("PUBLISH PATH")
        blocks.append("-" * 62)
        for label, detail in trace.as_rows():
            blocks.append("  %-28s %s" % (label, detail))
        managed = (trace.failure or {}).get("StackTrace")
        if managed:
            blocks.append("")
            blocks.append(".NET STACK TRACE")
            blocks.append("-" * 62)
            blocks.append(managed)
        text = (trace.failure or {}).get("Traceback")
        if text:
            blocks.append("")
            blocks.append("TRACEBACK")
            blocks.append("-" * 62)
            blocks.append(text)
    return "\n".join(blocks)


def _history_detail_text(detail):
    """The selected entry, rendered for reading rather than as raw JSON."""
    if not detail:
        return "Select a history entry above to see its full record."
    blocks = []

    def section(title, rows):
        if not rows:
            return
        blocks.append(title)
        blocks.append("-" * 62)
        blocks.append(_pairs_text(rows, 28))
        blocks.append("")

    section("IDENTITY", detail["Identity"])
    section("OUTCOME", detail["Outcome"])

    if detail["Stages"]:
        blocks.append("STAGES")
        blocks.append("-" * 62)
        for number, name, status, note in detail["Stages"]:
            blocks.append("  %-3s %-38s %-12s %s"
                          % (number, name, status, note))
        blocks.append("")

    if detail["ElementIdMap"]:
        blocks.append("REPLACED ELEMENTS - old -> new (mandatory disclosure)")
        blocks.append("-" * 62)
        for kind, old_id, new_id in detail["ElementIdMap"]:
            blocks.append("  %-6s %-12s -> %s" % (kind, old_id, new_id))
        blocks.append("")

    section("COUNTERS", detail["Counters"])

    for title, items in (("WARNINGS", detail["Warnings"]),
                         ("ERRORS", detail["Errors"]),
                         ("FINAL VALIDATION", detail["FinalValidation"])):
        if items:
            blocks.append(title)
            blocks.append("-" * 62)
            for item in items:
                blocks.append("  - %s" % item)
            blocks.append("")

    if detail["CsvDisagreement"]:
        blocks.append("!! JSON / CSV DISAGREEMENT - authoritative source: "
                      + detail["AuthoritativeSource"])
        blocks.append("   " + detail["CsvWarning"])
    return "\n".join(blocks).rstrip()


def _legend_text():
    return "  ".join("%s %s" % (marker, label)
                     for marker, label, _hint in vm.legend())


def load_eto():
    """The three .NET namespaces this window needs. Imported on demand."""
    import Eto.Drawing as ED
    import Eto.Forms as EF
    import System
    import System.Collections          # noqa: F401 - populates the namespace
    return EF, ED, System


def resolve_array_list(System):
    """``System.Collections.ArrayList``, however this host exposes it."""
    collections = getattr(System, "Collections", None)
    array_list = getattr(collections, "ArrayList", None)
    if array_list is not None:
        return array_list
    from System.Collections import ArrayList
    return ArrayList


def resolve_object_list(System):
    """``System.Collections.Generic.List[System.Object]``, or None.

    ``GridView.DataStore`` is declared ``IEnumerable<object>``.
    ``ArrayList`` implements only the **non-generic** ``IEnumerable``, so it
    does not satisfy that contract: the assignment can succeed while Eto
    enumerates nothing, which shows as a grid with headers and no rows.

    ``List[Object]`` does implement ``IEnumerable<object>`` and is available
    in every .NET host including IronPython 2.7, which makes it the narrowest
    correct choice. ``ArrayList`` remains the fallback so a host without
    generic instantiation still renders something rather than failing to
    build.
    """
    try:
        from System import Object
        from System.Collections.Generic import List
        return List[Object]
    except Exception:
        generic = getattr(getattr(System, "Collections", None), "Generic",
                          None)
        list_type = getattr(generic, "List", None)
        object_type = getattr(System, "Object", None)
        if list_type is None or object_type is None:
            return None
        try:
            return list_type[object_type]
        except Exception:
            return None


def count_of(enumerable):
    """How many items an enumerable actually yields. Never raises.

    Deliberately enumerates rather than reading ``Count``: the question is
    what Eto will see when it walks the store, not what the object claims.
    """
    if enumerable is None:
        return None
    try:
        total = 0
        for _item in enumerable:
            total += 1
        return total
    except Exception as exc:
        return "(not enumerable: %s: %s)" % (type(exc).__name__, exc)


#: pythonnet emits a fresh .NET type for every Python subclass of a .NET class.
#: Defining the class once and reusing it keeps repeated launches from piling
#: up generated types in the AppDomain.
_WINDOW_TYPE = None


def window_type(modules=None):
    global _WINDOW_TYPE
    if _WINDOW_TYPE is None:
        _WINDOW_TYPE = define_window(*(modules or load_eto()))
    return _WINDOW_TYPE


def reset_window_type():
    """Forget the generated type. Used by the launcher and by the tests."""
    global _WINDOW_TYPE
    _WINDOW_TYPE = None


def define_window(EF, ED, System):
    """Build the window class against the supplied Eto/System modules."""

    EventArgs = System.EventArgs
    EventHandler = System.EventHandler
    ArrayList = resolve_array_list(System)
    ObjectList = resolve_object_list(System)
    #: The type actually used for GridView.DataStore, recorded for diagnosis.
    STORE_TYPE = ObjectList if ObjectList is not None else ArrayList

    #: Rhino 8 IronPython does not surface `Eto.Forms.GridItemCollection`;
    #: CPython/pythonnet does. Its absence is a supported runtime variation,
    #: recorded in the capability record and never a startup failure. Nothing
    #: below references the type - `ArrayList` is used in both hosts.
    HAS_GRID_ITEM_COLLECTION = hasattr(EF, "GridItemCollection")

    class PlanningWindow(EF.Form):
        """Deliberately no ``__init__``.

        pythonnet would forward the type call's arguments to a base .NET
        constructor. Construction takes no arguments; :meth:`bind` does the
        work that an ``__init__`` normally would.
        """

        # -- construction primitives ---------------------------------------
        #
        # Every one of these builds parameterless and then assigns properties.
        # No .NET constructor below receives a keyword argument.

        def label(self, text, font=None):
            control = EF.Label()
            control.Text = text
            if font is not None:
                control.Font = font
            return control

        def button(self, text):
            control = EF.Button()
            control.Text = text
            return control

        def prose(self, height=None):
            """A read-only pane that **wraps**.

            `mono` deliberately does not: the Change Plan detail and the
            diagnostics are column-aligned text that wrapping would ruin. But
            the same setting on Next Action and the source messages is what
            put a horizontal scrollbar under two sentences of English in the
            live window.
            """
            control = self.mono(height)
            control.Wrap = True
            return control

        def mono(self, height=None):
            control = EF.TextArea()
            control.ReadOnly = True
            control.Wrap = False
            control.Text = ""
            control.Font = ED.Font(MONOSPACE, 9.0)
            if height is not None:
                control.Height = height
            return control

        def layout(self, padding=None):
            control = EF.DynamicLayout()
            control.Spacing = ED.Size(6, 6)
            if padding is not None:
                control.Padding = ED.Padding(padding)
            return control

        def tab_page(self, text, content):
            page = EF.TabPage()
            page.Text = text
            page.Content = content
            return page

        def column(self, heading, width, index):
            control = EF.GridColumn()
            control.HeaderText = heading
            control.Width = width
            control.DataCell = EF.TextBoxCell(index)
            return control

        # -- delegate plumbing ---------------------------------------------

        def connect(self, control, event_name, callback, sink=None):
            """Attach ``callback`` using the delegate type the event declares.

            The type is read from the event rather than assumed, and attached
            through reflection, which behaves the same under IronPython and
            pythonnet.

            ``sink`` is where the strong reference is kept. It defaults to the
            window's own list, which lives as long as the window. Controls that
            are rebuilt - the modal - pass their own list instead, so their
            delegates are released with them rather than accumulating here.
            """
            info = control.GetType().GetEvent(event_name)
            if info is None:
                raise StartupError(
                    "attach events", "%s.GetEvent(%r)"
                    % (control.GetType().Name, event_name),
                    control.GetType().Name,
                    AttributeError("no such event"), "")
            delegate = EventHandler[EventArgs](callback)
            declared = info.EventHandlerType
            if not declared.IsAssignableFrom(delegate.GetType()):
                raise StartupError(
                    "attach events",
                    "%s.%s += EventHandler[EventArgs]"
                    % (control.GetType().Name, event_name),
                    control.GetType().Name,
                    TypeError("event declares %s" % declared.FullName), "")
            info.AddEventHandler(control, delegate)
            #: Strong reference. Without this the delegate is collectable and
            #: the control quietly stops responding.
            keep = self._handlers if sink is None else sink
            keep.append((control, event_name, delegate, callback))
            return delegate

        # -- construction --------------------------------------------------

        #: True while `sync_controls` is writing to controls, so the change
        #: handlers ignore values the window set itself.
        _syncing = False

        def bind(self, application):
            """Everything an ``__init__`` would do, done after construction.

            Each stage is named, so a failure identifies the control rather
            than this method.
            """
            self.app = application
            self._handlers = []
            self._rows = []
            self._checkpoint = None

            with self.stage("create Form") as step:
                step.building("self.Title = app.window_title", "Form")
                #: Not the module constant: a validation session must be
                #: unmistakable from the title bar alone.
                self.Title = application.window_title
                step.building("ED.Size(1280, 820)", "Eto.Drawing.Size")
                self.ClientSize = ED.Size(1280, 820)
                step.building("ED.Padding(8)", "Eto.Drawing.Padding")
                self.Padding = ED.Padding(8)

            with self.stage("create buttons") as step:
                step.building("EF.Button(); .Text = ...", "Button")
                self.browse_source_button = self.button("Browse Source 3DM")
                self.browse_manifest_button = self.button("Browse Manifest")
                self.detect_button = self.button("Detect Inputs")
                self.use_active_button = self.button(
                    "Use Active RVT as Expected Path")
                self.refresh_button = self.button(
                    "Refresh Live Revit Snapshot")
                self.analyse_button = self.button("Analyse")
                self.plan_button = self.button("Generate Change Plan")
                self.open_logs_button = self.button("Open Log Folder")
                self.export_button = self.button("Export Preview Report")
                step.building("EF.Button(); .Enabled = False", "Button")
                self.browse_expected_button = self.button(
                    "Browse Expected RVT")
                #: Enabled only when every gate passes; see `publish_gate`.
                self.publish = self.button(PUBLISH_LABEL)
                self.publish.Enabled = False
                self.publish.ToolTip = self.app.publish_tooltip

            with self.stage("create safety strip") as step:
                step.building("EF.TextArea(); .ReadOnly = True", "TextArea")
                #: One line now, not five labelled internals.
                self.safety = self.mono(26)

            with self.stage("create detail panel") as step:
                step.building("EF.TextArea(); .ReadOnly = True", "TextArea")
                self.setup = self.mono()
                self.facts = self.mono()
                self.issues = self.mono(150)
                self.lock_notice = self.mono(60)
                #: One line, directly above the grid, naming what crossed each
                #: boundary. The grid rendering has failed twice; this makes
                #: the next failure self-describing.
                self.grid_diagnostic = self.mono(28)
                self.publish_gate_notice = self.mono(70)
                self.publish_result = self.mono()
                self.problems = self.mono(110)
                self.summary = self.mono()
                step.building("EF.GridView(); .ShowHeader = True",
                              "GridView")
                #: Columns come from the 8F.1 contract, so a heading cannot
                #: exist without the row key that fills it.
                self.history_grid = EF.GridView()
                self.history_grid.ShowHeader = True
                self.history_grid.GridLines = EF.GridLines.Both
                for index, (heading, _key, width) in enumerate(hv.COLUMNS):
                    self.history_grid.Columns.Add(
                        self.column(heading, width, index))
                self.history_rows_shown = []
                #: Phase 12C. The project review table: one row per building,
                #: read only. `EF.GridView` is already the type behind the
                #: Change Plan and History tables, so this adds a third
                #: instance of a construction this host has proven, not a new
                #: control type.
                step.building("EF.GridView(); .ShowHeader = True", "GridView")
                self.project_grid = EF.GridView()
                self.project_grid.ShowHeader = True
                self.project_grid.GridLines = EF.GridLines.Both
                for index, (heading, _key, width) in enumerate(
                        vm.PROJECT_COLUMNS):
                    self.project_grid.Columns.Add(
                        self.column(heading, width, index))
                self.project_rows_shown = []
                self.project_totals_text = self.mono(120)
                self.project_notice = self.label("")
                #: Phase 13A. The dashboard blocks, each a view over state
                #: that already exists elsewhere.
                self.project_header = self.mono(120)
                #: Operator sentences, not tables. They wrap.
                self.source_block = self.prose(120)
                self.status_block = self.mono(120)
                self.next_action_block = self.prose(120)
                self.refresh_history_button = self.button("Refresh History")
                #: Deliberately not "Export Report". The preview report and
                #: the publish report describe different things, and a label
                #: that blurs them would let one be mistaken for the other.
                self.export_report_button = self.button(
                    "Export Publish Report")
                self.export_report_button.Enabled = False
                self.history_notice = self.label("")
                self.history_detail = self.mono()
                self.history = self.mono()
                self.messages = self.mono(90)
                self.detail = self.mono(150)

            with self.stage("create GridView columns") as step:
                step.building("EF.GridView(); .ShowHeader = True", "GridView")
                self.grid = EF.GridView()
                self.grid.ShowHeader = True
                self.grid.GridLines = EF.GridLines.Both
                step.building("EF.GridColumn(); .DataCell = EF.TextBoxCell(i)",
                              "GridColumn")
                for index, (heading, _key, width) in enumerate(PLAN_COLUMNS):
                    self.grid.Columns.Add(self.column(heading, width, index))

                step.building("EF.DropDown(); .Items.Add(name)", "DropDown")
                #: One building publishes per run; the list makes that limit
                #: visible rather than implicit.
                self.buildings = EF.DropDown()
                self._building_ids = []

                step.building("EF.CheckBox(); .Text = ...", "CheckBox")
                self.toggles = []
                for name in vm.TOGGLE_FILTERS:
                    box = EF.CheckBox()
                    box.Text = name
                    self.toggles.append((name, box))

                step.building("EF.Label(); .Text = ...", "Label")
                self.headline = self.label("")
                self.legend = self.label(_legend_text(),
                                         ED.Font(MONOSPACE, 8.5))
                step.building("EF.DropDown(); .Items.Add(...)", "DropDown")
                self.publish_mode = EF.DropDown()
                for name in pub.PUBLISH_MODES:
                    self.publish_mode.Items.Add(name)
                self.publish_mode.SelectedIndex = 0
                self.obsolete_action = EF.DropDown()
                for name in pub.OBSOLETE_ACTIONS:
                    self.obsolete_action.Items.Add(name)
                self.obsolete_action.SelectedIndex = 0

                step.building("EF.CheckBox(); .Text = ...", "CheckBox")
                step.building("EF.TextArea()  # validation banner",
                              "TextArea")
                self.validation_banner = self.mono(150)
                self.confirm_publish_box = EF.CheckBox()
                self.confirm_publish_box.Text = "Confirm Publish"
                self.confirm_delete_box = EF.CheckBox()
                self.confirm_delete_box.Text = "Confirm Delete Obsolete"
                step.building("EF.TextBox()", "TextBox")
                self.delete_word = EF.TextBox()

                step.building("EF.TabControl()", "TabControl")
                self.tabs = EF.TabControl()

            with self.stage("create Project Setup tab") as step:
                step.building("EF.TabPage(); .Content = ...", "TabPage")
                self.tabs.Pages.Add(
                    self.tab_page("Project Setup", self.setup_page(step)))

            with self.stage("create Planning Summary tab") as step:
                step.building("EF.TabPage(); .Content = ...", "TabPage")
                self.tabs.Pages.Add(
                    self.tab_page("Planning Summary", self.summary_page(step)))

            with self.stage("create Change Plan tab") as step:
                step.building("EF.TabPage(); .Content = ...", "TabPage")
                self.tabs.Pages.Add(
                    self.tab_page("Change Plan", self.plan_page(step)))

            with self.stage("create History tab") as step:
                step.building("EF.TabPage(); .Content = ...", "TabPage")
                self.tabs.Pages.Add(
                    self.tab_page("History and Diagnostics",
                                  self.history_page(step)))

            with self.stage("create Publish tab") as step:
                step.building("EF.TabPage(); .Content = ...", "TabPage")
                self.tabs.Pages.Add(
                    self.tab_page("Publish", self.publish_page(step)))

            with self.stage("set Form.Content") as step:
                step.building("EF.DynamicLayout(); .Add(...)", "DynamicLayout")
                self.Content = self.build_layout(step)

            with self.stage("attach events") as step:
                step.building("EventInfo.AddEventHandler(control, delegate)",
                              "EventHandler[EventArgs]")
                self.attach_events()

            with self.stage("initial render") as step:
                step.building("self.refresh()", "Form")
                self.refresh()
            return self

        def stage(self, name):
            self._checkpoint = Checkpoint(name)
            return self._checkpoint

        def attach_events(self):
            for attribute, event_name, handler_name in EVENT_BINDINGS:
                self.connect(getattr(self, attribute), event_name,
                             getattr(self, handler_name))
            #: One delegate per toggle, each retained like every other.
            for _name, box in self.toggles:
                self.connect(box, "CheckedChanged", self.on_toggle)
            for event_name, handler_name in FORM_EVENT_BINDINGS:
                self.connect(self, event_name, getattr(self, handler_name))

        def build_layout(self, step):
            root = self.layout()
            root.AddRow(self.safety)
            root.Add(self.tabs, True, True)
            root.AddRow(self.messages)

            step.building("EF.DynamicLayout(); BeginHorizontal()",
                          "DynamicLayout")
            footer = self.layout()
            footer.BeginHorizontal()
            footer.Add(self.label(FOOTER_NOTE), True)
            footer.Add(self.publish)
            footer.EndHorizontal()
            root.AddRow(footer)
            return root

        def setup_page(self, step):
            step.building("EF.DynamicLayout(); .Padding = ED.Padding(6)",
                          "DynamicLayout")
            page = self.layout(6)

            #: The action bar gets its own column space, like every other
            #: band. Its trailing spacer used to share the page's column
            #: grid, which pinned every row below it into the width of one
            #: button and left the rest of the window blank - the layout
            #: complaint from the first live acceptance, in one line.
            #:
            #: `BeginVertical` is the single mechanism used throughout. An
            #: `AddSeparateRow` here did the same job by a second route, and
            #: two ways of saying one thing is one too many.
            page.BeginVertical()
            page.AddRow(self.browse_source_button,
                        self.browse_manifest_button, self.detect_button,
                        self.use_active_button, self.refresh_button,
                        self.analyse_button, self.plan_button, None)
            page.EndVertical()

            #: Top band: what is loaded, where it stands, what to do next -
            #: three equal columns across the full width.
            #: **Every band gets its own vertical section.**
            #:
            #: Columns are shared by every row of a DynamicLayout section. The
            #: dashboard band below defines three of them, and a one-cell row
            #: in a three-column section occupies *one column* - it does not
            #: span. So the Buildings grid, asking correctly to expand, was
            #: handed a third of the window while the rest sat empty. That is
            #: exactly what the live screenshot showed, and asking for xscale
            #: could never have fixed it.
            #:
            #: `BeginVertical` starts an independent column space. One band,
            #: one section, and the grid's section has a single column.
            page.BeginVertical()
            page.Add(self.label(
                "PROJECT SOURCE                     STATUS"
                "                     NEXT ACTION"), True)
            page.BeginHorizontal()
            page.Add(self.project_header, True, True)
            page.Add(self.status_block, True, True)
            page.Add(self.next_action_block, True, True)
            page.EndHorizontal()
            page.EndVertical()

            #: The selector is compact and keeps its own section, so its
            #: trailing spacer cannot constrain the grid below it.
            page.BeginVertical()
            page.Add(self.label(
                "BUILDINGS - one RVT model per building. Model State says "
                "where the model is; Freshness says how old the result is; "
                "Plan says what it concluded."), True)
            page.BeginHorizontal()
            page.Add(self.label("Building:"))
            page.Add(self.buildings)
            page.Add(None, True)
            page.EndHorizontal()
            page.EndVertical()

            #: The primary control, alone in its section: one column, full
            #: width, and the only control on the page given both scales.
            #: The Phase 12C table, moved here rather than copied - there is
            #: one project table in the product and this is it.
            page.BeginVertical()
            page.Add(self.project_grid, True, True)
            page.Add(self.project_notice, True)
            page.EndVertical()

            #: Everything below is evidence for when something is wrong. It
            #: keeps every fact it had and stops being the first thing read.
            page.BeginVertical()
            page.Add(self.label("DETAILS AND DIAGNOSTICS"), True)
            page.BeginHorizontal()
            page.Add(self.source_block, True, True)
            page.Add(self.setup, True, True)
            page.Add(self.facts, True, True)
            page.EndHorizontal()
            page.EndVertical()

            page.BeginVertical()
            page.Add(self.project_totals_text, True)
            page.Add(self.label("Blocking setup problems:"), True)
            page.Add(self.problems, True)
            page.EndVertical()
            return page

        def summary_page(self, step):
            """The manifest planning summary.

            Phase 13A moved the project review table to Project Setup, where
            the operator is actually setting the project up. It was moved,
            not copied - a second table would be a second thing to keep true.
            """
            step.building("EF.DynamicLayout(); .Padding = ED.Padding(6)",
                          "DynamicLayout")
            page = self.layout(6)
            page.Add(self.summary, True, True)
            return page

        def plan_page(self, step):
            step.building("EF.DynamicLayout(); .Padding = ED.Padding(6)",
                          "DynamicLayout")
            page = self.layout(6)
            page.AddRow(self.lock_notice)
            page.AddRow(self.headline)
            #: The only filter control. Nothing ticked means every row shows.
            page.BeginHorizontal()
            page.Add(self.label("Show only:"))
            for _name, box in self.toggles:
                page.Add(box)
            page.Add(None, True)
            page.EndHorizontal()
            page.AddRow(self.legend)
            page.AddRow(self.grid_diagnostic)
            page.Add(self.grid, True, True)
            page.AddRow(self.detail)
            page.AddRow(self.issues)
            return page

        def publish_page(self, step):
            step.building("EF.DynamicLayout(); .Padding = ED.Padding(6)",
                          "DynamicLayout")
            page = self.layout(6)
            #: First thing on the tab. In production it renders empty and is
            #: hidden, so the production layout is unchanged.
            page.AddRow(self.validation_banner)
            page.BeginHorizontal()
            page.Add(self.label("Publish Mode:"))
            page.Add(self.publish_mode)
            page.Add(self.label("Obsolete Action:"))
            page.Add(self.obsolete_action)
            page.Add(None, True)
            page.EndHorizontal()
            page.BeginHorizontal()
            page.Add(self.browse_expected_button)
            page.Add(self.confirm_publish_box)
            page.Add(self.confirm_delete_box)
            page.Add(self.label("type DELETE:"))
            page.Add(self.delete_word)
            page.Add(None, True)
            page.EndHorizontal()
            page.AddRow(self.publish_gate_notice)
            page.BeginHorizontal()
            page.Add(self.publish, True)
            page.EndHorizontal()
            page.Add(self.publish_result, True, True)
            return page

        def history_page(self, step):
            step.building("EF.DynamicLayout(); .Padding = ED.Padding(6)",
                          "DynamicLayout")
            page = self.layout(6)
            page.BeginHorizontal()
            page.Add(self.refresh_history_button)
            page.Add(self.export_report_button)
            page.Add(self.open_logs_button)
            page.Add(self.export_button)
            page.Add(None, True)
            page.EndHorizontal()
            page.AddRow(self.history_notice)
            page.Add(self.history_grid, True, True)
            page.AddRow(self.history_detail)
            page.Add(self.history, True, True)
            return page

        # -- handlers ------------------------------------------------------
        #
        # Each takes (sender, event) because that is the EventHandler<EventArgs>
        # signature. A failure inside one is reported in the messages pane; an
        # exception escaping into the Eto loop would close the window.

        def guard(self, work, reason="button"):
            self._refresh_reason = reason
            try:
                work()
            except Exception as exc:
                self.app.state.note(
                    "UI error: %s: %s" % (type(exc).__name__, exc))
            self.refresh()

        def on_browse_source(self, sender, event):
            self.guard(lambda: self.app.set_source_3dm(
                self.pick("3DM model", "*.3dm")))

        def on_browse_manifest(self, sender, event):
            self.guard(lambda: self.app.set_manifest(
                self.pick("Project manifest", "*.json")))

        def on_detect(self, sender, event):
            self.guard(self.app.detect)

        def on_building_selected(self, sender, event):
            index = self.buildings.SelectedIndex
            if 0 <= index < len(self._building_ids):
                chosen = self._building_ids[index]
                self.guard(lambda: self.app.select_building(chosen))

        def on_toggle(self, sender, event):
            self.app.filters = [name for name, box in self.toggles
                                if box.Checked]
            self.refresh_grid("toggle changed")

        def on_browse_expected(self, sender, event):
            #: Selects a path only. Nothing is opened, read or saved.
            self.guard(lambda: self.app.set_expected_rvt(
                self.pick("Expected Revit model", "*.rvt")),
                "Browse Expected RVT")

        def on_publish_mode(self, sender, event):
            index = self.publish_mode.SelectedIndex
            if 0 <= index < len(pub.PUBLISH_MODES):
                self.guard(lambda: self.app.set_publish_mode(
                    pub.PUBLISH_MODES[index]), "Publish Mode")

        def on_obsolete_action(self, sender, event):
            index = self.obsolete_action.SelectedIndex
            if 0 <= index < len(pub.OBSOLETE_ACTIONS):
                self.guard(lambda: self.app.set_obsolete_action(
                    pub.OBSOLETE_ACTIONS[index]), "Obsolete Action")

        def on_confirm_publish(self, sender, event):
            if self._syncing:
                return
            self.app.set_confirm_publish(self.confirm_publish_box.Checked)
            self.refresh()

        def on_confirm_delete(self, sender, event):
            if self._syncing:
                return
            self.app.set_confirm_delete(
                self.confirm_delete_box.Checked, self.delete_word.Text)
            #: The box must end up showing what was actually granted - an
            #: unticked box after a wrong word is the honest state - but it is
            #: not written here. `refresh` calls `sync_controls`, which is the
            #: one place state is pushed onto controls, and which suppresses
            #: the CheckedChanged this assignment would otherwise raise.
            self.refresh()

        def on_publish(self, sender, event):
            """The only control that can lead to a write. Never writes here."""
            self.guard(self.confirm_then_request, "Publish")

        def confirm_then_request(self):
            if not self.app.publish_enabled:
                return None
            if not self.modal("Confirm publish",
                              self.app.confirmation_lines()):
                self.app.state.note("Publish cancelled at the confirmation.")
                return None
            if self.app.session.deletes_obsolete:
                if not self.modal("Confirm deletion",
                                  self.app.delete_confirmation_lines()):
                    self.app.state.note("Deletion cancelled.")
                    return None
            return self.app.request_publish()

        def modal(self, title, lines):
            """Show a blocking confirmation. True only if Confirm was clicked.

            The previous version built a dialog with **no buttons at all** and
            read ``ShowModal() == DialogResult.Ok``, which nothing could ever
            produce. Three things changed, and each one was a defect:

            * ``ClientSize`` is assigned, so the dialog opens usable instead of
              auto-sizing to nothing around a control with no natural size.
            * The buttons sit in their own row, a sibling of the scrolling
              body rather than inside it, so no amount of content can push
              them out of reach.
            * The decision is a Python flag set by the button handlers. Closing
              with X runs neither handler, so the flag stays False and X
              behaves as Cancel - the safe direction, by construction rather
              than by mapping a result code.

            The body is a read-only ``TextArea``: Eto's scrollable text region,
            already proven in this window. Nesting one inside a ``Scrollable``
            would give two scrollbars over the same text.
            """
            decision = {"confirmed": False}
            #: Retained here, not on ``self._handlers``. A modal is rebuilt on
            #: every publish; this frame is alive for as long as ShowModal
            #: blocks, which is exactly the delegates' useful life.
            delegates = []

            dialog = EF.Dialog()
            dialog.Title = title
            dialog.Resizable = True

            body = self.mono()
            body.Text = "\n".join(lines)

            cancel = self.button(CANCEL_LABEL)
            accept = self.button(CONFIRM_LABEL)

            def on_cancel(sender, event):
                decision["confirmed"] = False
                dialog.Close()

            def on_accept(sender, event):
                decision["confirmed"] = True
                dialog.Close()

            self.connect(cancel, "Click", on_cancel, sink=delegates)
            self.connect(accept, "Click", on_accept, sink=delegates)

            layout = self.layout(10)
            #: The only child that expands. Everything else keeps its height.
            layout.Add(body, True, True)
            layout.BeginHorizontal()
            layout.Add(None, True, False)     # spacer: buttons sit right
            layout.Add(cancel, False, False)
            layout.Add(accept, False, False)
            layout.EndHorizontal()

            dialog.Content = layout
            #: After Content. Sizing a dialog with nothing in it is undefined.
            dialog.ClientSize = ED.Size(MODAL_WIDTH, MODAL_HEIGHT)
            #: Esc cancels. ``DefaultButton`` is deliberately left unset: Enter
            #: must not be able to commit a write to the model.
            dialog.AbortButton = cancel
            dialog.ShowModal(self)
            return decision["confirmed"]

        def on_use_active(self, sender, event):
            self.guard(self.app.use_active_as_expected)

        def on_refresh_snapshot(self, sender, event):
            self.guard(self.app.refresh_snapshot)

        def on_analyse(self, sender, event):
            self.guard(self.app.analyse)

        def on_plan(self, sender, event):
            self.guard(self.app.generate_change_plan, "Generate Change Plan")

        def on_export_report(self, sender, event):
            """Choose a destination and write the report. Read-only publish."""
            self.guard(self.export_selected_report, "export publish report")

        def export_selected_report(self):
            if not self.app.publish_report_enabled:
                self.app.state.note(self.app.publish_report_gate())
                return None
            path = self.pick_save("Export Publish Report",
                                  self.app.suggested_report_name())
            if not path:
                #: Cancelled. Nothing written, nothing changed.
                return None
            return self.app.export_publish_report(path)

        def pick_save(self, title, suggested):
            """A modal save dialog. Blocking, so there is no callback."""
            dialog = EF.SaveFileDialog()
            dialog.Title = title
            dialog.FileName = suggested
            dialog.Filters.Add(EF.FileFilter("Text report", ".txt"))
            dialog.Filters.Add(EF.FileFilter("JSON report", ".json"))
            if dialog.ShowDialog(self) == EF.DialogResult.Ok:
                return dialog.FileName
            return None

        def on_refresh_history(self, sender, event):
            """Read-only. Re-reads the log; touches no planning state."""
            self.guard(self.app.refresh_history, "refresh history")

        def on_open_logs(self, sender, event):
            self.guard(self.app.open_log_folder)

        def on_export(self, sender, event):
            self.guard(self.app.export_preview_report)

        def selected_index(self):
            """The selected row, from whichever property this host provides.

            ``SelectedRow`` is -1 when nothing is selected. ``SelectedRows``
            is the multi-selection enumerable; it is consulted as a fallback
            because not every Eto platform keeps the two in step.
            """
            index = getattr(self.grid, "SelectedRow", -1)
            if index is None or index < 0:
                for candidate in (getattr(self.grid, "SelectedRows", None)
                                  or []):
                    return candidate
                return -1
            return index

        def on_row_selected(self, sender, event):
            #: Resolved against the Python rows, not against the DataStore, so
            #: the detail record is the full view model rather than the
            #: stringified cells.
            index = self.selected_index()
            row = self._rows[index] if 0 <= index < len(self._rows) else None
            self.detail.Text = _detail_text(row, self.app)

        def on_tab_changed(self, sender, event):
            #: The safety strip must be current on whichever tab is in front.
            #: Deliberately does NOT rebuild the grid - a tab change replacing
            #: a correct DataStore is one of the ways rows can vanish.
            self.safety.Text = self.app.operator_header()

        def on_shown(self, sender, event):
            #: Rendering only. Analyse is never started automatically - the
            #: operator chooses when this window reads the model.
            self._refresh_reason = "window shown"
            self.refresh()

        def on_closed(self, sender, event):
            del self._handlers[:]

        def pick(self, title, pattern):
            """A modal file dialog. Blocking, so there is no callback to bind."""
            dialog = EF.OpenFileDialog()
            dialog.Title = title
            #: FileFilter's own constructor is positional, not a property bag.
            dialog.Filters.Add(EF.FileFilter(title, pattern))
            if dialog.ShowDialog(self) == EF.DialogResult.Ok:
                return dialog.FileName
            return None

        # -- rendering -----------------------------------------------------

        def refresh(self):
            #: First, so the capability record it produces is current by the
            #: time the Diagnostics text is built below.
            self.refresh_grid(getattr(self, "_refresh_reason", "refresh"))
            self.safety.Text = self.app.operator_header()
            self.setup.Text = _pairs_text(
                self.app.safety_strip() + self.app.setup_rows(), 24)
            problems = self.app.setup_problems()
            self.problems.Text = ("\n".join("- " + p for p in problems)
                                  if problems else "None.")
            self.summary.Text = _sections_text(self.app.summary_sections())
            self.project_header.Text = _pairs_text(
                self.app.project_header(), 18)
            #: Operator message first, technical detail last and labelled.
            self.source_block.Text = _blocks_text(self.app.source_section())
            self.status_block.Text = "STATUS\n" + "-" * 34 + "\n" + \
                _pairs_text(self.app.status(), 14)
            #: Guidance, and labelled as guidance. It reports readiness; it
            #: cannot create any.
            self.next_action_block.Text = "NEXT ACTION\n" + "-" * 34 + \
                "\n" + _pairs_text(self.app.next_action_rows(), 14)
            self.facts.Text = "\n".join([
                "SOURCE 3DM", "-" * 62,
                _pairs_text(self.app.source_facts(), 30), "",
                "MANIFEST", "-" * 62,
                _pairs_text(self.app.manifest_facts(), 30)])
            self.refresh_buildings()
            locks = self.app.plan_locked()
            #: A cached result renders in the same table, so the reason it is
            #: not a live plan is stated in the same place the lock is. The
            #: banner comes first: what the table is showing has to be read
            #: before why the tab is locked.
            banner = self.app.review_banner()
            self.lock_notice.Text = "\n".join(
                banner + ["CHANGE PLAN LOCKED:\n  - " + "\n  - ".join(locks)
                          if locks else "Change Plan unlocked."])
            self.refresh_project_grid()
            self.issues.Text = _issues_text(self.app.issue_sections())
            self.refresh_history_grid()
            self.history.Text = "\n".join([
                _pairs_text(self.app.diagnostics(), 24), "",
                _history_text(self.app.history_rows())])
            #: Current blockers first - replaced each action, so one
            #: controller error renders as exactly one line however many
            #: times this method runs - then the activity log beneath.
            self.messages.Text = "\n".join(
                #: Derived from the session on every refresh, so it can never
                #: lag behind the terminal state the way an appended log line
                #: did: after the first successful publish the newest entry
                #: still read "Waiting for Revit".
                [vm.publish_status_line(self.app.session)]
                + ["BLOCKING: %s" % b for b in self.app.state.blockers]
                + self.app.state.messages[-10:])
            self.sync_controls()
            reasons = self.app.publish_gate()
            self.publish_gate_notice.Text = (
                "PUBLISH DISABLED:\n  - " + "\n  - ".join(reasons)
                if reasons else
                "Publish is armed. Confirmation is still required.")
            banner = vm.validation_banner(self.app.validation, self.app.wiring)
            self.validation_banner.Text = "\n".join(banner)
            self.validation_banner.Visible = bool(banner)
            self.publish_result.Text = _publish_text(self.app)
            self.apply_lock()

        def sync_controls(self):
            """Write application state back onto the controls. One place.

            The first live failure left the Confirm Publish box ticked while
            the gate said "Tick Confirm Publish before publishing": the
            terminal state had cleared the session's confirmation, but nothing
            ever cleared the checkbox. Internal state and visible state are
            reconciled here, on every refresh, rather than in whichever
            callback happens to remember.

            ``_syncing`` suppresses the ``CheckedChanged`` handlers, which
            would otherwise read the value this method just wrote and call
            straight back into `refresh`.
            """
            session = self.app.session
            self._syncing = True
            try:
                self.confirm_publish_box.Checked = bool(session.confirm_publish)
                self.confirm_delete_box.Checked = bool(session.confirm_delete)
                if not session.confirm_delete and self.delete_word.Text:
                    #: The typed word is part of the confirmation. Clearing one
                    #: without the other leaves a half-armed control.
                    self.delete_word.Text = ""
            finally:
                self._syncing = False
            #: Re-asserted on every refresh, not only at construction.
            self.publish.Enabled = self.app.publish_enabled
            self.publish.ToolTip = self.app.publish_tooltip

        def post(self, callback):
            """Run ``callback`` on the Eto UI thread.

            Revit dispatches ``IExternalEventHandler.Execute`` on its own main
            thread, which in Rhino.Inside.Revit is also the thread that owns
            this window - so a direct call is normally right. "Normally" is
            not a guarantee to hang a write path on, and ``Invoke`` is a
            no-op when already on the UI thread, so it is always used. If Eto
            cannot marshal, the callback still runs rather than being lost.
            """
            try:
                #: An explicit System.Action, for the same reason every event
                #: delegate here is explicit: an implicit conversion is one of
                #: the things that differs between the two host runtimes.
                EF.Application.Instance.Invoke(System.Action(callback))
            except Exception:
                callback()

        def refresh_history_grid(self):
            """Rebuild the History table and restore the selection by key.

            Read-only. Nothing here touches planning or publish state: it
            cannot approve, invalidate or queue anything.
            """
            rows = self.app.history_table_rows()
            self.history_rows_shown = rows
            values = [["" if row.get(key) is None else str(row.get(key))
                       for _heading, key, _width in hv.COLUMNS]
                      for row in rows]
            store = self.make_grid_store(values)
            self.history_grid.DataStore = store
            #: Measured on the control, never on the Python list - the 8D
            #: lesson. `Rows rendered` once reported success while the live
            #: grid was empty.
            shown = count_of(self.history_grid.DataStore)

            if not rows:
                self.history_notice.Text = (
                    "No publish history for this package yet.")
            else:
                self.history_notice.Text = (
                    "%d publish log entr%s, newest first. Rows shown: %s."
                    % (len(rows), "y" if len(rows) == 1 else "ies", shown))

            self.app.reconcile_history_selection()
            index = self.app.selected_history_index()
            self._syncing = True
            try:
                #: Restored only when the same logical entry is still present;
                #: otherwise the grid is left unselected.
                self.history_grid.SelectedRow = index if index >= 0 else -1
            except Exception:
                pass
            finally:
                self._syncing = False
            self.history_detail.Text = _history_detail_text(
                self.app.history_detail())
            self.export_report_button.Enabled = (
                self.app.publish_report_enabled)
            return shown

        def refresh_project_grid(self):
            """Rebuild the project review table. Never fires a selection."""
            rows = self.app.project_rows()
            self.project_rows_shown = rows
            values = [["" if row.get(key) is None else str(row.get(key))
                       for _heading, key, _width in vm.PROJECT_COLUMNS]
                      for row in rows]
            self._syncing = True
            try:
                self.project_grid.DataStore = self.make_grid_store(values)
                index = [i for i, row in enumerate(rows) if row["Selected"]]
                self.project_grid.SelectedRow = index[0] if index else -1
            except Exception:
                pass
            finally:
                self._syncing = False
            self.project_totals_text.Text = _pairs_text(
                self.app.project_totals(), 32)
            selected = [row for row in rows if row["Selected"]]
            self.project_notice.Text = (
                "%s  |  %s  |  %s"
                % (selected[0]["BuildingId"],
                   vm.MODEL_STATE_NOTES[selected[0]["ModelState"]],
                   selected[0]["FreshnessNote"])
                if selected else "No building selected.")
            return len(rows)

        def on_project_row_selected(self, sender, event):
            """Selecting a building. It can only ever discard authorisation.

            Routed through `app.select_project_row`, which routes through
            `select_building` - so the approval and both confirmations are
            invalidated here exactly as they are from the building list.
            """
            if self._syncing:
                return
            index = getattr(self.project_grid, "SelectedRow", -1)
            if index is None or index < 0:
                return
            self.app.select_project_row(index)
            self.refresh()

        def history_selected_index(self):
            index = getattr(self.history_grid, "SelectedRow", -1)
            if index is None or index < 0:
                for candidate in (getattr(self.history_grid, "SelectedRows",
                                          None) or []):
                    return candidate
                return -1
            return index

        def on_history_row_selected(self, sender, event):
            """Read-only. Selecting a row cannot change publish state."""
            if self._syncing:
                return
            self.app.select_history_row(self.history_selected_index())
            self.history_detail.Text = _history_detail_text(
                self.app.history_detail())
            self.export_report_button.Enabled = self.app.publish_report_enabled

        def make_grid_store(self, rows):
            """Every GridView DataStore is built here, and only here.

            ``rows`` is a sequence of value sequences, or of ready GridItems.
            A fresh collection is returned each time, so assigning it replaces
            the previous contents rather than appending to them.

            The type is ``List[Object]`` where available - see
            :func:`resolve_object_list` for why ``ArrayList`` is not enough.
            """
            store = STORE_TYPE()
            for values in rows:
                if isinstance(values, EF.GridItem):
                    item = values
                else:
                    #: GridItem's params overload, splatted into positional
                    #: arguments. A list or dict passed whole would bind as a
                    #: single cell instead of spreading across the columns.
                    item = EF.GridItem(*values)
                store.Add(item)
            return store

        def refresh_buildings(self):
            """Rebuild the building list without firing a selection change."""
            rows = self.app.building_list()
            ids = [r["BuildingId"] for r in rows]
            if ids == self._building_ids:
                return
            self._building_ids = ids
            self.buildings.Items.Clear()
            for row in rows:
                self.buildings.Items.Add(
                    "%s  %s  %s  %s floors  %s"
                    % (row["BuildingId"], row["Name"], row["Program"],
                       row["FloorCount"], row["FootprintArea"]))
            if self.app.state.building_id in ids:
                self.buildings.SelectedIndex = ids.index(
                    self.app.state.building_id)

        #: Everything that could change the setup while an approved request
        #: is pending in Revit. The approved plan must still describe the
        #: world when the handler runs, so none of it may move.
        LOCKED_WHILE_IN_FLIGHT = (
            "browse_source_button", "browse_manifest_button", "detect_button",
            "buildings", "use_active_button", "browse_expected_button",
            "refresh_button", "analyse_button", "plan_button",
            "publish_mode", "obsolete_action", "confirm_publish_box",
            "confirm_delete_box", "delete_word", "publish")

        def apply_lock(self):
            locked = self.app.controls_locked
            for name in self.LOCKED_WHILE_IN_FLIGHT:
                control = getattr(self, name, None)
                if control is None:
                    continue
                if name == "publish" and not locked:
                    continue          # its own gate decides
                control.Enabled = not locked
            return locked

        def refresh_grid(self, reason="refresh"):
            """Rebuild the grid, recording what crossed each boundary.

            Every count below is measured on a different side of a boundary
            that has failed before, so a future failure names itself instead
            of having to be reproduced.
            """
            self._sequence = getattr(self, "_sequence", 0) + 1
            plan_rows = self.app.plan_rows()
            self._rows = plan_rows
            self.headline.Text = self.app.plan_headline()

            values = [["" if row.get(key) is None else str(row.get(key))
                       for _heading, key, _width in PLAN_COLUMNS]
                      for row in self._rows]
            store = self.make_grid_store(values)
            before = count_of(store)
            self.grid.DataStore = store
            #: Read back from the control, not from the local variable: the
            #: question is what the grid holds, not what we handed it.
            assigned = self.grid.DataStore
            after = count_of(assigned)

            self.record_capabilities(store, assigned, before, after, reason,
                                     len(plan_rows))
            self.grid_diagnostic.Text = (
                "plan rows %s | renderer %d | store %s (%s) | grid %s | "
                "seq %d | %s"
                % (len(plan_rows), len(self._rows), before,
                   type(store).__name__, after, self._sequence, reason))
            self.detail.Text = _detail_text(None)
            return after

        def record_capabilities(self, store, assigned=None, before=None,
                                after=None, reason="refresh", plan_rows=None):
            """What this host actually supports, and what the grid received.

            `Rows rendered` previously reported ``len(self._rows)`` - the
            Python list length. That is the wrong side of the boundary: it
            says what we intended to display, not what the grid holds, and it
            reported success while the live grid showed nothing. Every count
            here is now measured on the control.
            """
            def described(value):
                try:
                    return type(value).__name__
                except Exception:
                    return "(unknown)"

            def prop(name, default="(unavailable)"):
                try:
                    return getattr(self.grid, name)
                except Exception:
                    return default

            first = None
            try:
                for item in (assigned if assigned is not None else store):
                    first = item
                    break
            except Exception:
                first = None

            self.app.state.runtime_capabilities = {
                "Runtime": runtime_name(),
                "GridItemCollection available": HAS_GRID_ITEM_COLLECTION,
                "Grid refresh sequence": getattr(self, "_sequence", 0),
                "Last refresh reason": reason,
                "Plan rows from app": (len(self._rows) if plan_rows is None
                                       else plan_rows),
                "Renderer rows (_rows)": len(self._rows),
                "Filters active": ", ".join(self.app.filters) or "(none)",
                "Store type built": described(store),
                "Store count before assign": before,
                "DataStore type after assign": described(assigned),
                "DataStore count after assign": after,
                "First item type": described(first) if first is not None
                                   else "(no rows)",
                "First item value count": (len(getattr(first, "Values", []))
                                           if first is not None else 0),
                "GridView columns": len(prop("Columns", [])),
                "GridView column cell indexes": ", ".join(
                    str(getattr(c.DataCell, "Index", "?"))
                    for c in prop("Columns", [])),
                "GridView Visible": prop("Visible"),
                "GridView Enabled": prop("Enabled"),
                "GridView Height": prop("Height"),
            }
            return self.app.state.runtime_capabilities

    return PlanningWindow


def create_window(app, modules=None):
    """Build the window over ``app``.

    ``modules`` lets the runtime harness substitute stand-ins for Eto and
    System; live callers leave it None.
    """
    with Checkpoint("load Eto") as step:
        step.building("import Eto.Forms, Eto.Drawing, System", "(modules)")
        loaded = modules or load_eto()
    with Checkpoint("define window type") as step:
        step.building("class PlanningWindow(EF.Form)", "Form")
        factory = window_type(loaded)
    with Checkpoint("create Form") as step:
        #: No constructor arguments - see rule 2 in the module docstring.
        step.building("PlanningWindow()", "Form")
        window = factory()
    return window.bind(app)
