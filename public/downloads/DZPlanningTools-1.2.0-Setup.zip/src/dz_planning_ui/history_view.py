"""Tab 4 - the publish history, as plain data.

Pure Python. No Eto, no Revit, no controller, and **no write of any kind**.
The Phase 7 publish log is append-only; this module reads it and nothing else.
There is no code path here that opens a file, edits an entry, reorders history
or "cleans it up".

Two projections, both read-only:

:func:`rows`
    One table row per entry, newest first - what the grid renders.
:func:`detail`
    Everything about one selected entry - what the detail panel renders.

Historical entries are shown as they were written. Where a log contradicts
itself the contradiction is surfaced with the authoritative source named; it is
never reconciled, hidden or silently repaired. See :func:`csv_contradicts`.
"""

from dz_revit_publisher import datetime_compat

from . import formatting as fmt

CSV_DISAGREEMENT_WARNING = (
    "This historical run predates the ElementId reporting fix. The CSV rows "
    "record OldElementId == NewElementId for replaced floors. The JSON entry "
    "below is authoritative; the CSV is append-only and has not been rewritten."
)

#: The publish log's own field names. The UI reads what `phase07c_log`
#: actually writes: `PublishTimestamp`, `PublishStatus` and `BaselineRvtPath`.
#: Reading `Timestamp`/`Status`/`RevitModelPath` instead made every one of the
#: 41 historical entries render as "unavailable", which looked like a defect in
#: the log rather than in this view.
TIMESTAMP_KEYS = ("PublishTimestamp", "Timestamp")
STATUS_KEYS = ("PublishStatus", "Status")
RVT_PATH_KEYS = ("BaselineRvtPath", "RevitModelPath", "RvtPath")

#: Shown for an entry carrying a genuine `UserClickTimestamp`. A publish that
#: really wrote must be distinguishable at a glance from a preview or a
#: validation run. Text, not colour: the marker has to survive a greyscale
#: screenshot and a screen reader, so the word is carried alongside the glyph.
CLICKED = "* clicked"
NOT_CLICKED = "preview"

#: Terminal statuses that mean the transaction group was rolled back.
ROLLED_BACK = "ROLLED BACK"

#: Every counter that represents a real model write. Shared with
#: `view_models.WRITE_COUNTERS`; duplicated deliberately rather than imported,
#: because this module must not depend on the publish-tab view model.
WRITE_COUNTERS = ("identityMigrated", "parametersUpdated", "bindingsWritten",
                  "projectValuesUpdated", "levelsUpdated",
                  "levelParametersUpdated", "floorsCreated", "floorsReplaced",
                  "floorsGeometryEditedInPlace", "boundarySetsDeleted",
                  "boundarySetsCreated", "boundariesReplaced", "areasCreated",
                  "areasReplaced", "areasReassociated", "obsoleteMarked",
                  "obsoleteDeleted")

NO_CHANGES = "no changes written"
ROLLED_BACK_SUMMARY = "rolled back - nothing assimilated"


def first(entry, keys):
    for key in keys:
        value = entry.get(key)
        if value:
            return value
    return None


def clicked(entry):
    """True when a genuine operator click produced this entry.

    The distinction is safety-relevant: it is how an operator tells a run that
    actually wrote to the model from a preview or validation run.
    """
    return bool((entry or {}).get("UserClickTimestamp"))


def rolled_back(entry):
    entry = entry or {}
    results = entry.get("Results") or {}
    if results.get("rollbackOccurred"):
        return True
    return first(entry, STATUS_KEYS) == ROLLED_BACK


def wrote_nothing(results):
    """True when every write counter is zero - the idempotency signature."""
    if not results:
        return False
    return all(not results.get(name) for name in WRITE_COUNTERS)


def write_summary(entry):
    """One phrase for what this entry did to the model.

    A rolled-back run and a no-change run both write nothing, and they are
    different things. Neither may be described as the other.
    """
    entry = entry or {}
    results = entry.get("Results") or {}
    if rolled_back(entry):
        return ROLLED_BACK_SUMMARY
    if not results:
        return fmt.UNAVAILABLE
    if wrote_nothing(results):
        return NO_CHANGES
    parts = []
    for name in ("floorsCreated", "floorsReplaced", "areasCreated",
                 "areasReplaced", "areasReassociated", "parametersUpdated",
                 "obsoleteMarked", "obsoleteDeleted"):
        value = results.get(name)
        if value:
            parts.append("%s %s" % (name, value))
    return ", ".join(parts) if parts else NO_CHANGES


def element_id_map(entry):
    """Old -> new ElementId pairs, floors then areas.

    Mandatory disclosure wherever a replacement occurred. A ragged pair - more
    old ids than new, or the reverse - is reported rather than dropped.
    """
    results = (entry or {}).get("Results") or {}
    pairs = []
    for old_key, new_key, kind in (
            ("floorOldElementIds", "floorNewElementIds", "Floor"),
            ("areaOldElementIds", "areaNewElementIds", "Area")):
        old_ids = [str(i) for i in (results.get(old_key) or [])]
        new_ids = [str(i) for i in (results.get(new_key) or [])]
        for index, old_id in enumerate(old_ids):
            new_id = new_ids[index] if index < len(new_ids) else "(unrecorded)"
            pairs.append((kind, old_id, new_id))
        for extra in new_ids[len(old_ids):]:
            pairs.append((kind, "(unrecorded)", extra))
    return pairs


def csv_contradicts(entry, csv_rows):
    """True when the CSV claims an id was unchanged but the JSON says otherwise.

    The Scenario 3 primary publish wrote `old == new` for replaced floors. That
    row is wrong and cannot be corrected - the log is append-only. Surfacing it
    is the only honest option.
    """
    results = (entry or {}).get("Results") or {}
    if not results.get("floorsReplaced"):
        return False
    old = [str(i) for i in (results.get("floorOldElementIds") or [])]
    new = [str(i) for i in (results.get("floorNewElementIds") or [])]
    if not old or old == new:
        return False
    stamps = set(str(entry.get(key) or "") for key in
                 ("RunId", "PublishTimestamp", "Timestamp",
                  "UserClickTimestamp")) - set([""])
    for row in (csv_rows or []):
        row_stamp = str(row.get("RunId") or row.get("Timestamp") or "")
        if stamps and row_stamp not in stamps:
            continue
        if row.get("Action") == "MIGRATE":
            continue
        if (row.get("OldElementId")
                and row.get("OldElementId") == row.get("NewElementId")):
            return True
    return False


# -- the table --------------------------------------------------------------

#: (heading, row key, width). The window builds its columns from this, so a
#: column cannot exist in one place and not the other.
COLUMNS = (
    ("When", "Timestamp", 150),
    ("Click", "Click", 70),
    ("Building", "BuildingId", 70),
    ("Status", "Status", 170),
    ("Mode", "PublishMode", 130),
    ("Transaction", "TransactionResult", 110),
    ("Wrote", "WriteSummary", 300),
    ("Skipped", "Skipped", 70),
    ("Replaced", "Replaced", 70),
)


def row(entry, csv_rows=None):
    """One table row. Values are the log's own, formatted but never altered."""
    entry = entry or {}
    results = entry.get("Results") or {}
    return {
        "Timestamp": fmt.optional(first(entry, TIMESTAMP_KEYS)),
        "Click": CLICKED if clicked(entry) else NOT_CLICKED,
        "Clicked": clicked(entry),
        "BuildingId": fmt.optional(entry.get("BuildingId")),
        "Status": fmt.optional(first(entry, STATUS_KEYS)),
        "PublishMode": fmt.optional(entry.get("PublishMode")),
        "TransactionResult": fmt.optional(entry.get("TransactionResult")),
        "WriteSummary": write_summary(entry),
        "Skipped": str(results.get("skipped") or 0),
        "Replaced": str(results.get("floorsReplaced") or 0),
        "RolledBack": rolled_back(entry),
        "CsvDisagreement": csv_contradicts(entry, csv_rows),
        "Key": entry_key(entry),
    }


def entry_key(entry):
    """A stable identity for one log entry, for selection across reloads.

    The log has no id field, so identity is composed from what a publish
    cannot change about itself after the fact. Position is deliberately not
    used: a reload that prepends a new entry would otherwise silently move the
    selection onto a different record.
    """
    entry = entry or {}
    return "|".join(str(entry.get(key) or "") for key in
                    ("PublishTimestamp", "Timestamp", "UserClickTimestamp",
                     "PublishStatus", "Status", "BuildingId",
                     "TransactionResult"))


def entries_of(payload):
    """The raw entries, newest first, without projecting them.

    Ordered by the parsed publish timestamp rather than by file order, so
    entries written in different sessions - or in different time zones - sort
    correctly. Entries with an unreadable timestamp keep their file order at
    the end rather than being dropped.
    """
    entries = (payload or {}).get("Entries") or []
    ordered = sorted(
        enumerate(entries),
        key=lambda pair: (datetime_compat.sort_key(
            first(pair[1], TIMESTAMP_KEYS), "PublishTimestamp"), pair[0]),
        reverse=True)
    return [entry for _index, entry in ordered]


def rows(payload, csv_rows=None):
    """Every entry as a table row, newest first."""
    return [row(entry, csv_rows) for entry in entries_of(payload)]


# -- the detail panel -------------------------------------------------------

def stage_rows(entry):
    """The nine executor stages of one entry, in order.

    Reads `Status`, which is what `executor.Stage.as_dict` writes. Reading
    `Result` - a key no stage has ever carried - is what made all nine rows of
    the first successful live publish render `unavailable`.
    """
    out = []
    for stage in ((entry or {}).get("StageResults") or []):
        detail = list(stage.get("Detail") or [])
        if stage.get("Error"):
            detail.append("ERROR: %s" % stage["Error"])
        out.append((str(stage.get("Stage")), fmt.optional(stage.get("Name")),
                    fmt.optional(stage.get("Status")),
                    "; ".join(str(part) for part in detail)))
    return out


def failing_stage(entry):
    """The first stage that did not succeed, or None."""
    for stage in ((entry or {}).get("StageResults") or []):
        status = str(stage.get("Status") or "").lower()
        if status not in ("ok", "skipped", "pending", "not reached"):
            return ("%s %s" % (stage.get("Stage"),
                               fmt.optional(stage.get("Name"))),
                    fmt.optional(stage.get("Error")))
    return None


def identity_rows(entry):
    """What this publish was, and what it was published from."""
    entry = entry or {}
    return [
        ("Timestamp", fmt.optional(first(entry, TIMESTAMP_KEYS))),
        ("User click", fmt.optional(entry.get("UserClickTimestamp"))),
        ("Publish kind", CLICKED if clicked(entry) else NOT_CLICKED),
        ("Building", fmt.optional(entry.get("BuildingId"))),
        ("Building SourceId", fmt.optional(entry.get("BuildingSourceId"))),
        ("Project / Option / Revision",
         "%s / %s / %s" % (fmt.optional(entry.get("ProjectId")),
                           fmt.optional(entry.get("Option")),
                           fmt.optional(entry.get("Revision")))),
        ("Revit model", fmt.full_path(first(entry, RVT_PATH_KEYS))),
        ("Revit document", fmt.optional(entry.get("RevitDocumentName"))),
        ("Manifest", fmt.full_path(entry.get("ManifestPath"))),
        ("Manifest SHA-256", fmt.optional(entry.get("ManifestSha256"))),
        ("Source model SHA-256", fmt.optional(entry.get("SourceModelHash"))),
        ("Baseline RVT SHA-256", fmt.optional(entry.get("BaselineRvtSha256"))),
        ("Publish mode", fmt.optional(entry.get("PublishMode"))),
        ("Obsolete action", fmt.optional(entry.get("ObsoleteAction"))),
        ("Confirm delete", str(entry.get("ConfirmDelete"))),
        ("Publisher version", fmt.optional(entry.get("PublisherVersion"))),
    ]


def outcome_rows(entry):
    """What happened to the model. The rolled-back case is stated, not implied."""
    entry = entry or {}
    results = entry.get("Results") or {}
    out = [
        ("Status", fmt.optional(first(entry, STATUS_KEYS))),
        ("Transaction", fmt.optional(entry.get("TransactionResult"))),
        ("Outcome", write_summary(entry)),
    ]
    if rolled_back(entry):
        out.append(("Model", "No change was assimilated. The transaction "
                             "group was rolled back."))
        failure = failing_stage(entry)
        if failure:
            out.append(("Failing stage", failure[0]))
            out.append(("Stage error", failure[1]))
    elif wrote_nothing(results):
        out.append(("Model", "Zero model changes were written. Every write "
                             "counter is zero."))
    return out


def detail(entry, csv_rows=None):
    """Everything about one selected entry. Read-only projection.

    `is None` means "nothing selected". An entry that happens to carry no
    fields is still an entry and still projects - a degenerate log record
    should render as empty, not vanish.
    """
    if entry is None:
        return None
    return {
        "Identity": identity_rows(entry),
        "Outcome": outcome_rows(entry),
        "Stages": stage_rows(entry),
        "Counters": fmt.counter_rows(entry.get("Results") or {}),
        "ElementIdMap": element_id_map(entry),
        "Warnings": list(entry.get("Warnings") or []),
        "Errors": list(entry.get("Errors") or []),
        "FinalValidation": list(entry.get("FinalValidation") or []),
        "Clicked": clicked(entry),
        "RolledBack": rolled_back(entry),
        "CsvDisagreement": csv_contradicts(entry, csv_rows),
        "AuthoritativeSource": "JSON",
        "CsvWarning": (CSV_DISAGREEMENT_WARNING
                       if csv_contradicts(entry, csv_rows) else ""),
    }


# -- the Phase 8C projection, retained ---------------------------------------
#
# `history_entry` and `history_entries` are what Tab 4 rendered before 8F and
# what the 8C tests assert. Kept here, unchanged in behaviour, so the move out
# of `view_models` is behaviour-preserving.

def history_entry(entry, csv_rows=None):
    results = entry.get("Results") or {}
    disagreement = csv_contradicts(entry, csv_rows)
    return {
        "Timestamp": fmt.optional(first(entry, TIMESTAMP_KEYS)),
        "UserClickTimestamp": fmt.optional(entry.get("UserClickTimestamp")),
        "RvtPath": fmt.full_path(first(entry, RVT_PATH_KEYS)),
        "ManifestSha256": fmt.optional(entry.get("ManifestSha256")),
        "SourceModelHash": fmt.optional(entry.get("SourceModelHash")),
        "Status": fmt.optional(first(entry, STATUS_KEYS)),
        "TransactionResult": fmt.optional(entry.get("TransactionResult")),
        "Counters": fmt.counter_rows(results),
        "Warnings": list(entry.get("Warnings") or []),
        "Errors": list(entry.get("Errors") or []),
        "ElementIdMap": list(zip(
            [str(i) for i in (results.get("floorOldElementIds") or [])],
            [str(i) for i in (results.get("floorNewElementIds") or [])])),
        "CsvDisagreement": disagreement,
        "AuthoritativeSource": "JSON",
        "CsvWarning": CSV_DISAGREEMENT_WARNING if disagreement else "",
    }


def history_entries(payload, csv_rows=None):
    """Newest first. Reads only; the log is append-only and stays that way."""
    return [history_entry(entry, csv_rows) for entry in entries_of(payload)]
