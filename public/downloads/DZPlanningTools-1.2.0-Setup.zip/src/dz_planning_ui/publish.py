"""The publish session: state machine, and the frozen approved plan.

Pure Python. No Eto, no Revit, and - deliberately - no import of
``controller.publish``. This module decides *whether* a publish may be
requested and *what exactly* was approved; it never performs one.

The central idea is that confirmation freezes a decision. What the operator
saw and agreed to is captured as a canonical byte string and sealed with a
SHA-256 digest. Nothing downstream may act on anything else: at execution time
the plan is re-derived in a valid Revit context and must reproduce that digest
exactly, or the publish is blocked. A plan is never silently substituted for
the one that was approved.
"""

import copy
import hashlib
import json
import uuid

# -- state machine ----------------------------------------------------------
#
# Phase 8E reports coarse states only. Stage-by-stage progress needs a callback
# threaded through the executor, and the executor is frozen until 8F.

READY = "READY"
WAITING_FOR_REVIT = "WAITING FOR REVIT"
PUBLISHING = "PUBLISHING"
DONE = "DONE"
BLOCKED = "BLOCKED"
ROLLED_BACK = "ROLLED BACK"
FAILED = "FAILED"

#: A request is outstanding; the model may be being written.
IN_FLIGHT = (WAITING_FOR_REVIT, PUBLISHING)
#: The request is over, whatever the outcome.
TERMINAL = (DONE, BLOCKED, ROLLED_BACK, FAILED)

PREVIEW_ONLY = "Preview Only"
PUBLISH_MODES = (PREVIEW_ONLY, "Create or Update", "Update Existing Only")
#: What the operator may choose. `Archive` was removed in V1.1: it executed
#: exactly as `Mark Only` - the executor branches on the obsolete action in one
#: place and compares against `Delete` - so it offered a third choice with no
#: third behaviour, in the dropdown that also contains the destructive one.
#:
#: The engine constant survives in `change_detection` so historical log and
#: report rows that record `Archive` remain readable. Nothing reinterprets
#: them; they are simply not producible any more.
OBSOLETE_ACTIONS = ("Mark Only", "Delete")

#: Retired, and named so a request carrying it can be refused by name rather
#: than falling through a generic "unknown value" path.
RETIRED_ACTIONS = ("Archive",)
DELETE = "Delete"


# -- diagnostics ------------------------------------------------------------
#
# The first live publish collapsed to `FAILED / unavailable / unavailable`
# because the only record of the exception was a string folded into the plan's
# blocker list, where it also - wrongly - invalidated the plan. Every layer now
# records what it reached, and a failure keeps its type, message and traceback.

APPROVED_PLAN = "APPROVED PLAN"
DISPATCH = "DISPATCH"
EXTERNAL_EVENT_RAISE = "EXTERNAL EVENT RAISE"
HANDLER = "HANDLER"
SAFETY_GATE = "SAFETY GATE"
CONTROLLER = "CONTROLLER"
CALLBACK = "CALLBACK"

#: Layers that run before `controller.publish` is entered. A failure in any of
#: them means no transaction was started and the model was never opened for
#: writing - which is a different thing from a rollback, and must read
#: differently.
PRE_WRITE_LAYERS = (APPROVED_PLAN, DISPATCH, EXTERNAL_EVENT_RAISE, HANDLER,
                    SAFETY_GATE)


def exception_detail(exc):
    """Everything recoverable about a failure, Python or .NET.

    IronPython surfaces a .NET exception as a Python one whose useful parts -
    the CLR type name, the managed stack trace, the inner exception - hang off
    attributes that ``str(exc)`` throws away. Each is read defensively,
    because the whole point of this function is to run when things are broken.
    """
    detail = {"Type": type(exc).__name__, "Message": str(exc),
              "Traceback": None, "ClrType": None, "StackTrace": None,
              "Inner": None}
    try:
        import traceback
        detail["Traceback"] = traceback.format_exc()
    except Exception:
        pass
    #: IronPython hangs the managed exception off `clsException`; pythonnet
    #: exposes the .NET members directly on the Python exception.
    managed = getattr(exc, "clsException", None) or exc
    try:
        get_type = getattr(managed, "GetType", None)
        if callable(get_type):
            detail["ClrType"] = str(get_type().FullName)
    except Exception:
        pass
    try:
        stack = getattr(managed, "StackTrace", None)
        if stack:
            detail["StackTrace"] = str(stack)
    except Exception:
        pass
    try:
        inner = getattr(managed, "InnerException", None)
        if inner is not None:
            detail["Inner"] = "%s: %s" % (inner.GetType().FullName,
                                          inner.Message)
    except Exception:
        pass
    return detail


class PublishTrace(object):
    """One publish attempt, recorded across every layer it touches.

    Carried on the :class:`ApprovedPlan` but deliberately *outside* the sealed
    payload: it is written to after sealing, by every layer, and must never
    disturb the digest.
    """

    def __init__(self):
        self.steps = []
        self.failure = None

    def step(self, layer, event, detail=None):
        self.steps.append({"Layer": layer, "Event": event,
                           "Detail": None if detail is None else str(detail)})
        return self

    def fail(self, layer, exc, note=None):
        """Record the exception that ended the attempt, in full."""
        self.failure = {"Layer": layer, "Note": note}
        self.failure.update(exception_detail(exc))
        return self.step(layer, "threw", "%s: %s" % (self.failure["Type"],
                                                     self.failure["Message"]))

    def reached(self, layer, event=None):
        for entry in self.steps:
            if entry["Layer"] == layer and (event is None
                                            or entry["Event"] == event):
                return True
        return False

    @property
    def failed_layer(self):
        return (self.failure or {}).get("Layer")

    @property
    def before_write(self):
        """True when the attempt ended before `controller.publish` ran."""
        if not self.reached(CONTROLLER, "entered"):
            return True
        return False

    def as_rows(self):
        return [("%d. %s" % (i + 1, entry["Layer"]),
                 entry["Event"] + ("  -  " + entry["Detail"]
                                   if entry["Detail"] else ""))
                for i, entry in enumerate(self.steps)]


# -- development validation -------------------------------------------------
#
# The forced-rollback proof needs one deliberate failure inside the Phase 7
# TransactionGroup. That hook is development-only, and the danger is not that
# it exists but that a session could be running with it armed - or *not* armed -
# without the operator being able to see which. So it is an explicit object,
# injected by the validation launcher and carried through the same graph the
# production window uses. It is never reachable from a control, and it is
# rendered in the title, the safety strip and the confirmation modal whenever
# it is on.

#: The only stage the validation gate accepts. Stage 5 fails *after* stages
#: 1-4 have committed real work, so only a group rollback can undo it.
REQUIRED_STAGE = 5

#: The request key `controller.publish` actually reads. Snake case, not the
#: PascalCase the result payloads use - the executor parameter is
#: `fail_at_stage` and the controller reads `request.force_fail_at_stage`.
FORCE_FAIL_KEY = "force_fail_at_stage"

NOT_ARMED = "ROLLBACK VALIDATION NOT ARMED"
#: Carries the banner phrase, so what the operator reads in the refusal is the
#: same wording they see on screen.
NOT_ARMED_DETAIL = (
    "%s. The request does not carry ForceFailAtStage = %d. Publishing is "
    "refused: a validation session must never silently fall back to a normal "
    "publish." % (NOT_ARMED, REQUIRED_STAGE))
CHANNEL_NOT_READY = (
    "The Revit ExternalEvent channel is not ready. Rollback validation "
    "requires the real publish pipeline.")


class ValidationConfig(object):
    """Whether this session is a development validation run, and how.

    Inactive by default and inactive for every production launch. There is no
    setter, no control and no request parameter that can turn it on: the
    validation launcher constructs one and injects it into
    :func:`~dz_planning_ui.app.launch`.
    """

    def __init__(self, rollback_validation_active=False,
                 force_fail_at_stage=None):
        self.rollback_validation_active = bool(rollback_validation_active)
        self.force_fail_at_stage = force_fail_at_stage

    @property
    def active(self):
        return self.rollback_validation_active

    @property
    def armed(self):
        """Active *and* correctly configured. Anything else refuses."""
        return (self.rollback_validation_active
                and self.force_fail_at_stage == REQUIRED_STAGE)

    @property
    def title_suffix(self):
        return "FORCED ROLLBACK VALIDATION" if self.active else None

    def rows(self):
        """What the window must show. Empty for a production session."""
        if not self.active:
            return []
        return [("Validation mode", "FORCED ROLLBACK"),
                ("ForceFailAtStage",
                 str(self.force_fail_at_stage)
                 if self.force_fail_at_stage is not None else NOT_ARMED)]

    def apply_to(self, request):
        """Add the hook to an outgoing request. Only when armed."""
        if self.armed:
            request[FORCE_FAIL_KEY] = self.force_fail_at_stage
        return request

    def request_is_armed(self, request):
        """True when ``request`` carries exactly the expected hook."""
        return (request or {}).get(FORCE_FAIL_KEY) == REQUIRED_STAGE


#: The production default. Shared, and never mutated - `apply_to` is the only
#: method that writes anything, and it writes to the caller's request.
PRODUCTION = ValidationConfig()


def canonical(payload):
    """One byte string for one decision.

    Sorted keys and fixed separators, so two dictionaries that mean the same
    thing serialise identically and a digest comparison is meaningful.
    """
    return json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, default=str)


def digest_of(payload):
    return hashlib.sha256(canonical(payload).encode("utf-8")).hexdigest()


def replacement_ids(plan):
    """Every ElementId that will be physically replaced, in plan order."""
    from . import formatting as fmt
    ids = []
    for row in (list((plan or {}).get("Changes") or [])
                + list((plan or {}).get("Obsolete") or [])):
        if fmt.is_replacement(row.get("FloorAction")):
            current = row.get("ElementId") or row.get("PreviousElementId")
            if current is not None:
                ids.append(str(current))
    return ids


def projection(state, session, confirmed_at=None, token=None):
    """The curated record of what is being approved.

    A projection rather than the whole controller response: it carries every
    field the decision depends on and nothing incidental, so the digest is
    stable across re-derivation in the Revit context.
    """
    payload = state.plan or {}
    plan = payload.get("Plan") or {}
    analysis = state.analysis or {}
    return {
        "ExpectedRvtPath": state.expected_rvt_path,
        "BuildingId": state.building_id,
        "ManifestPath": state.manifest_path,
        "ManifestSha256": analysis.get("ManifestSha256"),
        "SourcePath": state.source_3dm_path,
        "SourceModelHash": analysis.get("SourceModelHash"),
        "PlanStatus": payload.get("PublishStatus") or payload.get("Status"),
        "PublishMode": session.mode,
        "ObsoleteAction": session.obsolete_action,
        "Counts": dict(plan.get("Counts") or {}),
        "Expected": dict(plan.get("Expected") or {}),
        "ReplacementElementIds": replacement_ids(plan),
        "Plan": plan,
        "ConfirmedAt": confirmed_at,
        "Token": token,
    }


class ApprovedPlan(object):
    """One confirmation, held as two independent representations.

    **The canonical projection** is JSON-safe, deterministic and sealed with a
    SHA-256 digest. It is what the digest check verifies.

    **The frozen executable plan** is a deep copy of the exact planned payload
    the operator confirmed, including the live ``ChangePlan`` object. It is
    what actually executes.

    Both are deep-copied on the way in, so nothing the UI does afterwards can
    reach either. The executable plan is *never* regenerated: the handler runs
    this object, and if context has drifted it blocks. Re-deriving a plan at
    execution time - even to compare it - is one refactor away from silently
    publishing something the operator never saw.
    """

    def __init__(self, payload, executable=None, trace=None,
                 validation=None):
        self._payload = copy.deepcopy(payload)
        #: The validation configuration this record was sealed under. Travels
        #: with the record through the dispatcher and the ExternalEvent, so
        #: the handler can re-check it without reaching back into the UI - and
        #: so no module reload can leave a half-configured session behind.
        self.validation = validation or PRODUCTION
        #: Deliberately outside the seal: written to after sealing, by every
        #: layer, and never part of the canonical payload or the digest.
        self.trace = trace if trace is not None else PublishTrace()
        #: An independent copy. It must not alias `state.plan` or anything
        #: else the UI still holds a reference to.
        self._executable = copy.deepcopy(executable) if executable else None
        self.canonical = canonical(self._payload)
        self.digest = hashlib.sha256(
            self.canonical.encode("utf-8")).hexdigest()

    @property
    def executable(self):
        """The frozen planned payload, passed straight to `controller.publish`.

        Returned as the stored object, not a copy: this *is* the plan being
        executed, and the executor records its results onto it.
        """
        return self._executable

    @property
    def has_executable(self):
        return bool(self._executable and self._executable.get("_plan"))

    def executable_projection(self):
        """Project the frozen executable plan the same way the seal was made.

        Serialised from the ``ChangePlan`` **object** rather than from the
        payload's cached `Plan` dictionary. The object is what executes, so
        the object is what must be verified: reading the cached dictionary
        would compare the seal against a copy of itself and pass even if the
        plan behind it had been altered.

        `as_dict()` is a pure read - no controller call, no classification.
        """
        if not self.has_executable:
            return None
        payload = copy.deepcopy(self._payload)
        try:
            plan = self._executable["_plan"].as_dict()
        except Exception:
            return None
        payload["Plan"] = plan
        payload["Counts"] = dict(plan.get("Counts") or {})
        payload["Expected"] = dict(plan.get("Expected") or {})
        payload["ReplacementElementIds"] = replacement_ids(plan)
        payload["PlanStatus"] = (self._executable.get("PublishStatus")
                                 or self._executable.get("Status"))
        return payload

    def verify_executable(self):
        """The frozen plan still projects to exactly what was sealed.

        A consistency check between the two representations, performed on
        stored data. It does not re-plan anything.
        """
        projected = self.executable_projection()
        if projected is None:
            return False
        return canonical(projected) == self.canonical

    @property
    def payload(self):
        """A copy. Callers may do what they like with it."""
        return copy.deepcopy(self._payload)

    def get(self, key, default=None):
        return copy.deepcopy(self._payload.get(key, default))

    @property
    def token(self):
        return self._payload.get("Token")

    def verify(self):
        """True when the sealed payload still digests to the sealed value."""
        return digest_of(self._payload) == self.digest

    def matches(self, other_payload):
        """True when a freshly derived projection is byte-identical."""
        return canonical(other_payload) == self.canonical

    def _base_request(self):
        """The request as the operator approved it. No development hook."""
        return {
            "manifest_path": self._payload.get("ManifestPath"),
            "source_3dm_path": self._payload.get("SourcePath"),
            "building_id": self._payload.get("BuildingId"),
            "expected_rvt_path": self._payload.get("ExpectedRvtPath"),
            "publish_mode": self._payload.get("PublishMode"),
            "obsolete_action": self._payload.get("ObsoleteAction"),
            #: The only request in the product that sets these.
            "confirm_publish": True,
            "confirm_delete_obsolete":
                self._payload.get("ObsoleteAction") == DELETE,
            "publish": True,
        }

    def as_request(self):
        """The plain request dict `controller.publish` consumes.

        ``force_fail_at_stage`` is added only when a development validation
        configuration was injected *and* is correctly armed. A production
        record carries a :data:`PRODUCTION` config, whose `apply_to` adds
        nothing, so no production publish can carry the hook.
        """
        return self.validation.apply_to(self._base_request())


class PublishSession(object):
    """Everything about the pending or finished publish, and nothing else."""

    def __init__(self):
        self.mode = PREVIEW_ONLY
        self.obsolete_action = "Mark Only"
        self.confirm_publish = False
        self.confirm_delete = False
        self.state = READY
        self.approved = None
        self.result = None
        self.blocking_reason = None

    # -- lifecycle ---------------------------------------------------------
    @property
    def trace(self):
        """The diagnostic record of the last attempt, if there was one."""
        return getattr(self.approved, "trace", None)

    @property
    def failed_before_write(self):
        """True when the attempt ended before `controller.publish` ran.

        An infrastructure failure. Nothing was written, no transaction was
        started, and - the point of asking - the Change Plan the operator
        reviewed did not become wrong because the plumbing broke.
        """
        if self.state != FAILED:
            return False
        trace = self.trace
        return trace is None or trace.before_write

    @property
    def in_flight(self):
        return self.state in IN_FLIGHT

    @property
    def terminal(self):
        return self.state in TERMINAL

    @property
    def wants_write(self):
        return self.mode != PREVIEW_ONLY

    @property
    def deletes_obsolete(self):
        return self.obsolete_action == DELETE

    def approve(self, state, now=None, executable=None, trace=None,
                validation=None):
        """Freeze the decision - both representations. Returns the record.

        ``now`` is the confirmation timestamp and is sealed *into* the
        payload, so it must be generated before this call, not after: the
        digest covers it and nothing may edit it afterwards.
        """
        token = uuid.uuid4().hex
        self.approved = ApprovedPlan(
            projection(state, self, confirmed_at=now, token=token),
            executable=executable, trace=trace, validation=validation)
        self.state = WAITING_FOR_REVIT
        self.result = None
        self.blocking_reason = None
        return self.approved

    def publishing(self):
        self.state = PUBLISHING
        return self.state

    def finish(self, status, result=None, reason=None):
        """Land in a terminal state and clear both confirmations.

        Both reset on *every* terminal outcome - including BLOCKED and FAILED -
        so a second attempt is always a fresh, deliberate decision.
        """
        self.state = status if status in TERMINAL else FAILED
        self.result = result
        self.blocking_reason = reason
        self.confirm_publish = False
        self.confirm_delete = False
        return self.state

    def reset(self):
        self.state = READY
        self.approved = None
        self.result = None
        self.blocking_reason = None
        self.confirm_publish = False
        self.confirm_delete = False
        return self

    def invalidate(self, why=None):
        """Context moved. Any approval is void."""
        if self.state in IN_FLIGHT:
            #: Never discard an approval while Revit may be acting on it.
            return False
        self.approved = None
        self.confirm_publish = False
        self.confirm_delete = False
        if self.state in TERMINAL:
            self.state = READY
        self.blocking_reason = why or self.blocking_reason
        return True
