"""Finding the manifest and the source 3DM, without ever guessing.

Two rules shape everything here.

**Search is bounded.** The manifest is looked for only under the configured
Exports root, and the source only beside the manifest or where the manifest
says it is. Nothing walks the drive.

**Ambiguity is reported, never resolved.** When two candidates are equally
good, detection abstains and hands the operator the list. Picking one would be
a coin flip that looks like a decision - and the wrong source silently
publishes the wrong geometry.

Detection reads. It never creates, moves or modifies a file.
"""

import io
import json
import os

from dz_revit_publisher import datetime_compat, manifest_loader

MANIFEST_NAME = "project_manifest.json"

#: Why a candidate was chosen, for display beside the field.
EXPLICIT = "explicitly selected"
ADJACENT = "the only .3dm beside the manifest"
RECORDED = "recorded by the manifest"
NEWEST = "newest valid export by ExportTimestamp"

#: How the current source came to be selected. Kept separate from the path
#: itself: a populated path is not evidence that the operator chose it, and
#: treating it as such is what let a previous setup's source survive a
#: manifest change.
MANUAL = "MANUAL"
DETECTED_ADJACENT = "DETECTED_ADJACENT"
MANIFEST_RECORDED = "MANIFEST_RECORDED"
NONE = "NONE"

#: Detection outcomes that the UI may replace freely on re-detection.
REPLACEABLE = (DETECTED_ADJACENT, MANIFEST_RECORDED, NONE)

_PROVENANCE_BY_REASON = {
    EXPLICIT: MANUAL,
    ADJACENT: DETECTED_ADJACENT,
    RECORDED: MANIFEST_RECORDED,
}


def provenance_for(reason):
    """The provenance a detection reason implies."""
    return _PROVENANCE_BY_REASON.get(reason, NONE)

AMBIGUOUS_MANIFEST = (
    "%d manifests share the newest ExportTimestamp (%s). Select one; "
    "detection will not choose between equally current exports.")
AMBIGUOUS_SOURCE = (
    "%d .3dm files sit beside the manifest. Select one; detection will not "
    "choose between them.")


class Detected(object):
    """A detection outcome: a path, why, and what else was considered."""

    def __init__(self, path=None, reason=None, candidates=None,
                 problems=None, ambiguous=False):
        self.path = path
        self.reason = reason
        self.candidates = list(candidates or [])
        self.problems = list(problems or [])
        self.ambiguous = bool(ambiguous)

    def __repr__(self):
        return "Detected(path=%r, reason=%r, ambiguous=%r)" % (
            self.path, self.reason, self.ambiguous)

    @property
    def found(self):
        return bool(self.path)

    def as_dict(self):
        return {
            "Path": self.path,
            "Reason": self.reason,
            "Candidates": list(self.candidates),
            "Problems": list(self.problems),
            "Ambiguous": self.ambiguous,
        }


# -- manifest ---------------------------------------------------------------

def read_manifest(path):
    """`(manifest, problem)`. Invalid JSON is a problem, never an exception."""
    try:
        with io.open(path, "r", encoding="utf-8-sig") as handle:
            return json.load(handle), None
    except ValueError as exc:
        return None, "%s: not valid JSON (%s)" % (path, exc)
    except Exception as exc:
        return None, "%s: unreadable (%s: %s)" % (path, type(exc).__name__, exc)


def manifest_timestamp(manifest, path):
    """The logical export time. Never the filesystem mtime.

    A file copied between machines carries a new mtime and the same export;
    ordering by mtime would call the copy the newer export.
    """
    raw = (manifest.get("exportMetadata") or {}).get("ExportTimestamp")
    return datetime_compat.parse_iso_datetime(
        raw, "exportMetadata.ExportTimestamp", default=None)


def validate_manifest_file(path):
    """`(manifest, timestamp, problem)` for one candidate."""
    manifest, problem = read_manifest(path)
    if problem:
        return None, None, problem
    stamp = manifest_timestamp(manifest, path)
    if stamp is None:
        return None, None, ("%s: no readable exportMetadata.ExportTimestamp"
                            % path)
    return manifest, stamp, None


def detect_manifest(explicit=None, exports_root=None):
    """Precedence: explicit selection, then newest valid export."""
    if explicit:
        if not os.path.isfile(explicit):
            return Detected(problems=["Manifest not found: %s" % explicit])
        _m, _t, problem = validate_manifest_file(explicit)
        if problem:
            #: Surfaced as blocking here, before any live Revit query.
            return Detected(problems=[problem])
        return Detected(explicit, EXPLICIT)

    if not exports_root or not os.path.isdir(exports_root):
        return Detected(problems=["No Exports root to search: %s"
                                  % (exports_root or "(unset)")])

    candidates, problems, scored = [], [], []
    for found in manifest_loader.find_manifests(exports_root):
        candidates.append(found)
        _m, stamp, problem = validate_manifest_file(found)
        if problem:
            problems.append(problem)
            continue
        scored.append((stamp, found))

    if not scored:
        return Detected(candidates=candidates,
                        problems=problems or ["No valid manifest under %s"
                                              % exports_root])

    newest = max(stamp for stamp, _p in scored)
    tied = sorted(path for stamp, path in scored if stamp == newest)
    if len(tied) > 1:
        return Detected(candidates=tied, problems=problems + [
            AMBIGUOUS_MANIFEST % (len(tied), newest.isoformat())],
            ambiguous=True)
    return Detected(tied[0], NEWEST, candidates, problems)


# -- source 3DM -------------------------------------------------------------

def adjacent_sources(manifest_path):
    """Every `.3dm` in the manifest's own folder. One directory, never a walk."""
    if not manifest_path:
        return []
    folder = os.path.dirname(os.path.abspath(manifest_path))
    if not os.path.isdir(folder):
        return []
    return sorted(os.path.join(folder, name)
                  for name in os.listdir(folder)
                  if name.lower().endswith(".3dm")
                  and os.path.isfile(os.path.join(folder, name)))


def recorded_source(manifest, manifest_path):
    """The source the manifest names, if it resolves to a real file.

    `exportMetadata.RhinoFileName` is often a title rather than a path - the
    Phase 6A package records `UNSAVED RHINO DOCUMENT`. Anything that does not
    resolve to an existing `.3dm` is treated as absent, not as a candidate.
    """
    recorded = (manifest or {}).get("exportMetadata", {}).get("RhinoFileName")
    if not recorded or not str(recorded).lower().endswith(".3dm"):
        return None
    if os.path.isabs(recorded) and os.path.isfile(recorded):
        return recorded
    for base in (os.path.dirname(os.path.abspath(manifest_path or ".")),
                 (manifest or {}).get("exportMetadata", {}).get("ExportFolder")):
        if not base:
            continue
        resolved = os.path.join(base, os.path.basename(recorded))
        if os.path.isfile(resolved):
            return resolved
    return None


#: Positive evidence, from the authoritative reader, that a file with a `.3dm`
#: extension is not actually a readable 3DM.
_UNOPENABLE = "could not be opened"

REJECTED_UNREADABLE = (
    "A .3dm was found beside the manifest but Rhino could not open it, so it "
    "was not selected: %s. Choose a source with Browse Source 3DM.")

EXPLICIT_UNREADABLE = "Rhino could not open this .3dm: %s"


def unreadable_reason(path, reader=None):
    """Why `path` is definitely not a readable 3DM, or ``None``.

    Delegates to `source_reader.describe`, the same reader the publish path
    uses, so there is no second copy of 3DM-reading logic here.

    **"Cannot tell" is never "unreadable".** `describe` returns file-level
    facts without Rhino, and on a machine where Rhino is absent every 3DM
    would look unopenable. Rejecting on that would break the read-only UI
    everywhere Rhino is not installed. So this returns a reason only on the
    reader's explicit "could not be opened", and stays silent otherwise.
    """
    if not path:
        return None
    reader = reader or _default_reader()
    if reader is None:
        return None
    try:
        facts = reader(path)
    except Exception:
        #: A validator that throws must not become a way to reject sources.
        return None
    for warning in (facts or {}).get("Warnings") or []:
        if _UNOPENABLE in str(warning):
            return str(warning)
    return None


def _default_reader():
    """`source_reader.describe`, imported lazily.

    Lazy because `detection` is imported by offline tests on machines with no
    Rhino, and because a missing reader must degrade to "cannot tell" rather
    than to an import error.
    """
    try:
        from dz_revit_publisher import source_reader
        return source_reader.describe
    except Exception:
        return None


def detect_source(explicit=None, manifest_path=None, manifest=None,
                  reader=None):
    """Precedence: explicit, one adjacent `.3dm`, then what the manifest names.

    An automatically detected candidate is validated before it is bound. The
    Phase 9B live run adopted a 43-byte text placeholder purely because it
    ended in `.3dm`, then failed much later with "Source 3DM could not be
    read" - a true message that said nothing about detection having chosen
    the file. Extension is not evidence.
    """
    if explicit:
        if not os.path.isfile(explicit):
            return Detected(problems=["Source 3DM not found: %s" % explicit])
        if not explicit.lower().endswith(".3dm"):
            return Detected(problems=["Not a .3dm file: %s" % explicit])
        reason = unreadable_reason(explicit, reader)
        if reason:
            #: The operator's choice is kept, so the field still shows what
            #: they picked and the problem names it. Discarding it would leave
            #: them staring at an empty box.
            return Detected(explicit, EXPLICIT,
                            problems=[EXPLICIT_UNREADABLE % explicit])
        return Detected(explicit, EXPLICIT)

    found = adjacent_sources(manifest_path)
    #: Filter before counting. One real model beside one stray placeholder is
    #: not ambiguous - it is one candidate and one thing that is not a model.
    rejected = [one for one in found if unreadable_reason(one, reader)]
    adjacent = [one for one in found if one not in rejected]

    if len(adjacent) == 1:
        return Detected(adjacent[0], ADJACENT, adjacent)
    if len(adjacent) > 1:
        return Detected(candidates=adjacent,
                        problems=[AMBIGUOUS_SOURCE % len(adjacent)],
                        ambiguous=True)

    if rejected:
        #: Say that a candidate was seen and refused. Silently falling through
        #: to "no source found" would hide the only fact that explains it.
        return Detected(candidates=list(found),
                        problems=[REJECTED_UNREADABLE % ", ".join(rejected)])

    resolved = recorded_source(manifest, manifest_path)
    if resolved:
        if unreadable_reason(resolved, reader):
            return Detected(candidates=[resolved],
                            problems=[REJECTED_UNREADABLE % resolved])
        return Detected(resolved, RECORDED, [resolved])
    return Detected(problems=["No source .3dm found beside the manifest, and "
                              "the manifest does not record a usable path. "
                              "Select one."])
