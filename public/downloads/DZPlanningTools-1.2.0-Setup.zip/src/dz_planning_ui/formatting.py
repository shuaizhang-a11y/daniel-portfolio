"""Presentation helpers. Pure text; no Eto, no Revit, no domain logic."""

UNAVAILABLE = "unavailable"

#: The UI never invents an action name. These map the engine's own vocabulary
#: onto a short label plus a symbol, so the distinction never depends on colour.
ACTION_LABELS = {
    "CREATE": ("CREATE", "[+]", "new tracked element"),
    "UPDATE PARAMETERS": ("UPDATE PARAMETERS", "[~]", "metadata only"),
    "UPDATE ELEVATION": ("UPDATE ELEVATION", "[^]", "level moves"),
    "UPDATE GEOMETRY": ("UPDATE GEOMETRY", "[#]", "boundary changed"),
    "SKIP": ("SKIP", "[=]", "no write required"),
    "OBSOLETE": ("OBSOLETE", "[!]", "no source floor matches"),
    "CONFLICT": ("CONFLICT", "[X]", "ambiguous identity"),
    "BLOCKED": ("BLOCKED", "[X]", "publishing refused"),
}

#: A physical replacement is not the same thing as a classification CREATE.
REPLACE_MARKER = "[R]"
REPLACE_LABEL = "REPLACE"
NEW_ELEMENT_ID_PENDING = "assigned during Publish"


def action_label(action):
    """`('UPDATE GEOMETRY', '[#]', 'boundary changed')`, never colour alone."""
    return ACTION_LABELS.get(action, (str(action), "[?]", ""))


def action_text(action):
    label, marker, _hint = action_label(action)
    return "%s %s" % (marker, label)


def is_replacement(floor_action):
    """The engine says `REPLACE (controlled, new ElementId)` when ids change."""
    return bool(floor_action) and str(floor_action).startswith("REPLACE")


def floor_action_text(floor_action):
    if is_replacement(floor_action):
        return "%s %s" % (REPLACE_MARKER, floor_action)
    return str(floor_action or "")


def full_path(path):
    """Paths are never shortened, abbreviated or ellipsised anywhere in the UI.

    Working copies are byte-identical clones with identical Revit titles; the
    full path is the only thing that tells them apart.
    """
    return str(path) if path else "(none)"


def optional(value, formatter=None):
    """Missing Phase 5 metrics read as `unavailable`; they never raise."""
    if value is None or value == "":
        return UNAVAILABLE
    try:
        return formatter(value) if formatter else str(value)
    except Exception:
        return UNAVAILABLE


def metres(value, places=3):
    return optional(value, lambda v: "%.*f m" % (places, float(v)))


def square_metres(value, places=2):
    return optional(value, lambda v: "%.*f m2" % (places, float(v)))


def ratio(value, places=3):
    return optional(value, lambda v: "%.*f" % (places, float(v)))


def short_hash(value, length=16):
    """Hashes are truncated for the table; the detail panel shows them whole."""
    if not value:
        return UNAVAILABLE
    text = str(value)
    return text[:length] + ("..." if len(text) > length else "")


def yes_no(value):
    if value is None:
        return UNAVAILABLE
    return "yes" if value else "no"


def file_size(value):
    """Bytes, with a human-readable companion. Never lossy on the exact count."""
    if value is None:
        return UNAVAILABLE
    try:
        count = int(value)
    except (TypeError, ValueError):
        return UNAVAILABLE
    for unit, scale in (("MB", 1024 * 1024), ("KB", 1024)):
        if count >= scale:
            return "%d bytes (%.1f %s)" % (count, count / float(scale), unit)
    return "%d bytes" % count


def full_hash(value):
    """The whole digest. Used wherever a value must be checkable by eye."""
    return str(value) if value else UNAVAILABLE


def counter_rows(results):
    """Every counter, including zeros.

    A run that wrote nothing is the proof of strict idempotency, so a zero is
    the most informative value on the panel and is never hidden.
    """
    if not results:
        return []
    rows = []
    for name in sorted(results):
        value = results[name]
        if isinstance(value, list):
            value = ", ".join(str(v) for v in value) if value else "(none)"
        rows.append((name, str(value)))
    return rows
