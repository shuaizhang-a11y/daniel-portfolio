"""The DZ Planning Tools product UI.

Importing this package must never require Revit, Rhino or Grasshopper. Only
:mod:`dz_planning_ui.main_window` and :mod:`dz_planning_ui.app` touch Eto, and
they import it lazily, so everything below can be tested offline.

The UI never calls ``Autodesk.Revit.DB``. It reaches the model only through
:mod:`dz_planning_app`, and in this checkpoint only through the read-only
entry points ``analyse``, ``plan`` and ``history``.
"""

from . import formatting, validation, view_models
from .state import (PRODUCT_NAME, PUBLISH_STATUS, UI_MODE, WINDOW_TITLE,
                    UiBusy, UiState)

__all__ = ["formatting", "validation", "view_models", "UiState", "UiBusy",
           "UI_MODE", "PUBLISH_STATUS", "WINDOW_TITLE",
           "PRODUCT_NAME"]
