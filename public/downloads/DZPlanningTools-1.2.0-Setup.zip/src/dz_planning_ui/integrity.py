"""Preview integrity: is this plan payload safe to present as a plan?

Phase 8D asserts integrity **directly from the structured `controller.plan()`
response**. It does not consult the publish log, and it never writes one. A
historical Grasshopper log entry describes a different run by a different
caller and is not evidence about the payload in hand.

The check answers one question: *did anything execute, and does this payload
describe the setup currently on screen?* It is deliberately separate from
"is the plan valid" - a plan can be legitimately blocked (wrong model, a
duplicate identity) and still be a perfectly trustworthy payload.

Nothing here repairs, normalises or coerces a payload that fails. An unsafe
payload is refused whole; a UI that silently corrected one would be hiding the
very condition the check exists to catch.
"""

import json

#: The only statuses a read-only checkpoint can legitimately produce.
#:
#: BLOCKED is included on purpose. A blocked plan executed nothing, and
#: treating it as an integrity violation would replace the real reason - a
#: wrong model, say - with a spurious "payload unsafe" message, hiding the
#: operator's actual problem behind a scarier one.
SAFE_STATUSES = ("PREVIEWED", "VALIDATED", "BLOCKED")

#: Substrings that mean the engine ran. Matched case-insensitively against the
#: status, the transaction result and every stage record.
EXECUTION_MARKERS = ("started", "committed", "assimilated", "rolled back",
                     "rollback", "published", "executing", "failed")

#: The only transaction result a preview may carry, matched exactly.
NOT_STARTED = "not started"

#: The context every actionable plan must carry, as
#: (payload field, expectation key). All four tie the plan to the setup that
#: is on screen; a plan missing any of them cannot be shown to describe it.
BINDINGS = (
    ("BuildingId", "building_id"),
    ("ManifestSha256", "manifest_sha256"),
    ("SourceModelHash", "source_model_hash"),
    ("RevitModelPath", "active_rvt_path"),
)

#: Statuses whose payloads are actionable, and therefore must be fully bound.
ACTIONABLE_STATUSES = ("PREVIEWED", "VALIDATED")

INCOMPLETE_CONTEXT = (
    "This payload is incomplete: %s missing. It is shown for diagnosis only "
    "and its context has NOT been verified against the current setup.")


class IntegrityResult(object):
    """Three separate verdicts, deliberately not collapsed into one.

    ``execution_safe``  nothing ran: no transaction, no stages, no results.
    ``context_complete`` the payload carries all four binding fields.
    ``context_matches``  every binding it *does* carry matches the setup.

    ``ok`` means safe to **inspect**. ``approvable`` means safe to **act on**.
    They differ for a BLOCKED payload: some controller blocking branches
    return before the plan is fully built, so a blocked payload may be
    legitimately unbound. Inspecting it is how the operator sees *why* it
    blocked; approving it must remain impossible.

    A binding that is present but different is always a rejection, blocked or
    not - that is a payload describing a different model, manifest, source or
    building, which is the failure this check exists to catch.
    """

    def __init__(self, execution_safe, context_complete, context_matches,
                 status=None, reasons=None, checked=None, missing=None):
        self.execution_safe = bool(execution_safe)
        self.context_complete = bool(context_complete)
        self.context_matches = bool(context_matches)
        self.status = status
        self.reasons = list(reasons or [])
        self.checked = list(checked or [])
        self.missing = list(missing or [])

    def __repr__(self):
        return ("IntegrityResult(ok=%r, execution_safe=%r, "
                "context_complete=%r, context_matches=%r, status=%r)"
                % (self.ok, self.execution_safe, self.context_complete,
                   self.context_matches, self.status))

    @property
    def is_blocked(self):
        return self.status == "BLOCKED"

    @property
    def ok(self):
        """Safe to inspect.

        Incomplete context is tolerated only for a BLOCKED payload, and even
        then it is reported rather than passed over.
        """
        if not (self.execution_safe and self.context_matches):
            return False
        if self.context_complete:
            return True
        return self.is_blocked

    @property
    def approvable(self):
        """Safe to act on. Never true for BLOCKED, never true if unbound."""
        return (self.ok and self.context_complete and self.context_matches
                and self.status in ACTIONABLE_STATUSES)

    @property
    def context_verified(self):
        """Only true when every binding was present *and* matched."""
        return self.context_complete and self.context_matches

    @property
    def incomplete_context_reason(self):
        if self.context_complete or not self.missing:
            return None
        return INCOMPLETE_CONTEXT % ", ".join(self.missing)

    @property
    def blocking_reason(self):
        if self.ok:
            return None
        return ("The Change Plan was refused because the payload is not a "
                "safe read-only preview: %s" % "; ".join(self.reasons))


def _status(payload):
    for key in ("PublishStatus", "Status"):
        value = payload.get(key)
        if value:
            return str(value)
    return None


def _mentions_execution(text):
    lowered = str(text).lower()
    return [marker for marker in EXECUTION_MARKERS if marker in lowered]


def _serialisable(payload):
    try:
        json.dumps(payload)
    except Exception as exc:
        return "the payload is not JSON-serialisable (%s: %s)" % (
            type(exc).__name__, exc)
    return None


def _replacement_rows(plan):
    from . import formatting as fmt
    rows = list(plan.get("Changes") or []) + list(plan.get("Obsolete") or [])
    return [row for row in rows if fmt.is_replacement(row.get("FloorAction"))]


def check(payload, expectations=None):
    """Validate one `controller.plan()` response. Pure; touches nothing."""
    reasons, checked = [], []
    expectations = expectations or {}

    if not isinstance(payload, dict):
        return IntegrityResult(False, False, False,
                               reasons=["the plan payload is not a mapping"])

    # -- the payload must survive a round trip ---------------------------
    checked.append("JSON-serialisable")
    problem = _serialisable(payload)
    if problem:
        #: Refused immediately: nothing below can be trusted to mean what it
        #: says if the payload cannot even be represented.
        return IntegrityResult(False, False, False, _status(payload),
                               [problem], checked)

    # -- nothing may have executed ---------------------------------------
    checked.append("TransactionResult")
    transaction = payload.get("TransactionResult")
    if transaction != NOT_STARTED:
        reasons.append(
            "TransactionResult is %r; a preview must report %r exactly"
            % (transaction, NOT_STARTED))

    checked.append("StageResults")
    stages = payload.get("StageResults")
    if stages:
        reasons.append("StageResults contains %d entry/entries; a preview "
                       "must not run an execution stage" % len(stages))
    for stage in (stages or []):
        hits = _mentions_execution(stage)
        if hits:
            reasons.append("a stage record reports %s" % ", ".join(hits))

    checked.append("Status")
    status = _status(payload)
    if status is not None and status not in SAFE_STATUSES:
        reasons.append("status is %r; a preview must be one of %s"
                       % (status, ", ".join(SAFE_STATUSES)))

    checked.append("Results")
    results = payload.get("Results")
    if results:
        #: `Results` is populated only by `execute()`. Its presence means the
        #: nine-stage executor ran, whatever the other fields claim.
        reasons.append("Results is populated; the executor has run")

    # -- no element id may be assigned before Publish ---------------------
    plan = payload.get("Plan") or {}
    checked.append("replacement NewElementId")
    for row in _replacement_rows(plan):
        assigned = row.get("NewElementId")
        if assigned:
            reasons.append(
                "floor %s is a replacement but already carries "
                "NewElementId %s; ids are assigned during Publish"
                % (row.get("FloorIndex"), assigned))

    # -- the plan must describe the setup on screen -----------------------
    #
    # Completeness and agreement are tracked separately. A missing field is
    # not evidence of a match, so it is never silently treated as one.
    execution_safe = not reasons
    missing, mismatched = [], []

    for key, expectation in BINDINGS:
        checked.append(key)
        actual = plan.get(key)
        if actual in (None, ""):
            missing.append(key)
            continue
        expected = expectations.get(expectation)
        if expected in (None, ""):
            #: Nothing to compare against; the field is present, so the
            #: payload is still complete.
            continue
        if key == "RevitModelPath":
            if not _same_path(actual, expected):
                mismatched.append(
                    "the plan was produced against %s but the active model is "
                    "%s" % (actual, expected))
        elif str(actual) != str(expected):
            mismatched.append(
                "the plan reports %s %s but the current setup is %s"
                % (key, actual, expected))

    context_complete = not missing
    context_matches = not mismatched
    reasons.extend(mismatched)

    status = _status(payload)
    if missing:
        note = INCOMPLETE_CONTEXT % ", ".join(missing)
        if status in ACTIONABLE_STATUSES or status is None:
            #: An actionable payload must be fully bound. Missing context is a
            #: failure, not a footnote.
            reasons.append(note)
        #: For BLOCKED it is reported through `missing` and
        #: `incomplete_context_reason`, not as a rejection.

    return IntegrityResult(execution_safe, context_complete, context_matches,
                           status, reasons, checked, missing)


def _same_path(left, right):
    import os
    if not left or not right:
        return False
    return (os.path.normcase(os.path.abspath(str(left)))
            == os.path.normcase(os.path.abspath(str(right))))


def expectations_from(state):
    """The live setup a plan must match, taken from the UI session."""
    analysis = state.analysis or {}
    return {
        "building_id": state.building_id,
        "manifest_sha256": analysis.get("ManifestSha256"),
        "source_model_hash": analysis.get("SourceModelHash"),
        "active_rvt_path": state.active_rvt_path,
    }
