"""The application object behind the window.

Every button the operator can press resolves to a method here. The Eto window
does nothing but construct widgets and forward clicks, which is why the whole
interaction model can be tested without Revit, Rhino or Eto present.

Phase 8D is read-only. This module deliberately has no reference to
``dz_planning_app.publish`` anywhere - not disabled, not guarded, absent. The
only controller entry points imported are ``analyse``, ``plan`` and
``history``.
"""

import io
import json
import os

from dz_planning_app import analyse as controller_analyse
from dz_planning_app import history as controller_history
from dz_planning_app import plan as controller_plan
from dz_planning_app import to_json_safe
from dz_revit_publisher import source_reader

import datetime

from . import confirm, detection, integrity
from . import history_view as hv
from . import report_export as rx
from . import publish as pub
from . import validation as val
from . import view_models as vm
from . import state as st
from .state import (PRODUCT_NAME, PUBLISH_STATUS, WINDOW_TITLE, UiBusy,
                    UiState)

#: Shown on the disabled placeholder. The control exists so the operator can
#: see where publishing will live, and see that it is not here yet.
PUBLISH_LABEL = "Publish"
#: Kept for the disabled-state tooltip and for tests that assert the control
#: exists before it is usable.
PUBLISH_PLACEHOLDER = "Publish"

REPORT_NAME = "phase08c_preview_report.txt"


def _now():
    """The confirmation timestamp, to the second. Local time, ISO 8601."""
    return datetime.datetime.now().replace(microsecond=0).isoformat()


class PlanningApp(object):
    """Holds the session, calls the controller, formats the outcome.

    ``bridge`` is the Rhino.Inside.Revit bridge, injected by :func:`launch`. It
    is optional so that every method below runs offline in a test.
    """

    def __init__(self, bridge=None, config=None, validation=None):
        self.bridge = bridge
        self.config = config or {}
        #: Development validation, injected by the rollback launcher and
        #: inactive for every production launch. Explicit injection rather
        #: than a runtime patch: a patched class or module can be replaced by
        #: a reload, an injected object travels with the window it configured.
        self.validation = validation or pub.PRODUCTION
        self.state = UiState()
        self.manifest = {}
        #: The one filtering mechanism: a set of action toggles. An empty
        #: set means SHOW ALL. There is no second, single-select filter - a
        #: dropdown left on a non-matching action rendered a valid six-row
        #: plan as zero rows while the counters still read six.
        self.filters = []
        #: The publish session and the dispatcher that serialises requests.
        #: `dispatcher` is injected by the Revit wiring; without it the UI
        #: still runs, and Publish simply never becomes available.
        self.session = pub.PublishSession()
        self.dispatcher = None
        self.wiring = None
        #: The raw planned payload behind `state.plan`, kept only so it can be
        #: frozen at confirmation. Never rendered, never serialised.
        self._planned_payload = None
        self.refresh_snapshot()

    # -- controls ----------------------------------------------------------

    def set_source_3dm(self, path):
        """Browse Source 3DM. This - and only this - is a MANUAL choice."""
        self.state.start_action("Browse Source 3DM")
        found = detection.detect_source(explicit=path)
        self.state.source_detection = found
        #: The operator's choice is kept even when invalid, so the field shows
        #: what they picked and the problem names it. Discarding it would
        #: leave them staring at an empty box wondering what went wrong.
        chosen = found.path or (path or None)
        self.state.set_source(chosen,
                              detection.MANUAL if chosen else detection.NONE)
        #: Always invalidates, even when the same path is chosen again: the
        #: file at that path may have been replaced since the plan was built,
        #: and the UI cannot tell without re-reading it.
        self.state.clear_plan()
        #: Browsing is a re-affirmation, so any retained-override flag clears.
        self.state.source_retained_override = False
        if found.problems:
            self.state.block(found.problems)
        self.refresh_source_facts()
        return self.state.source_3dm_path

    def set_manifest(self, path):
        """Browse Manifest. An explicit choice always wins over detection."""
        self.state.start_action("Browse Manifest")
        found = detection.detect_manifest(explicit=path)
        self.state.manifest_detection = found
        previous = self.state.manifest_path
        self.state.manifest_path = found.path or (path or None)
        self.manifest = {}
        if found.problems:
            #: Schema and JSON failures surface here, before any Revit query.
            self.state.block(found.problems)
        self.state.clear_plan()
        if self.state.manifest_path != previous:
            self._resolve_source_against_new_manifest()
        self.load_manifest_facts()
        return self.state.manifest_path

    def _resolve_source_against_new_manifest(self):
        """A new manifest invalidates a source that was derived from the old.

        A detected source belonged to the previous manifest and is dropped. A
        manual one is kept - the operator chose it - but is flagged unless it
        sits beside the new manifest, which is objective evidence that it
        belongs to it.
        """
        provenance = self.state.source_provenance
        if provenance in detection.REPLACEABLE:
            if self.state.source_3dm_path:
                self.state.note(
                    "Manifest changed; the previously detected source was "
                    "cleared. Press Detect Inputs.")
            self.state.set_source(None, detection.NONE)
            self.state.source_facts = {}
            self.state.source_retained_override = False
            return None

        adjacent = detection.adjacent_sources(self.state.manifest_path)
        if self.state.source_3dm_path in adjacent:
            #: It lives beside the new manifest, so no ceremony is needed.
            self.state.source_retained_override = False
            return self.state.source_3dm_path
        self.state.source_retained_override = True
        self.state.note(
            "Manifest changed. The manually selected source was retained and "
            "must be confirmed before planning.")
        return self.state.source_3dm_path

    def detect(self):
        """Detect Inputs. Fills in whatever is unambiguous, and says why."""
        self.state.start_action("Detect Inputs")
        problems = []

        found = detection.detect_manifest(
            explicit=self.state.manifest_path,
            exports_root=self.config.get("exports_root"))
        self.state.manifest_detection = found
        if found.found:
            self.state.manifest_path = found.path
        problems.extend(found.problems)
        self.load_manifest_facts()

        #: Only a MANUAL selection is passed as explicit. Passing whatever
        #: happened to be in `source_3dm_path` made Detect Inputs a no-op once
        #: any source was set - it silently kept the previous setup's file and
        #: reported "explicitly selected", which is how the Scenario 3 run
        #: classified widened geometry against the baseline footprint.
        #: A MANUAL choice is authoritative only while it still belongs to
        #: the current setup. Once it has been retained across a manifest
        #: change it is a *pending* override, not an instruction, so Detect
        #: Inputs re-derives instead of echoing it back. Without this, Detect
        #: was a no-op after a manifest change and kept the previous setup's
        #: .3dm - which is how Scenario 3 classified widened geometry against
        #: the baseline footprint.
        authoritative = (self.state.source_provenance == detection.MANUAL
                         and not self.state.source_retained_override)
        explicit = self.state.source_3dm_path if authoritative else None
        source = detection.detect_source(
            explicit=explicit,
            manifest_path=self.state.manifest_path,
            manifest=self.manifest)
        self.state.source_detection = source
        if source.found:
            self.state.set_source(source.path,
                                  detection.provenance_for(source.reason))
            if source.reason != detection.EXPLICIT:
                #: Re-derived from this manifest, so no longer carried over.
                self.state.source_retained_override = False
        elif not authoritative and self.state.source_3dm_path:
            #: Re-detection found nothing. Leaving the previous setup's file
            #: in place would be the original defect wearing a new hat.
            self.state.note("Detection found no source beside this manifest; "
                            "the previous selection was cleared.")
            self.state.set_source(None, detection.NONE)
            self.state.source_facts = {}
            self.state.source_retained_override = False
        problems.extend(source.problems)
        self.refresh_source_facts()

        if problems:
            self.state.block(problems)
        return {"Manifest": found.as_dict(), "Source": source.as_dict()}

    def select_building(self, building_id):
        """Choosing a building discards the previous building's plan.

        **And its approval.** Selecting a building is a context change of
        exactly the same kind as changing the expected RVT path, the publish
        mode or the obsolete action, all of which already void any approval -
        this one did not, which meant an approval sealed for one building, and
        a typed delete confirmation given for it, could still be standing
        while a different building was selected.

        Read-only planning results may be kept across a selection change.
        Destructive authorisation never is.
        """
        self.state.start_action("Select Building")
        previous = self.state.building_id
        chosen = self.state.select_building(building_id)
        if chosen != previous:
            self.session.invalidate("Building changed to %s." % chosen)
            self.state.note("Building changed to %s; the previous Change "
                            "Plan and any approval were discarded." % chosen)
            self.refresh_source_facts()
            self.load_review_preview()
        return chosen

    def load_review_preview(self):
        """Show the selected building's last review result, read only.

        Deliberately **not** loaded into `state.plan`. Plan Valid, integrity
        and the publish gate all read `plan`, so putting a remembered result
        there would put it into the publish path; put here it can only be
        looked at. Publishing still requires Refresh, Analyse and Generate
        against the live model, exactly as it did before this existed.
        """
        self.state.review_preview = self.state.review_for(
            self.state.building_id)
        return self.state.review_preview

    def load_manifest_facts(self):
        """Read the manifest for its facts and its building list."""
        path = self.state.manifest_path
        if not path:
            self.state.manifest_facts = {}
            self.state.buildings = []
            return None
        manifest, problem = detection.read_manifest(path)
        if problem:
            self.state.manifest_facts = {}
            self.state.buildings = []
            self.state.block([problem])
            return None
        self.manifest = manifest
        self.state.manifest_facts = vm.manifest_facts(path, manifest)
        self.state.buildings = vm.building_rows(manifest,
                                                self.state.building_id)
        ids = [b["BuildingId"] for b in self.state.buildings]
        if ids and self.state.building_id not in ids:
            #: The remembered building is not in this manifest. Select the
            #: first rather than leaving a request that cannot resolve.
            self.state.select_building(ids[0])
            self.state.buildings = vm.building_rows(manifest, ids[0])
        return self.state.manifest_facts

    def refresh_source_facts(self):
        """Read-only facts about the selected .3dm. Never modifies it."""
        path = self.state.source_3dm_path
        if not path:
            self.state.source_facts = {}
            return None
        self.state.source_facts = source_reader.describe(
            path, self._source_id())
        return self.state.source_facts

    def _source_id(self):
        for building in (self.manifest.get("buildings") or []):
            if building.get("BuildingId") == self.state.building_id:
                return building.get("SourceId")
        return None

    def use_active_as_expected(self):
        """Use Active RVT as Expected Path."""
        self.state.start_action("Use Active RVT as Expected Path")
        self.session.invalidate("Expected RVT path changed.")
        return self.state.use_active_as_expected()

    def set_expected_rvt(self, path):
        """Browse Expected RVT. Selects a path only.

        It does not open, read or save the model: it declares which document
        this session is allowed to write to. Changing it invalidates the plan
        and any confirmation, because an approval belongs to one model.
        """
        self.state.start_action("Browse Expected RVT")
        if not path:
            return self.state.expected_rvt_path
        self.session.invalidate("Expected RVT path changed.")
        return self.state.set_expected_rvt(path)

    def refresh_snapshot(self):
        """Refresh Live Revit Snapshot.

        Reads the active document path through the bridge. This is a read, and
        it goes through the bridge rather than ``Autodesk.Revit.DB`` so the UI
        never touches the Revit API surface directly.

        **Every refresh invalidates the current analysis and plan**, whether
        or not the path changed, and whether or not the read succeeds. The
        same file can be edited in place while `PathName` stays identical, and
        the plan carries no digest of the live model - so an unchanged path is
        no evidence that the plan still describes what is open. Comparing
        paths would silently keep a stale plan in exactly the case the
        operator pressed Refresh to check.

        Setup selections survive: source, manifest, building and
        ExpectedRvtPath are the operator's choices, not derived state.
        """
        self.state.start_action("Refresh Live Revit Snapshot")
        #: Bumped whether or not the read succeeds, and whether or not the
        #: path changed - for exactly the reason the plan is discarded below.
        #: Any review result generated under the previous token stops being
        #: CURRENT here, which is the whole point of pressing Refresh.
        self.state.snapshot_token += 1
        had_plan = bool(self.state.plan or self.state.analysis)
        #: Cleared before the read, so a failure cannot leave the old plan
        #: standing. Plan Valid returns to `unavailable`, the Change Plan tab
        #: relocks, and rows, counters and the detail panel all empty.
        self.state.clear_plan()
        if had_plan:
            self.state.note("Live snapshot refreshed; the previous analysis "
                            "and Change Plan were discarded. Run Analyse and "
                            "Generate Change Plan again.")

        if self.bridge is None or not getattr(self.bridge, "available", False):
            #: The absent active document is already a blocking setup problem;
            #: this note explains why it is absent.
            self.state.note(
                "Rhino.Inside.Revit is not available; no live snapshot.")
            return None
        try:
            context = self.bridge.context()
        except Exception as exc:
            #: `_fail` records it as a blocking setup message. The plan stays
            #: cleared - a failed refresh never restores what it invalidated.
            return self._fail("Live snapshot failed", exc)
        self.state.active_rvt_path = getattr(context, "document_path", None)
        return self.state.active_rvt_path

    def analyse(self):
        """Analyse. Reads the source, the manifest and the live model."""
        return self._run("Analyse", self._analyse)

    def generate_change_plan(self):
        """Generate Change Plan. Classifies; never writes."""
        return self._run("Generate Change Plan", self._plan)

    def load_history(self):
        if not self.state.manifest_path:
            return None
        try:
            self.state.history = to_json_safe(
                controller_history(self.state.as_request(), self.config))
        except Exception as exc:
            return self._fail("History read failed", exc)
        return self.state.history

    def open_log_folder(self):
        """Open Log Folder. Returns the folder; opening it is best-effort."""
        folder = self.log_folder()
        if not folder or not os.path.isdir(folder):
            self.state.note("No log folder yet: %s" % folder)
            return None
        try:
            os.startfile(folder)  # noqa: S606 - Windows shell open, read-only
        except Exception as exc:
            self.state.note("Could not open %s (%s)" % (folder, exc))
        return folder

    def log_folder(self):
        payload = self.state.history or {}
        if payload.get("PackageFolder"):
            return payload["PackageFolder"]
        if self.state.manifest_path:
            return os.path.join(os.path.dirname(self.state.manifest_path),
                                "revit_publish")
        return None

    def export_preview_report(self, path=None):
        """Export Preview Report. Writes a text file; touches no Revit element."""
        if not self.state.plan:
            self.state.block(
                ["Generate a Change Plan before exporting a report."])
            return None
        path = path or os.path.join(
            os.path.dirname(self.state.manifest_path or os.getcwd()),
            REPORT_NAME)
        try:
            with io.open(path, "w", encoding="utf-8") as handle:
                handle.write(self.report_text())
        except Exception as exc:
            return self._fail("Report export failed", exc)
        self.state.note("Preview report written to %s" % path)
        return path

    # -- publish session ---------------------------------------------------

    def set_publish_mode(self, mode):
        self.state.start_action("Publish Mode")
        if mode in pub.PUBLISH_MODES:
            self.session.mode = mode
        #: The mode is part of the plan, so the plan must be rebuilt under it.
        #: Preview Only and Update Existing Only can classify differently, and
        #: approving one while publishing the other is exactly the confusion
        #: the frozen-plan rule exists to prevent.
        self.session.invalidate("Publish Mode changed.")
        self.state.clear_plan()
        return self.session.mode

    def set_obsolete_action(self, action):
        self.state.start_action("Obsolete Action")
        if action in pub.OBSOLETE_ACTIONS:
            self.session.obsolete_action = action
        elif action in pub.RETIRED_ACTIONS:
            #: Refused by name. Silently keeping the previous action would
            #: leave the operator believing they had chosen something else -
            #: and this is the dropdown that also contains Delete.
            self.state.note(
                "%s is no longer an active obsolete action. The action is "
                "still %s. Choose %s."
                % (action, self.session.obsolete_action,
                   " or ".join(pub.OBSOLETE_ACTIONS)))
        elif action is not None:
            self.state.note("Unknown Obsolete Element Action %r. The action "
                            "is still %s." % (action,
                                              self.session.obsolete_action))
        self.session.invalidate("Obsolete Action changed.")
        self.state.clear_plan()
        return self.session.obsolete_action

    def set_confirm_publish(self, value):
        self.session.confirm_publish = bool(value)
        return self.session.confirm_publish

    def set_confirm_delete(self, value, typed=None):
        """Confirm Delete Obsolete. Only the exact word unlocks it."""
        if value and not confirm.typed_delete_correctly(typed or ""):
            self.session.confirm_delete = False
            self.state.note("Type %s exactly to confirm deletion."
                            % confirm.DELETE_WORD)
            return False
        self.session.confirm_delete = bool(value)
        return self.session.confirm_delete

    def plan_request(self):
        """The preview request, classified under the selected publish mode.

        Never sets `publish` or `confirm_publish`; previewing cannot write
        whatever the mode says.
        """
        return self.state.as_request(
            publish_mode=self.session.mode,
            obsolete_action=self.session.obsolete_action,
            confirm_delete_obsolete=self.session.deletes_obsolete)

    def publish_gate(self):
        """Every reason Publish is disabled. Empty means it is enabled."""
        return val.publish_gate_reasons(self.state, self.session,
                                        self.dispatcher, self.validation,
                                        self.wiring)

    def confirmation_lines(self):
        """The modal text, built from a projection of what would be approved.

        Built from the same projection the approval seals, so what the
        operator reads is what gets frozen.
        """
        preview = pub.ApprovedPlan(pub.projection(self.state, self.session),
                                   validation=self.validation)
        return confirm.publish_confirmation(preview, self.validation)

    def delete_confirmation_lines(self):
        preview = pub.ApprovedPlan(pub.projection(self.state, self.session))
        return confirm.delete_confirmation(preview)

    def request_publish(self, now=None):
        """Freeze the decision and raise the ExternalEvent. Never writes.

        This method does not touch Revit and does not call the executor. It
        seals the approved plan and hands it to the dispatcher; Revit calls
        back on its own event loop, where the write may legally happen.

        Every step is recorded on a :class:`~dz_planning_ui.publish.PublishTrace`
        carried by the approved record, so a failure anywhere between here and
        the executor names its layer instead of collapsing to "FAILED".
        """
        reasons = self.publish_gate()
        if reasons:
            self.state.block(reasons)
            return None
        if self.session.deletes_obsolete and not self.session.confirm_delete:
            self.state.block(["Confirm Delete Obsolete has not been given."])
            return None
        if self.dispatcher is None:
            self.state.block(["No Revit publish channel is wired; "
                              "publishing requires Rhino.Inside.Revit."])
            return None

        if not self._planned_payload:
            self.state.block(["No executable plan is held; generate a Change "
                              "Plan again before publishing."])
            return None

        trace = pub.PublishTrace()
        #: The confirmation timestamp is generated *here*, before sealing, and
        #: goes into the payload the digest covers. Nothing may write it
        #: afterwards - a sealed record that is still being edited is not
        #: sealed. Until this moment the modal correctly reads "pending".
        confirmed_at = now or _now()
        trace.step(pub.APPROVED_PLAN, "sealing", "confirmed at %s"
                   % confirmed_at)
        approved = self.session.approve(self.state, confirmed_at,
                                        executable=self._planned_payload,
                                        trace=trace,
                                        validation=self.validation)
        #: The two frozen representations must agree at the moment of
        #: sealing. If they do not, the retained payload is stale and nothing
        #: is requested.
        if not approved.verify_executable():
            self.session.reset()
            self.state.block([
                "The plan held for execution does not match the plan that was "
                "reviewed. Generate a Change Plan again and re-confirm."])
            return None
        trace.step(pub.APPROVED_PLAN, "sealed",
                   "digest %s" % approved.digest[:16])

        #: Last check before the event is raised. A validation session that
        #: has lost its hook must never proceed as an ordinary publish - that
        #: would write six real floor replacements to the model under the
        #: belief that they were about to be rolled back.
        if self.validation.active:
            request = approved.as_request()
            if not self.validation.request_is_armed(request):
                trace.step(pub.APPROVED_PLAN, "refused", pub.NOT_ARMED)
                self.session.finish(pub.BLOCKED, reason=pub.NOT_ARMED_DETAIL)
                self.state.note(
                    "Forced rollback validation request is not armed. "
                    "Nothing was raised and the model is untouched.")
                return None
            trace.step(pub.APPROVED_PLAN, "validation armed",
                       "ForceFailAtStage = %s"
                       % request[pub.FORCE_FAIL_KEY])

        trace.step(pub.DISPATCH, "request entered")
        try:
            self.dispatcher.request(approved)
        except Exception as exc:
            #: The event could not be raised. The publish infrastructure
            #: failed *before* anything was written - which says nothing about
            #: whether the Change Plan is correct, so the plan is kept and no
            #: plan-integrity blocker is invented. See `fail_before_write`.
            trace.fail(pub.EXTERNAL_EVENT_RAISE, exc)
            self.fail_before_write(exc)
            return None
        trace.step(pub.EXTERNAL_EVENT_RAISE, "returned",
                   "waiting for Revit to call the handler")
        self.state.note("Publish requested. Waiting for Revit.")
        return approved

    def fail_before_write(self, exc):
        """Land a publish attempt that failed before any write was possible.

        Deliberately *not* `state.block`. A blocker there feeds
        `state.blocking_errors`, which drives `plan_valid` to NO - so the
        first live failure reported "The Change Plan is not approvable" when
        the only thing wrong was that the ExternalEvent had never been
        created. The plan stays inspectable; the failure is reported on the
        Publish tab, where it happened.

        The confirmation is still cleared, so a retry is a fresh, deliberate
        decision rather than a blind one.
        """
        detail = pub.exception_detail(exc)
        self.session.finish(pub.FAILED, reason="%s: %s"
                            % (detail["Type"], detail["Message"]))
        self.state.note(
            "Publish failed before any write: %s: %s. The model was not "
            "opened for writing and the Change Plan is unchanged."
            % (detail["Type"], detail["Message"]))
        return self.session.state

    def on_publish_result(self, result):
        """Called back after the handler ran. Lands the state machine."""
        result = result or {}
        status = result.get("Status")
        if status == "PUBLISHED" or status == "PUBLISHED WITH WARNINGS":
            terminal = pub.DONE
        elif status == "ROLLED BACK":
            terminal = pub.ROLLED_BACK
        elif status == "BLOCKED":
            terminal = pub.BLOCKED
        else:
            terminal = pub.FAILED
        reason = "; ".join(result.get("Errors") or []) or None
        trace = self.session.trace
        if trace is not None:
            trace.step(pub.CALLBACK, "result received", terminal)
        self.session.finish(terminal, result=result, reason=reason)
        #: Every terminal state supersedes "Waiting for Revit" in the log, as
        #: well as in the derived status line rendered above it.
        self.state.note(vm.publish_status_line(self.session))
        #: The log has a new entry. Reloading is read-only and cannot alter
        #: planning state; a selection pointing at a vanished record is
        #: cleared rather than left dangling.
        self.reload_history()
        if terminal == pub.DONE:
            #: The published model has moved on, so every derived view is
            #: stale. This is the only outcome that invalidates the plan:
            #: BLOCKED and FAILED never reached the executor, and ROLLED BACK
            #: left the model exactly as the plan still describes it.
            self.state.clear_plan()
        elif reason:
            #: Reported on the Publish tab. Not a plan blocker - the plan did
            #: not become wrong because the publish path failed.
            self.state.note("Publish did not complete: %s" % reason)
        return self.session.state

    @property
    def controls_locked(self):
        """True while an approved request is pending in Revit.

        Nothing that could change the setup may move between the raise and
        the callback: the approved plan must still describe the world when
        the handler runs.
        """
        return self.session.in_flight

    #: Every control the window offers, by label.
    def actions(self):
        return {
            "Browse Source 3DM": self.set_source_3dm,
            "Browse Manifest": self.set_manifest,
            "Detect Inputs": self.detect,
            "Use Active RVT as Expected Path": self.use_active_as_expected,
            "Analyse": self.analyse,
            "Generate Change Plan": self.generate_change_plan,
            "Refresh Live Revit Snapshot": self.refresh_snapshot,
            "Open Log Folder": self.open_log_folder,
            "Refresh History": self.refresh_history,
            "Export Publish Report": self.export_publish_report,
            "Export Preview Report": self.export_preview_report,
        }

    @property
    def publish_enabled(self):
        """True only when every gate passes. See `publish_gate` for why not."""
        return not self.publish_gate()

    @property
    def publish_tooltip(self):
        reasons = self.publish_gate()
        if not reasons:
            return "Publish to %s" % (self.state.expected_rvt_path or "")
        return "Publish is disabled: " + " ".join(reasons)

    # -- view models -------------------------------------------------------

    def setup_rows(self):
        return vm.project_setup_rows(self.state, self.state.analysis,
                                     {"program": self._program()})

    def _program(self):
        for building in (self.manifest.get("buildings") or []):
            if building.get("BuildingId") == self.state.building_id:
                return building.get("Program")
        return None

    def setup_problems(self):
        return vm.setup_problem_rows(self.state)

    def source_facts(self):
        return vm.source_fact_rows(self.state.source_facts, self.state)

    def manifest_facts(self):
        return vm.manifest_fact_rows(self.state.manifest_facts)

    def building_list(self):
        return vm.building_rows(self.manifest, self.state.building_id)

    def toggle_counts(self):
        """Counts describe the whole plan, never only the visible rows.

        Filtering is a view concern; the summary is a fact about the plan.
        """
        return vm.toggle_counts(vm.change_rows(self.displayed_plan))

    def issue_sections(self):
        return vm.issue_sections(self.state)

    def plan_locked(self):
        return val.plan_tab_lock_reasons(self.state)

    def element_detail(self, row):
        return vm.element_detail(row,
                                 vm.change_for_row(self.displayed_plan, row))

    def summary_sections(self):
        return vm.planning_summary(self.manifest, self.state.building_id)

    @property
    def displayed_plan(self):
        """What the Change Plan table renders - which is not the verdict.

        The live plan when there is one; otherwise the cached result being
        reviewed. **Rendering only.** Plan Valid, integrity, the safety strip
        and the publish gate all continue to read `state.plan`, so a cached
        result changes what is shown and nothing about what is allowed.

        One accessor rather than four, because the counters, the headline,
        the table and the detail panel disagreeing about which plan they were
        describing is a failure this codebase has already had.
        """
        if self.state.plan:
            return self.state.plan
        preview = self.state.review_preview
        return preview.plan if preview is not None else None

    @property
    def reviewing_cached(self):
        return bool(not self.state.plan and self.state.review_preview)

    def review_banner(self):
        """Why the table is showing something that is not a live plan."""
        return vm.review_banner(self.state)

    def plan_rows(self):
        """Rows for the table. A locked tab renders nothing at all.

        With no toggle active this returns every row: an empty selection is
        SHOW ALL, never SHOW NONE. A valid plan must never render empty
        merely because nothing has been selected yet.

        A cached result is exempt from the lock, and only from the lock: the
        tab is locked because there is no *live* plan, which is exactly what
        the banner above the table says. Rendering nothing here would answer
        "show me what B001 said" with a blank table.
        """
        if self.reviewing_cached:
            return vm.filter_rows_multi(vm.change_rows(self.displayed_plan),
                                        self.filters)
        if val.plan_tab_lock_reasons(self.state):
            return []
        return vm.filter_rows_multi(vm.change_rows(self.state.plan),
                                    self.filters)

    # -- Phase 13A: the Project Setup dashboard ----------------------------
    #
    # Every method here reads. None of them writes state, and none is
    # consulted by anything that decides what may publish - `next_action`
    # reads the publish gate, never the reverse, so a recommendation cannot
    # become a permission.

    def project_header(self):
        """Project / Manifest: what is loaded and whether it is usable."""
        return vm.project_header_rows(self.state, self.manifest)

    def source_section(self):
        """PROJECT SOURCE: the operator message, then the technical detail.

        The diagnostics are kept - they are precise and they matter when
        something is wrong - they are simply no longer the first thing read.
        """
        return vm.source_section(self.state)

    def source_status(self):
        return vm.source_status(self.state)

    def manifest_status(self):
        return vm.manifest_status(self.state)

    def source_diagnostics(self):
        return vm.source_diagnostics(self.state)

    def status(self):
        """Source, RVT, Snapshot, Analysis, Plan - the readiness block."""
        return vm.status_rows(self.state)

    def next_action(self):
        """What to do next. Deterministic, derived, and guidance only.

        The publish gate is passed *in*: this reports the gate's verdict and
        has no say in it.
        """
        return vm.next_action(self.state, self.session, self.publish_gate())

    def next_action_rows(self):
        return vm.next_action_rows(self.next_action())

    def selected_building_rows(self):
        """The selected building's binding, stated plainly beside the table."""
        bid = self.state.building_id
        freshness = self.state.freshness_of(bid)
        return [
            ("Selected building", bid or "(none)"),
            ("Expected RVT", vm.fmt.full_path(self.state.expected_rvt_path)),
            ("Model state", vm.model_state(self.state, bid)),
            ("Freshness", st.FRESHNESS_LABELS[freshness]),
        ]

    # -- Phase 12C: the project review table -------------------------------

    def project_rows(self):
        """One row per building. Read only, and it authorises nothing."""
        return vm.project_review_rows(self.manifest, self.state)

    def project_totals(self):
        return vm.project_review_totals(self.project_rows())

    def select_project_row(self, index):
        """Selecting a row selects that building and shows its last review.

        It goes through `select_building`, so it inherits every invalidation
        a selection change carries - including the approval and both
        confirmations. There is no path here that restores authorisation.
        """
        rows = self.project_rows()
        if index is None or index < 0 or index >= len(rows):
            return None
        return self.select_building(rows[index]["BuildingId"])

    def toggle_filter(self, name):
        """Multi-select: toggling one never clears the others."""
        if name in self.filters:
            self.filters.remove(name)
        else:
            self.filters.append(name)
        return list(self.filters)

    def plan_headline(self):
        return vm.plan_headline(self.displayed_plan)

    def history_rows(self):
        return vm.history_entries(self.state.history, self._csv_rows())

    # -- Tab 4: History ----------------------------------------------------
    #
    # Rendering only. Nothing here reaches the publish path: History has no
    # route to `request_publish`, the dispatcher or the wiring, and selecting
    # a row cannot approve, invalidate or queue anything.

    def history_table_rows(self):
        """Every log entry as a table row, newest first."""
        return hv.rows(self.state.history, self._csv_rows())

    def history_entry_at(self, index):
        entries = hv.entries_of(self.state.history)
        if 0 <= index < len(entries):
            return entries[index]
        return None

    def select_history_row(self, index):
        """Select by position; remember by key. Returns the detail, or None.

        A negative or out-of-range index clears the selection rather than
        raising, because a reload can legitimately shrink the table under a
        selection that was valid a moment ago.
        """
        entry = self.history_entry_at(index if index is not None else -1)
        self.state.history_selection = hv.entry_key(entry) if entry else None
        return self.history_detail()

    def clear_history_selection(self):
        self.state.history_selection = None
        return None

    def selected_history_index(self):
        """Where the remembered entry is now, or -1 if it is gone."""
        key = self.state.history_selection
        if not key:
            return -1
        for index, entry in enumerate(hv.entries_of(self.state.history)):
            if hv.entry_key(entry) == key:
                return index
        return -1

    def selected_history_entry(self):
        return self.history_entry_at(self.selected_history_index())

    def history_detail(self):
        """The selected entry's full record, or None when nothing is selected."""
        return hv.detail(self.selected_history_entry(), self._csv_rows())

    def refresh_history(self):
        """Refresh History. Re-reads the append-only log and nothing else.

        `controller.history` takes no bridge and opens no transaction, so this
        is a pure file read. It exists because History was previously only
        loaded as a side effect of Analyse, which meant the tab could not be
        opened without also running the planning path.
        """
        self.state.start_action("Refresh History")
        return self.reload_history()

    @property
    def publish_report_enabled(self):
        """Export Publish Report is available only with a selected entry."""
        ok, _reason = rx.exportable(self.selected_history_entry())
        return ok

    def publish_report_gate(self):
        """Why the export is unavailable, or None."""
        _ok, reason = rx.exportable(self.selected_history_entry())
        return reason

    def suggested_report_name(self, extension=".txt"):
        return rx.suggested_name(self.selected_history_entry(), extension)

    def export_publish_report(self, path):
        """Write the selected entry as a report. Never a publish.

        A filesystem failure is reported as an export failure and nothing
        else. The publish result is terminal and immutable: an export that
        cannot write a file must not restate DONE as FAILED, and does not
        touch the session at all.
        """
        self.state.start_action("Export Publish Report")
        entry = self.selected_history_entry()
        result = rx.write_report(entry, path, self._csv_rows())
        if result.ok:
            self.state.note(result.message)
        else:
            #: A note, not a blocker: this says nothing about the plan.
            self.state.note("Report export failed: %s" % result.error)
        return result

    def reconcile_history_selection(self):
        """Forget a remembered entry that is no longer in the log.

        Called on every render, not only on reload. A key that no longer
        resolves is state claiming a selection the table cannot show - the
        same divergence between internal state and what is on screen that the
        Confirm Publish checkbox suffered in 8E.
        """
        if self.state.history_selection and self.selected_history_index() < 0:
            self.state.history_selection = None
        return self.state.history_selection

    def reload_history(self):
        """Re-read the log and keep the selection only if it still exists.

        Called after a terminal publish. It reads; it never changes planning
        or publish state, and it never approves or invalidates a plan.
        """
        self.load_history()
        return self.reconcile_history_selection()

    @property
    def window_title(self):
        """Unmistakable when a development hook is armed."""
        suffix = self.validation.title_suffix
        if suffix:
            return "%s - %s" % (PRODUCT_NAME, suffix)
        return WINDOW_TITLE

    def validation_rows(self):
        """The armed-state fields. Empty for a production session."""
        return vm.validation_rows(self.validation, self.wiring)

    def operator_header(self):
        """The one-line header across the top of the window.

        The same facts the safety strip carries, said the way an operator
        would. `safety_strip` is untouched and still renders in Details.
        """
        return vm.operator_header(self.state, self.session)

    def safety_strip(self):
        return vm.safety_strip(self.state) + self.validation.rows()

    def diagnostics(self):
        return vm.diagnostics_rows(self.state, session=self.session)

    def publish_result_rows(self):
        return vm.publish_result_rows(self.session)

    def replacement_map_rows(self):
        return vm.replacement_map_rows(self.session.result)

    def report_text(self):
        lines = [vm.safety_strip_text(self.state), "",
                 self.plan_headline(), ""]
        payload = self.state.plan or {}
        if payload.get("PlanText"):
            lines.append(payload["PlanText"])
        return "\n".join(lines)

    # -- internals ---------------------------------------------------------

    def _run(self, what, work):
        """One long-running request at a time.

        A second Analyse arriving while the first is mid-flight would race on
        the same state and report whichever finished last.
        """
        try:
            self.state.begin(what)
        except UiBusy as exc:
            self.state.note(str(exc))
            return None
        try:
            return work()
        finally:
            self.state.end()

    def _analyse(self):
        #: Dropped before the attempt, not after it. A result generated under
        #: this same live snapshot would otherwise still classify as CURRENT
        #: after the analysis meant to replace it had failed.
        self.state.discard_review(self.state.building_id)
        problems = self.setup_problems()
        if problems:
            #: Replaced, never accumulated: these are the current reasons.
            self.state.block(problems)
            return None
        try:
            payload = controller_analyse(self.plan_request(), self.bridge,
                                         self.config)
        except Exception as exc:
            return self._fail("Analyse failed", exc)
        self.manifest = payload.get("_manifest") or {}
        self.state.analysis = to_json_safe(payload)
        self.state.plan = None
        self._planned_payload = None
        self._analysis_payload = payload
        #: A blocked analysis is a result, not a silence. Without this the
        #: window would show an empty Setup tab and no reason for it.
        self._report(payload)
        self.load_history()
        return self.state.analysis

    def _plan(self):
        self.state.discard_review(self.state.building_id)
        if not self.state.analysis:
            #: Re-derived rather than remembered. Starting this action cleared
            #: the previous blockers, and "Run Analyse first" would replace a
            #: specific reason - WRONG MODEL, say - with a vaguer one.
            problems = self.setup_problems()
            self.state.block(problems or ["Run Analyse first."])
            return None
        try:
            payload = controller_plan(self.plan_request(), self.bridge,
                                      self.config,
                                      getattr(self, "_analysis_payload", None))
        except Exception as exc:
            return self._fail("Change Plan failed", exc)
        #: The raw payload carries the live ChangePlan, which cannot survive
        #: being made JSON-safe. It is retained so confirmation can freeze the
        #: exact plan that will execute, rather than re-deriving one later.
        self._planned_payload = payload
        safe = to_json_safe(payload)
        #: Asserted from this response, never from the publish log. A payload
        #: that fails is refused whole - not repaired, not normalised.
        result = integrity.check(safe, integrity.expectations_from(self.state))
        self.state.integrity = result
        self.state.plan = safe
        if not result.ok:
            self.state.block([result.blocking_reason])
            self.state.plan_lock_reasons = val.plan_tab_lock_reasons(self.state)
            return None
        #: `_report` populates the blockers this reads, so it runs first.
        self._report(payload)
        self.state.plan_lock_reasons = val.plan_tab_lock_reasons(self.state)
        self.record_review()
        return self.state.plan

    def record_review(self, now=None):
        """Keep this building's review result. Called only after a plan.

        A blocked plan is recorded too - "B002 was blocked, here is why" is a
        review finding, and dropping it would leave the project table unable
        to tell a blocked building from an unvisited one. A payload that
        failed *integrity* is never recorded: it was refused whole, and a
        refused payload is not a finding about the building.
        """
        result = self.state.integrity
        if not self.state.plan or result is None or not result.ok:
            return None
        inner = (self.state.plan or {}).get("Plan") or {}
        review = st.BuildingReviewResult(
            building_id=self.state.building_id,
            source_id=self._source_id(),
            source_sha256=(self.state.source_facts or {}).get("Sha256"),
            expected_rvt_path=self.state.expected_rvt_path,
            #: What was actually open, not what was asked for.
            observed_rvt_path=self.state.active_rvt_path,
            snapshot_token=self.state.snapshot_token,
            plan=self.state.plan,
            analysis=self.state.analysis,
            plan_valid=self.state.plan_valid,
            blockers=inner.get("Blocking") or [],
            conflicts=inner.get("Conflicts") or [],
            counts=inner.get("Counts") or {},
            generated_at=now or _now())
        return self.state.record_review(review)

    def _report(self, payload):
        """Surface whatever the controller refused to do, and why.

        Replaces the current blockers rather than appending, so re-rendering
        or re-running cannot multiply one error into several lines.
        """
        self.state.block(payload.get("Errors") or [])
        return payload

    def _fail(self, what, exc):
        """A controller failure is reported, never raised into the UI loop.

        An unhandled exception in an Eto callback takes down the window and
        loses the session; a message keeps the operator informed instead.
        """
        message = "%s: %s: %s" % (what, type(exc).__name__, exc)
        self.state.last_error = message
        self.state.block([message])
        self.state.note(message)
        return None

    def _csv_rows(self):
        """The per-element CSV, read only so the JSON can be cross-checked."""
        folder = self.log_folder()
        if not folder:
            return []
        path = os.path.join(folder, "phase07c_publish_log.csv")
        if not os.path.isfile(path):
            return []
        import csv
        try:
            with io.open(path, "r", encoding="utf-8-sig", newline="") as handle:
                return list(csv.DictReader(handle))
        except Exception:
            return []


def launch(bridge=None, config=None, validation=None):
    """Open the window. Imports Eto lazily so this module stays offline-safe.

    Construction happens before any controller call, so a rendering failure
    here cannot have started Analyse, cannot have reached ``publish``, and
    cannot have opened a Revit transaction. The caller reports the error; it is
    never allowed to surface as a raw pythonnet dialog.
    """
    from .main_window import create_window
    application = PlanningApp(bridge, config, validation=validation)
    window = create_window(application)
    window.Show()
    return window


def dump(app):
    """Everything the window shows, as JSON. Used for live read-only checks."""
    return json.dumps({
        "SafetyStrip": app.safety_strip(),
        "Setup": app.setup_rows(),
        "Headline": app.plan_headline(),
        "Rows": app.plan_rows(),
        "Diagnostics": app.diagnostics(),
    }, indent=2, default=str)
