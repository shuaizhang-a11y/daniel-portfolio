"""Every value the window displays, computed as plain data.

Nothing here imports Eto, Revit or Rhino. The window is a renderer over these
structures, which is what makes the whole UI testable offline.
"""

import os

from dz_revit_publisher import change_detection as cd
from dz_revit_publisher import datetime_compat

from . import formatting as fmt
from . import state as st
from . import validation as val
from .state import PUBLISH_STATUS, UI_MODE

# -- Change Plan filters ----------------------------------------------------

#: Rows that need the operator's attention. These are never hidden by the
#: default view: a filter can narrow *to* them, never away from them.
ALWAYS_VISIBLE = (cd.CONFLICT, cd.BLOCKED)

# -- Safety strip -----------------------------------------------------------

def safety_strip(state):
    """The row that is visible from every tab, in every state.

    The active document path is shown whole. Working copies are byte-identical
    clones with identical Revit titles, so the path is the only thing that
    distinguishes a fixture from the production model.
    """
    #: Read from the named state, never from truthiness: `None` and `False`
    #: are different answers and must not render alike.
    labels = {state.UNAVAILABLE: fmt.UNAVAILABLE, state.NO: "NO",
              state.YES: "YES"}
    return [
        ("Active RVT", fmt.full_path(state.active_rvt_path)),
        ("Expected RVT", fmt.full_path(state.expected_rvt_path)),
        ("Path match", "MATCH" if state.paths_match else (
            "NOT SET" if not state.expected_rvt_path else "WRONG MODEL")),
        ("Plan valid", labels[state.plan_valid_state]),
        ("Blocking errors", str(len(state.blocking_errors))),
        ("Conflicts", str(len(state.conflicts))),
        ("UI mode", UI_MODE),
        ("Publish", PUBLISH_STATUS),
    ]


#: Phase 13C. The strip across the top of every tab used to read
#: `UI mode  WRITE-ENABLED (publish requires explicit confirmation)` beside
#: `Publish  ARMED - requires confirmation`, which is developer vocabulary in
#: the most prominent place in the product. The facts stay - `safety_strip`
#: is unchanged and still renders in Details - but the header says them the
#: way an operator would.
def operator_header(state, session=None):
    """One line: which building, whether the plan stands, what stops it."""
    verdict = {state.UNAVAILABLE: "not generated", state.NO: "NOT VALID",
               state.YES: "VALID"}[state.plan_valid_state]
    blockers = len(state.blocking_errors)
    conflicts = len(state.conflicts)
    #: Named `authorised` rather than the obvious word: the UI package is
    #: guarded against carrying that bare name at all, so nothing in it can
    #: resemble an invocation of the engine's write entry point. The guard
    #: caught this twice on the way in - once as a variable, once as prose in
    #: this very comment - which is exactly what it is for.
    authorised = "READY" if (session is not None and session.confirm_publish
                             and session.wants_write
                             and state.plan_valid is True
                             and state.paths_match) else "not authorised"
    parts = [
        state.building_id or "no building",
        "Plan: %s" % verdict,
        "Blockers: %d" % blockers,
        "Conflicts: %d" % conflicts,
        "Publish: %s" % authorised,
    ]
    model = os.path.basename(state.active_rvt_path or "") or "no model open"
    return "   |   ".join([model] + parts)


def safety_strip_text(state):
    return "   |   ".join("%s: %s" % pair for pair in safety_strip(state))


# -- Tab 1: Project Setup ---------------------------------------------------

def project_setup_rows(state, analysis=None, environment=None):
    analysis = analysis or state.analysis or {}
    environment = environment or {}
    identity = analysis.get("Identity") or {}
    context = analysis.get("Context") or {}
    problems = val.setup_problems(state)

    return [
        ("Active RVT path", fmt.full_path(state.active_rvt_path)),
        ("Expected RVT path", fmt.full_path(state.expected_rvt_path)),
        ("Exact match", "MATCH" if state.paths_match else (
            "NOT SET" if not state.expected_rvt_path else "MISMATCH")),
        ("Source 3DM path", fmt.full_path(state.source_3dm_path)),
        ("Manifest path", fmt.full_path(
            analysis.get("ManifestPath") or state.manifest_path)),
        ("Project ID", fmt.optional(identity.get("projectId"))),
        ("Option", fmt.optional(identity.get("option"))),
        ("Revision", fmt.optional(identity.get("revision"))),
        ("Building", fmt.optional(analysis.get("Building")
                                  or state.building_id)),
        ("Program", fmt.optional(environment.get("program"))),
        ("Source model SHA-256",
         fmt.optional(analysis.get("SourceModelHash"))),
        ("Manifest SHA-256", fmt.optional(analysis.get("ManifestSha256"))),
        ("Revit version", fmt.optional(context.get("RevitVersion"))),
        ("Rhino.Inside version",
         fmt.optional(context.get("RhinoInsideRevitVersion"))),
        ("Rhino version", fmt.optional(context.get("RhinoVersion"))),
        ("Setup status", "READY" if not problems else
         "BLOCKED (%d)" % len(problems)),
    ]


def setup_problem_rows(state):
    return list(val.setup_problems(state))


# -- Tab 2: Planning Summary ------------------------------------------------

def _rule(manifest, rule_id):
    for row in (manifest.get("compliance") or []):
        if row.get("RuleId") == rule_id:
            return row
    return {}


def _rule_line(manifest, rule_id):
    """Renders one compliance rule, or `unavailable`.

    A rule the Phase 5 export never produced is an absence, not an error.
    """
    row = _rule(manifest, rule_id)
    if not row:
        return fmt.UNAVAILABLE
    actual = fmt.optional(row.get("ActualValue"),
                          lambda v: "%.3f" % float(v))
    unit = row.get("ActualUnit") or ""
    target = row.get("TargetValue")
    parts = ["%s %s" % (actual, unit) if unit else actual]
    if target is not None:
        parts.append("(target %s %s)" % (target, row.get("TargetUnit") or ""))
    parts.append(str(row.get("Status") or fmt.UNAVAILABLE))
    return "  ".join(p.strip() for p in parts if p and p.strip())


def planning_summary(manifest, building_id=None):
    """Sections of (label, value). Missing metrics read `unavailable`."""
    manifest = manifest or {}
    buildings = manifest.get("buildings") or []
    floors = manifest.get("floors") or []
    if building_id:
        selected = [b for b in buildings if b.get("BuildingId") == building_id]
        building = selected[0] if selected else {}
        floors = [f for f in floors if f.get("BuildingId") == building_id]
    else:
        building = buildings[0] if buildings else {}

    total_gfa = None
    plates = [f.get("FloorPlateArea") for f in floors
              if f.get("FloorPlateArea") is not None]
    if plates:
        total_gfa = sum(float(p) for p in plates)

    project = [
        ("Buildings", str(len(buildings)) if buildings else fmt.UNAVAILABLE),
        ("Site area", fmt.square_metres((manifest.get("site") or {})
                                        .get("siteArea"))),
    ]
    massing = [
        ("Building", fmt.optional(building.get("BuildingId"))),
        ("Program", fmt.optional(building.get("Program"))),
        ("Floors", str(len(floors)) if floors else fmt.UNAVAILABLE),
        ("Building height", fmt.metres(building.get("Height"))),
        ("Footprint area", fmt.square_metres(building.get("FootprintArea"))),
        ("Total GFA", fmt.square_metres(total_gfa)),
        ("FSR-included GFA",
         fmt.square_metres(building.get("FSRIncludedGFA"))),
    ]
    per_floor = [(("Floor %02d  %s" % (f.get("FloorIndex") or 0,
                                       f.get("LevelName") or "")).strip(),
                  "%s at %s%s" % (fmt.square_metres(f.get("FloorPlateArea")),
                                  fmt.metres(f.get("Elevation")),
                                  "" if f.get("IncludedInFSR", True)
                                  else "  (excluded from FSR)"))
                 for f in floors]
    compliance = [
        ("FSR", _rule_line(manifest, "FSR")),
        ("Site coverage", _rule_line(manifest, "SITE_COVERAGE")),
        ("Deep soil", _rule_line(manifest, "DEEP_SOIL")),
        ("Communal open space",
         _rule_line(manifest, "COMMUNAL_OPEN_SPACE")),
        ("Height plane", _rule_line(manifest, "HEIGHT_PLANE")),
        ("Solar access", _rule_line(manifest, "SOLAR_ACCESS")),
        ("Parking - vehicle", _rule_line(manifest, "PARKING_VEHICLE")),
        ("Parking - visitor", _rule_line(manifest, "PARKING_VISITOR")),
        ("Parking - accessible", _rule_line(manifest, "PARKING_ACCESSIBLE")),
        ("Parking - bicycle", _rule_line(manifest, "PARKING_BICYCLE")),
    ]
    return [("Project", project), ("Massing", massing),
            ("Per-floor GFA", per_floor or [("(no floors)", fmt.UNAVAILABLE)]),
            ("Compliance", compliance)]


# -- Tab 3: Change Plan -----------------------------------------------------

def _snapshot_pair(change, field, formatter):
    previous = (change.get("PreviousSnapshot") or {}).get(field)
    current = (change.get("CurrentSnapshot") or {}).get(field)
    return formatter(previous), formatter(current)


def change_row(change, building_id=None):
    """One formal FloorKey, flattened for the table."""
    action = change.get("Action")
    floor_action = change.get("FloorAction")
    replacement = fmt.is_replacement(floor_action)
    label, marker, hint = fmt.action_label(action)

    previous_elevation, proposed_elevation = _snapshot_pair(
        change, "Elevation", fmt.metres)
    previous_area, proposed_area = _snapshot_pair(
        change, "FloorPlateArea", fmt.square_metres)
    previous_hash, proposed_hash = _snapshot_pair(
        change, "BoundaryHash", fmt.short_hash)

    current_id = change.get("ElementId") or change.get("PreviousElementId")
    if replacement:
        # The new id does not exist yet, and this checkpoint never creates it.
        new_id = fmt.NEW_ELEMENT_ID_PENDING
    else:
        new_id = change.get("NewElementId") or ""

    reasons = list(change.get("Warnings") or [])
    if change.get("Error"):
        reasons.insert(0, change["Error"])

    return {
        "Building": building_id or fmt.UNAVAILABLE,
        "FloorIndex": change.get("FloorIndex"),
        "StableKey": change.get("StableKey"),
        "CurrentElementId": str(current_id) if current_id else "(none)",
        "NewElementId": str(new_id),
        "Action": action,
        "ActionLabel": label,
        "ActionMarker": marker,
        "ActionText": fmt.action_text(action),
        "ActionHint": hint,
        "IsReplacement": replacement,
        "LevelAction": fmt.optional(change.get("LevelAction")),
        "FloorAction": fmt.floor_action_text(floor_action),
        "BoundaryAction": fmt.optional(change.get("BoundaryAction")),
        "AreaAction": fmt.optional(change.get("AreaAction")),
        "AreaPlanAction": fmt.optional(change.get("AreaPlanAction")),
        "PreviousElevation": previous_elevation,
        "ProposedElevation": proposed_elevation,
        "PreviousArea": previous_area,
        "ProposedArea": proposed_area,
        "PreviousBoundaryHash": previous_hash,
        "ProposedBoundaryHash": proposed_hash,
        #: The table truncates hashes to stay readable; the detail panel shows
        #: these, so a boundary change can actually be checked against the log.
        "PreviousBoundaryHashFull": fmt.optional(
            (change.get("PreviousSnapshot") or {}).get("BoundaryHash")),
        "ProposedBoundaryHashFull": fmt.optional(
            (change.get("CurrentSnapshot") or {}).get("BoundaryHash")),
        "Detail": fmt.optional(change.get("Detail")),
        "Reason": "; ".join(reasons) if reasons else "",
        "NeedsAttention": action in ALWAYS_VISIBLE or bool(change.get("Error")),
    }


def change_rows(payload):
    """Every change and every obsolete element, in one ordered table."""
    plan = (payload or {}).get("Plan") or {}
    building_id = plan.get("BuildingId")
    rows = [change_row(c, building_id) for c in (plan.get("Changes") or [])]
    rows.extend(change_row(c, building_id)
                for c in (plan.get("Obsolete") or []))
    return rows


def plan_is_no_change(payload):
    rows = change_rows(payload)
    return bool(rows) and all(r["Action"] == cd.SKIP for r in rows)


def plan_headline(payload):
    """The one-line verdict above the table."""
    plan = (payload or {}).get("Plan") or {}
    if not plan:
        return "No Change Plan yet. Run Analyse, then Generate Change Plan."
    status = (payload or {}).get("PublishStatus") or (payload or {}).get("Status")
    if status == "BLOCKED":
        #: Visibly distinct from PREVIEWED and VALIDATED, in words.
        return ("BLOCKED - this plan cannot be reviewed or approved until the "
                "blocking errors are resolved.")
    expected = plan.get("Expected") or {}
    if plan_is_no_change(payload):
        return ("NO CHANGE REQUIRED - every floor matches the model. "
                "This is a successful result, not a failure.")
    return ("created %d   updated %d   skipped %d   obsolete %d   conflicts %d"
            % (expected.get("created", 0), expected.get("updated", 0),
               expected.get("skipped", 0), expected.get("obsolete", 0),
               expected.get("conflicts", 0)))


def legend():
    """Shown beside the table so the marks never need to be guessed."""
    rows = [(marker, label, hint)
            for label, marker, hint in
            (fmt.action_label(a) for a in TOGGLE_FILTERS
             if a != REPLACE_FILTER)]
    rows.append((fmt.REPLACE_MARKER, fmt.REPLACE_LABEL,
                 "existing element deleted and rebuilt; new ElementId"))
    return rows


# -- Tab 4: History and Diagnostics -----------------------------------------

#: Phase 8F moved the history projections into their own pure module. They are
#: re-exported here because the log's field-name quirks and the Scenario 3 CSV
#: anomaly are history concerns, not publish-tab concerns - and because Tab 4
#: outgrew a single shared view model. Behaviour is unchanged.
from .history_view import (CSV_DISAGREEMENT_WARNING,  # noqa: E402,F401
                           RVT_PATH_KEYS, STATUS_KEYS, TIMESTAMP_KEYS,
                           csv_contradicts as _csv_contradicts,
                           first as _first, history_entries, history_entry)


def diagnostics_rows(state, payload=None, session=None):
    payload = payload or state.plan or state.analysis or {}
    capabilities = getattr(state, "runtime_capabilities", None) or {}
    rows = [(name, str(capabilities[name])) for name in sorted(capabilities)]
    if session is not None:
        rows.append(("Publish state", session.state))
    return rows + [
        ("UI mode", UI_MODE),
        ("Publish", PUBLISH_STATUS),
        ("Controller status", fmt.optional(payload.get("Status"))),
        ("Transaction", fmt.optional(payload.get("TransactionResult")
                                     or "not started")),
        ("Warnings", str(len(state.warnings))),
        ("Blocking errors", str(len(state.blocking_errors))),
        ("Conflicts", str(len(state.conflicts))),
    ]


# -- Phase 8D: setup facts --------------------------------------------------

#: How the provenance reads in Project Setup. Diagnostic text only.
PROVENANCE_LABELS = {
    "MANUAL": "MANUAL (chosen by the operator)",
    "DETECTED_ADJACENT": "DETECTED ADJACENT (found beside the manifest)",
    "MANIFEST_RECORDED": "MANIFEST RECORDED (path named by the manifest)",
    "NONE": "none selected",
}


def source_fact_rows(facts, state=None):
    """What the operator needs to know about the chosen .3dm.

    The origin is shown because a path alone does not say whether anyone
    chose it, and a source carried over from a previous manifest looks
    exactly like a correct one.
    """
    facts = facts or {}
    provenance = getattr(state, "source_provenance", "NONE")
    rows = [
        ("Source origin", PROVENANCE_LABELS.get(provenance, provenance)),
    ]
    if getattr(state, "source_retained_override", False):
        rows.append(("Source warning",
                     "RETAINED MANUAL OVERRIDE - confirm it belongs to this "
                     "manifest"))
    return rows + [
        ("Source 3DM path", fmt.full_path(facts.get("Path"))),
        ("File size", fmt.file_size(facts.get("SizeBytes"))),
        ("SHA-256", fmt.full_hash(facts.get("Sha256"))),
        ("Model units", fmt.optional(facts.get("ModelUnits"))),
        ("Objects carrying DZ.SourceId",
         fmt.optional(facts.get("SourceIdObjectCount"))),
        ("Matching this building", fmt.optional(facts.get("MatchesSourceId"))),
    ]


def manifest_fact_rows(facts):
    facts = facts or {}
    return [
        ("Manifest path", fmt.full_path(facts.get("Path"))),
        ("SHA-256", fmt.full_hash(facts.get("Sha256"))),
        ("Project ID", fmt.optional(facts.get("ProjectId"))),
        ("Option", fmt.optional(facts.get("Option"))),
        ("Revision", fmt.optional(facts.get("Revision"))),
        ("Export timestamp", fmt.optional(facts.get("ExportTimestamp"))),
        ("Schema version", fmt.optional(facts.get("SchemaVersion"))),
        ("Buildings in manifest", fmt.optional(facts.get("BuildingCount"))),
    ]


def manifest_facts(path, manifest):
    """JSON-safe manifest facts. Never raises on a partial manifest."""
    from dz_revit_publisher import manifest_loader
    manifest = manifest or {}
    metadata = manifest.get("exportMetadata") or {}
    try:
        sha = manifest_loader.calculate_sha256(path) if path else None
    except Exception:
        sha = None
    return {
        "Path": path,
        "Sha256": sha,
        "ProjectId": metadata.get("ProjectId"),
        "Option": metadata.get("Option"),
        "Revision": metadata.get("Revision"),
        "ExportTimestamp": metadata.get("ExportTimestamp"),
        "SchemaVersion": (metadata.get("SchemaVersion")
                          or manifest.get("schemaVersion")),
        "BuildingCount": len(manifest.get("buildings") or []),
    }


def building_rows(manifest, selected=None):
    """The single-selection building list. One building publishes per run."""
    rows = []
    for building in ((manifest or {}).get("buildings") or []):
        rows.append({
            "BuildingId": building.get("BuildingId"),
            "Name": fmt.optional(building.get("BuildingName")),
            "Program": fmt.optional(building.get("Program")),
            "FloorCount": fmt.optional(building.get("FloorCount")),
            "FootprintArea": fmt.square_metres(building.get("FootprintArea")),
            "Selected": building.get("BuildingId") == selected,
        })
    return rows


# -- Phase 8D: multi-select filters -----------------------------------------

#: The action toggles above the table. REPLACE is a physical sub-action rather
#: than a classification, so it filters separately from the eight statuses.
REPLACE_FILTER = "Replace"
TOGGLE_FILTERS = (cd.CREATE, cd.UPDATE_PARAMETERS, cd.UPDATE_ELEVATION,
                  cd.UPDATE_GEOMETRY, REPLACE_FILTER, cd.SKIP, cd.OBSOLETE,
                  cd.CONFLICT, cd.BLOCKED)


def filter_rows_multi(rows, selected=None):
    """Union of the active toggles. No toggle active means everything.

    Conflicts and blockers survive every combination, for the reason Phase 8C
    established: a filter left set is how an operator publishes something they
    never inspected.
    """
    active = [f for f in (selected or []) if f]
    if not active:
        return list(rows)
    keep = []
    for row in rows:
        matched = row.get("Action") in active
        if REPLACE_FILTER in active and row.get("IsReplacement"):
            matched = True
        if matched or row.get("NeedsAttention"):
            keep.append(row)
    return keep


def toggle_counts(rows):
    """The count beside each toggle, including zeros."""
    counts = dict((name, 0) for name in TOGGLE_FILTERS)
    for row in rows:
        action = row.get("Action")
        if action in counts:
            counts[action] += 1
        if row.get("IsReplacement"):
            counts[REPLACE_FILTER] += 1
    return [(name, counts[name]) for name in TOGGLE_FILTERS]


# -- Phase 8D: element detail -----------------------------------------------

ADDED = "added"
REMOVED = "removed"
CHANGED = "changed"

#: Textual markers, so a diff stays readable with all colour removed.
DIFF_MARKERS = {ADDED: "[+]", REMOVED: "[-]", CHANGED: "[~]"}


def snapshot_diff(change):
    """Only the fields that actually differ, each classified textually."""
    previous = (change or {}).get("PreviousSnapshot") or {}
    current = (change or {}).get("CurrentSnapshot") or {}
    rows = []
    for field in sorted(set(list(previous.keys()) + list(current.keys()))):
        was, now = previous.get(field), current.get(field)
        if was == now:
            continue
        if field not in previous or was is None:
            kind = ADDED
        elif field not in current or now is None:
            kind = REMOVED
        else:
            kind = CHANGED
        rows.append({
            "Field": field,
            "Kind": kind,
            "Marker": DIFF_MARKERS[kind],
            "Was": fmt.optional(was),
            "Now": fmt.optional(now),
            "Text": "%s %-18s %s -> %s" % (DIFF_MARKERS[kind], field,
                                           fmt.optional(was),
                                           fmt.optional(now)),
        })
    return rows


IDENTITY_BLOCK_LINES = (
    "The existing element will be REPLACED, not updated in place.",
    "Its ElementId changes; the stable FloorKey does not.",
    "SourceId ownership is unchanged.",
)


def identity_change_block(row):
    """Shown for a physical replacement only. Empty for everything else."""
    if not row or not row.get("IsReplacement"):
        return []
    return [
        ("Current ElementId", row.get("CurrentElementId")),
        ("New ElementId", fmt.NEW_ELEMENT_ID_PENDING),
        ("Stable FloorKey", "%s  (unchanged)" % row.get("StableKey")),
        ("SourceId ownership", "unchanged"),
        ("What happens", IDENTITY_BLOCK_LINES[0]),
        ("", IDENTITY_BLOCK_LINES[1]),
        ("", IDENTITY_BLOCK_LINES[2]),
    ]


def element_detail(row, change=None):
    """Every documented field for one selected row, untruncated."""
    if not row:
        return {"Rows": [], "Diff": [], "Identity": [], "Empty": True}
    detail = [
        ("FloorKey", row.get("StableKey")),
        ("Building", row.get("Building")),
        ("Floor index", row.get("FloorIndex")),
        ("Current ElementId", row.get("CurrentElementId")),
        ("Proposed action", row.get("ActionText")),
        ("Elevation was", row.get("PreviousElevation")),
        ("Elevation proposed", row.get("ProposedElevation")),
        ("Area was", row.get("PreviousArea")),
        ("Area proposed", row.get("ProposedArea")),
        ("Boundary hash was", row.get("PreviousBoundaryHashFull")),
        ("Boundary hash proposed", row.get("ProposedBoundaryHashFull")),
        ("Level action", row.get("LevelAction")),
        ("Floor action", row.get("FloorAction")),
        ("Boundary action", row.get("BoundaryAction")),
        ("Area action", row.get("AreaAction")),
        ("Area Plan action", row.get("AreaPlanAction")),
        ("Detail", row.get("Detail")),
        ("Reason", row.get("Reason") or "(none)"),
    ]
    return {
        "Rows": [(label, fmt.optional(value)) for label, value in detail],
        "Diff": snapshot_diff(change or {}),
        "Identity": identity_change_block(row),
        "Empty": False,
    }


def change_for_row(payload, row):
    """The raw engine record behind a rendered row, for the snapshot diff."""
    plan = (payload or {}).get("Plan") or {}
    for record in (list(plan.get("Changes") or [])
                   + list(plan.get("Obsolete") or [])):
        if record.get("StableKey") == (row or {}).get("StableKey"):
            return record
    return {}


# -- Phase 8D: issue sections -----------------------------------------------

#: Order is fixed and errors open by default: the operator must see what stops
#: them before what merely concerns them.
def issue_sections(state):
    return [
        {"Title": "Blocking Errors", "Expanded": True,
         "Items": list(state.blocking_errors)},
        {"Title": "Conflicts", "Expanded": False,
         "Items": list(state.conflicts)},
        {"Title": "Warnings", "Expanded": False,
         "Items": list(state.warnings)},
    ]


# -- Phase 8E: publish result ------------------------------------------------

NO_CHANGES = ("No changes written - the model already matches the approved "
              "source. This is a successful result.")
ROLLED_BACK_NOTE = ("The transaction was rolled back. No change was "
                    "assimilated into the model.")

#: Counters that mean something was written. `skipped` is not one of them.
WRITE_COUNTERS = ("identityMigrated", "parametersUpdated", "bindingsWritten",
                  "projectValuesUpdated", "levelsUpdated",
                  "levelParametersUpdated", "floorsCreated", "floorsReplaced",
                  "floorsGeometryEditedInPlace", "boundarySetsDeleted",
                  "boundarySetsCreated", "boundariesReplaced", "areasCreated",
                  "areasReplaced", "areasReassociated", "obsoleteMarked",
                  "obsoleteDeleted")


def wrote_nothing(results):
    """True when every write counter is zero - the idempotency signature."""
    if not results:
        return False
    return all(not results.get(name) for name in WRITE_COUNTERS)


#: What each layer's failure means for the model. The operator must be able to
#: tell "the plumbing broke" from "the write was rolled back" without reading
#: Python source.
NOT_ENTERED = "not entered"
NOT_STARTED = "not started"
NO_WRITE_ATTEMPTED = ("No Revit write was attempted. No transaction was "
                      "opened and the model is untouched.")
WRITE_ROLLED_BACK = ("A transaction group was started and rolled back. No "
                     "change was assimilated; the model is as it was.")


def failure_rows(session):
    """Where a failed attempt stopped, and what it means for the model.

    The first live publish reported ``FAILED / unavailable / unavailable`` and
    nothing else, because the exception existed only as a string folded into
    the plan's blockers. These rows are built from the trace instead.
    """
    trace = session.trace
    result = session.result or {}
    layer = ((trace.failed_layer if trace is not None else None)
             or result.get("FailureLayer"))
    if layer is None and session.state not in ("FAILED", "BLOCKED"):
        return []

    rows = [("Failure layer", fmt.optional(layer))]
    detail = (trace.failure if trace is not None and trace.failure
              else result.get("Exception")) or {}
    if detail.get("Type"):
        rows.append(("Exception", "%s: %s" % (detail["Type"],
                                              detail.get("Message"))))
    if detail.get("ClrType"):
        rows.append((".NET type", detail["ClrType"]))
    if detail.get("Inner"):
        rows.append(("Inner exception", detail["Inner"]))
    if detail.get("Note"):
        rows.append(("Note", detail["Note"]))

    entered = trace is not None and trace.reached("CONTROLLER", "entered")
    rows.append(("Controller publish", "entered" if entered
                 else NOT_ENTERED))
    rows.append(("Revit write", NOT_STARTED if not entered else
                 fmt.optional(result.get("TransactionResult"))))
    if not entered:
        rows.append(("Model", NO_WRITE_ATTEMPTED))
    return rows


def publish_result_rows(session):
    """The terminal result. Counters always in full, zeros included."""
    result = session.result or {}
    results = result.get("Results") or {}
    rows = [
        ("Publish state", session.state),
        ("Controller status", fmt.optional(controller_status(result))),
        ("Transaction", fmt.optional(result.get("TransactionResult"))),
    ]
    rows.extend(failure_rows(session))
    if session.state == "ROLLED BACK":
        rows.append(("Model", WRITE_ROLLED_BACK))
    if session.state == "DONE" and wrote_nothing(results):
        #: A success, and the UI must say so rather than looking like failure.
        rows.append(("Outcome", NO_CHANGES))
    if session.state == "ROLLED BACK":
        rows.append(("Outcome", ROLLED_BACK_NOTE))
        for stage in (result.get("StageResults") or []):
            #: Same key defect as `stage_rows`: this read `Result` and so
            #: named stage 1 as the failure whatever actually went wrong.
            if str(stage.get("Status", "")).lower() not in STAGE_OK:
                rows.append(("Failing stage", "%s %s"
                             % (fmt.optional(stage.get("Stage")),
                                fmt.optional(stage.get("Name")))))
                rows.append(("Stage error", fmt.optional(stage.get("Error"))))
                break
    for message in (result.get("Errors") or []):
        rows.append(("Error", message))
    for message in (result.get("Warnings") or [])[:12]:
        rows.append(("Warning", message))
    rows.extend(fmt.counter_rows(results))
    return rows


#: Stage statuses the executor treats as "this stage did not fail".
STAGE_OK = ("ok", "skipped", "pending")

#: What the session is doing, by state. Derived on every refresh from the
#: session itself rather than appended to a log, so it cannot go stale: after
#: the first successful live publish the newest log line still read "Publish
#: requested. Waiting for Revit." because nothing ever superseded it.
PUBLISH_STATUS_LINES = {
    "READY": "Ready. Publish requires explicit confirmation.",
    "WAITING FOR REVIT": "Publish requested. Waiting for Revit.",
    "PUBLISHING": "Publishing. Revit is executing the transaction group.",
    "DONE": "Publish completed successfully.",
    "BLOCKED": "Publish blocked before any write. The model is untouched.",
    "ROLLED BACK": "Publish rolled back. No change was assimilated.",
    "FAILED": "Publish failed. See the Publish tab for the failing layer.",
}

DONE_WITH_WARNINGS = "Publish completed with warnings."


def validation_rows(validation, wiring=None):
    """The armed-state fields, for the safety strip and the Publish banner.

    Empty for a production session, so the banner simply does not exist there.
    A screenshot of a validation session must be self-proving: mode, stage and
    channel are all on screen, and none of them is inferred from a console.
    """
    if validation is None or not validation.active:
        return []
    from . import publish as pub
    rows = list(validation.rows())
    ready = wiring is not None and getattr(wiring, "available", False)
    rows.append(("Publish channel", "READY" if ready else "NOT READY"))
    if not validation.armed:
        rows.append(("Armed", pub.NOT_ARMED))
    return rows


def validation_banner(validation, wiring=None):
    """The block shown at the top of the Publish tab. Empty in production."""
    rows = validation_rows(validation, wiring)
    if not rows:
        return []
    return (["=" * 62, "FORCED ROLLBACK VALIDATION - DEVELOPMENT SESSION",
             "=" * 62]
            + ["  %-18s %s" % pair for pair in rows]
            + ["", "  This session will deliberately fail inside the Phase 7",
               "  TransactionGroup. The publish is expected to ROLL BACK.",
               "=" * 62])


def controller_status(result):
    """The controller's own verdict, under either of the two key names.

    A live result carries ``Status``; a publish-log entry carries the same
    value as ``PublishStatus``. `projection` already reconciles the two, and
    anything reading a verdict must do the same or it will quietly read a
    warning-carrying publish as a clean one.
    """
    result = result or {}
    return result.get("PublishStatus") or result.get("Status")


def publish_status_line(session):
    """One line on where the publish stands. Always current.

    Read from the session on every refresh through the same
    `refresh` -> `sync_controls` path that reconciles the controls, so there
    is one status mechanism rather than two that can disagree.
    """
    if session.state == "DONE":
        if controller_status(session.result) == "PUBLISHED WITH WARNINGS":
            return DONE_WITH_WARNINGS
    return PUBLISH_STATUS_LINES.get(session.state, str(session.state))


def stage_detail(stage):
    """The stage's own account of what it did, or why it failed."""
    parts = list(stage.get("Detail") or [])
    if stage.get("Error"):
        parts.append("ERROR: %s" % stage["Error"])
    return "; ".join(str(p) for p in parts)


def stage_rows(session):
    """All nine stages, in order, whatever the outcome.

    The status key is ``Status``. Reading ``Result`` - which no stage has ever
    carried - is what made all nine rows of the first successful live publish
    render `unavailable` beside `TransactionResult: assimilated`. The executor
    is unchanged; only this mapping was wrong.
    """
    result = session.result or {}
    return [(str(stage.get("Stage")), fmt.optional(stage.get("Name")),
             fmt.optional(stage.get("Status")), stage_detail(stage))
            for stage in (result.get("StageResults") or [])]


def replacement_map_rows(result):
    """Old -> new ElementId. Mandatory whenever anything was replaced.

    An element is never silently replaced: when this returns rows the view
    must show them, and must not allow them to be collapsed away.
    """
    results = (result or {}).get("Results") or {}
    rows = []
    for old_key, new_key in (("floorOldElementIds", "floorNewElementIds"),
                             ("areaOldElementIds", "areaNewElementIds")):
        old_ids = [str(i) for i in (results.get(old_key) or [])]
        new_ids = [str(i) for i in (results.get(new_key) or [])]
        kind = "Floor" if old_key.startswith("floor") else "Area"
        for index, old_id in enumerate(old_ids):
            new_id = new_ids[index] if index < len(new_ids) else "(unrecorded)"
            rows.append((kind, old_id, new_id))
    return rows


def replacement_map_required(result):
    results = (result or {}).get("Results") or {}
    return bool(results.get("floorsReplaced") or results.get("areasReplaced"))


# -- Phase 12C: the project review table ------------------------------------

#: (heading, row key, width). Freshness sits *before* the verdict, so the
#: first thing read about a remembered row is how old it is.
PROJECT_COLUMNS = (
    ("Building", "BuildingId", 70),
    ("Name", "Name", 120),
    #: The filename, never the path. The full path lives in the row's
    #: `ExpectedRvtFull` and in the notice under the table - one absolute
    #: path was enough to set the width of the entire dashboard.
    ("Expected RVT", "ExpectedRvt", 140),
    ("Model State", "ModelState", 95),
    ("Freshness", "Freshness", 165),
    ("Plan", "Plan", 60),
    ("Changes", "Changes", 60),
    ("Obsolete", "Obsolete", 65),
    ("Blockers", "Blockers", 60),
    ("Conflicts", "Conflicts", 62),
    ("Last Analysed", "LastAnalysed", 90),
)


def project_review_rows(manifest, state):
    """One row per building in the manifest, in manifest order.

    Driven by the manifest rather than by the results store, so the table is
    the same whatever order the buildings were visited in, and a building
    that has never been analysed still appears - as NOT ANALYSED, which is a
    fact the operator needs, not an absence to hide.
    """
    rows = []
    for building in ((manifest or {}).get("buildings") or []):
        bid = building.get("BuildingId")
        result = state.review_for(bid)
        freshness = st.classify_freshness(result, state.live_facts_for(bid))
        expected = state.expected_rvt_for(bid)
        rows.append({
            "BuildingId": bid,
            "Name": fmt.optional(building.get("BuildingName")),
            "ExpectedRvt": (os.path.basename(expected) if expected
                            else "(not set)"),
            "ExpectedRvtFull": fmt.optional(expected),
            #: Where the model stands, which is a different question from how
            #: old the result is. ACTIVE says the document is in front of the
            #: operator; it says nothing about whether the last result still
            #: describes it - that is Freshness, in its own column.
            "ModelState": model_state(state, bid),
            "Freshness": st.FRESHNESS_LABELS[freshness],
            "FreshnessState": freshness,
            "FreshnessNote": st.FRESHNESS_NOTES[freshness],
            #: The verdict is what the plan said when it was generated. It is
            #: rendered in its own column, never merged into Freshness, so a
            #: remembered VALID cannot be read as a claim about now.
            "Plan": result.verdict if result is not None else st.NO_VERDICT,
            "Changes": _count_cell(result, "changes"),
            "Obsolete": _count_cell(result, "obsolete"),
            "Blockers": (str(len(result.blockers)) if result is not None
                         else st.NO_VERDICT),
            "Conflicts": (str(len(result.conflicts)) if result is not None
                          else st.NO_VERDICT),
            "LastAnalysed": (fmt.optional(result.generated_at)
                             if result is not None else st.NO_VERDICT),
            "Selected": bid == state.building_id,
            "IsCurrent": st.is_current(freshness),
        })
    return rows


def _count_cell(result, attribute):
    if result is None:
        return st.NO_VERDICT
    return str(getattr(result, attribute))


#: How each freshness state is totalled. Every state maps to exactly one
#: bucket and every bucket is shown, so the buckets always sum to the number
#: of buildings - a summary that hid a state would be a summary that hid a
#: building.
FRESHNESS_BUCKETS = (
    ("Current", (st.CURRENT,)),
    ("Cached - RVT not open", (st.CACHED_NOT_OPEN,)),
    ("Stale", (st.STALE_SOURCE, st.STALE_SNAPSHOT)),
    ("Wrong model for the building", (st.WRONG_ACTIVE_MODEL,)),
    ("Expected RVT not assigned", (st.RVT_NOT_ASSIGNED,)),
    ("Not analysed", (st.NOT_ANALYSED,)),
)


def project_review_totals(rows):
    """Aggregate the table. Every change total is labelled LAST ANALYSED.

    Current and remembered counts are never added together into one
    unlabelled number: the totals below describe what the last analysis of
    each building said, which is not the same as what is true now, and the
    labels say so.
    """
    rows = list(rows or [])
    states = [row["FreshnessState"] for row in rows]
    totals = [("Buildings", len(rows))]
    for label, members in FRESHNESS_BUCKETS:
        totals.append((label, sum(1 for one in states if one in members)))
    analysed = [row for row in rows if row["FreshnessState"] != st.NOT_ANALYSED]
    totals.extend([
        ("Last-known valid plans",
         sum(1 for row in analysed if row["Plan"] == "VALID")),
        ("Last-known blocked plans",
         sum(1 for row in analysed if row["Plan"] == "BLOCKED")),
        ("LAST ANALYSED changes", _sum_cells(analysed, "Changes")),
        ("LAST ANALYSED obsolete", _sum_cells(analysed, "Obsolete")),
        ("LAST ANALYSED blockers", _sum_cells(analysed, "Blockers")),
        ("LAST ANALYSED conflicts", _sum_cells(analysed, "Conflicts")),
    ])
    return totals


def _sum_cells(rows, key):
    total = 0
    for row in rows:
        value = row.get(key)
        if value not in (None, st.NO_VERDICT):
            total += int(value)
    return total


#: Shown whenever the Change Plan table is rendering a remembered result
#: rather than a live one. Publishing needs the live path, every time.
REVIEW_ONLY_NOTICE = (
    "REVIEW ONLY - this is a cached result from an earlier visit, not a "
    "current validation.")
REOPEN_NOTICE = ("Open the expected RVT and Refresh, Analyse and Generate "
                 "Change Plan again before publishing.")


def review_banner(state):
    """The lines shown above a cached Change Plan. Empty when it is live."""
    result = getattr(state, "review_preview", None)
    if result is None:
        return []
    freshness = st.classify_freshness(result,
                                      state.live_facts_for(result.building_id))
    return [
        "%s  %s" % (REVIEW_ONLY_NOTICE, result.building_id),
        "Freshness: %s - %s" % (st.FRESHNESS_LABELS[freshness],
                                st.FRESHNESS_NOTES[freshness]),
        "Plan result when analysed: %s at %s"
        % (result.verdict, fmt.optional(result.generated_at)),
        REOPEN_NOTICE,
    ]


# -- Phase 13A: the Project Setup dashboard ---------------------------------
#
# A **view** over state that already exists. Nothing below owns anything: the
# manifest, the selected building, the per-building expected paths, the review
# results, the snapshot, the analysis, the plan and the publish gate are all
# read from where they already live. There is no second planning state
# machine here, and nothing on this dashboard can create readiness - it can
# only report the readiness the rest of the product already decided.

#: What the operator can be told about a building's model without inferring
#: anything. `NOT ACTIVE` deliberately does not say "closed": a document can
#: be open in Revit without being the active one, and the product cannot tell
#: the difference. Presentation only - nothing here reads a file.
MODEL_ACTIVE = "ACTIVE"
MODEL_NOT_ACTIVE = "NOT ACTIVE"
MODEL_UNBOUND = "UNBOUND"

MODEL_STATES = (MODEL_ACTIVE, MODEL_NOT_ACTIVE, MODEL_UNBOUND)

MODEL_STATE_NOTES = {
    MODEL_ACTIVE: "This building's Expected RVT is the active Revit document.",
    MODEL_NOT_ACTIVE: ("This building's Expected RVT is not the active "
                       "document, so its current state is unknown."),
    MODEL_UNBOUND: "No Expected RVT has been assigned to this building.",
}


def model_state(state, building_id):
    """Where this building's model stands, as far as can honestly be said."""
    expected = state.expected_rvt_for(building_id)
    if not expected:
        return MODEL_UNBOUND
    if st.same_path(expected, state.active_rvt_path):
        return MODEL_ACTIVE
    return MODEL_NOT_ACTIVE


# -- the project header ------------------------------------------------------

# -- Phase 13B: the operator-facing source vocabulary -----------------------
#
# One vocabulary, extended in place. Phase 13A introduced these states in
# implementation language (OK / NOT SET / NOT FOUND); 13B renames them to what
# an operator would say and adds the one distinction that was missing -
# CHANGED. Nothing here is a second state machine: every answer is derived
# from `state.source_facts`, `state.source_retained_override` and the review
# store, all of which already exist and are already authoritative.

SOURCE_CURRENT = "CURRENT"
SOURCE_CHANGED = "CHANGED"
SOURCE_MISSING = "MISSING"
SOURCE_UNREADABLE = "UNREADABLE"
SOURCE_UNCONFIRMED = "UNCONFIRMED"
SOURCE_NOT_SELECTED = "NOT SELECTED"

SOURCE_STATES = (SOURCE_CURRENT, SOURCE_CHANGED, SOURCE_MISSING,
                 SOURCE_UNREADABLE, SOURCE_UNCONFIRMED, SOURCE_NOT_SELECTED)

#: The one phrase Rhino produces when `File3dm.Read` returns None. Phase 10A
#: established the rule this depends on: a missing Rhino makes every 3DM look
#: unopenable, so only positive evidence of failure counts as UNREADABLE.
_UNOPENABLE = "could not be opened"


def source_status(state):
    """Whether the selected source .3dm is usable, in operator terms.

    **Unknown is not failure.** Without Rhino, `describe` returns file facts
    and a warning saying model facts could not be read. That warning is not
    evidence of a bad file, so it never produces UNREADABLE - it would
    otherwise condemn every source on every machine without Rhino, which is
    the Phase 10A hardening this must not regress. Only the reader's explicit
    "could not be opened" counts.

    Equally, identity that cannot be established is not identity that
    matches: a file whose hash could not be computed reads UNCONFIRMED rather
    than CURRENT.
    """
    if not state.source_3dm_path:
        return SOURCE_NOT_SELECTED
    facts = state.source_facts or {}
    if facts.get("Exists") is False:
        return SOURCE_MISSING
    for warning in (facts.get("Warnings") or []):
        if _UNOPENABLE in str(warning):
            return SOURCE_UNREADABLE
    if getattr(state, "source_retained_override", False):
        #: Carried across a manifest change without being re-affirmed. It may
        #: belong to the previous project, so it is not called current.
        return SOURCE_UNCONFIRMED
    current = facts.get("Sha256")
    if not current:
        #: The file is there and nothing says it is bad, but its identity has
        #: not been established. That is a third answer, not a yes.
        return SOURCE_UNCONFIRMED
    if source_changed_since_review(state, current):
        return SOURCE_CHANGED
    return SOURCE_CURRENT


def source_changed_since_review(state, current=None):
    """Was any existing review built on a different source?

    A statement about the *relationship* between the source and the reviews
    already gathered - which is why it is asked separately from whether the
    source is readable. With no reviews yet there is nothing to contradict,
    and the source is simply current.

    Reads the same recorded hash `classify_freshness` uses, so CHANGED here
    and STALE_SOURCE there can never disagree.
    """
    if current is None:
        current = (state.source_facts or {}).get("Sha256")
    if not current:
        return False
    for result in (state.review_results_by_building or {}).values():
        if result.source_sha256 and result.source_sha256 != current:
            return True
    return False


#: The operator message for each state, and the sentence that explains it.
#: Raw diagnostics are never the headline - they are kept, separately, by
#: `source_diagnostics` below.
SOURCE_HEADLINES = {
    SOURCE_CURRENT: (
        "SOURCE CURRENT",
        "The Rhino planning source is readable and matches every review in "
        "this session."),
    SOURCE_CHANGED: (
        "SOURCE CHANGED",
        "The Rhino planning source changed after the current review. "
        "Analyse again before publishing."),
    SOURCE_MISSING: (
        "SOURCE MISSING",
        "The expected Rhino source file cannot be found."),
    SOURCE_UNREADABLE: (
        "SOURCE UNREADABLE",
        "The source file exists but DZ Planning Tools could not read it."),
    SOURCE_UNCONFIRMED: (
        "SOURCE UNCONFIRMED",
        "The source file could not be confirmed as this project's. Press "
        "Browse Source 3DM to choose it again, or Detect Inputs."),
    SOURCE_NOT_SELECTED: (
        "NO SOURCE SELECTED",
        "No Rhino source .3dm has been chosen for this project."),
}


# -- the manifest ------------------------------------------------------------

MANIFEST_LOADED = "LOADED"
MANIFEST_INVALID = "INVALID"
MANIFEST_NOT_SELECTED = "NOT SELECTED"

MANIFEST_STATES = (MANIFEST_LOADED, MANIFEST_INVALID, MANIFEST_NOT_SELECTED)

MANIFEST_HEADLINES = {
    MANIFEST_LOADED: ("MANIFEST LOADED",
                      "The project manifest was read successfully."),
    MANIFEST_INVALID: (
        "MANIFEST INVALID",
        "The project manifest is missing or cannot be interpreted."),
    MANIFEST_NOT_SELECTED: ("NO MANIFEST SELECTED",
                            "No project_manifest.json has been chosen."),
}


def manifest_status(state):
    """Loaded, invalid, or not chosen. Distinguished truthfully.

    `load_manifest_facts` empties `manifest_facts` and blocks with the reason
    whenever the file cannot be read or parsed, so an empty facts dict beside
    a selected path is exactly the "could not be interpreted" case - not a
    guess, and not a second parser.
    """
    if not state.manifest_path:
        return MANIFEST_NOT_SELECTED
    if not (state.manifest_facts or {}):
        return MANIFEST_INVALID
    return MANIFEST_LOADED


# -- diagnostics, kept but demoted ------------------------------------------

def source_diagnostics(state):
    """The technical detail, gathered in one place and shown *below* the
    status. Nothing is discarded; it simply stops being the headline.

    Raw reader and detection text is precise and useless as a first line -
    the Phase 9B live run reported `Source 3DM could not be read: ...` far
    from the decision that caused it, and the operator had no way to act on
    it.
    """
    lines = []
    for found in (state.manifest_detection, state.source_detection):
        for problem in (getattr(found, "problems", None) or []):
            if problem not in lines:
                lines.append(problem)
    for warning in ((state.source_facts or {}).get("Warnings") or []):
        if warning not in lines:
            lines.append(warning)
    for warning in ((state.manifest_facts or {}).get("Warnings") or []):
        if warning not in lines:
            lines.append(warning)
    return lines


def project_header_rows(state, manifest=None):
    """PROJECT SOURCE - what is loaded, and whether it can be relied on.

    Operator language throughout. Filenames rather than paths, a named status
    rather than a hash comparison, and a count rather than a schema dump. The
    full paths, hashes and schema fields remain in the facts panel below.
    """
    manifest = manifest or {}
    facts = state.manifest_facts or {}
    buildings = (manifest.get("buildings") or [])
    return [
        ("Manifest", _base(state.manifest_path)),
        ("Manifest status", manifest_status(state)),
        ("Project", fmt.optional(facts.get("ProjectId"))),
        ("Option / revision", "%s / %s" % (fmt.optional(facts.get("Option")),
                                           fmt.optional(
                                               facts.get("Revision")))),
        ("Source 3DM", _base(state.source_3dm_path)),
        ("Source status", source_status(state)),
        ("Source identity", _identity_line(state)),
        ("Buildings", str(len(buildings))),
        ("Selected building", state.building_id or "(none)"),
    ]


def _identity_line(state):
    """Whether this source carries objects for the selected building.

    `MatchesSourceId` is None when Rhino could not be asked. That reads as
    unavailable, never as a mismatch - the same rule the status above obeys.
    """
    matches = (state.source_facts or {}).get("MatchesSourceId")
    if matches is None:
        return "Not confirmed"
    return "Matched" if matches else "DOES NOT MATCH this building"


def source_headline(state):
    """The two operator lines: what the status is, and what it means."""
    return SOURCE_HEADLINES[source_status(state)]


def manifest_headline(state):
    return MANIFEST_HEADLINES[manifest_status(state)]


def source_section(state):
    """The whole PROJECT SOURCE block, headline first, detail last."""
    manifest_title, manifest_detail = manifest_headline(state)
    source_title, source_detail = source_headline(state)
    blocks = [("MANIFEST", [manifest_title, manifest_detail]),
              ("SOURCE", [source_title, source_detail])]
    diagnostics = source_diagnostics(state)
    if diagnostics:
        blocks.append(("DETAILS", list(diagnostics)))
    return blocks


def _base(path):
    return os.path.basename(path) if path else "(not set)"


# -- the status block --------------------------------------------------------

RVT_OK = "OK"
RVT_NO_DOCUMENT = "NO ACTIVE DOCUMENT"
RVT_NOT_ASSIGNED = "NOT ASSIGNED"
RVT_WRONG_MODEL = "WRONG MODEL"

SNAPSHOT_NONE = "NONE"
SNAPSHOT_CURRENT = "CURRENT"
SNAPSHOT_STALE = "STALE"
SNAPSHOT_READ = "READ"

ANALYSIS_COMPLETE = "COMPLETE"
ANALYSIS_NOT_RUN = "NOT RUN"

PLAN_VALID = "VALID"
PLAN_BLOCKED = "BLOCKED"
PLAN_NOT_GENERATED = "NOT GENERATED"


def rvt_status(state):
    if not state.active_rvt_path:
        return RVT_NO_DOCUMENT
    if not state.expected_rvt_path:
        return RVT_NOT_ASSIGNED
    return RVT_OK if state.paths_match else RVT_WRONG_MODEL


def snapshot_status(state):
    """What the live read is worth for the selected building.

    Reuses the Phase 12C freshness classification rather than re-deriving a
    parallel notion of currency - there is one answer to "is this still
    true?", and it is `classify_freshness`.
    """
    if not state.active_rvt_path:
        return SNAPSHOT_NONE
    freshness = state.freshness_of(state.building_id)
    if st.is_current(freshness):
        return SNAPSHOT_CURRENT
    if freshness in (st.STALE_SNAPSHOT, st.STALE_SOURCE):
        return SNAPSHOT_STALE
    #: A snapshot exists, but no current review result depends on it.
    return SNAPSHOT_READ


def plan_status(state):
    if not state.plan:
        return PLAN_NOT_GENERATED
    return PLAN_VALID if state.plan_valid is True else PLAN_BLOCKED


def status_rows(state):
    """The five-line readiness block. Each line is one existing fact."""
    return [
        ("Source", source_status(state)),
        ("RVT", rvt_status(state)),
        ("Snapshot", snapshot_status(state)),
        ("Analysis", ANALYSIS_COMPLETE if state.analysis
         else ANALYSIS_NOT_RUN),
        ("Plan", plan_status(state)),
        ("Blockers", str(len(state.blocking_errors))),
        ("Conflicts", str(len(state.conflicts))),
    ]


# -- Next Action -------------------------------------------------------------

NEXT_LOAD_PROJECT = "LOAD_PROJECT"
#: Phase 13B split the single "resolve the project source" step into the four
#: things that can actually be wrong, because "load the project" is useless
#: advice to someone whose source file was moved.
NEXT_REPAIR_MANIFEST = "REPAIR_MANIFEST"
NEXT_RESTORE_SOURCE = "RESTORE_SOURCE"
NEXT_RESOLVE_SOURCE = "RESOLVE_SOURCE"
NEXT_REANALYSE_SOURCE = "REANALYSE_SOURCE"
NEXT_SELECT_BUILDING = "SELECT_BUILDING"
NEXT_ASSIGN_RVT = "ASSIGN_RVT"
NEXT_OPEN_EXPECTED = "OPEN_EXPECTED"
NEXT_REFRESH = "REFRESH"
NEXT_ANALYSE = "ANALYSE"
NEXT_RESOLVE_BLOCKERS = "RESOLVE_BLOCKERS"
NEXT_GENERATE_PLAN = "GENERATE_PLAN"
NEXT_APPROVE = "APPROVE"
NEXT_READY = "READY"

#: The order they are tested in, and the only order. Exposed so a test can
#: assert the sequence rather than infer it from ten separate scenarios.
NEXT_ACTION_PRECEDENCE = (
    NEXT_LOAD_PROJECT, NEXT_REPAIR_MANIFEST, NEXT_RESTORE_SOURCE,
    NEXT_RESOLVE_SOURCE, NEXT_SELECT_BUILDING, NEXT_REFRESH,
    NEXT_ASSIGN_RVT, NEXT_OPEN_EXPECTED, NEXT_REANALYSE_SOURCE,
    NEXT_ANALYSE, NEXT_RESOLVE_BLOCKERS, NEXT_GENERATE_PLAN, NEXT_APPROVE,
    NEXT_READY)


def next_action(state, session=None, gate_reasons=None):
    """What to do next, decided by rule and returned as text. Guidance only.

    Deterministic: the same state always produces the same answer, and every
    branch reads state that already exists. It performs nothing, and it is
    never consulted by the publish gate - the arrow points one way, from the
    gate into this, so a recommendation can never become a permission.

    The precedence is the brief's, with one refinement: an analysis that has
    not run *because* something is blocking reports the blocker rather than
    telling the operator to press Analyse again. Advising an action that is
    already known to fail is worse than saying nothing.
    """
    gate_reasons = list(gate_reasons or [])
    blockers = list(state.blocking_errors)

    #: The project source comes first, and each way it can be wrong gets its
    #: own instruction. "Load the project" is useless advice to someone whose
    #: source file was moved.
    manifest = manifest_status(state)
    if manifest == MANIFEST_NOT_SELECTED and not state.source_3dm_path:
        return _action(NEXT_LOAD_PROJECT, "Load the project",
                       "Select a project_manifest.json and its source .3dm, "
                       "or press Detect Inputs.")
    if manifest != MANIFEST_LOADED:
        return _action(NEXT_REPAIR_MANIFEST, "Load a readable project manifest",
                       MANIFEST_HEADLINES[manifest][1])

    source = source_status(state)
    if source == SOURCE_NOT_SELECTED:
        return _action(NEXT_LOAD_PROJECT, "Select the Rhino source",
                       SOURCE_HEADLINES[source][1])
    if source == SOURCE_MISSING:
        return _action(NEXT_RESTORE_SOURCE,
                       "Restore or select the Rhino source file",
                       SOURCE_HEADLINES[source][1])
    if source in (SOURCE_UNREADABLE, SOURCE_UNCONFIRMED):
        return _action(NEXT_RESOLVE_SOURCE,
                       "Resolve the %s Rhino source" % source.lower(),
                       SOURCE_HEADLINES[source][1])

    if not state.building_id:
        return _action(NEXT_SELECT_BUILDING, "Select a Building",
                       "Choose which building to work on.")

    status = rvt_status(state)
    if status == RVT_NO_DOCUMENT:
        return _action(NEXT_REFRESH, "Refresh the active Revit model",
                       "No active Revit document has been read yet.")
    if status == RVT_NOT_ASSIGNED:
        return _action(NEXT_ASSIGN_RVT,
                       "Assign the active RVT to %s" % state.building_id,
                       "Press Use Active RVT as Expected Path.")
    if status == RVT_WRONG_MODEL:
        return _action(NEXT_OPEN_EXPECTED, "Open the Expected RVT",
                       "%s expects %s, but a different document is active."
                       % (state.building_id,
                          _base(state.expected_rvt_path)))
    #: Two different reasons a result stops being current, and two
    #: different fixes. Phase 13A sent both to Refresh, which does nothing
    #: about a changed .3dm - the source has to be read again, and that is
    #: Analyse.
    if state.freshness_of(state.building_id) == st.STALE_SOURCE:
        return _action(NEXT_REANALYSE_SOURCE,
                       "Analyse %s again" % state.building_id,
                       SOURCE_HEADLINES[SOURCE_CHANGED][1])
    if snapshot_status(state) == SNAPSHOT_STALE:
        return _action(NEXT_REFRESH, "Refresh the active Revit model",
                       "The live snapshot was re-read after the last result, "
                       "so the model may have changed since.")
    if not state.analysis and not blockers:
        return _action(NEXT_ANALYSE, "Analyse %s" % state.building_id,
                       "Read the source, the manifest and the live model.")
    if blockers:
        return _action(NEXT_RESOLVE_BLOCKERS,
                       "Resolve %d blocker%s before publishing"
                       % (len(blockers), "" if len(blockers) == 1 else "s"),
                       blockers[0])
    if not state.plan:
        return _action(NEXT_GENERATE_PLAN, "Generate the Change Plan",
                       "Classify what would change in %s."
                       % state.building_id)
    if gate_reasons:
        return _action(NEXT_APPROVE, "Review and approve the Change Plan",
                       gate_reasons[0])
    return _action(NEXT_READY, "Ready to Publish",
                   "%s is ready to publish to %s."
                   % (state.building_id, _base(state.expected_rvt_path)))


def _action(code, action, detail):
    return {"Code": code, "Action": action, "Detail": detail}


def next_action_rows(recommendation):
    return [("Next action", recommendation["Action"]),
            ("Why", recommendation["Detail"])]
