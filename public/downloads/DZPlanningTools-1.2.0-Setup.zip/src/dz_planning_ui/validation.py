"""Readiness checks the UI performs before it asks the controller anything.

These duplicate no domain logic: the engine remains the authority on whether a
plan is publishable. This is only about whether the window has enough
information to make a sensible request, and about surfacing the wrong-model
condition prominently.
"""

import os

from dz_planning_app import expected_path_conflict

RETAINED_OVERRIDE = (
    "The source .3dm was chosen manually for a different manifest and has "
    "been retained. Confirm it belongs to this manifest - press Browse "
    "Source 3DM to re-affirm it, or Detect Inputs to find the one beside "
    "the manifest.")

MISSING_MANIFEST = "Select a project_manifest.json before running Analyse."
MISSING_SOURCE = "Select the source .3dm before running Analyse."
NO_ACTIVE_DOCUMENT = "No active Revit document."


def setup_problems(state):
    """Blocking reasons, in the order the operator should fix them."""
    problems = []
    if not state.active_rvt_path:
        problems.append(NO_ACTIVE_DOCUMENT)
    if not state.manifest_path:
        problems.append(MISSING_MANIFEST)
    elif not os.path.isfile(state.manifest_path):
        problems.append("Manifest not found: %s" % state.manifest_path)
    if not state.source_3dm_path:
        problems.append(MISSING_SOURCE)
    elif not os.path.isfile(state.source_3dm_path):
        problems.append("Source 3DM not found: %s" % state.source_3dm_path)
    if getattr(state, "source_retained_override", False):
        #: Blocking, so a manual source carried across a manifest change can
        #: never reach Plan Valid YES without being re-affirmed.
        problems.append(RETAINED_OVERRIDE)
    conflict = expected_path_conflict(state.expected_rvt_path,
                                      state.active_rvt_path)
    if conflict:
        problems.append(conflict)
    return problems


def is_wrong_model(state):
    return bool(expected_path_conflict(state.expected_rvt_path,
                                       state.active_rvt_path))


def planning_ready(state):
    """A wrong model blocks planning readiness outright."""
    return not setup_problems(state)


NO_BUILDING = "Select a building before generating a Change Plan."
NO_EXPECTED = "Set the Expected RVT path before generating a Change Plan."
NOT_ANALYSED = "Run Analyse before opening the Change Plan."
NO_PLAN = "Generate a Change Plan to open this tab."
BLOCKED_PLAN = ("The Change Plan is BLOCKED. Resolve the "
                "blocking errors before it can be reviewed.")


def plan_tab_lock_reasons(state):
    """Why the Change Plan tab is locked. Empty means it opens.

    Ordered so the operator is told the first thing to fix, not the last
    consequence of not having fixed it.
    """
    reasons = list(setup_problems(state))
    if not state.building_id:
        reasons.append(NO_BUILDING)
    if not state.expected_rvt_path:
        reasons.append(NO_EXPECTED)
    if not state.analysis:
        reasons.append(NOT_ANALYSED)
    elif not state.plan:
        reasons.append(NO_PLAN)
    #: A payload that failed integrity locks the tab exactly as a wrong model
    #: does. It is never rendered "for information".
    if state.integrity is not None and not state.integrity.ok:
        reasons.append(state.integrity.blocking_reason)
    #: A BLOCKED payload is safe to *inspect* - nothing executed - but it is
    #: not an approvable plan. The blocking panel shows; the table does not.
    #: Its own reasons are used verbatim, so a wrong model still reads as the
    #: engine's frozen message rather than a paraphrase.
    if state.plan_is_blocked:
        blocking = [r for r in state.blocking_errors if r not in reasons]
        reasons.extend(blocking or [BLOCKED_PLAN])
    #: Incomplete context is stated outright rather than left implied. A
    #: payload whose bindings are absent has not been shown to describe this
    #: setup, and must never be presented as though it had.
    if state.integrity is not None:
        note = state.integrity.incomplete_context_reason
        if note and note not in reasons:
            reasons.append(note)
    return reasons


def plan_tab_unlocked(state):
    return not plan_tab_lock_reasons(state)


# -- Phase 8E: the publish gate ---------------------------------------------

NO_PLAN_TO_PUBLISH = "Generate a Change Plan before publishing."
PLAN_NOT_APPROVABLE = "The Change Plan is not approvable."
PREVIEW_ONLY_MODE = ("Publish Mode is Preview Only. Preview never writes; "
                     "choose Create or Update to publish.")
NOT_CONFIRMED = "Tick Confirm Publish before publishing."
NO_EXPECTED_PATH = "Set the Expected RVT path before publishing."
WRONG_MODEL_PUBLISH = ("The active document is not the expected model. "
                       "Publishing is blocked.")
DISPATCHER_BUSY = "A publish is already in flight."
HAS_BLOCKING_ERRORS = "Resolve the blocking errors before publishing."


def publish_gate_reasons(state, session, dispatcher=None, validation=None,
                         wiring=None):
    """Why Publish is disabled. Empty means every gate passed.

    Ordered so the operator is told the first thing to fix. Publishing is the
    one irreversible action in the product, so every condition is stated
    rather than folded into a single boolean.
    """
    reasons = []
    if not state.plan:
        reasons.append(NO_PLAN_TO_PUBLISH)
        return reasons
    if state.plan_valid is not True:
        reasons.append(PLAN_NOT_APPROVABLE)
    result = state.integrity
    if result is not None and not result.approvable:
        reasons.append(PLAN_NOT_APPROVABLE)
    if not session.wants_write:
        reasons.append(PREVIEW_ONLY_MODE)
    if not session.confirm_publish:
        reasons.append(NOT_CONFIRMED)
    if not state.expected_rvt_path:
        reasons.append(NO_EXPECTED_PATH)
    elif not state.paths_match:
        reasons.append(WRONG_MODEL_PUBLISH)
    if state.blocking_errors:
        reasons.append(HAS_BLOCKING_ERRORS)
    if session.in_flight or (dispatcher is not None
                             and getattr(dispatcher, "busy", False)):
        reasons.append(DISPATCHER_BUSY)
    if plan_tab_lock_reasons(state):
        reasons.append("The Change Plan is locked.")
    #: Development validation. Every one of these is refused rather than
    #: downgraded: a validation session that cannot arm its hook must not
    #: quietly become an ordinary publish that really writes.
    if validation is not None and validation.active:
        from . import publish as pub
        if not validation.armed:
            reasons.append(pub.NOT_ARMED)
        if wiring is not None and not getattr(wiring, "available", False):
            reasons.append(pub.CHANNEL_NOT_READY)
    #: De-duplicated, order preserved.
    seen, ordered = set(), []
    for reason in reasons:
        if reason not in seen:
            seen.add(reason)
            ordered.append(reason)
    return ordered
