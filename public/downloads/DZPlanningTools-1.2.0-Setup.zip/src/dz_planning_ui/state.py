"""UI session state and the concurrency guard.

Pure Python: no Eto, no Revit. The window binds to this; every decision the UI
makes about what is enabled is derived here, so it can be tested offline.
"""

import os

from . import detection

#: This checkpoint can write, through the ExternalEvent path only.
UI_MODE = "WRITE-ENABLED (publish requires explicit confirmation)"
PUBLISH_STATUS = "ARMED - requires confirmation"
#: The product name, and the only place it is written. Deliberately carries
#: no version: the authoritative product version lives in the installer and
#: is recorded in `install_manifest.json`, and the UI has no import path to
#: it. A number hardcoded here would be a second source of truth that could
#: drift from the first - worse than showing none.
PRODUCT_NAME = "DZ Planning Tools"

#: What the window is called. Internal phase numbers are development
#: vocabulary; they told an operator nothing and dated the product on sight.
WINDOW_TITLE = PRODUCT_NAME
FOOTER_NOTE = ("Publishing goes through a Revit ExternalEvent. Every write is "
               "confirmed, revalidated and transactional.")

IDLE = "idle"
BUSY = "busy"


class UiBusy(Exception):
    """Raised when a second long-running request arrives while one is running."""


class UiState(object):
    """Everything the window shows, and nothing it does."""

    def __init__(self):
        self.active_rvt_path = None
        self.expected_rvt_path = None
        self.source_3dm_path = None
        self.manifest_path = None
        self.building_id = "B001"

        self.analysis = None
        self.plan = None
        self.history = None
        #: The stable key of the selected History entry, not its index: a
        #: reload that prepends a newer entry would otherwise move the
        #: selection silently onto a different record.
        self.history_selection = None

        #: How the current source was chosen. A populated `source_3dm_path`
        #: is NOT evidence that the operator picked it; only this says so.
        self.source_provenance = detection.NONE
        #: True when a MANUAL source survived a manifest change without being
        #: re-affirmed. Blocking: it may belong to the previous setup.
        self.source_retained_override = False

        #: Detection outcomes and the facts rendered beside each field.
        self.manifest_detection = None
        self.source_detection = None
        self.source_facts = {}
        self.manifest_facts = {}
        self.buildings = []

        #: Phase 12C. One RVT model holds one building, so the expected path
        #: is a per-building mapping rather than one session-wide value.
        #: `expected_rvt_path` above remains the selected building's entry -
        #: the single value every downstream check already reads - and this
        #: is where the others are remembered while another is selected.
        #: Session-only: nothing here is written to the manifest.
        self.expected_rvt_by_building = {}
        #: One authoritative BuildingReviewResult per BuildingId. Read-only
        #: review history; it never reaches the publish gate.
        self.review_results_by_building = {}
        #: A cached result being *rendered* in the Change Plan table. It is
        #: deliberately not `plan`: Plan Valid, integrity and the publish
        #: gate all read `plan`, and a remembered result must reach none of
        #: them.
        self.review_preview = None
        #: Bumped by every live-snapshot read. The product holds no digest of
        #: the Revit model, so "has it been re-read since?" is the strongest
        #: honest question available - and it is the same reasoning that makes
        #: `refresh_snapshot` discard the plan unconditionally.
        self.snapshot_token = 0

        #: Why the Change Plan tab is locked, if it is. Empty means unlocked.
        self.plan_lock_reasons = []
        self.integrity = None

        self.status = IDLE
        self.last_error = None

        #: Two distinct things, kept apart on purpose.
        #:
        #: `blockers` is why the *current* action could not proceed. It is
        #: replaced wholesale each action, so one controller error shows once
        #: however many times the window re-renders.
        #:
        #: `messages` is the activity log. It is append-only, but only for
        #: entries that represent distinct actions: a note identical to the
        #: previous one is not recorded again. Before this split, every render
        #: path that reported an error appended it, and a single blocked
        #: Analyse showed the same line four times while the count read 1.
        self.messages = []
        self.blockers = []
        self.action = None
        self._logged = set()

        #: What the host runtime actually supports, filled in by the window.
        #: A missing Eto type is a supported variation, recorded here rather
        #: than raised; see main_window.record_capabilities.
        self.runtime_capabilities = {}

        #: Phase 8E wires a publish path. It is still never reached from a
        #: UI callback: the callback only raises an ExternalEvent, and only
        #: the handler may call the controller.
        self.publish_available = True

    # -- concurrency -------------------------------------------------------
    @property
    def busy(self):
        return self.status == BUSY

    def begin(self, what):
        if self.busy:
            raise UiBusy("%s is already running. Wait for it to finish." % what)
        self.status = BUSY
        self.start_action(what)
        return self

    def end(self):
        self.status = IDLE

    # -- messages ----------------------------------------------------------

    def start_action(self, what):
        """A new action supersedes the previous one's blocking reasons."""
        self.action = what
        self.blockers = []
        self._logged = set()
        return self

    def note(self, message):
        """Record one activity entry. Returns whether it was new.

        Skipped when this action has already said it, or when it repeats the
        previous entry verbatim - two clicks that hit the same wall should not
        read as two different problems.
        """
        key = (self.action, message)
        if key in self._logged:
            return False
        if self.messages and self.messages[-1] == message:
            self._logged.add(key)
            return False
        self._logged.add(key)
        self.messages.append(message)
        return True

    def block(self, messages):
        """Replace the current action's blocking reasons."""
        self.blockers = [m for m in messages if m]
        return self.blockers

    # -- derived readiness -------------------------------------------------
    @property
    def paths_match(self):
        if not self.expected_rvt_path or not self.active_rvt_path:
            return False
        return (os.path.normcase(os.path.abspath(self.expected_rvt_path))
                == os.path.normcase(os.path.abspath(self.active_rvt_path)))

    @property
    def blocking_errors(self):
        """Everything currently preventing a plan, from both sources.

        The controller reports its refusals in the payload; the UI's own
        pre-flight refuses before a payload exists at all. Counting only the
        payload made the safety strip read "Blocking errors 0" while a blocker
        was displayed right below it.
        """
        source = self.plan or self.analysis or {}
        errors = list(source.get("Errors") or [])
        for blocker in self.blockers:
            if blocker not in errors:
                errors.append(blocker)
        return errors

    @property
    def conflicts(self):
        plan = (self.plan or {}).get("Plan") or {}
        return list(plan.get("Conflicts") or [])

    @property
    def warnings(self):
        source = self.plan or self.analysis or {}
        return list(source.get("Warnings") or [])

    @property
    def plan_status(self):
        """The controller's own verdict: PREVIEWED, VALIDATED or BLOCKED."""
        payload = self.plan or {}
        return payload.get("PublishStatus") or payload.get("Status")

    @property
    def plan_is_blocked(self):
        """Structurally safe to inspect is not the same as safe to approve.

        A BLOCKED payload executed nothing, so it passes integrity and its
        contents can be read. It is still not a plan anyone may act on.
        """
        return self.plan_status == "BLOCKED"

    @property
    def context_verified(self):
        """Every binding present *and* matching. Missing is never a match."""
        result = self.integrity
        return bool(result is not None and result.context_verified)

    @property
    def plan_valid(self):
        """Tri-state, and deliberately so.

        ``None``  no current plan payload to evaluate - nothing has been
                  asked yet, or what was asked has been invalidated.
        ``False`` a payload exists and is not approvable.
        ``True``  a payload exists and all six conditions hold.

        Collapsing the first two would tell an operator who has not yet run
        Analyse that their plan is invalid, which is a different and more
        alarming claim than "there is nothing here yet".
        """
        if not self.plan:
            #: Nothing to evaluate: unavailable, not refused.
            return None
        plan = self.plan.get("Plan")
        if plan is None:
            #: A payload exists but carries no plan. That is a malformed
            #: response, which is a refusal rather than an absence.
            return False
        result = self.integrity
        if result is not None and not result.approvable:
            #: Covers a failed execution check, an unbound payload, a
            #: mismatched binding, and every BLOCKED payload.
            return False
        if self.plan_is_blocked or self.blocking_errors:
            return False
        from . import validation as val
        if not val.planning_ready(self):
            #: The payload is retained for diagnosis, so this is NO, not
            #: unavailable.
            return False
        return bool(plan.get("PlanValid"))

    #: The three states, named. Rendering reads this rather than testing
    #: truthiness, where `None` and `False` would collapse into one.
    UNAVAILABLE = "unavailable"
    NO = "no"
    YES = "yes"

    @property
    def plan_valid_state(self):
        verdict = self.plan_valid
        if verdict is None:
            return self.UNAVAILABLE
        return self.YES if verdict else self.NO

    @property
    def plan_unlocked(self):
        return bool(self.plan) and not self.plan_lock_reasons

    @property
    def can_analyse(self):
        return bool(self.manifest_path and self.source_3dm_path
                    and not self.busy)

    @property
    def can_plan(self):
        return bool(self.analysis and not self.busy)

    def set_source(self, path, provenance):
        """Set the source and how it was chosen, together.

        Changing either invalidates the plan: a plan derived from a different
        source no longer describes what is selected, and the Scenario 3 live
        run showed exactly what a stale source produces - a correct-looking
        plan built on the wrong geometry.
        """
        changed = (path != self.source_3dm_path
                   or provenance != self.source_provenance)
        self.source_3dm_path = path
        self.source_provenance = provenance or detection.NONE
        if changed:
            self.clear_plan()
        return changed

    def use_active_as_expected(self):
        return self.set_expected_rvt(self.active_rvt_path)

    def set_expected_rvt(self, path):
        """Choosing the target model invalidates everything derived from it.

        A plan approved against one model must never be carried to another,
        so a change here returns Plan Valid to `unavailable` and requires a
        fresh preview.

        The choice is recorded against the **selected building**, so setting
        B002's model does not disturb B001's. Switching back restores it.
        """
        if path != self.expected_rvt_path:
            self.expected_rvt_path = path
            self.clear_plan()
        if self.building_id:
            self.expected_rvt_by_building[self.building_id] = path
        return self.expected_rvt_path

    def expected_rvt_for(self, building_id):
        """The model this building is bound to, or None if it has none."""
        return self.expected_rvt_by_building.get(building_id)

    # -- Phase 12C: per-building review results ----------------------------

    def record_review(self, result):
        """Keep one authoritative result per BuildingId, replacing any prior.

        Never appended to: two results for one building would let a summary
        report a building twice, or report the older of the two.
        """
        if result is not None and result.building_id:
            self.review_results_by_building[result.building_id] = result
        return result

    def review_for(self, building_id):
        return self.review_results_by_building.get(building_id)

    def discard_review(self, building_id):
        """Drop a building's result because it is about to be re-derived.

        Analyse and Generate both call this *before* running. Without it a
        superseded result generated under the same live snapshot would still
        classify as CURRENT after the attempt that replaced it had failed.
        """
        self.review_results_by_building.pop(building_id, None)
        if (self.review_preview is not None
                and self.review_preview.building_id == building_id):
            self.review_preview = None
        return self

    def live_facts_for(self, building_id):
        """The current session facts a result is dated against."""
        return {
            "source_sha256": (self.source_facts or {}).get("Sha256"),
            "expected_rvt_path": self.expected_rvt_for(building_id),
            "active_rvt_path": self.active_rvt_path,
            "snapshot_token": self.snapshot_token,
            #: Only the building being looked at can be in the wrong-model
            #: condition. A building nobody has selected is not being pointed
            #: anywhere, so its closed model is CACHED_NOT_OPEN, not an error.
            "selected": building_id == self.building_id,
        }

    def freshness_of(self, building_id):
        return classify_freshness(self.review_for(building_id),
                                  self.live_facts_for(building_id))

    def select_building(self, building_id):
        """Choosing a building discards everything derived from the old one.

        A plan left on screen after the selection changes would show one
        building's rows under another building's heading. The plan is cleared
        immediately rather than at the next Analyse.
        """
        if building_id and building_id != self.building_id:
            self.clear_plan()
            self.building_id = building_id
            #: The displayed expected path follows the selection. A building
            #: with no mapping yet shows none - inheriting the previous
            #: building's model would silently point one building's publish
            #: at another building's file.
            self.expected_rvt_path = self.expected_rvt_by_building.get(
                building_id)
        return self.building_id

    def clear_plan(self):
        """Drop the plan and every hash derived from it."""
        self.plan = None
        self.analysis = None
        self.integrity = None
        self.plan_lock_reasons = []
        #: The read-only preview goes with it. A cached result left rendered
        #: beside an emptied verdict would be the exact confusion 12C exists
        #: to prevent.
        self.review_preview = None
        return self

    def as_request(self, publish_mode=None, obsolete_action=None,
                   confirm_delete_obsolete=False):
        """The plain dict the controller expects. Never a Revit object.

        The mode is passed through so a preview is classified exactly as the
        publish will be. `ChangePlan` records the mode and the delete
        confirmation, so previewing under Preview Only and then publishing
        under Create or Update would produce two different plans - and the
        plan the operator approved must be the plan that executes.

        `publish` stays False and `confirm_publish` stays False: this request
        never writes. Only the approved request built at confirmation time
        sets those.
        """
        return {
            "manifest_path": self.manifest_path,
            "source_3dm_path": self.source_3dm_path,
            "building_id": self.building_id,
            "expected_rvt_path": self.expected_rvt_path,
            "publish_mode": publish_mode or "Preview Only",
            "obsolete_action": obsolete_action or "Mark Only",
            "confirm_publish": False,
            "confirm_delete_obsolete": bool(confirm_delete_obsolete),
            "publish": False,
        }


# -- Phase 12C: multi-building project review -------------------------------

#: One RVT model holds one building. A project is planned by visiting each
#: building's model in turn; the review results accumulate across those
#: visits. Nothing here opens a document, and nothing here publishes.

#: The verdict a plan carries (VALID / BLOCKED) and how old that verdict is
#: are different questions, and this vocabulary answers only the second.
#: Overloading one Status field is what would let a remembered VALID read as
#: a statement about the model as it is now.
CURRENT = "CURRENT"
CACHED_NOT_OPEN = "CACHED_NOT_OPEN"
STALE_SNAPSHOT = "STALE_SNAPSHOT"
STALE_SOURCE = "STALE_SOURCE"
WRONG_ACTIVE_MODEL = "WRONG_ACTIVE_MODEL"
RVT_NOT_ASSIGNED = "RVT_NOT_ASSIGNED"
NOT_ANALYSED = "NOT_ANALYSED"

FRESHNESS_STATES = (CURRENT, CACHED_NOT_OPEN, STALE_SNAPSHOT, STALE_SOURCE,
                    WRONG_ACTIVE_MODEL, RVT_NOT_ASSIGNED, NOT_ANALYSED)

#: **Exactly one state describes the model as it is now.** Everything that
#: asks "may this be treated as current?" asks it through this tuple, so a
#: state added later cannot quietly join the answer.
VERIFIED_CURRENT = (CURRENT,)

FRESHNESS_LABELS = {
    CURRENT: "CURRENT",
    CACHED_NOT_OPEN: "CACHED - RVT NOT OPEN",
    STALE_SNAPSHOT: "STALE - SNAPSHOT REREAD",
    STALE_SOURCE: "STALE - SOURCE CHANGED",
    WRONG_ACTIVE_MODEL: "WRONG MODEL FOR THIS BUILDING",
    RVT_NOT_ASSIGNED: "RVT NOT ASSIGNED",
    NOT_ANALYSED: "NOT ANALYSED",
}

FRESHNESS_NOTES = {
    CURRENT: ("Analysed against the active model, with the source and live "
              "snapshot unchanged since."),
    CACHED_NOT_OPEN: ("A previous review result. Its Revit model is not open, "
                      "so the current model state is unknown."),
    STALE_SNAPSHOT: ("The live snapshot was re-read after this result was "
                     "generated, so the model may have changed since."),
    STALE_SOURCE: ("The source .3dm changed after this result was generated. "
                   "The result describes different geometry."),
    WRONG_ACTIVE_MODEL: ("This building is bound to a model the result did "
                         "not come from. Open its Expected RVT and analyse "
                         "again."),
    RVT_NOT_ASSIGNED: ("No Expected RVT is assigned to this building. Assign "
                       "the active RVT as the expected model before "
                       "publishing."),
    NOT_ANALYSED: "No review result for this building in this session.",
}

#: Rendered where a verdict would otherwise be. A dash is not a verdict.
NO_VERDICT = "-"


def same_path(one, other):
    """Path comparison, done once. Missing is never a match."""
    if not one or not other:
        return False
    return (os.path.normcase(os.path.abspath(one))
            == os.path.normcase(os.path.abspath(other)))


class BuildingReviewResult(object):
    """One building's last review, and everything needed to date it.

    Read-only history. It carries a plan, but not the authority to act on
    one: `PlanValid` here is what was true when it was generated, which is a
    different claim from what is true now. See :func:`classify_freshness`.
    """

    def __init__(self, building_id, source_id=None, source_sha256=None,
                 expected_rvt_path=None, observed_rvt_path=None,
                 snapshot_token=None, plan=None, analysis=None,
                 plan_valid=None, blockers=None, conflicts=None,
                 counts=None, generated_at=None):
        self.building_id = building_id
        self.source_id = source_id
        #: The identity of the geometry this result describes. Without it a
        #: result could not be told apart from one built on a later export.
        self.source_sha256 = source_sha256
        self.expected_rvt_path = expected_rvt_path
        #: Which document was actually active when it was generated - not
        #: which one was expected. They match at analysis time, and only the
        #: observed one is evidence.
        self.observed_rvt_path = observed_rvt_path
        #: The live-snapshot generation this result was built under. The
        #: product holds no digest of the Revit model, so this counter is the
        #: only honest answer to "has the model been re-read since?".
        self.snapshot_token = snapshot_token
        self.plan = plan
        self.analysis = analysis
        self.plan_valid = plan_valid
        self.blockers = list(blockers or [])
        self.conflicts = list(conflicts or [])
        self.counts = dict(counts or {})
        self.generated_at = generated_at

    #: SKIP is not a change, and OBSOLETE is counted in its own column - so
    #: neither is folded into `changes`, and the three never double-count.
    NOT_A_CHANGE = ("SKIP", "OBSOLETE", "CONFLICT", "BLOCKED")

    @property
    def changes(self):
        return sum(int(count) for action, count in self.counts.items()
                   if action not in self.NOT_A_CHANGE)

    @property
    def obsolete(self):
        return int(self.counts.get("OBSOLETE") or 0)

    @property
    def verdict(self):
        """What the plan said *then*. Never what it says now."""
        if self.plan_valid is True:
            return "VALID"
        return "BLOCKED"


def classify_freshness(result, live):
    """How much of this result is still known to be true. Pure.

    ``live`` is a dict of the current session facts: ``source_sha256``,
    ``expected_rvt_path`` (this building's mapping), ``active_rvt_path`` and
    ``snapshot_token``.

    Ordered by what an operator most needs to know first, and written so that
    CURRENT requires positive confirmation of every condition. A missing or
    unreadable fact therefore never produces CURRENT - the Phase 10A rule,
    applied the other way round: "cannot tell" is not "verified".
    """
    if result is None:
        return NOT_ANALYSED
    live = live or {}
    if (not result.source_sha256
            or result.source_sha256 != live.get("source_sha256")):
        return STALE_SOURCE
    #: Unassigned is not wrong. Analysis does not require an Expected RVT, so
    #: a result can exist for a building that was never bound to a model -
    #: and "you have not said which model this is" is a different thing to
    #: tell an operator than "the wrong model is open". Assigning one later
    #: does not reach back and validate a result taken without one, which is
    #: why the *result's* binding is tested and not only the current mapping.
    if not result.expected_rvt_path or not live.get("expected_rvt_path"):
        return RVT_NOT_ASSIGNED
    #: Bound, but not to the model the result came from. Two ways to arrive:
    #: the binding was re-pointed after the result was generated, or this is
    #: the building being looked at and a different document is active. Both
    #: are "the model situation for this building is wrong", which is what
    #: the label says; neither is the ordinary case of a closed model below.
    if not same_path(result.observed_rvt_path, live.get("expected_rvt_path")):
        return WRONG_ACTIVE_MODEL
    if (live.get("selected")
            and not same_path(live.get("expected_rvt_path"),
                              live.get("active_rvt_path"))):
        return WRONG_ACTIVE_MODEL
    #: The ordinary multi-building state: this building's model simply is not
    #: the one open. Nothing is wrong; the current model state is unknown.
    if not same_path(result.observed_rvt_path, live.get("active_rvt_path")):
        return CACHED_NOT_OPEN
    if (result.snapshot_token is None
            or result.snapshot_token != live.get("snapshot_token")):
        return STALE_SNAPSHOT
    return CURRENT


def is_current(freshness):
    return freshness in VERIFIED_CURRENT
