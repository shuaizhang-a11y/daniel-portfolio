"""The publish report - what a publish actually did, as a durable file.

Pure Python. No Eto, no Revit, no controller. Nothing here can publish,
dispatch, raise an event or open a transaction, and nothing here writes to the
append-only publish log. The only file it creates is the report the operator
asked for, at the path the operator chose.

    history entry -> history_view.detail -> report model -> renderer -> file

Distinct from the **preview** report, which describes a plan before it runs.
This describes a completed record. A report built from a non-clicked entry says
so on its first line: a preview must never be mistaken for evidence that
something was written.

Formats are text and JSON, chosen by file extension. **PDF is not produced.**
`dz_report` is the Phase 6B planning-report generator - manifest-driven
compliance sections and charts - and has no publish-report path; reusing it
would mean presenting a compliance document as a publish record. A format that
was not produced is never claimed.
"""

import io
import json
import os

from . import formatting as fmt
from . import history_view as hv

TEXT = "text"
JSON = "json"
EXTENSIONS = {".txt": TEXT, ".log": TEXT, ".json": JSON}
DEFAULT_FORMAT = TEXT

PUBLISH_BANNER = "DZ PLANNING TOOLS - PUBLISH REPORT"
PREVIEW_BANNER = "DZ PLANNING TOOLS - PREVIEW RECORD (NOT A PUBLISH)"

PREVIEW_NOTE = (
    "This entry has no operator click timestamp. It is a preview or "
    "validation record, not evidence that anything was written to the Revit "
    "model.")

#: Refusing to write into the log folder is a safety rule, not tidiness: an
#: export dropped beside an append-only log is one careless glob away from
#: being read back as history.
LOG_FOLDER = "revit_publish"
REFUSED_DESTINATION = (
    "A report may not be written inside a '%s' folder. That folder holds the "
    "append-only publish log. Choose a location outside it." % LOG_FOLDER)

NO_ENTRY = "Select a history entry before exporting a report."


class ExportResult(object):
    """The outcome of one export. Never a publish outcome.

    A filesystem failure is a failure *of the export*. It says nothing about
    what the publish did, and it must never be allowed to restate a completed
    publish as failed.
    """

    def __init__(self, ok, path=None, fmt_name=None, error=None, message=None):
        self.ok = bool(ok)
        self.path = path
        self.format = fmt_name
        self.error = error
        self.message = message

    def __repr__(self):
        return "<ExportResult ok=%s format=%s path=%r>" % (
            self.ok, self.format, self.path)


def format_for(path):
    """The format this path asks for. Unknown extensions render as text."""
    _root, extension = os.path.splitext(path or "")
    return EXTENSIONS.get(extension.lower(), DEFAULT_FORMAT)


def refuses_destination(path):
    """The reason this path is refused, or None.

    Checked at every depth and on both separators, because the guard exists to
    stop a mistake rather than to stop a determined caller.
    """
    if not path:
        return "No destination was chosen."
    normalised = os.path.normpath(os.path.abspath(path))
    parts = [part.lower() for part in
             normalised.replace("\\", "/").split("/") if part]
    #: The file itself may be named anything; only its folders are checked.
    if LOG_FOLDER in parts[:-1]:
        return REFUSED_DESTINATION
    return None


def exportable(entry):
    """Whether a report can be produced, and why not when it cannot."""
    #: `is None`, not truthiness: an entry with no fields is still an entry,
    #: and reporting "select an entry" for one would be a lie about why.
    if entry is None:
        return False, NO_ENTRY
    return True, None


def suggested_name(entry, extension=".txt"):
    """A stable, filesystem-safe default name for one entry."""
    entry = entry or {}
    stamp = str(hv.first(entry, hv.TIMESTAMP_KEYS) or "unknown")
    building = str(entry.get("BuildingId") or "nobuilding")
    safe = "".join(c if (c.isalnum() or c in "-_") else "-"
                   for c in "%s_%s" % (stamp, building))
    kind = "publish" if hv.clicked(entry) else "preview"
    return "dz_%s_report_%s%s" % (kind, safe, extension)


# -- the model --------------------------------------------------------------

def report_model(entry, csv_rows=None):
    """Everything the report states, as plain data.

    Built from the same `history_view.detail` projection the UI renders, so a
    report and the panel it was exported from cannot disagree.
    """
    if entry is None:
        return None
    detail = hv.detail(entry, csv_rows)
    results = entry.get("Results") or {}
    is_clicked = hv.clicked(entry)
    return {
        "Kind": "publish" if is_clicked else "preview",
        "Clicked": is_clicked,
        "Banner": PUBLISH_BANNER if is_clicked else PREVIEW_BANNER,
        "PreviewNote": None if is_clicked else PREVIEW_NOTE,
        "Identity": detail["Identity"],
        "Outcome": detail["Outcome"],
        "Stages": detail["Stages"],
        "Counters": detail["Counters"],
        "ElementIdMap": detail["ElementIdMap"],
        "Warnings": detail["Warnings"],
        "Errors": detail["Errors"],
        "FinalValidation": detail["FinalValidation"],
        "RolledBack": detail["RolledBack"],
        "WroteNothing": hv.wrote_nothing(results),
        "WriteSummary": hv.write_summary(entry),
        "Skipped": results.get("skipped") or 0,
        "Replaced": results.get("floorsReplaced") or 0,
        "FailingStage": hv.failing_stage(entry),
        "CsvDisagreement": detail["CsvDisagreement"],
        "CsvWarning": detail["CsvWarning"],
        "AuthoritativeSource": detail["AuthoritativeSource"],
    }


# -- renderers --------------------------------------------------------------

def _pairs(rows, width=28):
    return ["  %-*s %s" % (width, label, value) for label, value in rows]


def render_text(model):
    """Deterministic text. Same input, same bytes."""
    if not model:
        return ""
    out = ["=" * 74, model["Banner"], "=" * 74, ""]
    if model["PreviewNote"]:
        out.extend(["!" * 74, model["PreviewNote"], "!" * 74, ""])

    out.append("IDENTITY")
    out.append("-" * 74)
    out.extend(_pairs(model["Identity"]))
    out.append("")

    out.append("OUTCOME")
    out.append("-" * 74)
    out.extend(_pairs(model["Outcome"]))
    out.append("")

    out.append("WHAT WAS WRITTEN")
    out.append("-" * 74)
    out.extend(_pairs([("Summary", model["WriteSummary"]),
                       ("Floors replaced", str(model["Replaced"])),
                       ("Skipped", str(model["Skipped"]))]))
    out.append("")

    if model["ElementIdMap"]:
        out.append("REPLACED ELEMENTS - old -> new (mandatory disclosure)")
        out.append("-" * 74)
        for kind, old_id, new_id in model["ElementIdMap"]:
            out.append("  %-6s %-14s -> %s" % (kind, old_id, new_id))
        out.append("")

    if model["Counters"]:
        out.append("COUNTERS")
        out.append("-" * 74)
        out.extend(_pairs(model["Counters"]))
        out.append("")

    if model["Stages"]:
        out.append("EXECUTOR STAGES")
        out.append("-" * 74)
        for number, name, status, detail in model["Stages"]:
            out.append("  %-3s %-38s %-12s %s"
                       % (number, name, status, detail))
        out.append("")

    for title, items in (("WARNINGS", model["Warnings"]),
                         ("ERRORS", model["Errors"]),
                         ("FINAL VALIDATION", model["FinalValidation"])):
        if items:
            out.append(title)
            out.append("-" * 74)
            for item in items:
                out.append("  - %s" % item)
            out.append("")

    if model["CsvDisagreement"]:
        out.append("JSON / CSV DISAGREEMENT")
        out.append("-" * 74)
        out.append("  Authoritative source: %s" % model["AuthoritativeSource"])
        out.append("  %s" % model["CsvWarning"])
        out.append("")

    out.append("=" * 74)
    out.append("Generated by DZ Planning Tools from the append-only Phase 7 "
               "publish log.")
    out.append("The log was read only. This report is a copy, not a record of "
               "record.")
    out.append("=" * 74)
    return "\n".join(out)


def render_json(model):
    """The same model, machine-readable. Sorted keys, so it is diffable."""
    if not model:
        return ""
    return json.dumps(model, indent=2, sort_keys=True, default=str)


RENDERERS = {TEXT: render_text, JSON: render_json}


def render(model, fmt_name=TEXT):
    return RENDERERS.get(fmt_name, render_text)(model)


# -- export -----------------------------------------------------------------

def write_report(entry, path, csv_rows=None):
    """Render one entry to ``path``. Returns an :class:`ExportResult`.

    Every failure is caught and reported as an export failure. Nothing here
    raises into the caller, because the caller is holding a completed publish
    result that must not be disturbed by a filesystem problem.
    """
    ok, reason = exportable(entry)
    if not ok:
        return ExportResult(False, path=path, error=reason)

    refusal = refuses_destination(path)
    if refusal:
        return ExportResult(False, path=path, error=refusal)

    fmt_name = format_for(path)
    try:
        model = report_model(entry, csv_rows)
        body = render(model, fmt_name)
    except Exception as exc:
        return ExportResult(False, path=path, fmt_name=fmt_name,
                            error="Could not build the report: %s: %s"
                                  % (type(exc).__name__, exc))
    try:
        with io.open(path, "w", encoding="utf-8") as handle:
            handle.write(body)
    except Exception as exc:
        return ExportResult(
            False, path=path, fmt_name=fmt_name,
            error="Could not write %s: %s: %s"
                  % (fmt.full_path(path), type(exc).__name__, exc))

    kind = "Publish report" if model["Clicked"] else "Preview record"
    return ExportResult(True, path=path, fmt_name=fmt_name,
                        message="%s written as %s to %s"
                                % (kind, fmt_name, fmt.full_path(path)))
