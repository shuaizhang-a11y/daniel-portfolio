"""The application facade: the only thing the UI is allowed to call.

Four entry points, all exchanging plain JSON-serialisable dictionaries:

    analyse(request)   read the source and the live model, no plan
    plan(request)      classify and render a Change Plan, never writes
    publish(request)   execute the approved plan through the executor
    history(request)   read the append-only publish log

The UI must not call Revit DB operations directly. Per checkpoint 8A.1, a write
reaches Revit only through the ExternalEvent dispatcher in :mod:`dispatch`; this
module performs the work once that context exists.
"""

import datetime

from dz_revit_publisher import change_detection as cd
from dz_revit_publisher import executor as ex
from dz_revit_publisher import manifest_loader, phase07c_log, shared_parameters
from dz_revit_publisher import source_reader
from dz_revit_publisher import validation as val
from dz_revit_publisher.phase07c_plan import ChangePlan

from .session import PublishRequest, expected_path_conflict

#: Publish statuses this layer can report.
BLOCKED = "BLOCKED"
PREVIEWED = "PREVIEWED"
VALIDATED = "VALIDATED"
PUBLISHED = "PUBLISHED"
PUBLISHED_WITH_WARNINGS = "PUBLISHED WITH WARNINGS"
ROLLED_BACK = "ROLLED BACK"
FAILED = "FAILED"


def _as_request(request):
    if isinstance(request, PublishRequest):
        return request
    return PublishRequest.from_dict(request)


def _blocked(request, messages, warnings=None):
    return {
        "Status": BLOCKED,
        "Request": request.as_dict(),
        "Errors": list(messages),
        "Warnings": list(warnings or []),
        "Plan": None,
        "Results": None,
        "StageResults": [],
        "TransactionResult": "not started",
    }


def analyse(request, bridge=None, config=None):
    """Read the source, the manifest and the live model. No classification."""
    request = _as_request(request)
    config = config or {}
    if request.input_error:
        return _blocked(request, ["INVALID INPUT: %s" % request.input_error])

    try:
        manifest_path, manifest, _info = manifest_loader.load(
            request.manifest_path, config.get("exports_root"))
    except Exception as exc:
        return _blocked(request, [str(exc)])

    checks = val.validate_manifest(manifest)
    if not checks.ok:
        return _blocked(request, checks.blocking, checks.warnings)

    building = manifest_loader.get_building(manifest, request.building_id)
    if building is None:
        return _blocked(request, ["Building %r is not in the manifest."
                                  % request.building_id])
    checks.extend(val.validate_building(
        building, manifest_loader.building_records(manifest)))

    points, geometry_notes = source_reader.read_footprint(
        building.source_id, request.source_3dm_path,
        (manifest_loader.project_identity(manifest).get("rhinoTolerance")
         or 0.01))
    if points is None:
        return _blocked(request, geometry_notes, checks.warnings)

    context = bridge.context() if bridge is not None else None
    observed = bridge.observe_floors(building) if bridge is not None else []

    return {
        "Status": PREVIEWED,
        "Request": request.as_dict(),
        "ManifestPath": manifest_path,
        "ManifestSha256": manifest_loader.calculate_sha256(manifest_path),
        "Identity": manifest_loader.project_identity(manifest),
        "Building": building.building_id,
        "SourceModelHash": source_reader.file_hash(request.source_3dm_path),
        "FootprintPoints": [list(p) for p in points],
        "ObservedFloors": observed,
        "ActiveDocumentPath": context.document_path if context else None,
        "Context": context.as_dict() if hasattr(context, "as_dict") else None,
        "Errors": list(checks.blocking),
        "Warnings": list(checks.warnings) + list(geometry_notes),
        # kept out of the serialisable payload, for the caller to pass onward
        "_manifest": manifest,
        "_building": building,
        "_points": points,
    }


def plan(request, bridge=None, config=None, analysis=None):
    """Classify and build a Change Plan. Never starts a Revit transaction."""
    request = _as_request(request)
    analysis = analysis or analyse(request, bridge, config)
    if analysis["Status"] == BLOCKED:
        return analysis

    manifest = analysis["_manifest"]
    building = analysis["_building"]
    points = analysis["_points"]
    ident = analysis["Identity"]
    manifest_sha = analysis["ManifestSha256"]

    changes, obsolete, conflicts, warns = cd.classify(
        building, ident, manifest_sha, points, analysis["ObservedFloors"],
        obsolete_action=request.obsolete_action)

    change_plan = ChangePlan(building, ident, manifest_sha,
                             request.publish_mode, request.obsolete_action,
                             request.confirm_delete_obsolete)
    change_plan.changes = changes
    change_plan.obsolete = obsolete
    change_plan.conflicts = conflicts
    change_plan.warnings.extend(list(analysis["Warnings"]) + list(warns))
    change_plan.blocking = cd.blocking_conflicts(
        conflicts, changes, obsolete, request.obsolete_action,
        request.confirm_delete_obsolete)
    change_plan.blocking.extend(analysis["Errors"])
    change_plan.rvt_path = analysis["ActiveDocumentPath"]
    change_plan.source_model_hash = analysis["SourceModelHash"]
    change_plan.migration = [c.as_dict() for c in changes if c.needs_migration]

    conflict = expected_path_conflict(request.expected_rvt_path,
                                      analysis["ActiveDocumentPath"])
    if conflict:
        change_plan.blocking.append(conflict)

    if request.publish_mode == "Update Existing Only":
        creates = [c.floor_index for c in changes if c.action == cd.CREATE]
        if creates:
            change_plan.blocking.append(
                "Publish Mode is Update Existing Only but the plan needs to "
                "create floor(s) %s. Switch to Create or Update, or correct "
                "the source." % ", ".join(str(i) for i in creates))

    payload = {
        "Status": BLOCKED if change_plan.blocking else (
            PREVIEWED if request.is_preview_only else VALIDATED),
        "Request": request.as_dict(),
        "ManifestPath": analysis["ManifestPath"],
        "ManifestSha256": manifest_sha,
        "ActiveDocumentPath": analysis["ActiveDocumentPath"],
        "Plan": change_plan.as_dict(),
        "PlanText": change_plan.render(),
        "Errors": list(change_plan.blocking),
        "Warnings": list(change_plan.warnings),
        "Results": None,
        "StageResults": [],
        "TransactionResult": "not started",
        "_plan": change_plan,
        "_manifest": manifest,
        "_building": building,
        "_points": points,
        "_identity": ident,
    }
    return payload


def publish(request_or_plan, bridge=None, config=None, planned=None):
    """Execute the approved plan. Requires an active Revit API context.

    Per 8A.1 this must be reached through the ExternalEvent dispatcher; calling
    it from a UI callback will fail at ``Transaction.Start()``, which is the
    correct and safe failure.
    """
    request = _as_request(request_or_plan)
    config = config or {}
    planned = planned or plan(request, bridge, config)
    if planned["Status"] == BLOCKED:
        return planned

    change_plan = planned["_plan"]

    if not request.wants_write:
        planned["Status"] = (PREVIEWED if request.is_preview_only
                             else VALIDATED)
        planned["Warnings"] = list(planned["Warnings"]) + [
            "Preview Only: no Revit element was changed."
            if request.is_preview_only else
            "Waiting for confirmation and a genuine publish action."]
        return planned

    if bridge is None or not getattr(bridge, "available", False):
        planned["Status"] = BLOCKED
        planned["Errors"] = list(planned["Errors"]) + [
            "Rhino.Inside.Revit is not available; nothing can be written."]
        return planned

    # Re-validate the active document immediately before the write. The
    # operator can switch documents between the click and the dispatch.
    context = bridge.context()
    conflict = expected_path_conflict(request.expected_rvt_path,
                                      context.document_path)
    if conflict:
        planned["Status"] = BLOCKED
        planned["Errors"] = list(planned["Errors"]) + [
            "Re-validated at execution time: " + conflict]
        return planned

    guids = shared_parameters.resolve_guids(config["shared_parameter_registry"])
    clicked_at = datetime.datetime.now().replace(microsecond=0).isoformat()
    (transaction_result, stages, results, validation_notes, publish_warnings,
     publish_errors, restored) = ex.execute(
        bridge, change_plan, planned["_building"], planned["_identity"],
        planned["_manifest"], planned["ManifestSha256"], guids,
        planned["_points"],
        int(request.force_fail_at_stage) if request.force_fail_at_stage else None)

    stage_results = [s.as_dict() for s in stages]
    warnings = list(planned["Warnings"]) + list(publish_warnings)
    errors = list(planned["Errors"]) + list(publish_errors)
    if publish_errors:
        status = ROLLED_BACK if transaction_result == "rolled back" else FAILED
    elif publish_warnings:
        status = PUBLISHED_WITH_WARNINGS
    else:
        status = PUBLISHED

    planned.update({
        "Status": status,
        "ClickedAt": clicked_at,
        "Results": results,
        "StageResults": stage_results,
        "FinalValidation": list(validation_notes),
        "TransactionResult": transaction_result,
        "SharedParameterFileRestoredTo": restored,
        "Errors": errors,
        "Warnings": warnings,
    })

    entry = phase07c_log.build_entry(
        status, change_plan, context, planned["ManifestPath"],
        planned["ManifestSha256"], change_plan.source_model_hash,
        context.document_path, request.baseline_rvt_sha256,
        transaction_result, stage_results, results, warnings, errors,
        clicked_at, validation_notes)
    try:
        json_path, _csv = phase07c_log.write(
            manifest_loader.package_folder(planned["ManifestPath"]), entry)
        planned["PublishLogPath"] = json_path
    except Exception as exc:
        planned["Warnings"] = warnings + ["Log write failed: %s" % exc]
    return planned


def history(request, config=None):
    """Read the append-only publish log. Never writes to it."""
    request = _as_request(request)
    config = config or {}
    try:
        manifest_path, _manifest, _info = manifest_loader.load(
            request.manifest_path, config.get("exports_root"))
    except Exception as exc:
        return {"Status": BLOCKED, "Errors": [str(exc)], "Entries": []}
    package = manifest_loader.package_folder(manifest_path)
    stored = phase07c_log.read_history(package)
    entries = stored.get("entries", [])
    return {
        "Status": PREVIEWED,
        "PackageFolder": package,
        "Count": len(entries),
        "ClickedCount": len([e for e in entries if e.get("UserClickTimestamp")]),
        "Entries": entries,
        "Errors": [],
    }


def to_json_safe(payload):
    """Strip the private handles so the result can be serialised."""
    return dict((k, v) for k, v in (payload or {}).items()
                if not k.startswith("_"))
