"""The ExternalEvent dispatch contract, mandated by checkpoint 8A.1.

8A.1 proved that a direct Eto callback cannot start a Revit Transaction, and
that a Revit ``ExternalEvent`` dispatch can. Everything that writes therefore
goes through here.

This module holds the *contract* and the concurrency guard. It has no Revit
import: the Revit ``ExternalEvent`` is supplied by the host at runtime, so the
whole dispatch decision path stays testable offline.
"""

READY = "ready"
IN_FLIGHT = "in-flight"
DONE = "done"


class DispatchBusy(Exception):
    """Raised when a second publish is requested while one is in flight."""


class PublishDispatcher(object):
    """Serialises publish requests onto Revit's event loop.

    The host wires ``raise_event`` to ``ExternalEvent.Raise`` and calls
    :meth:`execute` from inside ``IExternalEventHandler.Execute``, where a valid
    API context exists.
    """

    def __init__(self, raise_event, run_publish):
        self._raise_event = raise_event
        self._run_publish = run_publish
        self.state = READY
        self.pending = None
        self.last_result = None

    @property
    def busy(self):
        return self.state == IN_FLIGHT

    def request(self, payload):
        """Called from the UI thread. Raises the event; never writes."""
        if self.busy:
            raise DispatchBusy(
                "A publish is already in flight. Wait for it to complete.")
        self.state = IN_FLIGHT
        self.pending = payload
        try:
            self._raise_event()
        except Exception:
            self.state = READY
            self.pending = None
            raise
        return self.state

    def execute(self):
        """Called by Revit inside the ExternalEvent handler."""
        if self.pending is None:
            self.state = READY
            return None
        payload = self.pending
        try:
            self.last_result = self._run_publish(payload)
        finally:
            self.pending = None
            self.state = DONE
        return self.last_result

    def reset(self):
        self.state = READY
        self.pending = None
