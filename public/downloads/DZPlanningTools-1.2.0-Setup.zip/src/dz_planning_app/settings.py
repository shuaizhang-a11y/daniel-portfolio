"""Where everything lives. The one authoritative path-resolution layer.

Phase 8G's job is to make the product installable somewhere other than the
developer's checkout. Before this module the engine's paths were rooted at a
literal developer path, so a normal user had to edit Python source to install
it.

Two ideas do all the work here.

**The application finds itself.** The installed root is derived from this
file's own location, never from the working directory, an environment
assumption or a stored absolute path. Move or rename the installation and it
still resolves, because the answer is always "wherever I am".

**Absence is reported, never guessed.** Resolution runs in a fixed order -
explicit argument, environment variable, per-user config, installed config,
then defaults derived from the application root. A required file that is
missing at the end of that chain becomes a *problem* on the returned
:class:`Settings`. It never becomes a silent fallback, because a silent
fallback to a developer path is exactly the failure this module exists to
remove.

Pure Python. No Eto, no Revit, no Rhino.
"""

import io
import json
import os

APP_NAME = "DZPlanningTools"

#: The per-user configuration file, and the name of the copy shipped with the
#: application as a default.
CONFIG_NAME = "dz_planning_app.json"

#: Set to a config file path to override every other source. Highest priority
#: after an explicit argument, so a support session can point one launch
#: somewhere else without editing anything.
CONFIG_ENV = "DZ_PLANNING_CONFIG"

#: Overrides the detected application root. For development runs out of a
#: checkout, and for tests.
ROOT_ENV = "DZ_PLANNING_HOME"

#: Files the publish engine cannot run without. Both are shipped in `config/`.
REQUIRED_KEYS = ("shared_parameter_file", "shared_parameter_registry")

#: Everything a configuration file may set. Anything else is reported rather
#: than ignored, so a typo surfaces instead of silently doing nothing.
KNOWN_KEYS = ("shared_parameter_file", "shared_parameter_registry",
              "exports_root", "reports_root", "logs_root",
              "default_source_3dm")

SOURCE_EXPLICIT = "explicit argument"
SOURCE_ENV = "%s environment variable" % CONFIG_ENV
SOURCE_USER = "per-user configuration"
SOURCE_INSTALLED = "installed configuration"
SOURCE_DEFAULTS = "application defaults"


def _text(path):
    with io.open(path, "r", encoding="utf-8-sig") as handle:
        return handle.read()


def application_root(start=None):
    """The installed application root, derived from this file's location.

    ``<root>/src/dz_planning_app/settings.py`` -> ``<root>``. Overridable by
    :data:`ROOT_ENV` so a development checkout or a test can relocate it.
    """
    override = os.environ.get(ROOT_ENV)
    if override:
        return os.path.abspath(override)
    here = os.path.abspath(start or __file__)
    package = os.path.dirname(here)            # .../src/dz_planning_app
    source = os.path.dirname(package)          # .../src
    return os.path.dirname(source)             # .../<root>


def user_data_root():
    """Writable per-user data. Never inside the installed application.

    Immutable application files and things the product writes are kept apart,
    so an installation can live somewhere the user cannot write to.
    """
    base = (os.environ.get("APPDATA")
            or os.environ.get("XDG_CONFIG_HOME")
            or os.path.expanduser("~"))
    return os.path.join(base, APP_NAME)


def user_config_path():
    return os.path.join(user_data_root(), CONFIG_NAME)


def installed_config_path(root=None):
    return os.path.join(root or application_root(), "config", CONFIG_NAME)


class Settings(object):
    """Resolved paths, where they came from, and what is missing.

    ``problems`` is the point of this class. A caller that ignores it and uses
    the paths anyway gets whatever was resolved; a caller that reports it tells
    the operator exactly which file could not be found and where it looked.
    """

    def __init__(self, app_root, values, source, config_path=None,
                 problems=None, unknown=None):
        self.app_root = app_root
        self.source = source
        self.config_path = config_path
        self.problems = list(problems or [])
        self.unknown_keys = list(unknown or [])
        self.shared_parameter_file = values.get("shared_parameter_file")
        self.shared_parameter_registry = values.get(
            "shared_parameter_registry")
        self.exports_root = values.get("exports_root")
        self.reports_root = values.get("reports_root")
        self.logs_root = values.get("logs_root")
        self.default_source_3dm = values.get("default_source_3dm")

    @property
    def ok(self):
        return not self.problems

    def as_config(self):
        """The dict the controller consumes. Snake case, as `controller` reads."""
        return {
            "exports_root": self.exports_root,
            "shared_parameter_file": self.shared_parameter_file,
            "shared_parameter_registry": self.shared_parameter_registry,
        }

    def rows(self):
        """For the Diagnostics panel and the launcher banner."""
        return [
            ("Application root", self.app_root),
            ("Configuration source", self.source),
            ("Configuration file", self.config_path or "(none - defaults)"),
            ("Shared parameter file", self.shared_parameter_file),
            ("Shared parameter registry", self.shared_parameter_registry),
            ("Exports root", self.exports_root),
            ("Reports root", self.reports_root),
            ("Logs root", self.logs_root),
        ]

    def describe(self):
        lines = ["%-26s %s" % pair for pair in self.rows()]
        if self.unknown_keys:
            lines.append("%-26s %s" % ("Unknown config keys",
                                       ", ".join(self.unknown_keys)))
        for problem in self.problems:
            lines.append("PROBLEM: %s" % problem)
        return "\n".join(lines)


def defaults_for(root):
    """Everything derivable from the application root alone."""
    config_root = os.path.join(root, "config")
    data = user_data_root()
    return {
        "shared_parameter_file": os.path.join(
            config_root, "DZ_Planning_SharedParameters.txt"),
        "shared_parameter_registry": os.path.join(
            config_root, "dz_shared_parameters.json"),
        #: User data, not application data: the operator's exported packages
        #: live with the operator, and the manifest they browse to decides the
        #: log folder in any case.
        "exports_root": os.path.join(data, "Exports"),
        "reports_root": os.path.join(data, "Reports"),
        "logs_root": os.path.join(data, "Logs"),
        "default_source_3dm": None,
    }


def read_config(path):
    """Parse one configuration file. Returns (values, unknown, problem)."""
    try:
        payload = json.loads(_text(path))
    except Exception as exc:
        return {}, [], ("Configuration file could not be read: %s (%s: %s)"
                        % (path, type(exc).__name__, exc))
    if not isinstance(payload, dict):
        return {}, [], ("Configuration file must contain a JSON object: %s"
                        % path)
    values, unknown = {}, []
    for key in sorted(payload):
        value = payload[key]
        if key in KNOWN_KEYS:
            #: Empty strings are treated as "not set" rather than as a path,
            #: so a half-filled config falls through to the next source.
            if isinstance(value, str) and value.strip():
                values[key] = value.strip()
            elif value is not None and not isinstance(value, str):
                unknown.append("%s (expected a string)" % key)
        elif not key.startswith("_"):
            unknown.append(key)
    return values, unknown, None


def candidate_paths(explicit=None, root=None, environ=None):
    """Config files to try, best first, as (path, source) pairs."""
    environ = os.environ if environ is None else environ
    found = []
    if explicit:
        found.append((explicit, SOURCE_EXPLICIT))
    from_env = environ.get(CONFIG_ENV)
    if from_env:
        found.append((from_env, SOURCE_ENV))
    found.append((user_config_path(), SOURCE_USER))
    found.append((installed_config_path(root), SOURCE_INSTALLED))
    return found


def load(explicit=None, root=None, environ=None):
    """Resolve settings. Never raises; problems are reported on the result."""
    root = os.path.abspath(root) if root else application_root()
    values = defaults_for(root)
    source = SOURCE_DEFAULTS
    used_path = None
    problems, unknown = [], []

    for path, label in candidate_paths(explicit, root, environ):
        if not path:
            continue
        if not os.path.isfile(path):
            if label in (SOURCE_EXPLICIT, SOURCE_ENV):
                #: A config the caller *named* and that does not exist is an
                #: error, not a reason to move quietly to the next candidate.
                problems.append("Configuration file not found (%s): %s"
                                % (label, path))
            continue
        found, unknown_keys, problem = read_config(path)
        if problem:
            problems.append(problem)
            continue
        #: Relative paths resolve against the config file's own folder, so a
        #: config can travel with the tree it describes.
        base = os.path.dirname(os.path.abspath(path))
        for key in sorted(found):
            value = found[key]
            values[key] = (value if os.path.isabs(value)
                           else os.path.normpath(os.path.join(base, value)))
        unknown.extend(unknown_keys)
        source, used_path = label, path
        break

    settings = Settings(root, values, source, used_path, problems, unknown)
    for key in REQUIRED_KEYS:
        path = getattr(settings, key)
        if not path:
            settings.problems.append("%s is not configured." % key)
        elif not os.path.isfile(path):
            settings.problems.append(
                "%s does not exist: %s (from %s)" % (key, path, source))
    return settings


def apply(settings, publisher_config=None):
    """Point the publish engine at these paths.

    `dz_revit_publisher.config` exposes module attributes that `executor.py`
    reads directly. `configure` is the seam it already provides, so nothing in
    the protected engine changes.
    """
    if publisher_config is None:
        from dz_revit_publisher import config as publisher_config
    publisher_config.configure(
        project_root=settings.app_root,
        shared_parameter_file=settings.shared_parameter_file,
        shared_parameter_registry=settings.shared_parameter_registry,
        exports_root=settings.exports_root,
        default_source_3dm=settings.default_source_3dm)
    return publisher_config


def module_origins(packages=None):
    """Where each DZ package was actually imported from.

    Resolution is not the same as loading. An installation can resolve its own
    root correctly and still be running code from somewhere else if that other
    copy reached `sys.path` first - which is exactly the risk when a developer
    checkout lives on the same machine. This reports the file each package was
    really loaded from, so the answer is observed rather than assumed.
    """
    import sys
    names = packages or ("dz_planning_app", "dz_planning_ui",
                         "dz_revit_publisher", "dz_revit_integration")
    found = []
    for name in names:
        module = sys.modules.get(name)
        path = getattr(module, "__file__", None) if module else None
        found.append((name, os.path.dirname(os.path.abspath(path))
                      if path else "(not imported)"))
    return found


def loaded_outside(root, packages=None):
    """Packages loaded from somewhere other than ``root``. Empty is correct."""
    root = os.path.abspath(root).lower()
    return [(name, where) for name, where in module_origins(packages)
            if where != "(not imported)" and not where.lower().startswith(root)]


def ensure_user_dirs(settings):
    """Create the writable folders. Best effort; failure is reported."""
    made = []
    for path in (settings.exports_root, settings.reports_root,
                 settings.logs_root):
        if not path or os.path.isdir(path):
            continue
        try:
            os.makedirs(path)
            made.append(path)
        except Exception as exc:
            settings.problems.append("Could not create %s (%s: %s)"
                                     % (path, type(exc).__name__, exc))
    return made
