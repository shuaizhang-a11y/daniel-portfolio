"""Strict input parsing for the publish engine.

Extracted verbatim from the validated Phase 7C component. An unrecognised
Publish Mode raises; it never silently degrades to Preview Only.
"""

from dz_revit_publisher import change_detection as cd
from dz_revit_publisher.phase07c_plan import PUBLISH_MODES


MODE_ALIASES = {
    "0": "Preview Only", "preview": "Preview Only", "preview only": "Preview Only",
    "1": "Create or Update", "create": "Create or Update",
    "create or update": "Create or Update",
    "2": "Update Existing Only", "update": "Update Existing Only",
    "update existing only": "Update Existing Only",
}


def parse_publish_mode(value):
    """Strict. An unrecognised mode never silently becomes Preview Only."""
    if value is None:
        raise ValueError("Publish Mode is missing.")
    if isinstance(value, bool):
        raise ValueError("Boolean %r is not a valid Publish Mode." % value)
    if isinstance(value, (int, float)):
        index = int(value)
        for candidate, name in enumerate(PUBLISH_MODES):
            if index == candidate:
                return name
        raise ValueError("Unknown numeric Publish Mode: %s" % value)
    text = str(value).strip().strip('"').strip("'").lower()
    if text in MODE_ALIASES:
        return MODE_ALIASES[text]
    raise ValueError("Unsupported Publish Mode raw value: %r" % (value,))


#: Retired in V1.1. `Archive` executed exactly as `Mark Only`, so it offered a
#: third choice with no third behaviour. It is refused by name rather than
#: through the generic unknown-value path, because a request carrying it came
#: from somewhere that once had a reason to, and "unsupported" would not say
#: what changed.
RETIRED_OBSOLETE_ACTIONS = {
    "archive": ("Archive is no longer an active obsolete action. "
                "Choose Mark Only or Delete."),
}

#: The actions a request may carry. Deliberately narrower than
#: `cd.OBSOLETE_ACTIONS`, which retains `Archive` so historical records stay
#: readable - a log written last year must not become unparseable because the
#: choice was withdrawn this year.
ACTIVE_OBSOLETE_ACTIONS = (cd.MARK_ONLY, cd.DELETE)


def parse_obsolete_action(value):
    text = str(value or cd.MARK_ONLY).strip().strip('"').strip("'").lower()
    if text in RETIRED_OBSOLETE_ACTIONS:
        #: Never silently downgraded to Mark Only. The caller records this as
        #: an input error, and the controller blocks the plan on it, so the
        #: operator is told rather than quietly given different behaviour.
        raise ValueError(RETIRED_OBSOLETE_ACTIONS[text])
    for candidate in ACTIVE_OBSOLETE_ACTIONS:
        if text == candidate.lower():
            return candidate
    raise ValueError("Unsupported Obsolete Element Action: %r" % (value,))



def coerce_flag(value, default=False):
    """Grasshopper and Eto both hand us bools, strings or None."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    token = str(value).strip().lower()
    if token in ("true", "yes", "1"):
        return True
    if token in ("false", "no", "0"):
        return False
    return default


def coerce_text(value, default=None):
    if value is None:
        return default
    if isinstance(value, str) and not value.strip():
        return default
    return value
