"""Session state for one publish workflow.

A plain, serialisable record of what the operator has chosen. No Revit, no
Rhino, no UI framework: the UI binds to this, and the controller reads it.
"""

import os

from dz_revit_publisher import change_detection as cd

from .inputs import coerce_flag, coerce_text, parse_obsolete_action, \
    parse_publish_mode

PREVIEW_ONLY = "Preview Only"


class PublishRequest(object):
    """The inputs to analyse / plan / publish.

    Constructed from a plain dict so the same request can arrive from
    Grasshopper, from Eto, or from a test.
    """

    FIELDS = ("manifest_path", "source_3dm_path", "building_id",
              "expected_rvt_path", "publish_mode", "obsolete_action",
              "confirm_publish", "confirm_delete_obsolete", "publish",
              "force_fail_at_stage", "baseline_rvt_sha256")

    def __init__(self, manifest_path=None, source_3dm_path=None,
                 building_id="B001", expected_rvt_path=None,
                 publish_mode=PREVIEW_ONLY, obsolete_action=cd.MARK_ONLY,
                 confirm_publish=False, confirm_delete_obsolete=False,
                 publish=False, force_fail_at_stage=None,
                 baseline_rvt_sha256=None):
        self.manifest_path = coerce_text(manifest_path)
        self.source_3dm_path = coerce_text(source_3dm_path)
        self.building_id = coerce_text(building_id, "B001")
        self.expected_rvt_path = coerce_text(expected_rvt_path)
        self.publish_mode_raw = publish_mode
        self.obsolete_action_raw = obsolete_action
        self.confirm_publish = coerce_flag(confirm_publish)
        self.confirm_delete_obsolete = coerce_flag(confirm_delete_obsolete)
        self.publish = coerce_flag(publish)
        self.force_fail_at_stage = coerce_text(force_fail_at_stage)
        self.baseline_rvt_sha256 = coerce_text(baseline_rvt_sha256)

        #: Parsing is strict and deliberately eager: an unrecognised mode must
        #: surface as a blocking input error, never as a silent Preview Only.
        self.mode_error = None
        self.obsolete_error = None
        try:
            self.publish_mode = parse_publish_mode(self.publish_mode_raw)
        except ValueError as exc:
            self.publish_mode, self.mode_error = None, str(exc)
        try:
            self.obsolete_action = parse_obsolete_action(self.obsolete_action_raw)
        except ValueError as exc:
            self.obsolete_action, self.obsolete_error = cd.MARK_ONLY, str(exc)

    @classmethod
    def from_dict(cls, payload):
        payload = dict(payload or {})
        return cls(**dict((k, payload.get(k)) for k in cls.FIELDS
                          if k in payload))

    @property
    def input_error(self):
        return self.mode_error or self.obsolete_error

    @property
    def is_preview_only(self):
        return self.publish_mode == PREVIEW_ONLY

    @property
    def wants_write(self):
        """A write is intended only when mode, confirmation and trigger agree."""
        return bool(self.publish_mode and not self.is_preview_only
                    and self.confirm_publish and self.publish)

    def as_dict(self):
        return {
            "ManifestPath": self.manifest_path,
            "Source3DMPath": self.source_3dm_path,
            "BuildingId": self.building_id,
            "ExpectedRvtPath": self.expected_rvt_path,
            "PublishMode": self.publish_mode,
            "ObsoleteAction": self.obsolete_action,
            "ConfirmPublish": self.confirm_publish,
            "ConfirmDeleteObsolete": self.confirm_delete_obsolete,
            "Publish": self.publish,
            "ForceFailAtStage": self.force_fail_at_stage,
            "BaselineRvtSha256": self.baseline_rvt_sha256,
            "InputError": self.input_error,
        }


def expected_path_conflict(expected_path, active_path):
    """The wrong-model guard, in one place.

    Returns a blocking message or None. Used at plan time *and* re-used by the
    dispatcher at execution time, because the operator can switch documents
    between clicking and the event firing.
    """
    if not expected_path:
        return None
    if not active_path:
        return ("Expected RVT Path is set to %s but the active Revit document "
                "has never been saved." % expected_path)
    if os.path.normcase(os.path.abspath(str(expected_path).strip())) != \
            os.path.normcase(os.path.abspath(active_path)):
        return ("WRONG MODEL. Expected RVT Path is %s but the active Revit "
                "document is %s. Publishing is blocked so a fixture run cannot "
                "reach the production model."
                % (str(expected_path).strip(), active_path))
    return None
