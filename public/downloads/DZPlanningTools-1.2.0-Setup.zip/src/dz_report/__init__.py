"""DZ Planning Tools - Phase 6B formatted planning report generator.

Standalone package. It reads an existing Phase 6A export package and renders a
multi-page planning feasibility report. It never recalculates a planning result,
never imports RhinoCommon, and never modifies the source export package.
"""

__version__ = "1.0"
REPORT_SCHEMA_SUPPORTED = ("1.0",)
DEFINITION_PHASE = "6B"

__all__ = ["__version__", "REPORT_SCHEMA_SUPPORTED", "DEFINITION_PHASE"]
