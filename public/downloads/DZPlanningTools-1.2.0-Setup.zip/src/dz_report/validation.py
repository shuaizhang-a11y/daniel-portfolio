"""Pre-generation validation of a Phase 6A manifest.

Blocking issues stop PDF generation entirely. Non-blocking issues let the
report proceed and set the status to REPORT GENERATED WITH WARNINGS.
"""

import math

from .models import STATUS_VOCAB, ReportData

SUPPORTED_SCHEMA = ("1.0",)

REQUIRED_TOP_LEVEL = (
    "schemaVersion", "exportMetadata", "project", "site", "planningControls",
    "buildings", "floors", "compliance", "setbacks", "buildingSeparation",
    "openSpace", "heightPlanes", "parking", "solarAccess", "sourceObjects",
    "warnings",
)

CONTAINER_TYPES = {
    "exportMetadata": dict, "project": dict, "site": dict,
    "planningControls": dict, "buildings": list, "floors": list,
    "compliance": list, "setbacks": list, "buildingSeparation": list,
    "openSpace": dict, "heightPlanes": list, "parking": dict,
    "solarAccess": dict, "sourceObjects": list, "warnings": list,
}

PERCENT_FIELDS = (
    "FSRUtilisationPercent", "ActualSiteCoverage", "MaximumSiteCoverage",
    "ActualDeepSoilPercent", "RequiredDeepSoilPercent",
    "ActualCommunalOpenSpacePercent", "RequiredCommunalOpenSpacePercent",
    "SolarCompliantAreaPercent",
)


class ValidationResult(object):
    def __init__(self):
        self.blocking = []
        self.warnings = []
        self.checks = []

    @property
    def ok(self):
        return not self.blocking

    def block(self, message):
        self.blocking.append(message)

    def warn(self, message):
        self.warnings.append(message)

    def check(self, label, passed, detail=""):
        self.checks.append((label, "PASS" if passed else "FAIL", detail))
        return passed


def _finite(value):
    if value is None or isinstance(value, bool):
        return True
    if isinstance(value, (int, float)):
        return not (math.isnan(value) or math.isinf(value))
    return True


def _walk_numbers(node, path, result, limit=40):
    """Report non-finite numerics anywhere in the manifest."""
    if len(result.warnings) > limit:
        return
    if isinstance(node, dict):
        for key, value in node.items():
            _walk_numbers(value, "%s.%s" % (path, key), result, limit)
    elif isinstance(node, list):
        for index, value in enumerate(node):
            _walk_numbers(value, "%s[%d]" % (path, index), result, limit)
    elif not _finite(node):
        result.warn("Non-finite numeric value at %s." % path)


def validate_manifest(manifest):
    """Validate a loaded manifest. Returns a ValidationResult."""
    result = ValidationResult()

    if not isinstance(manifest, dict):
        result.block("Manifest root is not a JSON object.")
        return result

    missing = [key for key in REQUIRED_TOP_LEVEL if key not in manifest]
    if missing:
        result.block("Manifest is missing required sections: %s"
                     % ", ".join(missing))
    result.check("Required manifest sections present", not missing,
                 "missing: %s" % ", ".join(missing) if missing else
                 "%d/%d" % (len(REQUIRED_TOP_LEVEL), len(REQUIRED_TOP_LEVEL)))

    wrong_type = []
    for key, expected in CONTAINER_TYPES.items():
        if key in manifest and not isinstance(manifest[key], expected):
            wrong_type.append("%s (expected %s)" % (key, expected.__name__))
    if wrong_type:
        result.block("Manifest sections have the wrong structure: %s"
                     % ", ".join(wrong_type))
    result.check("Manifest section types", not wrong_type,
                 ", ".join(wrong_type) if wrong_type else "all as expected")

    schema = str(manifest.get("schemaVersion") or "")
    supported = schema in SUPPORTED_SCHEMA
    if not supported:
        result.block("Unsupported schemaVersion %r. Supported: %s"
                     % (schema, ", ".join(SUPPORTED_SCHEMA)))
    result.check("Schema version supported", supported, schema or "(absent)")

    if result.blocking:
        return result

    data = ReportData(manifest)

    if not str(data.project_id).strip():
        result.block("Project ID is missing from the manifest.")
    result.check("Project ID present", bool(str(data.project_id).strip()),
                 str(data.project_id))

    has_option = bool(str(data.option).strip())
    has_revision = bool(str(data.revision).strip())
    if not has_option:
        result.block("Option is missing from the manifest.")
    if not has_revision:
        result.block("Revision is missing from the manifest.")
    result.check("Option and revision present", has_option and has_revision,
                 "%s / %s" % (data.option, data.revision))

    # Status vocabulary across every status-bearing table.
    bad_status = []
    status_tables = (
        ("compliance", data.compliance, "Status"),
        ("setbacks", data.setbacks, "Status"),
        ("buildingSeparation", data.separation, "Status"),
        ("openSpace.regions", data.open_space_regions, "Status"),
        ("heightPlanes", data.height_planes, "Status"),
        ("solarAccess.regions", data.solar_regions, "Status"),
    )
    for label, rows, field in status_tables:
        for row in rows:
            value = row.get(field)
            if value is None:
                continue
            if value not in STATUS_VOCAB:
                bad_status.append("%s: %r" % (label, value))
    if bad_status:
        result.block("Status values outside the approved vocabulary: %s"
                     % "; ".join(sorted(set(bad_status))[:10]))
    result.check("Status vocabulary", not bad_status,
                 "%d status-bearing rows checked"
                 % sum(len(rows) for _, rows, _ in status_tables))

    overall = data.overall_status
    if overall is not None and overall not in STATUS_VOCAB:
        result.block("Overall compliance status %r is not in the approved "
                     "vocabulary." % overall)

    # Numeric sanity.
    before = len(result.warnings)
    _walk_numbers(manifest, "manifest", result)
    result.check("Numeric values finite", len(result.warnings) == before,
                 "%d non-finite value(s)" % (len(result.warnings) - before))

    # Identifier uniqueness - warning, not blocking, since Phase 6A already
    # blocks on it and the report should still be readable.
    building_ids = [row.get("BuildingId") for row in data.buildings
                    if row.get("BuildingId")]
    dupe_ids = sorted(set(i for i in building_ids if building_ids.count(i) > 1))
    if dupe_ids:
        result.warn("Duplicate BuildingId values in the manifest: %s"
                    % ", ".join(dupe_ids))
    result.check("BuildingId uniqueness", not dupe_ids,
                 "%d building(s)" % len(building_ids))

    source_ids = [row.get("SourceId") for row in data.buildings
                  if row.get("SourceId")]
    dupe_src = sorted(set(i for i in source_ids if source_ids.count(i) > 1))
    if dupe_src:
        result.warn("Duplicate building SourceId values: %s" % ", ".join(dupe_src))
    result.check("Building SourceId uniqueness", not dupe_src,
                 "%d SourceId(s)" % len(source_ids))

    missing_src = [row.get("BuildingId") for row in data.buildings
                   if not row.get("SourceId")]
    if missing_src:
        result.warn("Buildings without a SourceId: %s"
                    % ", ".join(str(i) for i in missing_src))

    audit_missing = [row for row in data.source_objects
                     if not row.get("SourceId")]
    if audit_missing:
        result.warn("%d Rhino source object(s) carry no DZ.SourceId; they are "
                    "reported as Not available rather than given an identifier."
                    % len(audit_missing))

    # Percentages must already be 0-100, not raw decimals.
    suspicious = []
    summary = data.summary
    for field in PERCENT_FIELDS:
        value = summary.get(field)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if value < 0 or value > 100.0000001:
                suspicious.append("%s=%s" % (field, value))
    if suspicious:
        result.warn("Percentage field(s) outside 0-100: %s. Values are shown "
                    "exactly as exported and are not rescaled."
                    % ", ".join(suspicious))
    result.check("Percentages within 0-100", not suspicious,
                 "%d field(s) checked" % len(PERCENT_FIELDS))

    # Units availability.
    missing_units = [row.get("RuleId") for row in data.compliance
                     if row.get("ActualValue") is not None
                     and not row.get("ActualUnit")]
    if missing_units:
        result.warn("Compliance rows without an ActualUnit: %s"
                    % ", ".join(str(i) for i in missing_units))
    result.check("Units available where expected", not missing_units,
                 "%d compliance row(s)" % len(data.compliance))

    # Section data availability.
    empty_sections = []
    for label, rows in (("buildings", data.buildings),
                        ("floors", data.floors),
                        ("compliance", data.compliance)):
        if not rows:
            empty_sections.append(label)
    if "compliance" in empty_sections or "buildings" in empty_sections:
        result.block("Manifest contains no %s rows; a meaningful report cannot "
                     "be produced." % " or ".join(empty_sections))
    elif empty_sections:
        result.warn("Manifest sections with no rows: %s"
                    % ", ".join(empty_sections))
    result.check("Core report sections populated",
                 not ("compliance" in empty_sections
                      or "buildings" in empty_sections),
                 "buildings=%d floors=%d compliance=%d"
                 % (len(data.buildings), len(data.floors), len(data.compliance)))

    return result


def cross_check_csv(data, project_summary_rows, compliance_rows):
    """Compare manifest values against the package CSVs. Returns issue list."""
    issues = []

    if project_summary_rows:
        csv_summary = {}
        for row in project_summary_rows:
            csv_summary[row.get("Field")] = row.get("Value")
        for field, value in data.summary.items():
            if field not in csv_summary:
                continue
            csv_value = csv_summary[field]
            if value is None:
                if csv_value not in ("", None):
                    issues.append("project_summary.csv %s = %r but manifest is null"
                                  % (field, csv_value))
                continue
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                try:
                    if abs(float(csv_value) - float(value)) > 1e-6:
                        issues.append("project_summary.csv %s = %s vs manifest %s"
                                      % (field, csv_value, value))
                except (TypeError, ValueError):
                    issues.append("project_summary.csv %s is not numeric (%r)"
                                  % (field, csv_value))
            elif str(csv_value) != str(value):
                issues.append("project_summary.csv %s = %r vs manifest %r"
                              % (field, csv_value, value))

    if compliance_rows:
        csv_status = {}
        for row in compliance_rows:
            csv_status[row.get("RuleId")] = row.get("Status")
        for row in data.compliance:
            rule = row.get("RuleId")
            if rule in csv_status and csv_status[rule] != row.get("Status"):
                issues.append("compliance_summary.csv %s status %r vs manifest %r"
                              % (rule, csv_status[rule], row.get("Status")))

    return issues
