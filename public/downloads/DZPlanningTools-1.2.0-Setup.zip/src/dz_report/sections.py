"""Report section builders producing ReportLab Platypus flowables."""

import os

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph,
                                Spacer, Table, TableStyle)

from .formatting import (NOT_AVAILABLE, clean_text, format_area, format_bool,
                         format_count, format_number, format_percent,
                         format_plain, format_status, format_value, is_missing,
                         join_ids, short_id, status_fill)

INK = colors.HexColor("#2F4F5F")
RULE = colors.HexColor("#C9D4DA")
BAND = colors.HexColor("#F4F7F8")
MUTED = colors.HexColor("#5C6B73")

PLANNING_DISCLAIMER = (
    "Design-stage feasibility assessment. Planning controls and statutory "
    "requirements must be verified against the applicable authority and "
    "project brief.")

PARKING_DISCLAIMER = (
    "CUSTOM PARKING RULE TABLE - VERIFY AGAINST APPLICABLE PLANNING AUTHORITY")

SOLAR_STATEMENT = "This assessment reports outdoor direct sun hours only."

SOLAR_EXCLUSIONS = [
    "Thermal-comfort simulation",
    "Indoor temperature simulation",
    "Daylight illuminance analysis",
    "Energy simulation",
    "sDA or ASE assessment",
    "Full apartment solar-access verification",
]

PARKING_EXCLUSIONS = [
    "Parking-bay dimensions",
    "Aisle widths",
    "Turning paths",
    "Ramp gradients",
    "Head clearances",
    "Vehicle circulation",
]

FLOOR_INDEX_CONVENTION = (
    "FloorIndex is 1-based and counts upward from the building base elevation. "
    "Floor index 1 is the lowest generated floor plate and its finished floor "
    "level equals the building base elevation. Level names are formatted L01, "
    "L02 and so on.")

NOT_A_PERMIT = [
    "a planning permit",
    "a statutory approval",
    "a compliance certificate",
    "a legal planning opinion",
    "a certified energy, daylight or traffic report",
]


class Styles(object):
    """Paragraph and table styles bound to the selected font family."""

    def __init__(self, font, bold_font, available_width):
        self.font = font
        self.bold = bold_font
        self.width = available_width
        self._figure_number = 0
        base = getSampleStyleSheet()

        self.title = ParagraphStyle(
            "DZTitle", parent=base["Title"], fontName=bold_font, fontSize=24,
            leading=29, textColor=INK, alignment=0, spaceAfter=4)
        self.subtitle = ParagraphStyle(
            "DZSubtitle", parent=base["Normal"], fontName=font, fontSize=13,
            leading=17, textColor=MUTED, spaceAfter=2)
        self.h1 = ParagraphStyle(
            "DZH1", parent=base["Heading1"], fontName=bold_font, fontSize=14,
            leading=18, textColor=INK, spaceBefore=2, spaceAfter=7)
        self.h2 = ParagraphStyle(
            "DZH2", parent=base["Heading2"], fontName=bold_font, fontSize=10.5,
            leading=14, textColor=INK, spaceBefore=10, spaceAfter=5)
        self.body = ParagraphStyle(
            "DZBody", parent=base["Normal"], fontName=font, fontSize=9,
            leading=13, textColor=colors.black, spaceAfter=5)
        self.small = ParagraphStyle(
            "DZSmall", parent=self.body, fontSize=7.8, leading=10.5,
            textColor=MUTED, spaceAfter=3)
        self.note = ParagraphStyle(
            "DZNote", parent=self.body, fontSize=8.2, leading=11.5,
            textColor=MUTED, spaceAfter=4)
        self.cell = ParagraphStyle(
            "DZCell", parent=base["Normal"], fontName=font, fontSize=7.4,
            leading=9.4, textColor=colors.black)
        self.cell_bold = ParagraphStyle(
            "DZCellBold", parent=self.cell, fontName=bold_font)
        self.head_cell = ParagraphStyle(
            "DZHeadCell", parent=self.cell, fontName=bold_font,
            textColor=colors.white)
        self.caption = ParagraphStyle(
            "DZCaption", parent=self.small, alignment=0, spaceBefore=3)
        self.cover_label = ParagraphStyle(
            "DZCoverLabel", parent=base["Normal"], fontName=font, fontSize=8,
            leading=11, textColor=MUTED)
        self.cover_value = ParagraphStyle(
            "DZCoverValue", parent=base["Normal"], fontName=bold_font,
            fontSize=11, leading=15, textColor=colors.black)


# ---------------------------------------------------------------------------
# building blocks
# ---------------------------------------------------------------------------

def heading(styles, number, title):
    return Paragraph("%s&nbsp;&nbsp;%s" % (number, clean_text(title).upper()),
                     styles.h1)


def _escape(text):
    return (clean_text(text).replace("&", "&amp;")
            .replace("<", "&lt;").replace(">", "&gt;"))


def para(styles, text, style=None):
    return Paragraph(_escape(text), style or styles.body)


def bullets(styles, items, style=None):
    flow = []
    for item in items:
        flow.append(Paragraph("&bull;&nbsp;&nbsp;%s" % _escape(item),
                              style or styles.body))
    return flow


def data_table(styles, headers, rows, widths=None, status_columns=(),
               align_right=(), font_size=7.4, repeat_header=True):
    """A wrapping, page-splitting table with repeated headers.

    `rows` are lists of plain values already formatted for display.
    """
    if not rows:
        return [para(styles, "No rows available for this table.", styles.note)]

    cell_style = ParagraphStyle("DZCellSized", parent=styles.cell,
                                fontSize=font_size, leading=font_size + 2.0)
    head_style = ParagraphStyle("DZHeadSized", parent=styles.head_cell,
                                fontSize=font_size, leading=font_size + 2.0)
    right_style = ParagraphStyle("DZCellRight", parent=cell_style, alignment=2)

    table_data = [[Paragraph(_escape(h), head_style) for h in headers]]
    for row in rows:
        line = []
        for index, value in enumerate(row):
            text = "" if value is None else str(value)
            style = right_style if index in align_right else cell_style
            line.append(Paragraph(_escape(text), style))
        table_data.append(line)

    if widths:
        total = float(sum(widths))
        col_widths = [styles.width * (w / total) for w in widths]
    else:
        col_widths = [styles.width / float(len(headers))] * len(headers)

    commands = [
        ("BACKGROUND", (0, 0), (-1, 0), INK),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.35, RULE),
        ("LEFTPADDING", (0, 0), (-1, -1), 3.5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3.5),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    for index in range(1, len(table_data)):
        if index % 2 == 0:
            commands.append(("BACKGROUND", (0, index), (-1, index), BAND))
    for column in status_columns:
        for index, row in enumerate(rows, start=1):
            if column >= len(row):
                continue
            raw = str(row[column] or "")
            for token in ("COMPLIES", "NON-COMPLIANT", "WARNING",
                          "NOT EVALUATED", "INVALID INPUT"):
                if token in raw:
                    fill = status_fill(token)
                    if fill:
                        commands.append(("BACKGROUND", (column, index),
                                         (column, index), colors.HexColor(fill)))
                    break

    table = Table(table_data, colWidths=col_widths, repeatRows=1 if repeat_header else 0)
    table.setStyle(TableStyle(commands))
    table.hAlign = "LEFT"
    return [table]


def key_value_table(styles, pairs, label_width=0.34):
    rows = []
    for label, value in pairs:
        rows.append([Paragraph(_escape(label), styles.cell_bold),
                     Paragraph(_escape("" if value is None else str(value)),
                               styles.cell)])
    table = Table(rows, colWidths=[styles.width * label_width,
                                   styles.width * (1 - label_width)])
    table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LINEBELOW", (0, 0), (-1, -1), 0.3, RULE),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    table.hAlign = "LEFT"
    return [table]


def figure(styles, path, caption, max_width=None, max_height=170 * mm):
    """Scale an image to the frame, preserving aspect ratio. Never fails hard.

    Figures are numbered as they are emitted, so a missing optional image
    leaves no gap in the sequence.
    """
    if not path or not os.path.isfile(path):
        return []
    try:
        from reportlab.lib.utils import ImageReader
        reader = ImageReader(path)
        source_w, source_h = reader.getSize()
        if not source_w or not source_h:
            return []
        width = max_width or styles.width
        height = width * float(source_h) / float(source_w)
        if height > max_height:
            height = max_height
            width = height * float(source_w) / float(source_h)
        image = Image(path, width=width, height=height)
        image.hAlign = "LEFT"
        flow = [image]
        if caption:
            styles._figure_number += 1
            flow.append(Paragraph(
                _escape("Figure %d. %s" % (styles._figure_number, caption)),
                styles.caption))
        flow.append(Spacer(1, 5))
        return flow
    except Exception:
        return []


# ---------------------------------------------------------------------------
# sections
# ---------------------------------------------------------------------------

def section_cover(styles, data, config, figures, report_timestamp):
    flow = []
    cover_image = figures.get("01_cover")
    if cover_image:
        flow.extend(figure(styles, cover_image, None, max_height=95 * mm))
        flow.append(Spacer(1, 8 * mm))
    else:
        flow.append(Spacer(1, 22 * mm))

    flow.append(Paragraph(_escape(config.get("reportTitle")
                                  or "Planning Feasibility Report"), styles.title))
    subtitle = config.get("reportSubtitle") or data.project_name
    if subtitle:
        flow.append(Paragraph(_escape(subtitle), styles.subtitle))
    flow.append(Spacer(1, 10 * mm))

    pairs = [
        ("Project name", data.project_name or NOT_AVAILABLE),
        ("Project ID", data.project_id or NOT_AVAILABLE),
    ]
    address = config.get("projectAddress")
    if address:
        pairs.append(("Project address", address))
    pairs.extend([
        ("Option", data.option or NOT_AVAILABLE),
        ("Revision", data.revision or NOT_AVAILABLE),
        ("Issue purpose", config.get("issuePurpose") or "Design Feasibility"),
        ("Prepared for", config.get("preparedFor") or config.get("clientName")
         or NOT_AVAILABLE),
        ("Prepared by", config.get("preparedBy") or "DZ Planning Tools"),
        ("Report date", report_timestamp.replace("T", " ")[:16]),
        ("Source export timestamp",
         (data.metadata.get("ExportTimestamp") or "").replace("T", " ")[:16]
         or NOT_AVAILABLE),
        ("Confidentiality", config.get("confidentiality") or "Confidential"),
    ])
    flow.extend(key_value_table(styles, pairs, label_width=0.32))
    flow.append(Spacer(1, 12 * mm))

    box = Table([[Paragraph(_escape(PLANNING_DISCLAIMER), styles.note)]],
                colWidths=[styles.width])
    box.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.6, RULE),
        ("BACKGROUND", (0, 0), (-1, -1), BAND),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    flow.append(box)
    flow.append(Spacer(1, 5))
    flow.append(para(styles,
                     "This report is not " + ", ".join(NOT_A_PERMIT[:-1])
                     + " or " + NOT_A_PERMIT[-1] + ".", styles.small))
    flow.append(PageBreak())
    return flow


def _summary_sentences(data):
    summary = data.summary
    counts, _source = data.status_counts()

    def num(key, decimals=2):
        return format_number(summary.get(key), decimals)

    building_count = summary.get("BuildingCount")
    building_text = ("%s buildings" % format_count(building_count)
                     if building_count != 1 else "1 building")

    first = ("The %s proposal contains %s with a total physical GFA of %s m2 "
             "on a site area of %s m2."
             % (clean_text(data.option) or "current",
                building_text.lower() if building_count != 1 else building_text,
                num("TotalPhysicalGFA"), num("SiteArea")))

    actual_fsr = summary.get("ActualFSR")
    target_fsr = summary.get("TargetFSR")
    if actual_fsr is None and target_fsr is None:
        second = "Floor space ratio values are not available in this export."
    elif target_fsr is None:
        second = ("The assessed Actual FSR is %s. No Target FSR is recorded."
                  % num("ActualFSR"))
    else:
        second = ("The assessed Actual FSR is %s against a Target FSR of %s."
                  % (num("ActualFSR"), num("TargetFSR")))

    parts = []
    for label, key in (("compliant", "COMPLIES"),
                       ("non-compliant", "NON-COMPLIANT"),
                       ("warning", "WARNING"),
                       ("not evaluated", "NOT EVALUATED"),
                       ("invalid input", "INVALID INPUT")):
        value = counts.get(key)
        if value:
            noun = "rule" if value == 1 else "rules"
            if label in ("warning",):
                parts.append("%d %s %s" % (value, label, noun))
            else:
                parts.append("%d %s %s" % (value, label, noun))
    third = ("The current assessment records %s."
             % (", ".join(parts) if parts else "no evaluated rules"))

    overall = data.overall_status
    fourth = ("The overall recorded compliance status for this option is %s."
              % (clean_text(overall) if overall else NOT_AVAILABLE))
    return [first, second, third, fourth]


def section_executive_summary(styles, data, charts):
    summary = data.summary
    flow = [heading(styles, "02", "Executive summary")]
    for sentence in _summary_sentences(data):
        flow.append(para(styles, sentence))
    flow.append(Spacer(1, 4))

    rows = [
        ("Site area", format_area(summary.get("SiteArea"))),
        ("Building count", format_count(summary.get("BuildingCount"))),
        ("Total physical GFA", format_area(summary.get("TotalPhysicalGFA"))),
        ("FSR included GFA", format_area(summary.get("FSRIncludedGFA"))),
        ("Actual FSR", format_number(summary.get("ActualFSR"), 2)),
        ("Target FSR", format_number(summary.get("TargetFSR"), 2)),
        ("Actual site coverage", format_percent(summary.get("ActualSiteCoverage"))),
        ("Maximum building height",
         format_value(summary.get("MaximumActualHeight"), "m")),
        ("Deep soil percentage",
         format_percent(summary.get("ActualDeepSoilPercent"))),
        ("Communal open space percentage",
         format_percent(summary.get("ActualCommunalOpenSpacePercent"))),
        ("Required vehicle parking",
         format_value(summary.get("RequiredVehicleParking"), "spaces")),
        ("Actual vehicle parking",
         format_value(summary.get("ActualVehicleParking"), "spaces")),
        ("Solar compliant area percentage",
         format_percent(summary.get("SolarCompliantAreaPercent"))),
        ("Overall compliance status", format_status(data.overall_status)),
    ]
    flow.extend(key_value_table(styles, rows, label_width=0.42))
    flow.append(Spacer(1, 6))
    flow.append(para(styles,
                     "The compliance status distribution is shown in Figure 1, "
                     "section 05.", styles.note))
    flow.append(PageBreak())
    return flow


_UNSET = object()


def _metric_row(label, value, unit, target=_UNSET, difference=_UNSET,
                status=None):
    """A metric row.

    A target or difference that is simply not applicable to the metric is left
    blank. One that is applicable but absent from the export reads
    "Not available", so a missing value is never confused with an empty one.
    """
    def cell(item):
        if item is _UNSET:
            return ""
        return NOT_AVAILABLE if is_missing(item) else format_plain(item, unit)

    return [label,
            NOT_AVAILABLE if is_missing(value) else format_plain(value, unit),
            unit or "",
            cell(target),
            cell(difference),
            format_status(status) if status else ""]


def section_key_metrics(styles, data):
    summary = data.summary
    flow = [heading(styles, "03", "Key development metrics")]
    flow.append(para(styles,
                     "Values are reproduced from the Phase 6A export package. "
                     "Unavailable values are shown as \"Not available\"; a value "
                     "of zero means a measured zero.", styles.note))

    def rule(rule_id, field):
        row = data.compliance_by_rule(rule_id)
        return row.get(field)

    rows = [
        _metric_row("Site area", summary.get("SiteArea"), "m2"),
        _metric_row("Building count", summary.get("BuildingCount"), "count"),
        _metric_row("Total footprint area", summary.get("TotalFootprintArea"), "m2"),
        _metric_row("Total physical GFA", summary.get("TotalPhysicalGFA"), "m2"),
        _metric_row("FSR included GFA", summary.get("FSRIncludedGFA"), "m2"),
        _metric_row("Actual FSR", summary.get("ActualFSR"), "ratio",
                    summary.get("TargetFSR"), rule("FSR", "Difference"),
                    rule("FSR", "Status")),
        _metric_row("Maximum permitted GFA", summary.get("MaximumPermittedGFA"), "m2"),
        _metric_row("Remaining GFA", summary.get("RemainingGFA"), "m2"),
        _metric_row("Excess GFA", summary.get("ExcessGFA"), "m2"),
        _metric_row("FSR utilisation", summary.get("FSRUtilisationPercent"), "%"),
        _metric_row("Actual site coverage", summary.get("ActualSiteCoverage"), "%",
                    summary.get("MaximumSiteCoverage"),
                    rule("SITE_COVERAGE", "Difference"),
                    rule("SITE_COVERAGE", "Status")),
        _metric_row("Maximum actual height", summary.get("MaximumActualHeight"), "m",
                    summary.get("PermittedMaximumHeight"),
                    rule("MAX_HEIGHT", "Difference"), rule("MAX_HEIGHT", "Status")),
        _metric_row("Deep soil area", summary.get("ActualDeepSoilArea"), "m2"),
        _metric_row("Deep soil percentage", summary.get("ActualDeepSoilPercent"), "%",
                    summary.get("RequiredDeepSoilPercent"),
                    rule("DEEP_SOIL", "Difference"), rule("DEEP_SOIL", "Status")),
        _metric_row("Communal open space area",
                    summary.get("ActualCommunalOpenSpaceArea"), "m2"),
        _metric_row("Communal open space percentage",
                    summary.get("ActualCommunalOpenSpacePercent"), "%",
                    summary.get("RequiredCommunalOpenSpacePercent"),
                    rule("COMMUNAL_OPEN_SPACE", "Difference"),
                    rule("COMMUNAL_OPEN_SPACE", "Status")),
    ]
    flow.extend(data_table(
        styles, ["Metric", "Value", "Unit", "Target", "Difference", "Status"],
        rows, widths=[30, 15, 8, 15, 14, 18], status_columns=(5,),
        align_right=(1, 3, 4)))
    flow.append(PageBreak())
    return flow


CUSTOM_CONTROL_TOKENS = ("UNVERIFIED", "CUSTOM", "NOT A VERIFIED")

# Logical reading order for the controls schedule. Anything the manifest adds
# beyond this list is appended alphabetically so nothing is ever dropped.
CONTROL_ORDER = [
    "Target FSR", "Maximum Height", "Maximum Site Coverage",
    "Front Setback", "Rear Setback", "Side Setback 1", "Side Setback 2",
    "Minimum Deep Soil Percentage", "Minimum Communal Open Space Percentage",
    "Minimum Building Separation",
    "Parking Rule Set Name", "Visitor Included in Vehicle Total",
    "Solar EPW Path", "Solar Location", "Solar North Angle",
    "Solar Analysis Date", "Solar Start Hour", "Solar End Hour",
    "Solar Timestep", "Minimum Solar Access Hours",
    "Required Solar Area Percentage", "Solar Grid Size", "Solar Sensor Offset",
    "Solar Context Mode",
    "Height Plane Default Angle", "Height Plane Default Offset",
    "Height Plane Default Base Height",
]


def _ordered_controls(controls):
    known = [name for name in CONTROL_ORDER if name in controls]
    extra = sorted(name for name in controls if name not in CONTROL_ORDER)
    return known + extra


def section_planning_controls(styles, data):
    flow = [heading(styles, "04", "Planning controls")]
    flow.append(para(styles,
                     "Planning controls as recorded in the export package, with "
                     "their source and validation state. Controls flagged below "
                     "are custom test values and are not verified statutory "
                     "presets.", styles.note))

    controls = data.controls
    rows = []
    flagged = []
    for name in _ordered_controls(controls):
        entry = controls.get(name) or {}
        value = entry.get("value")
        unit = entry.get("unit") or ""
        validation = clean_text(entry.get("validationStatus") or "")
        notes = clean_text(entry.get("notes") or "")
        marker = ""
        haystack = (validation + " " + notes).upper()
        if any(token in haystack for token in CUSTOM_CONTROL_TOKENS):
            marker = " [CUSTOM TEST RULE]"
            flagged.append(name)
        rows.append([
            clean_text(name) + marker,
            format_plain(value, unit),
            unit,
            clean_text(entry.get("source") or ""),
            clean_text(entry.get("overrideStatus") or ""),
            validation,
            notes,
        ])

    flow.extend(data_table(
        styles,
        ["Control", "Value", "Unit", "Source", "Override", "Validation", "Notes"],
        rows, widths=[19, 15, 7, 11, 7, 11, 30], font_size=7.0))

    if flagged:
        flow.append(Spacer(1, 6))
        flow.append(para(styles,
                         "Controls marked [CUSTOM TEST RULE] are NOT A VERIFIED "
                         "STATUTORY PRESET and must be confirmed with the "
                         "applicable planning authority before any reliance is "
                         "placed on the associated result.", styles.note))
    flow.append(PageBreak())
    return flow


def section_compliance(styles, data, charts):
    flow = [heading(styles, "05", "Compliance overview")]
    counts, source = data.status_counts()
    flow.append(para(styles,
                     "One row per assessed planning rule. Status values are "
                     "reproduced exactly as recorded; WARNING and NOT EVALUATED "
                     "are not compliant outcomes. Status counts are taken from "
                     "the %s." % source, styles.note))

    rows = []
    for row in data.compliance:
        rows.append([
            clean_text(row.get("RuleName") or row.get("RuleId") or ""),
            format_value(row.get("TargetValue"), row.get("TargetUnit")),
            format_value(row.get("ActualValue"), row.get("ActualUnit")),
            format_value(row.get("Difference"), row.get("DifferenceUnit")),
            format_status(row.get("Status")),
            join_ids(row.get("AffectedBuildingIds"), limit=6) or "",
        ])
    flow.extend(data_table(
        styles, ["Rule", "Target", "Actual", "Difference", "Status", "Affected"],
        rows, widths=[24, 14, 14, 14, 20, 14], status_columns=(4,),
        align_right=(1, 2, 3)))

    flow.append(Spacer(1, 8))
    flow.extend(figure(styles, charts.get("compliance_status"),
                       "Rule count by compliance status."))
    flow.append(PageBreak())

    flow.append(Paragraph("Rule summaries and limitations", styles.h2))
    notes_rows = []
    for row in data.compliance:
        notes_rows.append([
            clean_text(row.get("RuleName") or row.get("RuleId") or ""),
            clean_text(row.get("Summary") or ""),
            clean_text(row.get("Limitations") or ""),
        ])
    flow.extend(data_table(styles, ["Rule", "Summary", "Limitations"],
                           notes_rows, widths=[18, 41, 41], font_size=7.0))
    flow.append(PageBreak())
    return flow


def section_buildings(styles, data, config, charts):
    flow = [heading(styles, "06", "Building schedule")]
    flow.append(para(styles,
                     "One row per building. The schedule is split into geometry "
                     "and demand-driver tables so no column is clipped.",
                     styles.note))

    flow.append(Paragraph("Geometry and area", styles.h2))
    rows = []
    for row in data.buildings:
        rows.append([
            clean_text(row.get("BuildingId") or ""),
            clean_text(row.get("BuildingName") or ""),
            clean_text(row.get("Program") or ""),
            format_value(row.get("Height"), "m"),
            format_count(row.get("FloorCount")),
            format_area(row.get("FootprintArea")),
            format_area(row.get("PhysicalGFA")),
            format_area(row.get("FSRIncludedGFA")),
            format_value(row.get("Volume"), "m3"),
            format_bool(row.get("IncludeInFSR")),
        ])
    flow.extend(data_table(
        styles,
        ["ID", "Name", "Program", "Height", "Floors", "Footprint",
         "Physical GFA", "FSR GFA", "Volume", "In FSR"],
        rows, widths=[7, 15, 12, 9, 7, 12, 13, 12, 13, 7],
        align_right=(3, 4, 5, 6, 7, 8)))

    flow.append(Spacer(1, 8))
    flow.append(Paragraph("Demand drivers and status summary", styles.h2))
    status_rows = []
    for row in data.buildings:
        parts = []
        for label, key in (("Height", "MaximumHeightStatus"),
                           ("Setback", "SetbackOverallStatus"),
                           ("Separation", "BuildingSeparationOverallStatus"),
                           ("Height plane", "HeightPlaneOverallStatus"),
                           ("Parking", "ParkingEvaluationStatus"),
                           ("Solar", "SolarRelationshipStatus")):
            value = row.get(key)
            if is_missing(value):
                continue
            parts.append("%s: %s" % (label, clean_text(value)))
        status_rows.append([
            clean_text(row.get("BuildingId") or ""),
            clean_text(row.get("BuildingName") or ""),
            format_count(row.get("DwellingCount")),
            format_count(row.get("HotelRoomCount")),
            format_count(row.get("StudentBedCount")),
            format_count(row.get("EmployeeCount")),
            "; ".join(parts) if parts else NOT_AVAILABLE,
        ])
    flow.extend(data_table(
        styles,
        ["ID", "Name", "Dwellings", "Hotel rooms", "Student beds", "Employees",
         "Status summary"],
        status_rows, widths=[7, 15, 10, 10, 10, 10, 38],
        align_right=(2, 3, 4, 5)))

    flow.append(Spacer(1, 8))
    flow.extend(figure(styles, charts.get("gfa_by_building"),
                       "Gross floor area by building."))
    flow.append(PageBreak())
    return flow


def section_floors(styles, data):
    flow = [heading(styles, "07", "Floor schedule")]
    flow.append(para(styles, FLOOR_INDEX_CONVENTION, styles.note))
    rows = []
    for row in data.floors:
        rows.append([
            clean_text(row.get("BuildingId") or ""),
            clean_text(row.get("BuildingName") or ""),
            format_count(row.get("FloorIndex")),
            clean_text(row.get("LevelName") or ""),
            format_value(row.get("Elevation"), "m"),
            format_value(row.get("FloorToFloorHeight"), "m"),
            format_area(row.get("FloorPlateArea")),
            format_bool(row.get("IncludedInFSR")),
            format_area(row.get("CumulativeBuildingGFA")),
        ])
    flow.extend(data_table(
        styles,
        ["Building", "Name", "Index", "Level", "Elevation", "Floor to floor",
         "Floor plate", "In FSR", "Cumulative GFA"],
        rows, widths=[9, 16, 7, 8, 11, 12, 12, 8, 15],
        align_right=(2, 4, 5, 6, 8)))
    flow.append(PageBreak())
    return flow


def section_setbacks(styles, data, figures):
    flow = [heading(styles, "08", "Setbacks and building separation")]

    flow.append(Paragraph("Setback results", styles.h2))
    rows = []
    for row in data.setbacks:
        rows.append([
            clean_text(row.get("BuildingId") or ""),
            clean_text(row.get("BuildingName") or ""),
            clean_text(row.get("BoundaryCategory") or ""),
            format_value(row.get("RequiredSetback"), "m"),
            format_value(row.get("ActualSetback"), "m"),
            format_value(row.get("Shortfall"), "m"),
            format_area(row.get("IntrusionArea")),
            format_status(row.get("Status")),
        ])
    flow.extend(data_table(
        styles,
        ["Building", "Name", "Boundary", "Required", "Actual", "Shortfall",
         "Intrusion area", "Status"],
        rows, widths=[9, 14, 15, 10, 10, 10, 12, 20], status_columns=(7,),
        align_right=(3, 4, 5, 6)))
    flow.extend(figure(styles, figures.get("02_setbacks"),
                       "Setback diagram."))

    flow.append(Spacer(1, 8))
    flow.append(Paragraph("Building separation results", styles.h2))
    flow.append(para(styles,
                     "One row per unique building pair. Reciprocal pairs are not "
                     "duplicated.", styles.note))
    pair_rows = []
    for row in data.separation:
        pair_rows.append([
            clean_text(row.get("BuildingAId") or ""),
            clean_text(row.get("BuildingAName") or ""),
            clean_text(row.get("BuildingBId") or ""),
            clean_text(row.get("BuildingBName") or ""),
            format_value(row.get("RequiredSeparation"), "m"),
            format_value(row.get("ActualSeparation"), "m"),
            format_value(row.get("Shortfall"), "m"),
            format_area(row.get("OverlapArea")),
            format_status(row.get("Status")),
        ])
    flow.extend(data_table(
        styles,
        ["A", "Name A", "B", "Name B", "Required", "Actual", "Shortfall",
         "Overlap", "Status"],
        pair_rows, widths=[6, 13, 6, 13, 10, 10, 10, 11, 21],
        status_columns=(8,), align_right=(4, 5, 6, 7)))
    flow.extend(figure(styles, figures.get("03_separation"),
                       "Building separation diagram."))
    flow.append(PageBreak())
    return flow


def section_open_space(styles, data, config, charts, figures):
    flow = [heading(styles, "09", "Open space")]
    summary = data.summary

    rows = [
        ["Deep soil",
         format_percent(summary.get("RequiredDeepSoilPercent")),
         format_area(summary.get("ActualDeepSoilArea")),
         format_percent(summary.get("ActualDeepSoilPercent")),
         format_status(data.compliance_by_rule("DEEP_SOIL").get("Status"))],
        ["Communal open space",
         format_percent(summary.get("RequiredCommunalOpenSpacePercent")),
         format_area(summary.get("ActualCommunalOpenSpaceArea")),
         format_percent(summary.get("ActualCommunalOpenSpacePercent")),
         format_status(data.compliance_by_rule("COMMUNAL_OPEN_SPACE").get("Status"))],
    ]
    flow.extend(data_table(
        styles,
        ["Category", "Required", "Actual eligible area", "Actual percentage",
         "Status"],
        rows, widths=[22, 15, 22, 18, 23], status_columns=(4,),
        align_right=(1, 2, 3), font_size=8.0))

    overlap = data.open_space.get("crossCategoryOverlapArea")
    flow.append(Spacer(1, 5))
    flow.append(para(styles,
                     "Cross-category overlap area (project total): %s. This is "
                     "area designated as both deep soil and communal open space; "
                     "confirm whether dual counting is permitted."
                     % format_area(overlap), styles.note))

    flow.append(Spacer(1, 6))
    charts_row = []
    for key, caption in (("deep_soil", "Deep soil, required versus actual."),
                         ("communal_open_space",
                          "Communal open space, required versus actual.")):
        charts_row.extend(figure(styles, charts.get(key), caption,
                                 max_width=styles.width * 0.62))

    flow.extend(charts_row)

    if config.get("includeDetailedTables") and data.open_space_regions:
        flow.append(Spacer(1, 6))
        flow.append(Paragraph("Region results", styles.h2))
        region_rows = []
        for row in data.open_space_regions:
            region_rows.append([
                clean_text(row.get("Category") or ""),
                clean_text(row.get("RegionId") or ""),
                clean_text(row.get("RegionName") or ""),
                clean_text(row.get("AreaCategory") or ""),
                format_area(row.get("GrossArea")),
                format_area(row.get("EligibleArea")),
                format_area(row.get("BuildingOverlapArea")),
                format_area(row.get("CrossCategoryOverlapArea")),
                format_bool(row.get("IncludedInCalculation")),
                clean_text(row.get("Warnings") or ""),
            ])
        flow.extend(data_table(
            styles,
            ["Category", "Region", "Name", "Type", "Gross", "Eligible",
             "Building overlap", "Cross-cat", "Incl", "Warnings"],
            region_rows, widths=[12, 7, 15, 8, 9, 9, 11, 11, 6, 12],
            align_right=(4, 5, 6, 7), font_size=6.9))

    flow.extend(figure(styles, figures.get("04_open_space"),
                       "Open space plan."))
    flow.append(PageBreak())
    return flow


def section_height_plane(styles, data, figures):
    flow = [heading(styles, "10", "Height plane")]
    flow.append(para(styles,
                     "Full analysis planes are used for compliance. Trimmed "
                     "surfaces are display geometry only and do not affect any "
                     "compliance result. Large untrimmed analysis surfaces are "
                     "deliberately not reproduced in this report.", styles.note))

    rows = []
    for row in data.height_planes:
        point = ""
        if row.get("ViolationPointX") is not None:
            point = "%s, %s, %s" % (format_number(row.get("ViolationPointX"), 2),
                                    format_number(row.get("ViolationPointY"), 2),
                                    format_number(row.get("ViolationPointZ"), 2))
        rows.append([
            clean_text(row.get("HeightPlaneId") or ""),
            clean_text(row.get("HeightPlaneName") or ""),
            format_value(row.get("Angle"), "degrees"),
            format_value(row.get("Offset"), "m"),
            format_value(row.get("BaseHeight"), "m"),
            clean_text(row.get("BuildingId") or ""),
            format_value(row.get("MaximumExceedance"), "m"),
            format_status(row.get("Status")),
            point or NOT_AVAILABLE,
        ])
    flow.extend(data_table(
        styles,
        ["Plane", "Name", "Angle", "Offset", "Base", "Building",
         "Max exceedance", "Status", "Violation point"],
        rows, widths=[7, 16, 9, 8, 8, 9, 12, 18, 13], status_columns=(7,),
        align_right=(2, 3, 4, 6)))
    flow.extend(figure(styles, figures.get("05_height_plane"),
                       "Height plane assessment."))
    flow.append(PageBreak())
    return flow


PARKING_ROWS = (
    ("PARKING_VEHICLE", "Vehicle spaces"),
    ("PARKING_VISITOR", "Visitor spaces"),
    ("PARKING_ACCESSIBLE", "Accessible spaces"),
    ("PARKING_BICYCLE", "Bicycle spaces"),
    ("PARKING_EV", "EV-ready spaces"),
)


def section_parking(styles, data, config, charts):
    flow = [heading(styles, "11", "Parking")]

    banner = Table([[Paragraph(_escape(PARKING_DISCLAIMER), styles.cell_bold)]],
                   colWidths=[styles.width])
    banner.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.7, colors.HexColor("#B06A6A")),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F0E2E2")),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
        ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    flow.append(banner)
    flow.append(Spacer(1, 8))

    rule_set = data.parking.get("ruleSetName")
    verified = data.parking.get("verifiedStatutoryPreset")
    flow.extend(key_value_table(styles, [
        ("Parking rule set", clean_text(rule_set) if rule_set else NOT_AVAILABLE),
        ("Verified statutory preset", format_bool(verified)),
    ], label_width=0.34))
    flow.append(Spacer(1, 8))

    rows = []
    for rule_id, label in PARKING_ROWS:
        row = data.compliance_by_rule(rule_id)
        if not row:
            continue
        rows.append([
            label,
            format_count(row.get("TargetValue")),
            format_count(row.get("ActualValue")),
            format_count(row.get("Difference")),
            format_status(row.get("Status")),
        ])
    flow.extend(data_table(
        styles, ["Provision", "Required", "Actual", "Surplus or shortfall",
                 "Status"],
        rows, widths=[24, 15, 15, 20, 26], status_columns=(4,),
        align_right=(1, 2, 3), font_size=8.0))

    flow.append(Spacer(1, 8))
    flow.extend(figure(styles, charts.get("parking"),
                       "Parking provision, required versus actual."))

    if config.get("includeDetailedTables") and data.parking_demand:
        flow.append(PageBreak())
        flow.append(Paragraph("Per-building parking demand", styles.h2))
        demand_rows = []
        for row in data.parking_demand:
            demand_rows.append([
                clean_text(row.get("BuildingId") or ""),
                clean_text(row.get("BuildingName") or ""),
                clean_text(row.get("Program") or ""),
                clean_text(row.get("DemandBasis") or ""),
                format_number(row.get("DemandQuantity"), 2),
                format_count(row.get("RequiredVehicle")),
                format_count(row.get("RequiredVisitor")),
                format_count(row.get("RequiredAccessible")),
                format_count(row.get("RequiredBicycle")),
                format_count(row.get("RequiredEVReady")),
                format_bool(row.get("ParkingExempt")),
            ])
        flow.extend(data_table(
            styles,
            ["ID", "Name", "Program", "Basis", "Quantity", "Vehicle", "Visitor",
             "Accessible", "Bicycle", "EV-ready", "Exempt"],
            demand_rows, widths=[6, 13, 11, 13, 9, 8, 8, 10, 8, 9, 7],
            align_right=(4, 5, 6, 7, 8, 9), font_size=6.9))

    flow.append(Spacer(1, 8))
    flow.append(para(styles,
                     "Phase 5D assesses parking quantity only. The following are "
                     "not assessed:"))
    flow.extend(bullets(styles, PARKING_EXCLUSIONS, styles.note))
    flow.append(PageBreak())
    return flow


def section_solar(styles, data, config, charts, figures):
    flow = [heading(styles, "12", "Direct solar access")]
    flow.append(para(styles, SOLAR_STATEMENT, styles.body))
    flow.append(para(styles, "It is not:", styles.body))
    flow.extend(bullets(styles, SOLAR_EXCLUSIONS, styles.note))
    flow.append(Spacer(1, 6))

    config_data = data.solar_config
    summary = data.summary
    solar_rule = data.compliance_by_rule("SOLAR_ACCESS")

    month = config_data.get("month")
    day = config_data.get("day")
    if month is not None and day is not None:
        analysis_date = "%02d-%02d (MM-DD)" % (int(month), int(day))
    else:
        analysis_date = NOT_AVAILABLE
    def clock(hour):
        try:
            value = float(hour)
        except (TypeError, ValueError):
            return None
        return "%02d:%02d" % (int(value), int(round((value - int(value)) * 60)))

    start = clock(config_data.get("start"))
    end = clock(config_data.get("end"))
    analysis_time = "%s to %s" % (start, end) if start and end else NOT_AVAILABLE

    location = data.solar.get("locationSummary")
    epw = config_data.get("epw")

    flow.extend(key_value_table(styles, [
        ("EPW location", clean_text(location) if location else
         (clean_text(epw) if epw else NOT_AVAILABLE)),
        ("EPW file", clean_text(epw) if epw else NOT_AVAILABLE),
        ("Model north", format_value(config_data.get("north"), "degrees")),
        ("Analysis date", analysis_date),
        ("Analysis time", analysis_time),
        ("Timestep", format_number(config_data.get("timestep"), 0)),
        ("Context mode", clean_text(config_data.get("context")) or NOT_AVAILABLE),
        ("Grid size", format_value(config_data.get("grid"), "m")),
        ("Sensor offset", format_value(config_data.get("offset"), "m")),
        ("Minimum required direct sun hours",
         format_value(config_data.get("minimum"), "hours")),
        ("Required compliant area percentage",
         format_percent(config_data.get("required"))),
        ("Actual compliant area", format_area(summary.get("SolarCompliantArea"))),
        ("Actual compliant area percentage",
         format_percent(summary.get("SolarCompliantAreaPercent"))),
        ("Status", format_status(solar_rule.get("Status"))),
    ], label_width=0.42))

    flow.append(Spacer(1, 8))
    flow.extend(figure(styles, charts.get("solar"),
                       "Solar compliant area, required versus actual.",
                       max_width=styles.width * 0.62))

    if data.solar_regions:
        flow.append(PageBreak())
        flow.append(Paragraph("Solar target regions", styles.h2))
        rows = []
        for row in data.solar_regions:
            rows.append([
                clean_text(row.get("SolarTargetId") or ""),
                clean_text(row.get("SolarTargetName") or ""),
                format_area(row.get("TotalArea")),
                format_area(row.get("CompliantArea")),
                format_percent(row.get("CompliantAreaPercent")),
                format_value(row.get("AverageSunHours"), "hours"),
                format_value(row.get("MinimumSunHoursReceived"), "hours"),
                format_value(row.get("MaximumSunHoursReceived"), "hours"),
                format_status(row.get("Status")),
                clean_text(row.get("Warnings") or ""),
            ])
        flow.extend(data_table(
            styles,
            ["Target", "Name", "Total area", "Compliant area", "Compliant %",
             "Average", "Minimum", "Maximum", "Status", "Warnings"],
            rows, widths=[7, 14, 9, 10, 8, 7, 7, 7, 16, 15],
            status_columns=(8,), align_right=(2, 3, 4, 5, 6, 7), font_size=6.9))

    flow.extend(figure(styles, figures.get("06_solar_heatmap"),
                       "Direct sun hours heatmap."))

    if data.solar.get("meshResultsIncluded"):
        flow.append(Spacer(1, 6))
        flow.append(para(styles,
                         "Detailed per-face solar mesh results (%s rows) are not "
                         "reproduced in this report. Refer to "
                         "csv/solar_mesh_results.csv in the source export package."
                         % format_count(data.solar.get("meshResultRowCount")),
                         styles.note))
    flow.append(PageBreak())
    return flow


STANDARD_LIMITATIONS = [
    "Design-stage geometry. Massing is indicative and not a construction model.",
    "External context may be incomplete; missing neighbouring buildings, trees "
    "and other obstructions affect overshadowing and separation outcomes.",
    "Planning controls require verification against the applicable authority.",
    "Parking geometry has not been dimensionally assessed; only quantities are "
    "checked.",
    "Solar results depend on the modelled context, model north, EPW file and "
    "analysis period selected.",
    "Results correspond only to the identified project option and revision.",
]


def section_warnings(styles, data):
    flow = [heading(styles, "13", "Warnings, assumptions and limitations")]

    rows = []
    for row in data.sorted_warnings():
        rows.append([
            clean_text(row.get("Severity") or ""),
            clean_text(row.get("Module") or ""),
            clean_text(row.get("Rule") or ""),
            clean_text(row.get("BuildingId") or ""),
            clean_text(row.get("Message") or ""),
            clean_text(row.get("RecommendedAction") or ""),
        ])
    flow.append(para(styles,
                     "Messages recorded by the Phase 1 to 6A engines, ordered "
                     "BLOCKING, ERROR, WARNING then INFO. Exact duplicates are "
                     "removed.", styles.note))
    flow.extend(data_table(
        styles, ["Severity", "Module", "Rule", "Building", "Message",
                 "Recommended action"],
        rows, widths=[9, 18, 11, 7, 33, 22], font_size=7.0))

    flow.append(Spacer(1, 8))
    flow.append(Paragraph("Standard limitations", styles.h2))
    flow.extend(bullets(styles, STANDARD_LIMITATIONS))
    flow.append(Spacer(1, 6))
    flow.append(para(styles, PLANNING_DISCLAIMER, styles.note))
    flow.append(PageBreak())
    return flow


def section_provenance(styles, data, report_timestamp, manifest_hash,
                       package_folder, generator_version, backend):
    flow = [heading(styles, "14", "Data provenance")]
    flow.append(para(styles,
                     "This report displays existing Phase 6A export values and "
                     "does not independently recalculate planning results."))
    metadata = data.metadata
    pairs = [
        ("Schema version", metadata.get("SchemaVersion")),
        ("Export package version", metadata.get("ExportPackageVersion")),
        ("Source definition phase", metadata.get("DefinitionPhase")),
        ("Report generator version", generator_version),
        ("Report backend", backend),
        ("Project ID", data.project_id),
        ("Option", data.option),
        ("Revision", data.revision),
        ("Export timestamp", metadata.get("ExportTimestamp")),
        ("Report timestamp", report_timestamp),
        ("Rhino file name", metadata.get("RhinoFileName")),
        ("Grasshopper file name", metadata.get("GrasshopperFileName")),
        ("Rhino version", metadata.get("RhinoVersion")),
        ("Grasshopper version", metadata.get("GrasshopperVersion")),
        ("Rhino model units", metadata.get("RhinoModelUnits")),
        ("Rhino absolute tolerance", metadata.get("RhinoAbsoluteTolerance")),
        ("Ladybug version", metadata.get("LadybugVersion")),
        ("Site SourceId", metadata.get("SiteSourceId")),
        ("Site Rhino GUID", metadata.get("SiteRhinoGuid")),
        ("Source export package", package_folder),
        ("Manifest SHA-256", manifest_hash),
    ]
    cleaned = []
    for label, value in pairs:
        cleaned.append((label, NOT_AVAILABLE if is_missing(value)
                        else clean_text(value)))
    flow.extend(key_value_table(styles, cleaned, label_width=0.34))
    flow.append(PageBreak())
    return flow


def section_appendix(styles, data, config, validation, consistency, chart_notes,
                     font_notes, figures_used, figures_missing):
    flow = [heading(styles, "15", "Appendix")]

    flow.append(Paragraph("A1. Source object audit summary", styles.h2))
    by_type = {}
    missing_source = 0
    duplicates = 0
    for row in data.source_objects:
        key = clean_text(row.get("ObjectType") or "Unclassified")
        entry = by_type.setdefault(key, {"count": 0, "missing": 0, "dupe": 0})
        entry["count"] += 1
        if not row.get("SourceId"):
            entry["missing"] += 1
            missing_source += 1
        if row.get("DuplicateSourceId"):
            entry["dupe"] += 1
            duplicates += 1
    audit_rows = []
    for key in sorted(by_type):
        entry = by_type[key]
        audit_rows.append([key, format_count(entry["count"]),
                           format_count(entry["missing"]),
                           format_count(entry["dupe"])])
    audit_rows.append(["TOTAL", format_count(len(data.source_objects)),
                       format_count(missing_source), format_count(duplicates)])
    flow.extend(data_table(
        styles, ["Object type", "Objects", "Without SourceId",
                 "Duplicate SourceId"],
        audit_rows, widths=[40, 20, 20, 20], align_right=(1, 2, 3),
        font_size=8.0))

    if missing_source:
        flow.append(Spacer(1, 4))
        flow.append(para(styles,
                         "%d object(s) carry no DZ.SourceId. They are reported "
                         "as Not available rather than being assigned an "
                         "identifier by this report." % missing_source,
                         styles.note))

    flow.append(Spacer(1, 8))
    flow.append(Paragraph("A2. Validation results", styles.h2))
    check_rows = [[clean_text(label), state, clean_text(detail)]
                  for label, state, detail in validation.checks]
    flow.extend(data_table(styles, ["Check", "Result", "Detail"], check_rows,
                           widths=[38, 12, 50], font_size=7.4))

    if validation.warnings:
        flow.append(Spacer(1, 6))
        flow.append(Paragraph("A3. Report warnings", styles.h2))
        flow.extend(bullets(styles, validation.warnings, styles.note))

    if consistency is not None:
        flow.append(Spacer(1, 6))
        flow.append(Paragraph("A4. Manifest to CSV cross-check", styles.h2))
        if consistency:
            flow.extend(bullets(styles, consistency, styles.note))
        else:
            flow.append(para(styles,
                             "All cross-checked values in project_summary.csv "
                             "and compliance_summary.csv match the manifest.",
                             styles.note))

    notes = list(chart_notes) + list(font_notes)
    if notes:
        flow.append(Spacer(1, 6))
        flow.append(Paragraph("A5. Rendering notes", styles.h2))
        flow.extend(bullets(styles, notes, styles.note))

    flow.append(Spacer(1, 6))
    flow.append(Paragraph("A6. Figures", styles.h2))
    if figures_used:
        flow.append(para(styles, "Optional figures included: %s."
                         % ", ".join(sorted(figures_used)), styles.note))
    else:
        flow.append(para(styles, "No optional figures were supplied.",
                         styles.note))
    if figures_missing:
        flow.append(para(styles, "Optional figures not supplied: %s."
                         % ", ".join(sorted(figures_missing)), styles.note))

    hashes = data.file_hashes
    if hashes:
        flow.append(Spacer(1, 6))
        flow.append(Paragraph("A7. Source package file hashes (SHA-256)",
                              styles.h2))
        hash_rows = [[clean_text(name), clean_text(hashes[name])]
                     for name in sorted(hashes)]
        flow.extend(data_table(styles, ["File", "SHA-256"], hash_rows,
                               widths=[30, 70], font_size=6.6))

    flow.append(Spacer(1, 6))
    flow.append(Paragraph("A8. Report configuration", styles.h2))
    config_rows = [[clean_text(key), clean_text(config.get(key))]
                   for key in sorted(config)]
    flow.extend(data_table(styles, ["Setting", "Value"], config_rows,
                           widths=[35, 65], font_size=7.0))

    if config.get("showSourceIds") or config.get("showObjectGuids"):
        flow.append(PageBreak())
        flow.append(Paragraph("A9. Building identifiers", styles.h2))
        id_rows = []
        for row in data.buildings:
            line = [clean_text(row.get("BuildingId") or ""),
                    clean_text(row.get("BuildingName") or "")]
            if config.get("showSourceIds"):
                line.append(clean_text(row.get("SourceId") or NOT_AVAILABLE))
            if config.get("showObjectGuids"):
                line.append(clean_text(row.get("RhinoObjectGuid") or NOT_AVAILABLE))
            id_rows.append(line)
        headers = ["Building", "Name"]
        widths = [12, 24]
        if config.get("showSourceIds"):
            headers.append("SourceId")
            widths.append(32)
        if config.get("showObjectGuids"):
            headers.append("Rhino object GUID")
            widths.append(32)
        flow.extend(data_table(styles, headers, id_rows, widths=widths,
                               font_size=7.0))

    if data.solar.get("meshResultsIncluded"):
        flow.append(Spacer(1, 6))
        flow.append(para(styles,
                         "Detailed solar mesh face results are available in "
                         "csv/solar_mesh_results.csv and are deliberately not "
                         "printed here.", styles.note))
    return flow
