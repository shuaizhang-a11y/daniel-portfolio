"""Read-only accessors over a Phase 6A manifest.

Nothing here computes a planning result. Every value is returned exactly as the
Phase 6A exporter wrote it, including nulls.
"""

STATUS_VOCAB = (
    "COMPLIES",
    "NON-COMPLIANT",
    "WARNING",
    "NOT EVALUATED",
    "INVALID INPUT",
)

STATUS_ORDER = {
    "COMPLIES": 0,
    "NON-COMPLIANT": 1,
    "WARNING": 2,
    "NOT EVALUATED": 3,
    "INVALID INPUT": 4,
}

SEVERITY_ORDER = {"BLOCKING": 0, "ERROR": 1, "WARNING": 2, "INFO": 3}

COMPLIANCE_RULE_ORDER = [
    "FSR", "MAX_HEIGHT", "SITE_COVERAGE", "FRONT_SETBACK", "REAR_SETBACK",
    "SIDE_SETBACK_1", "SIDE_SETBACK_2", "BUILDING_SEPARATION", "DEEP_SOIL",
    "COMMUNAL_OPEN_SPACE", "HEIGHT_PLANE", "PARKING_VEHICLE", "PARKING_VISITOR",
    "PARKING_ACCESSIBLE", "PARKING_BICYCLE", "PARKING_EV", "SOLAR_ACCESS",
]


class ReportData(object):
    """Thin view over the manifest with defensive accessors."""

    def __init__(self, manifest, manifest_path=None, package=None):
        self.manifest = manifest or {}
        self.manifest_path = manifest_path
        self.package = package

    # -- containers ------------------------------------------------------
    @property
    def metadata(self):
        return self.manifest.get("exportMetadata") or {}

    @property
    def project(self):
        return self.manifest.get("project") or {}

    @property
    def summary(self):
        return self.project.get("summary") or {}

    @property
    def units(self):
        return self.project.get("units") or {}

    @property
    def site(self):
        return self.manifest.get("site") or {}

    @property
    def controls(self):
        value = self.manifest.get("planningControls")
        return value if isinstance(value, dict) else {}

    @property
    def buildings(self):
        return self._list("buildings")

    @property
    def floors(self):
        return self._list("floors")

    @property
    def compliance(self):
        rows = self._list("compliance")
        return sorted(rows, key=lambda row: _rule_rank(row.get("RuleId")))

    @property
    def setbacks(self):
        return self._list("setbacks")

    @property
    def separation(self):
        return self._unique_pairs(self._list("buildingSeparation"))

    @property
    def open_space(self):
        value = self.manifest.get("openSpace")
        return value if isinstance(value, dict) else {}

    @property
    def open_space_regions(self):
        regions = self.open_space.get("regions")
        return regions if isinstance(regions, list) else []

    @property
    def height_planes(self):
        return self._list("heightPlanes")

    @property
    def parking(self):
        value = self.manifest.get("parking")
        return value if isinstance(value, dict) else {}

    @property
    def parking_demand(self):
        rows = self.parking.get("demand")
        return rows if isinstance(rows, list) else []

    @property
    def parking_supply(self):
        rows = self.parking.get("supply")
        return rows if isinstance(rows, list) else []

    @property
    def solar(self):
        value = self.manifest.get("solarAccess")
        return value if isinstance(value, dict) else {}

    @property
    def solar_config(self):
        value = self.solar.get("configuration")
        return value if isinstance(value, dict) else {}

    @property
    def solar_regions(self):
        rows = self.solar.get("regions")
        return rows if isinstance(rows, list) else []

    @property
    def source_objects(self):
        return self._list("sourceObjects")

    @property
    def file_hashes(self):
        value = self.manifest.get("fileHashes")
        return value if isinstance(value, dict) else {}

    def _list(self, key):
        value = self.manifest.get(key)
        return value if isinstance(value, list) else []

    # -- identity --------------------------------------------------------
    @property
    def project_name(self):
        return (self.project.get("projectName")
                or self.metadata.get("ProjectName") or "")

    @property
    def project_id(self):
        return (self.project.get("projectId")
                or self.metadata.get("ProjectId") or "")

    @property
    def option(self):
        return self.project.get("option") or self.metadata.get("Option") or ""

    @property
    def revision(self):
        return self.project.get("revision") or self.metadata.get("Revision") or ""

    @property
    def overall_status(self):
        return self.summary.get("OverallComplianceStatus")

    # -- derived views (presentation only) --------------------------------
    def status_counts(self):
        """Counts taken from the manifest summary, falling back to a tally.

        The tally is a presentation convenience only; it counts rows already
        classified by the Phase 1-5E engines and reclassifies nothing.
        """
        summary = self.summary
        keys = (("COMPLIES", "CompliantCount"),
                ("NON-COMPLIANT", "NonCompliantCount"),
                ("WARNING", "WarningCount"),
                ("NOT EVALUATED", "NotEvaluatedCount"),
                ("INVALID INPUT", "InvalidInputCount"))
        counts = {}
        complete = True
        for status, key in keys:
            value = summary.get(key)
            if value is None:
                complete = False
            counts[status] = value
        if complete:
            return counts, "manifest summary"
        tally = dict((status, 0) for status in STATUS_VOCAB)
        for row in self.compliance:
            status = row.get("Status")
            if status in tally:
                tally[status] += 1
        return tally, "compliance table tally"

    def compliance_by_rule(self, rule_id):
        for row in self.compliance:
            if row.get("RuleId") == rule_id:
                return row
        return {}

    def building_name_map(self):
        mapping = {}
        for row in self.buildings:
            mapping[row.get("BuildingId")] = row.get("BuildingName")
        return mapping

    def sorted_warnings(self):
        """De-duplicated warnings ordered BLOCKING, ERROR, WARNING, INFO."""
        seen = set()
        rows = []
        for row in self._list("warnings"):
            key = (row.get("Severity"), row.get("Module"), row.get("Rule"),
                   row.get("BuildingId"), row.get("ObjectGuid"), row.get("Message"))
            if key in seen:
                continue
            seen.add(key)
            rows.append(row)
        rows.sort(key=lambda item: (
            SEVERITY_ORDER.get(item.get("Severity"), 9),
            str(item.get("Module") or ""),
            str(item.get("Message") or "")))
        return rows

    @staticmethod
    def _unique_pairs(rows):
        """Drop a B-A duplicate when A-B is already present."""
        seen = set()
        output = []
        for row in rows:
            a = row.get("BuildingAId")
            b = row.get("BuildingBId")
            key = tuple(sorted([str(a), str(b)]))
            if key in seen:
                continue
            seen.add(key)
            output.append(row)
        return output


def _rule_rank(rule_id):
    try:
        return COMPLIANCE_RULE_ORDER.index(rule_id)
    except ValueError:
        return len(COMPLIANCE_RULE_ORDER) + 1
