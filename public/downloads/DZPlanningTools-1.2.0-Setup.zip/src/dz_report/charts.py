"""Data-driven charts rendered from manifest values only.

Every chart uses values exactly as exported. Nulls are skipped rather than
plotted as zero, all value axes start at zero so no scale is misleading, and
each bar carries a printed value so the chart stays readable in black and white.
"""

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402

from .formatting import clean_text, is_missing  # noqa: E402
from .models import STATUS_VOCAB  # noqa: E402

# Restrained, consistent palette. Lightness is deliberately varied so the bars
# remain distinguishable when printed in greyscale.
INK = "#2F4F5F"
PALETTE = {
    "primary": "#4A7A96",
    "secondary": "#A8C4D4",
    "required": "#8C8C8C",
    "actual": "#4A7A96",
    "grid": "#D8D8D8",
}
STATUS_COLOURS = {
    "COMPLIES": "#6E9E77",
    "NON-COMPLIANT": "#B06A6A",
    "WARNING": "#C6A85C",
    "NOT EVALUATED": "#9A9A9A",
    "INVALID INPUT": "#7E7E9A",
}

FIGURE_DPI = 200
UNICODE_CHART_FONTS = [
    r"C:\Windows\Fonts\ARIALUNI.TTF",
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simsun.ttc",
]


def configure_fonts(require_unicode):
    """Point matplotlib at a local Unicode font when labels need one."""
    notes = []
    if not require_unicode:
        return notes
    for path in UNICODE_CHART_FONTS:
        if not os.path.isfile(path):
            continue
        try:
            font_manager.fontManager.addfont(path)
            name = font_manager.FontProperties(fname=path).get_name()
            plt.rcParams["font.family"] = name
            plt.rcParams["axes.unicode_minus"] = False
            notes.append("Charts use local font %s." % os.path.basename(path))
            return notes
        except Exception as exc:
            notes.append("Chart font %s unusable (%s)." % (path, exc))
    notes.append("WARNING: no Unicode font available for charts; some chart "
                 "labels may not render.")
    return notes


def _style(ax, title, ylabel):
    ax.set_title(clean_text(title), fontsize=11, color=INK, pad=10)
    if ylabel:
        ax.set_ylabel(clean_text(ylabel), fontsize=9, color=INK)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(PALETTE["grid"])
    ax.spines["bottom"].set_color(PALETTE["grid"])
    ax.tick_params(labelsize=8, colors=INK)
    ax.yaxis.grid(True, color=PALETTE["grid"], linewidth=0.6)
    ax.set_axisbelow(True)
    ax.set_ylim(bottom=0)


def _annotate(ax, bars, values, fmt="{:,.1f}"):
    for bar, value in zip(bars, values):
        if value is None:
            continue
        ax.annotate(fmt.format(value),
                    xy=(bar.get_x() + bar.get_width() / 2.0, bar.get_height()),
                    xytext=(0, 3), textcoords="offset points",
                    ha="center", va="bottom", fontsize=7.5, color=INK)


def _save(fig, folder, name):
    if not os.path.isdir(folder):
        os.makedirs(folder)
    path = os.path.join(folder, name)
    fig.savefig(path, dpi=FIGURE_DPI, bbox_inches="tight",
                facecolor="white", edgecolor="none")
    plt.close(fig)
    return path


def _numeric(value):
    if is_missing(value) or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if number != number or number in (float("inf"), float("-inf")):
        return None
    return number


def chart_compliance_status(data, folder):
    counts, _source = data.status_counts()
    labels = [s for s in STATUS_VOCAB]
    values = [_numeric(counts.get(s)) or 0 for s in labels]
    if sum(values) == 0:
        return None
    short = [l.replace(" ", "\n") for l in labels]
    fig, ax = plt.subplots(figsize=(6.4, 2.9))
    bars = ax.bar(short, values,
                  color=[STATUS_COLOURS[l] for l in labels],
                  edgecolor="white", linewidth=0.8, width=0.62)
    _annotate(ax, bars, values, "{:,.0f}")
    _style(ax, "Compliance status distribution", "Rules (count)")
    top = max(values)
    ax.set_ylim(0, top * 1.25 if top else 1)
    ax.set_yticks(range(0, int(top) + 2, max(1, int(top // 5) or 1)))
    return _save(fig, folder, "chart_compliance_status.png")


def chart_gfa_by_building(data, folder):
    rows = [r for r in data.buildings if _numeric(r.get("PhysicalGFA")) is not None]
    if not rows:
        return None
    labels = []
    for row in rows:
        bid = clean_text(row.get("BuildingId") or "")
        name = clean_text(row.get("BuildingName") or "")
        labels.append("%s\n%s" % (bid, name) if name else bid)
    physical = [_numeric(r.get("PhysicalGFA")) for r in rows]
    included = [_numeric(r.get("FSRIncludedGFA")) for r in rows]
    has_included = any(v is not None for v in included)

    width = max(5.4, min(9.0, 1.7 * len(rows) + 2.0))
    fig, ax = plt.subplots(figsize=(width, 3.1))
    if has_included:
        offset = 0.2
        bars_a = ax.bar([i - offset for i in range(len(rows))], physical,
                        width=0.38, label="Physical GFA",
                        color=PALETTE["primary"], edgecolor="white", linewidth=0.8)
        bars_b = ax.bar([i + offset for i in range(len(rows))],
                        [v if v is not None else 0 for v in included],
                        width=0.38, label="FSR included GFA",
                        color=PALETTE["secondary"], edgecolor="white", linewidth=0.8)
        _annotate(ax, bars_a, physical, "{:,.0f}")
        _annotate(ax, bars_b, included, "{:,.0f}")
        ax.legend(fontsize=8, frameon=False, loc="upper right")
    else:
        bars = ax.bar(range(len(rows)), physical, width=0.5,
                      color=PALETTE["primary"], edgecolor="white", linewidth=0.8)
        _annotate(ax, bars, physical, "{:,.0f}")
    ax.set_xticks(range(len(rows)))
    ax.set_xticklabels(labels, fontsize=8)
    _style(ax, "Gross floor area by building", "GFA (m2)")
    top = max([v for v in physical if v is not None] or [1])
    # Extra headroom when a legend is drawn inside the axes.
    ax.set_ylim(0, top * (1.45 if has_included else 1.22))
    return _save(fig, folder, "chart_gfa_by_building.png")


def _paired_chart(folder, name, title, ylabel, categories, required, actual,
                  fmt="{:,.0f}"):
    pairs = [(c, r, a) for c, r, a in zip(categories, required, actual)
             if r is not None or a is not None]
    if not pairs:
        return None
    categories = [p[0] for p in pairs]
    required = [p[1] for p in pairs]
    actual = [p[2] for p in pairs]

    width = max(4.6, min(9.0, 1.5 * len(categories) + 2.0))
    fig, ax = plt.subplots(figsize=(width, 3.0))
    positions = range(len(categories))
    bars_r = ax.bar([p - 0.19 for p in positions],
                    [v if v is not None else 0 for v in required],
                    width=0.36, label="Required", color=PALETTE["required"],
                    edgecolor="white", linewidth=0.8)
    bars_a = ax.bar([p + 0.19 for p in positions],
                    [v if v is not None else 0 for v in actual],
                    width=0.36, label="Actual", color=PALETTE["actual"],
                    edgecolor="white", linewidth=0.8)
    _annotate(ax, bars_r, required, fmt)
    _annotate(ax, bars_a, actual, fmt)
    ax.set_xticks(list(positions))
    ax.set_xticklabels([clean_text(c) for c in categories], fontsize=8)
    ax.legend(fontsize=8, frameon=False)
    _style(ax, title, ylabel)
    top = max([v for v in (required + actual) if v is not None] or [1])
    ax.set_ylim(0, top * 1.25 if top else 1)
    return _save(fig, folder, name)


PARKING_CHART_RULES = (
    ("PARKING_VEHICLE", "Vehicle"),
    ("PARKING_VISITOR", "Visitor"),
    ("PARKING_ACCESSIBLE", "Accessible"),
    ("PARKING_BICYCLE", "Bicycle"),
    ("PARKING_EV", "EV-ready"),
)


def chart_parking(data, folder):
    categories, required, actual = [], [], []
    for rule_id, label in PARKING_CHART_RULES:
        row = data.compliance_by_rule(rule_id)
        if not row:
            continue
        categories.append(label)
        required.append(_numeric(row.get("TargetValue")))
        actual.append(_numeric(row.get("ActualValue")))
    return _paired_chart(folder, "chart_parking.png",
                         "Parking: required versus actual", "Spaces (count)",
                         categories, required, actual, "{:,.0f}")


def chart_solar(data, folder):
    row = data.compliance_by_rule("SOLAR_ACCESS")
    required = _numeric(row.get("TargetValue"))
    actual = _numeric(row.get("ActualValue"))
    if required is None and actual is None:
        return None
    return _paired_chart(folder, "chart_solar.png",
                         "Direct solar access: compliant area percentage",
                         "Compliant area (%)", ["Solar access"],
                         [required], [actual], "{:,.1f}")


def chart_deep_soil(data, folder):
    row = data.compliance_by_rule("DEEP_SOIL")
    return _paired_chart(folder, "chart_deep_soil.png",
                         "Deep soil: required versus actual",
                         "Site area (%)", ["Deep soil"],
                         [_numeric(row.get("TargetValue"))],
                         [_numeric(row.get("ActualValue"))], "{:,.1f}")


def chart_communal_open_space(data, folder):
    row = data.compliance_by_rule("COMMUNAL_OPEN_SPACE")
    return _paired_chart(folder, "chart_communal_open_space.png",
                         "Communal open space: required versus actual",
                         "Site area (%)", ["Communal open space"],
                         [_numeric(row.get("TargetValue"))],
                         [_numeric(row.get("ActualValue"))], "{:,.1f}")


CHART_BUILDERS = (
    ("compliance_status", chart_compliance_status),
    ("gfa_by_building", chart_gfa_by_building),
    ("parking", chart_parking),
    ("solar", chart_solar),
    ("deep_soil", chart_deep_soil),
    ("communal_open_space", chart_communal_open_space),
)


def build_all(data, folder):
    """Render every chart. A failing chart never stops the report."""
    charts = {}
    notes = []
    for key, builder in CHART_BUILDERS:
        try:
            path = builder(data, folder)
        except Exception as exc:
            notes.append("Chart '%s' could not be generated (%s: %s)."
                         % (key, type(exc).__name__, exc))
            continue
        if path:
            charts[key] = path
        else:
            notes.append("Chart '%s' skipped: no usable values in the manifest."
                         % key)
    return charts, notes
