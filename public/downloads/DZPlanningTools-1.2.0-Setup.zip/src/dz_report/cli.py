"""Command-line entry point for the Phase 6B planning report generator.

Example
-------
python -m dz_report.cli ^
  --manifest "path\\to\\project_manifest.json" ^
  --output   "path\\to\\Planning_Report.pdf" ^
  --config   "path\\to\\report_config.json"
"""

import argparse
import datetime
import json
import os
import sys

from . import __version__
from .formatting import manifest_has_non_ascii
from .loader import (ManifestInvalid, ManifestNotFound, calculate_sha256,
                     load_config, load_csv, load_manifest, package_folder)
from .models import ReportData
from .pdf_generator import (GENERATED_FOLDER, discover_figures, generate_html,
                            generate_pdf, reportlab_available,
                            resolve_output_path)
from .validation import cross_check_csv, validate_manifest

DEFAULT_EXPORTS_ROOT = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "Exports")

STATUS_OK = "REPORT GENERATED"
STATUS_WARN = "REPORT GENERATED WITH WARNINGS"
STATUS_BLOCKED = "BLOCKED"
STATUS_FAILED = "FAILED"
STATUS_INTERIM = "HTML PREVIEW ONLY - PDF NOT GENERATED"


def build_parser():
    parser = argparse.ArgumentParser(
        prog="dz_report.cli",
        description="Generate a Phase 6B planning feasibility report from an "
                    "existing Phase 6A export package.")
    parser.add_argument("--manifest",
                        help="Path to project_manifest.json. When omitted the "
                             "newest package under --exports-root is selected "
                             "by its manifest exportTimestamp.")
    parser.add_argument("--exports-root", default=DEFAULT_EXPORTS_ROOT,
                        help="Folder searched for export packages.")
    parser.add_argument("--output", help="Explicit output file path.")
    parser.add_argument("--output-folder",
                        help="Folder for the report. Defaults to the export "
                             "package folder.")
    parser.add_argument("--config", help="Report configuration JSON.")
    parser.add_argument("--overwrite", action="store_true",
                        help="Replace an existing report of the same name.")
    parser.add_argument("--timestamped", action="store_true",
                        help="When the target exists, write a timestamped "
                             "version instead of failing.")
    parser.add_argument("--render-pages", action="store_true",
                        help="Render every PDF page to PNG for verification.")
    parser.add_argument("--render-dpi", type=int, default=170)
    parser.add_argument("--no-charts", action="store_true",
                        help="Skip generated charts.")
    parser.add_argument("--json-result", help="Write the result summary as JSON.")
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--version", action="version",
                        version="dz_report %s" % __version__)
    return parser


def _result_skeleton():
    return {
        "status": STATUS_BLOCKED,
        "manifestPath": None,
        "packageFolder": None,
        "manifestSha256": None,
        "reportPath": None,
        "backend": None,
        "pageCount": None,
        "fileSize": None,
        "reportSha256": None,
        "renderedPages": [],
        "figuresIncluded": [],
        "figuresMissing": [],
        "charts": [],
        "chartNotes": [],
        "fontNotes": [],
        "blocking": [],
        "warnings": [],
        "checks": [],
        "consistency": None,
        "textChecks": {},
        "counts": {},
    }


def verify_pdf(path, expect_tokens, render_pages=False, dpi=170):
    """Open the PDF, count pages, extract text and optionally render pages."""
    info = {"opens": False, "pageCount": None, "textChecks": {},
            "renderedPages": [], "notes": []}

    text = ""
    try:
        import fitz
        document = fitz.open(path)
        info["opens"] = True
        info["pageCount"] = document.page_count
        chunks = []
        for index in range(document.page_count):
            chunks.append(document.load_page(index).get_text("text"))
        text = "\n".join(chunks)
        if render_pages:
            folder = os.path.join(os.path.dirname(path), "report_assets",
                                  "rendered")
            if not os.path.isdir(folder):
                os.makedirs(folder)
            zoom = dpi / 72.0
            matrix = fitz.Matrix(zoom, zoom)
            for index in range(document.page_count):
                pixmap = document.load_page(index).get_pixmap(matrix=matrix)
                out = os.path.join(folder, "page_%03d.png" % (index + 1))
                pixmap.save(out)
                info["renderedPages"].append(out)
        document.close()
    except ImportError:
        info["notes"].append("PyMuPDF not available; falling back to pypdf.")
        try:
            from pypdf import PdfReader
            reader = PdfReader(path)
            info["opens"] = True
            info["pageCount"] = len(reader.pages)
            text = "\n".join((page.extract_text() or "")
                             for page in reader.pages)
        except Exception as exc:
            info["notes"].append("PDF could not be opened: %s" % exc)
    except Exception as exc:
        info["notes"].append("PDF verification error: %s" % exc)

    flat = " ".join(text.split())
    for label, token in expect_tokens.items():
        if not token:
            info["textChecks"][label] = "SKIPPED (no value)"
            continue
        info["textChecks"][label] = "FOUND" if str(token) in flat else "MISSING"
    info["_text"] = flat
    return info


def run(args):
    result = _result_skeleton()
    report_timestamp = datetime.datetime.now().replace(microsecond=0).isoformat()

    # -- configuration ---------------------------------------------------
    try:
        config, config_path = load_config(args.config)
    except ManifestInvalid as exc:
        result["blocking"].append(str(exc))
        result["status"] = STATUS_BLOCKED
        return result
    result["configPath"] = config_path

    # -- manifest --------------------------------------------------------
    try:
        manifest_path, manifest, selection = load_manifest(
            args.manifest, args.exports_root)
    except ManifestNotFound as exc:
        result["blocking"].append(str(exc))
        result["searched"] = exc.searched
        result["status"] = STATUS_BLOCKED
        return result
    except ManifestInvalid as exc:
        result["blocking"].append(str(exc))
        result["status"] = STATUS_BLOCKED
        return result
    except ValueError as exc:
        result["blocking"].append("Manifest is not valid JSON: %s" % exc)
        result["status"] = STATUS_BLOCKED
        return result

    package = package_folder(manifest_path)
    result["manifestPath"] = manifest_path
    result["packageFolder"] = package
    result["packageSelection"] = selection
    result["manifestSha256"] = calculate_sha256(manifest_path)

    # -- validation ------------------------------------------------------
    validation = validate_manifest(manifest)
    result["blocking"] = list(validation.blocking)
    result["warnings"] = list(validation.warnings)
    result["checks"] = list(validation.checks)
    if not validation.ok:
        result["status"] = STATUS_BLOCKED
        return result

    data = ReportData(manifest, manifest_path, package)
    result["counts"] = {
        "buildings": len(data.buildings),
        "floors": len(data.floors),
        "compliance": len(data.compliance),
        "setbacks": len(data.setbacks),
        "separation": len(data.separation),
        "openSpaceRegions": len(data.open_space_regions),
        "heightPlanes": len(data.height_planes),
        "parkingDemand": len(data.parking_demand),
        "parkingSupply": len(data.parking_supply),
        "solarRegions": len(data.solar_regions),
        "sourceObjects": len(data.source_objects),
        "warnings": len(data.sorted_warnings()),
    }

    # -- CSV cross-check -------------------------------------------------
    consistency = cross_check_csv(data,
                                  load_csv(package, "project_summary.csv"),
                                  load_csv(package, "compliance_summary.csv"))
    result["consistency"] = consistency
    if consistency:
        result["warnings"].extend(consistency)
        validation.warnings.extend(consistency)

    # -- charts ----------------------------------------------------------
    charts, chart_notes = {}, []
    if not args.no_charts:
        try:
            from . import charts as charts_module
            chart_notes.extend(charts_module.configure_fonts(
                manifest_has_non_ascii(manifest)))
            charts, notes = charts_module.build_all(
                data, os.path.join(package, GENERATED_FOLDER))
            chart_notes.extend(notes)
        except Exception as exc:
            chart_notes.append("Charts unavailable (%s: %s)."
                               % (type(exc).__name__, exc))
    result["charts"] = sorted(charts.keys())
    result["chartNotes"] = chart_notes

    # -- figures ---------------------------------------------------------
    figures, missing = discover_figures(package, config.get("figureFolder"))
    if not config.get("includeOptionalFigures", True):
        figures = {}
    result["figuresIncluded"] = sorted(figures.keys())
    result["figuresMissing"] = missing

    # -- output path -----------------------------------------------------
    has_reportlab, reportlab_version = reportlab_available()
    explicit = args.output
    if explicit and not has_reportlab and explicit.lower().endswith(".pdf"):
        # No ReportLab: the interim output is HTML, so never claim a .pdf name.
        explicit = os.path.splitext(explicit)[0] + ".html"
    try:
        output_path = resolve_output_path(
            package, data, explicit, args.output_folder,
            overwrite=args.overwrite, timestamped=args.timestamped)
        if not explicit and not has_reportlab:
            output_path = resolve_output_path(
                package, data, os.path.splitext(output_path)[0] + ".html",
                None, overwrite=args.overwrite, timestamped=args.timestamped)
    except FileExistsError as exc:
        result["blocking"].append(str(exc))
        result["status"] = STATUS_BLOCKED
        return result

    folder = os.path.dirname(output_path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)

    # -- generate --------------------------------------------------------
    if not has_reportlab:
        result["backend"] = "HTML (interim)"
        result["warnings"].append(
            "MISSING DEPENDENCY: ReportLab is not installed in this Python "
            "environment, so no PDF was produced. An interim HTML preview was "
            "written instead. PDF generation did not succeed.")
        try:
            generate_html(data, config, output_path, charts, validation,
                          report_timestamp, result["manifestSha256"], package)
        except Exception as exc:
            result["blocking"].append("HTML preview failed: %s: %s"
                                      % (type(exc).__name__, exc))
            result["status"] = STATUS_FAILED
            return result
        result["reportPath"] = output_path
        result["fileSize"] = os.path.getsize(output_path)
        result["reportSha256"] = calculate_sha256(output_path)
        result["status"] = STATUS_INTERIM
        return result

    result["backend"] = "ReportLab Platypus %s" % reportlab_version
    try:
        font_notes = generate_pdf(
            data, config, output_path, figures, charts, validation,
            consistency, chart_notes, result["manifestSha256"], package,
            report_timestamp)
    except Exception as exc:
        import traceback
        result["blocking"].append("PDF generation failed: %s: %s"
                                  % (type(exc).__name__, exc))
        result["traceback"] = traceback.format_exc()
        result["status"] = STATUS_FAILED
        return result

    result["fontNotes"] = font_notes
    result["reportPath"] = output_path

    # -- quality assurance -----------------------------------------------
    if not os.path.isfile(output_path):
        result["blocking"].append("PDF was not written to %s" % output_path)
        result["status"] = STATUS_FAILED
        return result
    size = os.path.getsize(output_path)
    result["fileSize"] = size
    if size <= 0:
        result["blocking"].append("PDF is zero bytes.")
        result["status"] = STATUS_FAILED
        return result

    info = verify_pdf(output_path, {
        "projectName": data.project_name,
        "projectId": data.project_id,
        "option": data.option,
        "revision": data.revision,
        "overallStatus": data.overall_status,
    }, render_pages=args.render_pages, dpi=args.render_dpi)

    result["pageCount"] = info["pageCount"]
    result["textChecks"] = info["textChecks"]
    result["renderedPages"] = info["renderedPages"]
    if info["notes"]:
        result["warnings"].extend(info["notes"])
    if not info["opens"]:
        result["blocking"].append("The generated PDF could not be opened.")
        result["status"] = STATUS_FAILED
        return result

    missing_tokens = [k for k, v in info["textChecks"].items() if v == "MISSING"]
    if missing_tokens:
        result["warnings"].append(
            "PDF text did not contain: %s" % ", ".join(missing_tokens))

    result["reportSha256"] = calculate_sha256(output_path)
    result["status"] = STATUS_WARN if result["warnings"] else STATUS_OK
    return result


def format_result(result):
    lines = []
    lines.append("Status              : %s" % result["status"])
    lines.append("Manifest            : %s" % result["manifestPath"])
    lines.append("Package             : %s" % result["packageFolder"])
    lines.append("Backend             : %s" % result["backend"])
    lines.append("Report              : %s" % result["reportPath"])
    lines.append("Pages               : %s" % result["pageCount"])
    lines.append("Size (bytes)        : %s" % result["fileSize"])
    lines.append("Report SHA-256      : %s" % result["reportSha256"])
    lines.append("Manifest SHA-256    : %s" % result["manifestSha256"])
    if result["counts"]:
        lines.append("Counts              : %s"
                     % ", ".join("%s=%s" % (k, v)
                                 for k, v in sorted(result["counts"].items())))
    if result["textChecks"]:
        lines.append("PDF text checks     : %s"
                     % ", ".join("%s=%s" % (k, v)
                                 for k, v in sorted(result["textChecks"].items())))
    lines.append("Figures included    : %s"
                 % (", ".join(result["figuresIncluded"]) or "none"))
    lines.append("Figures missing     : %s"
                 % (", ".join(result["figuresMissing"]) or "none"))
    lines.append("Charts              : %s"
                 % (", ".join(result["charts"]) or "none"))
    if result["renderedPages"]:
        lines.append("Rendered pages      : %d" % len(result["renderedPages"]))
    if result["consistency"] is not None:
        lines.append("CSV cross-check     : %s"
                     % ("%d difference(s)" % len(result["consistency"])
                        if result["consistency"] else "all values match"))
    for note in result["chartNotes"] + result["fontNotes"]:
        lines.append("  note   : %s" % note)
    for warning in result["warnings"]:
        lines.append("  WARNING: %s" % warning)
    for block in result["blocking"]:
        lines.append("  BLOCKED: %s" % block)
    if result.get("searched"):
        lines.append("  searched:")
        for item in result["searched"]:
            lines.append("     %s" % item)
    return "\n".join(lines)


def main(argv=None):
    args = build_parser().parse_args(argv)
    result = run(args)
    if args.json_result:
        with open(args.json_result, "w", encoding="utf-8") as handle:
            json.dump(result, handle, ensure_ascii=False, indent=2)
    if not args.quiet:
        print(format_result(result))
    if result["status"] in (STATUS_OK, STATUS_WARN):
        return 0
    if result["status"] == STATUS_INTERIM:
        return 2
    return 1


if __name__ == "__main__":
    sys.exit(main())
