"""Value formatting, status presentation and font selection.

Formatting rules that matter:

* ``None`` renders as "Not available" - never as zero.
* A genuine ``0`` renders as ``0`` / ``0.00``.
* Percentages arrive from Phase 6A already scaled 0-100 and are never
  re-multiplied.
* Unicode dashes are replaced with ASCII hyphens for display only; the source
  package is never modified and non-Latin scripts are preserved untouched.
"""

import os
import unicodedata

NOT_AVAILABLE = "Not available"

# Display-only dash normalisation. Deliberately narrow: only dash-like
# punctuation is touched, so CJK, Arabic and accented text pass through intact.
DASH_REPLACEMENTS = {
    u"\u2010": "-", u"\u2011": "-", u"\u2012": "-", u"\u2013": "-",
    u"\u2014": " - ", u"\u2015": " - ", u"\u2212": "-", u"\uFE58": "-",
    u"\uFE63": "-", u"\uFF0D": "-",
}
QUOTE_REPLACEMENTS = {
    u"\u2018": "'", u"\u2019": "'", u"\u201C": '"', u"\u201D": '"',
    u"\u2026": "...", u"\u00A0": " ",
}

STATUS_SYMBOLS = {
    "COMPLIES": "[+]",
    "NON-COMPLIANT": "[X]",
    "WARNING": "[!]",
    "NOT EVALUATED": "[-]",
    "INVALID INPUT": "[?]",
}

# Greys chosen so every status stays legible when printed in black and white.
STATUS_FILL = {
    "COMPLIES": "#E8EFE9",
    "NON-COMPLIANT": "#F0E2E2",
    "WARNING": "#F4EEDD",
    "NOT EVALUATED": "#ECECEC",
    "INVALID INPUT": "#E4E4EC",
}

PERCENT_UNITS = {"%", "percent", "percentage"}
INTEGER_UNITS = {"count", "spaces"}


def clean_text(value):
    """Normalise punctuation for PDF display without altering real content."""
    if value is None:
        return ""
    text = value if isinstance(value, str) else str(value)
    for source, target in DASH_REPLACEMENTS.items():
        text = text.replace(source, target)
    for source, target in QUOTE_REPLACEMENTS.items():
        text = text.replace(source, target)
    # Strip control characters that would render as black squares.
    text = "".join(ch for ch in text
                   if ch in ("\n", "\t") or unicodedata.category(ch)[0] != "C")
    return text.strip()


def has_non_ascii(value):
    try:
        clean_text(value).encode("ascii")
    except UnicodeEncodeError:
        return True
    return False


def manifest_has_non_ascii(manifest):
    """True when any string anywhere in the manifest needs a Unicode font."""
    stack = [manifest]
    while stack:
        node = stack.pop()
        if isinstance(node, dict):
            stack.extend(node.keys())
            stack.extend(node.values())
        elif isinstance(node, (list, tuple)):
            stack.extend(node)
        elif isinstance(node, str):
            if has_non_ascii(node):
                return True
    return False


def is_missing(value):
    return value is None or (isinstance(value, str) and not value.strip())


def format_number(value, decimals=2, thousands=True):
    """Format a number, preserving genuine zeros and reporting nulls."""
    if is_missing(value):
        return NOT_AVAILABLE
    if isinstance(value, bool):
        return "Yes" if value else "No"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return clean_text(value)
    if number != number or number in (float("inf"), float("-inf")):
        return NOT_AVAILABLE
    pattern = "{:,.%df}" % decimals if thousands else "{:.%df}" % decimals
    return pattern.format(number)


def format_value(value, unit=None, decimals=None):
    """Format a value with unit-aware precision. Nulls become Not available."""
    if is_missing(value):
        return NOT_AVAILABLE
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if isinstance(value, str):
        return clean_text(value)

    unit_key = (unit or "").strip()
    if decimals is None:
        if unit_key in PERCENT_UNITS:
            decimals = 1
        elif unit_key in INTEGER_UNITS:
            decimals = 0
        elif unit_key == "ratio":
            decimals = 2
        else:
            decimals = 2
    text = format_number(value, decimals)
    if text == NOT_AVAILABLE:
        return text
    # "count" is a bare quantity; appending the word reads as noise ("3 count").
    if unit_key and unit_key not in ("text", "boolean", "path", "count"):
        if unit_key in PERCENT_UNITS:
            return text + " %"
        return "%s %s" % (text, unit_key)
    return text


def format_plain(value, unit=None, decimals=None):
    """Unit-aware precision, but no unit suffix.

    For tables that already carry a dedicated Unit column, so the unit is not
    printed twice.
    """
    text = format_value(value, unit, decimals)
    if text == NOT_AVAILABLE:
        return text
    unit_key = (unit or "").strip()
    if unit_key in PERCENT_UNITS:
        return text[:-2].rstrip() if text.endswith(" %") else text
    suffix = " " + unit_key
    if unit_key and text.endswith(suffix):
        return text[:-len(suffix)]
    return text


def format_area(value):
    return format_value(value, "m2")


def format_percent(value):
    return format_value(value, "%")


def format_count(value):
    return format_value(value, "count")


def format_bool(value):
    if value is None:
        return NOT_AVAILABLE
    if isinstance(value, str):
        token = value.strip().upper()
        if token in ("TRUE", "YES"):
            return "Yes"
        if token in ("FALSE", "NO"):
            return "No"
        if not token:
            return NOT_AVAILABLE
        return clean_text(value)
    return "Yes" if value else "No"


def format_status(status):
    """Status text plus an ASCII symbol so colour is never load-bearing."""
    if is_missing(status):
        return NOT_AVAILABLE
    text = clean_text(status).upper()
    symbol = STATUS_SYMBOLS.get(text)
    if symbol is None:
        return text
    return "%s %s" % (symbol, text)


def status_fill(status):
    if is_missing(status):
        return None
    return STATUS_FILL.get(clean_text(status).upper())


def join_ids(value, limit=None):
    if is_missing(value):
        return ""
    if isinstance(value, (list, tuple)):
        items = [str(item) for item in value if item is not None]
    else:
        items = [item.strip() for item in str(value).split(";") if item.strip()]
    if limit and len(items) > limit:
        return "; ".join(items[:limit]) + " (+%d more)" % (len(items) - limit)
    return "; ".join(items)


def short_id(value, length=8):
    if is_missing(value):
        return ""
    text = str(value)
    return text if len(text) <= length else text[:length] + "..."


# ---------------------------------------------------------------------------
# fonts
# ---------------------------------------------------------------------------

# Locally installed Windows fonts only. Nothing is downloaded or bundled.
UNICODE_FONT_CANDIDATES = [
    ("ArialUnicode", r"C:\Windows\Fonts\ARIALUNI.TTF", None),
    ("MSYaHei", r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\msyhbd.ttc"),
    ("SimSun", r"C:\Windows\Fonts\simsun.ttc", None),
    ("DejaVuSans", r"C:\Windows\Fonts\DejaVuSans.ttf",
     r"C:\Windows\Fonts\DejaVuSans-Bold.ttf"),
]


def register_fonts(require_unicode):
    """Choose the body font family.

    Returns ``(regular, bold, notes)``. Falls back to Helvetica when the report
    contains no non-ASCII text, and warns loudly when Unicode text is present
    but no capable local font could be registered.
    """
    notes = []
    if not require_unicode:
        return "Helvetica", "Helvetica-Bold", notes

    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    for name, regular_path, bold_path in UNICODE_FONT_CANDIDATES:
        if not os.path.isfile(regular_path):
            continue
        try:
            pdfmetrics.registerFont(TTFont(name, regular_path))
        except Exception as exc:
            notes.append("Local font %s could not be registered (%s)."
                         % (regular_path, exc))
            continue
        bold_name = name
        if bold_path and os.path.isfile(bold_path):
            try:
                pdfmetrics.registerFont(TTFont(name + "-Bold", bold_path))
                bold_name = name + "-Bold"
            except Exception:
                bold_name = name
        notes.append("Unicode text detected; using local system font %s."
                     % os.path.basename(regular_path))
        return name, bold_name, notes

    # Last resort: ReportLab's built-in CJK CID font. Covers Chinese text but
    # not every script, so the limitation is reported rather than hidden.
    try:
        from reportlab.pdfbase.cidfonts import UnicodeCIDFont
        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
        notes.append(
            "WARNING: no local Unicode TrueType font was found. Falling back to "
            "the built-in STSong-Light CID font. Chinese text will render, but "
            "other non-Latin scripts may not.")
        return "STSong-Light", "STSong-Light", notes
    except Exception as exc:
        notes.append(
            "WARNING: non-English text is present but no Unicode-capable font "
            "could be registered (%s). Some characters may not render." % exc)
    return "Helvetica", "Helvetica-Bold", notes
