"""Locate and load a Phase 6A export package.

Package selection uses the ``exportTimestamp`` recorded inside each manifest,
not the filesystem modification time.
"""

import csv
import datetime
import hashlib
import io
import json
import os

MANIFEST_NAME = "project_manifest.json"

REQUIRED_TOP_LEVEL = (
    "schemaVersion", "exportMetadata", "project", "site", "planningControls",
    "buildings", "floors", "compliance", "setbacks", "buildingSeparation",
    "openSpace", "heightPlanes", "parking", "solarAccess", "sourceObjects",
    "warnings",
)


class ManifestNotFound(Exception):
    """Raised when no usable Phase 6A manifest can be located."""

    def __init__(self, message, searched=None):
        Exception.__init__(self, message)
        self.searched = list(searched or [])


from dz_revit_publisher.datetime_compat import parse_iso_datetime


class ManifestInvalid(Exception):
    """Raised when a manifest exists but cannot be used as a report source."""


def parse_timestamp(text, field="exportMetadata.ExportTimestamp"):
    """Parse an ISO 8601 timestamp; return None when it cannot be read.

    The project has one parser, in `dz_revit_publisher.datetime_compat`. This
    package would otherwise be independent of that one, but a duplicated
    date parser is the worse trade: this is the module that has already
    drifted once.
    """
    return parse_iso_datetime(text, field, default=None)


def find_manifests(root):
    """Every project_manifest.json under `root`, deepest-first is not implied."""
    found = []
    if not os.path.isdir(root):
        return found
    for dirpath, _dirnames, filenames in os.walk(root):
        if MANIFEST_NAME in filenames:
            found.append(os.path.join(dirpath, MANIFEST_NAME))
    return sorted(found)


def read_manifest(path):
    with io.open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def manifest_export_timestamp(manifest):
    metadata = manifest.get("exportMetadata") or {}
    return parse_timestamp(metadata.get("ExportTimestamp"))


def select_latest_package(root):
    """Return (manifest_path, manifest, candidates) for the newest export.

    Newest is decided by the manifest's own exportTimestamp. Manifests that do
    not parse, or that carry no readable timestamp, are reported rather than
    silently preferred.
    """
    candidates = find_manifests(root)
    if not candidates:
        raise ManifestNotFound(
            "No %s found under %s" % (MANIFEST_NAME, root), searched=[root])

    scored = []
    problems = []
    for path in candidates:
        try:
            manifest = read_manifest(path)
        except Exception as exc:
            problems.append("%s: unreadable (%s: %s)"
                            % (path, type(exc).__name__, exc))
            continue
        stamp = manifest_export_timestamp(manifest)
        if stamp is None:
            problems.append("%s: no readable exportMetadata.ExportTimestamp" % path)
            continue
        scored.append((stamp, path, manifest))

    if not scored:
        raise ManifestNotFound(
            "Found %d manifest file(s) but none carried a usable "
            "exportMetadata.ExportTimestamp." % len(candidates),
            searched=candidates + problems)

    scored.sort(key=lambda item: item[0])
    stamp, path, manifest = scored[-1]
    return path, manifest, {
        "candidates": candidates,
        "problems": problems,
        "selected_timestamp": stamp.isoformat(),
        "considered": len(scored),
    }


def load_manifest(explicit_path=None, search_root=None):
    """Load an explicit manifest, or auto-select the newest under `search_root`."""
    if explicit_path:
        if not os.path.isfile(explicit_path):
            raise ManifestNotFound("Manifest not found: %s" % explicit_path,
                                   searched=[explicit_path])
        try:
            manifest = read_manifest(explicit_path)
        except ValueError as exc:
            raise ManifestInvalid("Manifest is not valid JSON: %s (%s)"
                                  % (explicit_path, exc))
        stamp = manifest_export_timestamp(manifest)
        return explicit_path, manifest, {
            "candidates": [explicit_path],
            "problems": [],
            "selected_timestamp": stamp.isoformat() if stamp else None,
            "considered": 1,
        }
    if not search_root:
        raise ManifestNotFound("No manifest path and no search root supplied.")
    return select_latest_package(search_root)


def package_folder(manifest_path):
    return os.path.dirname(os.path.abspath(manifest_path))


def calculate_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_csv(package, name):
    """Load one Phase 6A CSV for cross-checking. Returns None when absent."""
    path = os.path.join(package, "csv", name)
    if not os.path.isfile(path):
        return None
    with io.open(path, "r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def load_config(path=None):
    """Report configuration. A missing file is not an error."""
    config = dict(DEFAULT_CONFIG)
    if not path:
        return config, None
    if not os.path.isfile(path):
        raise ManifestInvalid("Report configuration not found: %s" % path)
    with io.open(path, "r", encoding="utf-8") as handle:
        user = json.load(handle)
    if not isinstance(user, dict):
        raise ManifestInvalid("Report configuration must be a JSON object.")
    config.update(user)
    return config, path


DEFAULT_CONFIG = {
    "reportTitle": "Planning Feasibility Report",
    "reportSubtitle": "",
    "clientName": "",
    "projectAddress": "",
    "preparedBy": "DZ Planning Tools",
    "preparedFor": "",
    "confidentiality": "Confidential",
    "issuePurpose": "Design Feasibility",
    "showSourceIds": False,
    "showObjectGuids": False,
    "includeDetailedTables": True,
    "includeWarningsAppendix": True,
    "includeDataProvenance": True,
    "includeOptionalFigures": True,
    "figureFolder": "",
    "pageSize": "A4",
    "orientation": "Portrait",
}
