"""Report assembly: PDF via ReportLab Platypus, with an HTML interim fallback."""

import datetime
import html
import io
import os

from . import __version__
from .formatting import (NOT_AVAILABLE, clean_text, format_status, format_value,
                         manifest_has_non_ascii, register_fonts)
from .loader import calculate_sha256
from .models import ReportData

OPTIONAL_FIGURES = [
    "01_cover", "02_setbacks", "03_separation", "04_open_space",
    "05_height_plane", "06_solar_heatmap", "07_site_overview",
    "08_massing_overview",
]
FIGURE_EXTENSIONS = (".png", ".jpg", ".jpeg")

ASSETS_FOLDER = "report_assets"
GENERATED_FOLDER = os.path.join(ASSETS_FOLDER, "generated")


def reportlab_available():
    try:
        import reportlab  # noqa: F401
        return True, getattr(__import__("reportlab"), "Version", "unknown")
    except ImportError:
        return False, None


def discover_figures(package, figure_folder=None):
    """Locate optional figures. Missing figures are reported, never fatal."""
    folders = []
    if figure_folder:
        folders.append(figure_folder)
    folders.append(os.path.join(package, ASSETS_FOLDER))

    found = {}
    for key in OPTIONAL_FIGURES:
        for folder in folders:
            if key in found:
                break
            for extension in FIGURE_EXTENSIONS:
                candidate = os.path.join(folder, key + extension)
                if os.path.isfile(candidate):
                    found[key] = candidate
                    break
    missing = [key for key in OPTIONAL_FIGURES if key not in found]
    return found, missing


def resolve_output_path(package, data, explicit=None, output_folder=None,
                        overwrite=False, timestamped=False):
    """Decide where the report is written and refuse to clobber silently."""
    if explicit:
        path = os.path.abspath(explicit)
    else:
        folder = output_folder or package
        name = "%s_%s_%s_Planning_Report.pdf" % (
            _safe(data.project_id, "PROJECT"),
            _safe(_option_token(data.option), "Option"),
            _safe(data.revision, "P01"))
        path = os.path.join(folder, name)

    if os.path.exists(path) and not overwrite:
        if not timestamped:
            raise FileExistsError(
                "Report already exists: %s. Pass --overwrite to replace it, or "
                "--timestamped to write a new versioned file." % path)
        root, extension = os.path.splitext(path)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = "%s_%s%s" % (root, stamp, extension)
    return path


def _option_token(option):
    text = str(option or "Option").strip()
    if text.lower().startswith("option"):
        return text
    return "Option-%s" % text


def _safe(text, fallback):
    import re
    value = re.sub(r"[^A-Za-z0-9._\- ]+", "-", str(text or "")).strip()
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"-{2,}", "-", value).strip("-. ")
    return value or fallback


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------

def _build_canvas_class(footer_text, footer_font="Helvetica"):
    """Canvas that stamps the footer.

    The footer font must be the same family chosen for the body, otherwise
    non-Latin project names render as black boxes on the raw canvas.
    """
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas as canvas_module

    class NumberedCanvas(canvas_module.Canvas):
        """Two-pass canvas so every page can print 'Page X of Y'."""

        def __init__(self, *args, **kwargs):
            canvas_module.Canvas.__init__(self, *args, **kwargs)
            self._saved_states = []

        def showPage(self):
            self._saved_states.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            total = len(self._saved_states)
            for state in self._saved_states:
                self.__dict__.update(state)
                self._draw_footer(total)
                canvas_module.Canvas.showPage(self)
            canvas_module.Canvas.save(self)

        def _draw_footer(self, total):
            page = self._pageNumber
            if page == 1:
                return
            width, _height = self._pagesize
            self.saveState()
            self.setStrokeColorRGB(0.79, 0.83, 0.85)
            self.setLineWidth(0.4)
            self.line(18 * mm, 14 * mm, width - 18 * mm, 14 * mm)
            try:
                self.setFont(footer_font, 6.8)
            except Exception:
                self.setFont("Helvetica", 6.8)
            self.setFillColorRGB(0.36, 0.42, 0.45)
            self.drawString(18 * mm, 9.5 * mm, footer_text)
            self.drawRightString(width - 18 * mm, 9.5 * mm,
                                 "Page %d of %d" % (page, total))
            self.restoreState()

    return NumberedCanvas


def generate_pdf(data, config, output_path, figures, charts, validation,
                 consistency, chart_notes, manifest_hash, package,
                 report_timestamp):
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.units import mm
    from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate

    from . import sections

    page_size = A4
    if str(config.get("orientation", "Portrait")).lower().startswith("land"):
        page_size = landscape(A4)

    use_unicode = manifest_has_non_ascii(data.manifest)
    font, bold_font, font_notes = register_fonts(use_unicode)

    margin = 18 * mm
    frame_width = page_size[0] - 2 * margin
    styles = sections.Styles(font, bold_font, frame_width)

    option_text = clean_text(data.option)
    if option_text and not option_text.lower().startswith("option"):
        option_text = "Option %s" % option_text
    footer = " | ".join([part for part in [
        clean_text(data.project_name),
        "Project %s" % clean_text(data.project_id) if data.project_id else "",
        option_text,
        "Rev %s" % clean_text(data.revision) if data.revision else "",
        "Report %s" % report_timestamp.replace("T", " ")[:16],
    ] if part])

    doc = BaseDocTemplate(
        output_path, pagesize=page_size,
        leftMargin=margin, rightMargin=margin,
        topMargin=16 * mm, bottomMargin=20 * mm,
        title="%s - %s %s" % (config.get("reportTitle", "Planning Report"),
                              clean_text(data.project_id),
                              clean_text(data.option)),
        author=config.get("preparedBy") or "DZ Planning Tools",
        subject="Phase 6B planning feasibility report")

    frame = Frame(margin, 20 * mm, frame_width,
                  page_size[1] - 16 * mm - 20 * mm, id="body",
                  leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates([PageTemplate(id="main", frames=[frame])])

    story = []
    story.extend(sections.section_cover(styles, data, config, figures,
                                        report_timestamp))
    story.extend(sections.section_executive_summary(styles, data, charts))
    story.extend(sections.section_key_metrics(styles, data))
    story.extend(sections.section_planning_controls(styles, data))
    story.extend(sections.section_compliance(styles, data, charts))
    story.extend(sections.section_buildings(styles, data, config, charts))
    story.extend(sections.section_floors(styles, data))
    story.extend(sections.section_setbacks(styles, data, figures))
    story.extend(sections.section_open_space(styles, data, config, charts,
                                             figures))
    story.extend(sections.section_height_plane(styles, data, figures))
    story.extend(sections.section_parking(styles, data, config, charts))
    story.extend(sections.section_solar(styles, data, config, charts, figures))
    story.extend(sections.section_warnings(styles, data))
    if config.get("includeDataProvenance", True):
        story.extend(sections.section_provenance(
            styles, data, report_timestamp, manifest_hash, package,
            __version__, "ReportLab Platypus"))
    figures_used = sorted(figures.keys())
    figures_missing = [k for k in OPTIONAL_FIGURES if k not in figures]
    story.extend(sections.section_appendix(
        styles, data, config, validation, consistency, chart_notes, font_notes,
        figures_used, figures_missing))

    doc.build(story, canvasmaker=_build_canvas_class(footer, font))
    return font_notes


# ---------------------------------------------------------------------------
# HTML interim output
# ---------------------------------------------------------------------------

def generate_html(data, config, output_path, charts, validation,
                  report_timestamp, manifest_hash, package):
    """Interim, self-contained HTML preview used when ReportLab is absent."""
    from . import sections

    def esc(value):
        return html.escape("" if value is None else str(value))

    def kv(pairs):
        rows = "".join("<tr><th>%s</th><td>%s</td></tr>"
                       % (esc(k), esc(v)) for k, v in pairs)
        return "<table class='kv'>%s</table>" % rows

    def table(headers, rows):
        head = "".join("<th>%s</th>" % esc(h) for h in headers)
        body = "".join("<tr>%s</tr>"
                       % "".join("<td>%s</td>" % esc(c) for c in row)
                       for row in rows)
        return "<table><thead><tr>%s</tr></thead><tbody>%s</tbody></table>" % (
            head, body)

    summary = data.summary
    parts = []
    parts.append("<h1>%s</h1>" % esc(config.get("reportTitle")))
    parts.append("<p class='sub'>%s</p>" % esc(data.project_name))
    parts.append("<div class='warn'><strong>Interim HTML output.</strong> "
                 "ReportLab is not installed in this environment, so no PDF was "
                 "produced. This HTML preview is not a PDF report.</div>")
    parts.append("<p class='note'>%s</p>" % esc(sections.PLANNING_DISCLAIMER))
    parts.append(kv([
        ("Project name", data.project_name), ("Project ID", data.project_id),
        ("Option", data.option), ("Revision", data.revision),
        ("Report date", report_timestamp),
        ("Export timestamp", data.metadata.get("ExportTimestamp")),
        ("Overall status", format_status(data.overall_status)),
        ("Manifest SHA-256", manifest_hash),
        ("Source package", package),
    ]))

    parts.append("<h2>Executive summary</h2>")
    for sentence in sections._summary_sentences(data):
        parts.append("<p>%s</p>" % esc(sentence))

    parts.append("<h2>Compliance overview</h2>")
    parts.append(table(
        ["Rule", "Target", "Actual", "Difference", "Status"],
        [[row.get("RuleName"),
          format_value(row.get("TargetValue"), row.get("TargetUnit")),
          format_value(row.get("ActualValue"), row.get("ActualUnit")),
          format_value(row.get("Difference"), row.get("DifferenceUnit")),
          format_status(row.get("Status"))] for row in data.compliance]))

    parts.append("<h2>Building schedule</h2>")
    parts.append(table(
        ["ID", "Name", "Program", "Height", "Floors", "Physical GFA",
         "FSR GFA", "Status summary"],
        [[row.get("BuildingId"), row.get("BuildingName"), row.get("Program"),
          format_value(row.get("Height"), "m"),
          format_value(row.get("FloorCount"), "count"),
          format_value(row.get("PhysicalGFA"), "m2"),
          format_value(row.get("FSRIncludedGFA"), "m2"),
          row.get("MetadataStatus")] for row in data.buildings]))

    parts.append("<h2>Parking</h2>")
    parts.append("<p class='note'>%s</p>" % esc(sections.PARKING_DISCLAIMER))
    parts.append("<h2>Direct solar access</h2>")
    parts.append("<p class='note'>%s</p>" % esc(sections.SOLAR_STATEMENT))

    parts.append("<h2>Warnings</h2>")
    parts.append(table(["Severity", "Module", "Message"],
                       [[row.get("Severity"), row.get("Module"),
                         row.get("Message")] for row in data.sorted_warnings()]))

    if validation.warnings:
        parts.append("<h2>Report warnings</h2><ul>%s</ul>"
                     % "".join("<li>%s</li>" % esc(w) for w in validation.warnings))

    for key, path in sorted(charts.items()):
        rel = os.path.relpath(path, os.path.dirname(output_path))
        parts.append("<h3>%s</h3><img src='%s' alt='%s'>"
                     % (esc(key.replace("_", " ").title()),
                        esc(rel.replace("\\", "/")), esc(key)))

    style = """
    body{font-family:Segoe UI,Helvetica,Arial,sans-serif;margin:40px auto;
         max-width:1000px;color:#222;line-height:1.5}
    h1{color:#2F4F5F;margin-bottom:2px} h2{color:#2F4F5F;margin-top:32px}
    .sub{color:#5C6B73;margin-top:0}
    .warn{background:#F4EEDD;border:1px solid #C6A85C;padding:12px;margin:16px 0}
    .note{background:#F4F7F8;border:1px solid #C9D4DA;padding:10px}
    table{border-collapse:collapse;width:100%;margin:12px 0;font-size:13px}
    th,td{border:1px solid #C9D4DA;padding:6px 8px;text-align:left;
          vertical-align:top}
    thead th{background:#2F4F5F;color:#fff}
    tbody tr:nth-child(even){background:#F4F7F8}
    table.kv th{width:30%;background:#F4F7F8;color:#222}
    img{max-width:100%;height:auto;border:1px solid #C9D4DA}
    """
    document = ("<!doctype html><html lang='en'><head><meta charset='utf-8'>"
                "<title>%s</title><style>%s</style></head><body>%s</body></html>"
                % (esc(config.get("reportTitle")), style, "".join(parts)))
    with io.open(output_path, "w", encoding="utf-8") as handle:
        handle.write(document)
    return output_path
