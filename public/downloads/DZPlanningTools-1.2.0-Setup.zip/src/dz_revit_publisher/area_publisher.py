"""Native Revit Area planning, naming and the area-consistency comparison."""

from .validation import AREA_BLOCKING_RATIO, AREA_TOLERANCE_RATIO

MATCH = "MATCH"
WARNING = "WARNING"
BLOCKING = "BLOCKING"


def area_number(building_id, floor_index):
    """`B001-01`."""
    return "%s-%02d" % (building_id, int(floor_index))


def area_name(building_name, floor_index):
    """`Building A - Level 01 GFA`."""
    return "%s - Level %02d GFA" % (building_name or "Building", int(floor_index))


class AreaRequest(object):
    def __init__(self, number, name, floor_index, elevation, view_name,
                 floor_key, seed_point, expected_area, action="CREATE",
                 element_id=None, note=None):
        self.number = number
        self.name = name
        self.floor_index = floor_index
        self.elevation = elevation
        self.view_name = view_name
        self.floor_key = floor_key
        self.seed_point = seed_point
        self.expected_area = expected_area
        self.action = action
        self.element_id = element_id
        self.note = note
        self.error = None
        self.published_area = None
        self.difference = None
        self.difference_ratio = None
        self.status = None

    def evaluate(self):
        """Compare the published Revit area with the exported plate area."""
        if self.published_area is None or self.expected_area in (None, 0):
            self.status = None
            return self.status
        self.difference = float(self.published_area) - float(self.expected_area)
        self.difference_ratio = self.difference / float(self.expected_area)
        magnitude = abs(self.difference_ratio)
        if magnitude > AREA_BLOCKING_RATIO:
            self.status = BLOCKING
        elif magnitude > AREA_TOLERANCE_RATIO:
            self.status = WARNING
        else:
            self.status = MATCH
        return self.status

    def as_dict(self):
        return {
            "AreaNumber": self.number, "AreaName": self.name,
            "FloorIndex": self.floor_index, "Elevation": self.elevation,
            "ViewName": self.view_name, "FloorKey": self.floor_key,
            "SeedPoint": list(self.seed_point) if self.seed_point else None,
            "ExpectedArea": self.expected_area,
            "PublishedArea": self.published_area,
            "Difference": self.difference,
            "DifferenceRatio": self.difference_ratio,
            "AreaStatus": self.status, "Action": self.action,
            "ElementId": self.element_id, "Note": self.note,
            "Error": self.error,
        }


def plan(building, boundary_requests, plan_requests, existing_areas=None):
    """One native Area per level, matched on DZ_Floor_Key so reruns reuse.

    `existing_areas` maps a floor key to an existing Area ElementId.
    """
    existing = dict(existing_areas or {})
    boundary_by_index = dict((b.floor_index, b) for b in boundary_requests)
    view_by_index = dict((p.floor_index, p) for p in plan_requests)

    requests = []
    for floor in building.floors:
        index = floor.floor_index
        boundary = boundary_by_index.get(index)
        view = view_by_index.get(index)
        key = floor.key()
        request = AreaRequest(
            area_number(building.building_id, index),
            area_name(building.building_name, index),
            index, floor.elevation, view.name if view else None, key,
            boundary.seed if boundary else None, floor.plate_area)
        if key in existing:
            request.action = "REUSE"
            request.element_id = existing[key]
            request.note = "Area already published with this floor key"
        elif boundary is None or boundary.action == "ERROR":
            request.action = "ERROR"
            request.error = "No usable boundary loop for this level."
        elif request.seed_point is None:
            request.action = "ERROR"
            request.error = ("No interior point available; an Area cannot be "
                             "placed without one.")
        requests.append(request)
    return requests


# ---------------------------------------------------------------------------
# consistency
# ---------------------------------------------------------------------------

def consistency_rows(building, area_requests, floor_areas):
    """Manifest vs Revit Floor vs Revit Area, per level.

    `floor_areas` maps floor index to the measured Revit floor area in m2.
    """
    by_index = dict((a.floor_index, a) for a in area_requests)
    rows = []
    for floor in building.floors:
        index = floor.floor_index
        area_request = by_index.get(index)
        manifest_area = floor.plate_area
        revit_floor = (floor_areas or {}).get(index)
        revit_area = area_request.published_area if area_request else None

        floor_difference = _difference(manifest_area, revit_floor)
        area_difference = _difference(manifest_area, revit_area)
        status = _worst([_classify(manifest_area, revit_floor),
                         _classify(manifest_area, revit_area)])
        rows.append({
            "FloorIndex": index,
            "Level": area_request.view_name if area_request else None,
            "ManifestArea": manifest_area,
            "RevitFloorArea": revit_floor,
            "RevitAreaValue": revit_area,
            "FloorDifference": floor_difference,
            "AreaDifference": area_difference,
            "Status": status,
        })
    return rows


def _difference(expected, actual):
    if expected is None or actual is None:
        return None
    return float(actual) - float(expected)


def _classify(expected, actual):
    if expected in (None, 0) or actual is None:
        return None
    ratio = abs(float(actual) - float(expected)) / float(expected)
    if ratio > AREA_BLOCKING_RATIO:
        return BLOCKING
    if ratio > AREA_TOLERANCE_RATIO:
        return WARNING
    return MATCH


_RANK = {None: 0, MATCH: 1, WARNING: 2, BLOCKING: 3}


def _worst(statuses):
    worst = None
    for status in statuses:
        if _RANK.get(status, 0) > _RANK.get(worst, 0):
            worst = status
    return worst


def totals(building, area_requests, floor_areas, manifest_physical_gfa=None):
    """Project-level totals across the three sources."""
    manifest_total = sum(f.plate_area or 0.0 for f in building.floors)
    floor_total = sum((floor_areas or {}).values()) if floor_areas else None
    area_total = None
    published = [a.published_area for a in area_requests
                 if a.published_area is not None]
    if published:
        area_total = sum(published)
    return {
        "ManifestFloorPlateTotal": manifest_total,
        "ManifestPhysicalGFA": manifest_physical_gfa,
        "RevitFloorTotal": floor_total,
        "RevitAreaTotal": area_total,
        "FloorTotalStatus": _classify(manifest_total, floor_total),
        "AreaTotalStatus": _classify(manifest_total, area_total),
    }
