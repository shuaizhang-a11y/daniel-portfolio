"""ISO 8601 timestamps, parsed the same way in every host runtime.

``datetime.datetime.fromisoformat`` arrived in CPython 3.7. Rhino 8's
``_-RunPythonScript`` runs IronPython 2.7, where the attribute does not exist
at all - and an ``AttributeError`` is not a ``ValueError``, so a ``try/except
ValueError`` around it does not catch the failure. That is precisely how a
missing method surfaced as a blocking Analyse error in the live Phase 8C
window.

This module is the single parser for the whole project. It lives in
``dz_revit_publisher`` because that package is the base layer: it imports no
other DZ package, so ``dz_planning_app``, ``dz_planning_ui`` and ``dz_report``
can all depend on it without inverting the dependency direction.

Parsed values are returned as **naive UTC**. An offset timestamp is converted,
not truncated, so values written in different zones sort and compare
correctly. The original text is never modified: callers that display a
timestamp should keep showing the string they were given.
"""

import datetime
import re

#: Sentinel: distinguishes "no default supplied, so raise" from "default None".
REQUIRED = object()

#: Accepts, in one pass:
#:   2026-08-02                      date only
#:   2026-08-02T23:05:24             the form the Phase 6A exporter writes
#:   2026-08-02 23:05:24             space separator
#:   2026-08-02T23:05:24.123456      1 to 6 fractional digits, '.' or ','
#:   2026-08-02T23:05:24Z            UTC
#:   2026-08-02T23:05:24+10:00       offset, with or without the colon
ISO_PATTERN = re.compile(r"""
    ^
    (?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})
    (?:
        [T ]
        (?P<hour>\d{2}):(?P<minute>\d{2})
        (?: :(?P<second>\d{2})
            (?: [.,](?P<fraction>\d{1,6}) )?
        )?
    )?
    (?P<offset> Z | z | [+-]\d{2}:\d{2} | [+-]\d{4} | [+-]\d{2} )?
    $
""", re.VERBOSE)


def _offset_minutes(text):
    """Signed minutes east of UTC, or None for a naive timestamp."""
    if not text:
        return None
    if text in ("Z", "z"):
        return 0
    sign = -1 if text[0] == "-" else 1
    body = text[1:].replace(":", "")
    hours = int(body[:2])
    minutes = int(body[2:4]) if len(body) >= 4 else 0
    if minutes > 59:
        raise ValueError("offset minutes out of range")
    return sign * (hours * 60 + minutes)


def parse_iso_datetime(value, field=None, default=REQUIRED):
    """An ISO 8601 string as a naive UTC :class:`datetime.datetime`.

    ``value`` may already be a ``datetime`` (returned with any offset applied)
    or a ``date`` (midnight). Pass ``default=None`` to get that back instead
    of an exception for input that cannot be read; otherwise an unreadable
    value raises ``ValueError`` naming the field and the offending text, so a
    bad timestamp is never silently treated as absent.
    """
    if value is None or (isinstance(value, str) and not value.strip()):
        if default is REQUIRED:
            raise ValueError("%s is empty; expected an ISO 8601 timestamp."
                             % (field or "timestamp"))
        return default

    if isinstance(value, datetime.datetime):
        if value.tzinfo is None:
            return value
        return value.astimezone(_UTC).replace(tzinfo=None)
    if isinstance(value, datetime.date):
        return datetime.datetime(value.year, value.month, value.day)

    text = str(value).strip()
    match = ISO_PATTERN.match(text)
    if match is not None:
        try:
            return _build(match)
        except ValueError:
            pass                      # falls through to the shared failure
    if default is REQUIRED:
        raise ValueError(
            "%s is not a readable ISO 8601 timestamp: %r"
            % (field or "timestamp", text))
    return default


def _build(match):
    parts = match.groupdict()
    fraction = parts.get("fraction") or ""
    parsed = datetime.datetime(
        int(parts["year"]), int(parts["month"]), int(parts["day"]),
        int(parts["hour"] or 0), int(parts["minute"] or 0),
        int(parts["second"] or 0),
        int(fraction.ljust(6, "0")) if fraction else 0)
    offset = _offset_minutes(parts.get("offset"))
    if offset:
        #: Converted to UTC rather than discarded, so mixed-zone timestamps
        #: sort against each other correctly.
        parsed = parsed - datetime.timedelta(minutes=offset)
    return parsed


def format_iso_datetime(value, field=None):
    """Canonical ``YYYY-MM-DDTHH:MM:SS`` text, in naive UTC.

    For display, prefer the original string a record already carries; this is
    for the cases that need one deterministic spelling.
    """
    parsed = parse_iso_datetime(value, field)
    if parsed.microsecond:
        return parsed.strftime("%Y-%m-%dT%H:%M:%S.%f")
    return parsed.strftime("%Y-%m-%dT%H:%M:%S")


def sort_key(value, field=None):
    """A total order over timestamps, tolerating unreadable ones.

    Unreadable values sort before everything else rather than raising, so one
    corrupt history row cannot make the whole list unsortable.
    """
    parsed = parse_iso_datetime(value, field, default=None)
    if parsed is None:
        return (0, datetime.datetime(1, 1, 1))
    return (1, parsed)


class _Utc(datetime.tzinfo):
    """UTC, spelled for hosts without ``datetime.timezone`` (IronPython 2.7)."""

    ZERO = datetime.timedelta(0)

    def utcoffset(self, dt):
        return self.ZERO

    def dst(self, dt):
        return self.ZERO

    def tzname(self, dt):
        return "UTC"


_UTC = _Utc()
