"""Source geometry and file hashing for the DZ publish engine.

Extracted verbatim from the validated Phase 7C component. ``Rhino`` is imported
lazily inside :func:`read_footprint` so the module can be imported - and the
rest of the package tested - without Rhino installed.
"""

import hashlib
import os


def read_footprint(source_id, path, tolerance=0.01):
    """Footprint points in metres, normalised from the source document units."""
    import Rhino          # lazy: this module must import without Rhino

    notes = []
    if not os.path.isfile(path):
        return None, ["Source 3DM not found: %s" % path]
    file3dm = None
    try:
        file3dm = Rhino.FileIO.File3dm.Read(path)
        if file3dm is None:
            return None, ["Source 3DM could not be read: %s" % path]
        units = file3dm.Settings.ModelUnitSystem
        factor = Rhino.RhinoMath.UnitScale(units, Rhino.UnitSystem.Meters)
        matches = [o for o in file3dm.Objects
                   if o.Attributes.GetUserStrings().Get("DZ.SourceId") == source_id]
        if not matches:
            return None, ["SourceId %s not found in %s"
                          % (source_id, os.path.basename(path))]
        if len(matches) > 1:
            return None, ["SourceId %s matched %d objects; resolve the duplicate."
                          % (source_id, len(matches))]
        curve = matches[0].Geometry.DuplicateCurve()
        if abs(factor - 1.0) > 1e-12:
            curve.Transform(Rhino.Geometry.Transform.Scale(
                Rhino.Geometry.Point3d.Origin, factor))
            notes.append("Source document is in %s; scaled by %g to metres."
                         % (units, factor))
        got, polyline = curve.TryGetPolyline()
        if not got:
            simplified = curve.ToPolyline(0, 0, 0, 0, 0, tolerance, 0, 0, True)
            got, polyline = simplified.TryGetPolyline()
            if got:
                notes.append("Curve converted to a polyline within %.4f m."
                             % tolerance)
        if not got:
            return None, notes + ["Footprint could not be reduced to a polyline."]
        points = [(polyline[i].X, polyline[i].Y, polyline[i].Z)
                  for i in range(polyline.Count)]
        notes.append("Matched footprint in %s (read-only)." % os.path.basename(path))
        return points, notes
    except Exception as exc:
        return None, notes + ["Geometry read failed: %s: %s"
                              % (type(exc).__name__, exc)]
    finally:
        if file3dm is not None:
            try:
                file3dm.Dispose()
            except Exception:
                pass


def describe(path, source_id=None):
    """Read-only facts about a source 3DM, as JSON-safe values.

    Additive: nothing in the Phase 7 publish path calls this. Rhino is
    imported lazily inside, so this module still imports - and the offline
    suite still runs - on a machine without Rhino. When Rhino is unavailable
    the file-level facts are still returned and the model-level ones read
    None, with the reason in ``Warnings``.
    """
    facts = {
        "Path": os.path.abspath(path) if path else None,
        "Exists": bool(path and os.path.isfile(path)),
        "SizeBytes": None,
        "Sha256": None,
        "ModelUnits": None,
        "SourceIdObjectCount": None,
        "MatchesSourceId": None,
        "Warnings": [],
    }
    if not facts["Exists"]:
        facts["Warnings"].append("Source 3DM not found: %s" % path)
        return facts

    facts["SizeBytes"] = os.path.getsize(path)
    facts["Sha256"] = file_hash(path)

    try:
        import Rhino      # lazy: this module must import without Rhino
    except Exception as exc:
        facts["Warnings"].append(
            "Rhino is not available, so model units and the DZ.SourceId count "
            "could not be read (%s: %s)." % (type(exc).__name__, exc))
        return facts

    file3dm = None
    try:
        file3dm = Rhino.FileIO.File3dm.Read(path)
        if file3dm is None:
            facts["Warnings"].append("Source 3DM could not be opened: %s"
                                     % path)
            return facts
        facts["ModelUnits"] = str(file3dm.Settings.ModelUnitSystem)
        tagged = 0
        matching = 0
        for obj in file3dm.Objects:
            value = obj.Attributes.GetUserStrings().Get("DZ.SourceId")
            if value:
                tagged += 1
                if source_id and value == source_id:
                    matching += 1
        facts["SourceIdObjectCount"] = tagged
        if source_id:
            facts["MatchesSourceId"] = matching
            if matching == 0:
                facts["Warnings"].append(
                    "No object carries DZ.SourceId %s." % source_id)
            elif matching > 1:
                facts["Warnings"].append(
                    "%d objects carry DZ.SourceId %s; resolve the duplicate."
                    % (matching, source_id))
    except Exception as exc:
        facts["Warnings"].append("Source 3DM read failed: %s: %s"
                                 % (type(exc).__name__, exc))
    finally:
        if file3dm is not None:
            try:
                file3dm.Dispose()
            except Exception:
                pass
    return facts


def file_hash(path):
    if not path or not os.path.isfile(path):
        return None
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()
