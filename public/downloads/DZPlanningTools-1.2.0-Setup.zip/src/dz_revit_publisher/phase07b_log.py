"""Phase 7B publish log, written alongside the Phase 7A log.

Separate files so the Phase 7A history stays exactly as it was verified.
"""

import csv
import datetime
import io
import json
import os

from . import DEFINITION_PHASE, PUBLISH_STATUSES, __version__

LOG_FOLDER = "revit_publish"
JSON_NAME = "phase07b_publish_log.json"
CSV_NAME = "phase07b_publish_log.csv"

CSV_COLUMNS = [
    "PublishTimestamp", "PublishStatus", "PublishMode", "ProjectId", "Option",
    "Revision", "BuildingId", "BuildingSourceId", "AreaScheme", "Stage",
    "ItemKind", "ItemName", "ItemKey", "FloorIndex", "Action", "ElementId",
    "ExpectedArea", "PublishedArea", "Difference", "AreaStatus", "Note",
    "Error",
]


def iso_now():
    return datetime.datetime.now().replace(microsecond=0).isoformat()


def log_folder(package):
    return os.path.join(package, LOG_FOLDER)


def build_entry(status, plan, context, manifest_path, manifest_sha, identity,
                transaction_result=None, stage_results=None, warnings=None,
                errors=None, publish_mode=None, geometry_source=None):
    if status not in PUBLISH_STATUSES:
        status = "FAILED"
    building = plan.building if plan else None
    scheme = plan.scheme if plan else None

    def tally(items, attribute="action"):
        counts = {}
        for item in items or []:
            key = getattr(item, attribute, None) if not isinstance(item, dict) \
                else item.get("Action")
            counts[key] = counts.get(key, 0) + 1
        return counts

    definitions = tally(plan.parameter_definitions) if plan else {}
    bindings = tally(plan.binding_requests) if plan else {}
    plans = tally(plan.area_plan_requests) if plan else {}
    boundaries = tally(plan.boundary_requests) if plan else {}
    areas = tally(plan.area_requests) if plan else {}
    schedules = tally(plan.schedule_requests) if plan else {}

    return {
        "PublishTimestamp": iso_now(),
        "PublisherVersion": __version__,
        "DefinitionPhase": "7B",
        "PublishStatus": status,
        "PublishMode": publish_mode or (plan.publish_mode if plan else None),
        "ManifestPath": manifest_path,
        "ManifestSha256": manifest_sha,
        "RevitDocumentName": context.document_name if context else None,
        "RevitVersion": context.revit_version if context else None,
        "RevitBuild": context.revit_build if context else None,
        "RhinoInsideRevitVersion": context.rir_version if context else None,
        "ProjectId": identity.get("projectId") if identity else None,
        "Option": identity.get("option") if identity else None,
        "Revision": identity.get("revision") if identity else None,
        "BuildingId": building.building_id if building else None,
        "BuildingSourceId": building.source_id if building else None,
        "GeometrySource": geometry_source,

        "AreaScheme": scheme.name if scheme else None,
        "AreaSchemeAction": scheme.action if scheme else None,
        "AreaSchemeReason": scheme.reason if scheme else None,

        "SharedParameterFile": plan.shared_parameter_file if plan else None,
        "OriginalSharedParameterFile": (plan.original_shared_parameter_file
                                        if plan else None),

        "ParameterDefinitionsCreated": definitions.get("CREATE", 0),
        "ParameterDefinitionsReused": definitions.get("REUSE", 0),
        "ParameterDefinitionsConflicted": definitions.get("CONFLICT", 0),
        "BindingsCreated": bindings.get("CREATE", 0),
        "BindingsExtended": bindings.get("EXTEND", 0),
        "BindingsReused": bindings.get("REUSE", 0),

        "LevelsUpdated": len(plan.level_targets) if plan else 0,
        "FloorsUpdated": len(plan.floor_matches) if plan else 0,
        "FloorsUnmatched": len(plan.unmatched_floors) if plan else 0,
        "ProjectInformationWritten": len(plan.project_values) if plan else 0,

        "AreaPlansCreated": plans.get("CREATE", 0),
        "AreaPlansReused": plans.get("REUSE", 0),
        "BoundarySetsCreated": boundaries.get("CREATE", 0),
        "BoundarySetsReused": boundaries.get("REUSE", 0),
        "AreasCreated": areas.get("CREATE", 0),
        "AreasReused": areas.get("REUSE", 0),
        "AreasFailed": areas.get("ERROR", 0),
        "SchedulesCreated": schedules.get("CREATE", 0),
        "SchedulesReused": schedules.get("REUSE", 0),

        "Plan": plan.as_dict() if plan else None,
        "StageResults": list(stage_results or []),
        "Consistency": list(plan.consistency) if plan else [],
        "Totals": dict(plan.totals) if plan else {},
        "TransactionResult": transaction_result,
        "Warnings": list(warnings or []),
        "Errors": list(errors or []),
    }


def _rows(entry):
    common = {
        "PublishTimestamp": entry.get("PublishTimestamp"),
        "PublishStatus": entry.get("PublishStatus"),
        "PublishMode": entry.get("PublishMode"),
        "ProjectId": entry.get("ProjectId"),
        "Option": entry.get("Option"),
        "Revision": entry.get("Revision"),
        "BuildingId": entry.get("BuildingId"),
        "BuildingSourceId": entry.get("BuildingSourceId"),
        "AreaScheme": entry.get("AreaScheme"),
    }
    plan = entry.get("Plan") or {}
    rows = []

    for row in plan.get("ParameterDefinitions", []):
        rows.append(dict(common, Stage="SharedParameters",
                         ItemKind="Definition", ItemName=row.get("Name"),
                         ItemKey=row.get("Guid"), Action=row.get("Action")))
    for row in plan.get("Bindings", []):
        rows.append(dict(common, Stage="Bindings", ItemKind="Binding",
                         ItemName=row.get("Parameter"),
                         ItemKey=";".join(row.get("Categories") or []),
                         Action=row.get("Action"), Note=row.get("Note"),
                         Error=row.get("Error")))
    for row in plan.get("FloorMatches", []):
        rows.append(dict(common, Stage="FloorParameters", ItemKind="Floor",
                         ItemName="floor %s" % row.get("FloorIndex"),
                         ItemKey=row.get("FloorKey"),
                         FloorIndex=row.get("FloorIndex"), Action="UPDATE",
                         ElementId=row.get("ElementId"),
                         Note=row.get("MatchedBy")))
    for row in plan.get("LevelTargets", []):
        rows.append(dict(common, Stage="LevelParameters", ItemKind="Level",
                         ItemName=row.get("Name"), Action="UPDATE",
                         ElementId=row.get("Id")))
    for row in plan.get("ProjectInformation", []):
        rows.append(dict(common, Stage="ProjectInformation",
                         ItemKind="Parameter", ItemName=row.get("Parameter"),
                         ItemKey=row.get("ManifestField"), Action="UPDATE",
                         Note=str(row.get("Value"))))
    for row in plan.get("AreaPlans", []):
        rows.append(dict(common, Stage="AreaPlans", ItemKind="AreaPlan",
                         ItemName=row.get("RequestedName"),
                         FloorIndex=row.get("FloorIndex"),
                         Action=row.get("Action"), ElementId=row.get("ElementId"),
                         Note=row.get("Note"), Error=row.get("Error")))
    for row in plan.get("Boundaries", []):
        rows.append(dict(common, Stage="Boundaries", ItemKind="BoundarySet",
                         ItemName=row.get("ViewName"), ItemKey=row.get("BoundaryKey"),
                         FloorIndex=row.get("FloorIndex"),
                         Action=row.get("Action"),
                         ElementId=";".join(str(i) for i in
                                            (row.get("CurveElementIds") or [])),
                         ExpectedArea=row.get("ExpectedArea"),
                         PublishedArea=row.get("LoopArea"),
                         Note=row.get("Note"), Error=row.get("Error")))
    for row in plan.get("Areas", []):
        rows.append(dict(common, Stage="Areas", ItemKind="Area",
                         ItemName=row.get("AreaName"), ItemKey=row.get("FloorKey"),
                         FloorIndex=row.get("FloorIndex"),
                         Action=row.get("Action"), ElementId=row.get("ElementId"),
                         ExpectedArea=row.get("ExpectedArea"),
                         PublishedArea=row.get("PublishedArea"),
                         Difference=row.get("Difference"),
                         AreaStatus=row.get("AreaStatus"),
                         Note=row.get("Note"), Error=row.get("Error")))
    for row in plan.get("Schedules", []):
        rows.append(dict(common, Stage="Schedules", ItemKind="Schedule",
                         ItemName=row.get("Name"), Action=row.get("Action"),
                         ElementId=row.get("ElementId"),
                         Note=("missing fields: %s" % ", ".join(row.get("MissingFields")))
                         if row.get("MissingFields") else row.get("Note"),
                         Error=row.get("Error")))
    for row in entry.get("Consistency", []):
        rows.append(dict(common, Stage="Consistency", ItemKind="Comparison",
                         ItemName="floor %s" % row.get("FloorIndex"),
                         FloorIndex=row.get("FloorIndex"),
                         ExpectedArea=row.get("ManifestArea"),
                         PublishedArea=row.get("RevitAreaValue"),
                         Difference=row.get("AreaDifference"),
                         AreaStatus=row.get("Status")))
    if not rows:
        rows.append(dict(common, Stage="None", ItemKind="None"))
    return rows


def write(package, entry):
    folder = log_folder(package)
    if not os.path.isdir(folder):
        os.makedirs(folder)

    json_path = os.path.join(folder, JSON_NAME)
    history = {"schemaVersion": "1.0", "phase": "7B", "entries": []}
    if os.path.isfile(json_path):
        try:
            with io.open(json_path, "r", encoding="utf-8") as handle:
                existing = json.load(handle)
            if isinstance(existing, dict) and isinstance(existing.get("entries"), list):
                history = existing
        except Exception:
            backup = json_path + ".unreadable-%s" % datetime.datetime.now().strftime(
                "%Y%m%d_%H%M%S")
            try:
                os.rename(json_path, backup)
            except OSError:
                pass
    history.setdefault("entries", []).append(entry)
    history["latest"] = entry
    with io.open(json_path, "w", encoding="utf-8") as handle:
        json.dump(history, handle, ensure_ascii=False, indent=2, default=str)

    csv_path = os.path.join(folder, CSV_NAME)
    write_header = not os.path.isfile(csv_path)
    with io.open(csv_path, "a", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS,
                                extrasaction="ignore")
        if write_header:
            writer.writeheader()
        for row in _rows(entry):
            writer.writerow({key: ("" if row.get(key) is None else row.get(key))
                             for key in CSV_COLUMNS})
    return json_path, csv_path


def read_history(package):
    json_path = os.path.join(log_folder(package), JSON_NAME)
    if not os.path.isfile(json_path):
        return {"entries": []}
    with io.open(json_path, "r", encoding="utf-8") as handle:
        return json.load(handle)
