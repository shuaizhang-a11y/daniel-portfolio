"""Assemble and render the Phase 7B Publish Plan.

Every decision is taken before Revit is touched, so publishing is execution of
a reviewed plan rather than improvisation - the same discipline as Phase 7A.
"""

from . import COORDINATE_WARNING, PUBLISH_MODES
from . import parameter_bindings, shared_parameters
from .area_publisher import BLOCKING, WARNING


class Phase7BPlan(object):
    def __init__(self, building, identity, manifest_sha, publish_mode,
                 scheme=None):
        self.building = building
        self.identity = dict(identity or {})
        self.manifest_sha = manifest_sha
        self.publish_mode = publish_mode
        self.scheme = scheme

        self.parameter_definitions = []   # {"Name","Action","Guid","DataType"}
        self.binding_requests = []
        self.floor_matches = []
        self.unmatched_floors = []
        self.level_targets = []
        self.project_values = []
        self.area_plan_requests = []
        self.boundary_requests = []
        self.area_requests = []
        self.schedule_requests = []
        self.consistency = []
        self.totals = {}

        self.warnings = []
        self.blocking = []
        self.notes = []
        self.shared_parameter_file = None
        self.original_shared_parameter_file = None

    # -- state -----------------------------------------------------------
    @property
    def publish_ready(self):
        return (not self.blocking
                and self.publish_mode in ("Create New", "Update Existing")
                and self.scheme is not None and self.scheme.ok)

    @staticmethod
    def _tally(items, attribute="action"):
        counts = {}
        for item in items:
            key = getattr(item, attribute, None)
            counts[key] = counts.get(key, 0) + 1
        return counts

    def counts(self):
        return {
            "parameterDefinitions": self._count_dicts(self.parameter_definitions),
            "bindings": self._tally(self.binding_requests),
            "areaPlans": self._tally(self.area_plan_requests),
            "boundaries": self._tally(self.boundary_requests),
            "areas": self._tally(self.area_requests),
            "schedules": self._tally(self.schedule_requests),
            "floorsMatched": len(self.floor_matches),
            "floorsUnmatched": len(self.unmatched_floors),
            "levels": len(self.level_targets),
            "projectValues": len(self.project_values),
        }

    @staticmethod
    def _count_dicts(rows):
        counts = {}
        for row in rows:
            key = row.get("Action")
            counts[key] = counts.get(key, 0) + 1
        return counts

    # -- rendering -------------------------------------------------------
    def render(self):
        lines = []
        add = lines.append
        add("PHASE 7B PUBLISH PLAN")
        add("=" * 66)
        add("Project         : %s" % self.identity.get("projectId"))
        add("Option          : %s" % self.identity.get("option"))
        add("Revision        : %s" % self.identity.get("revision"))
        if self.building is not None:
            add("Building        : %s" % self.building.describe())
            add("SourceId        : %s" % self.building.source_id)
        add("Manifest SHA-256: %s" % self.manifest_sha)
        add("Publish Mode    : %s" % self.publish_mode)
        add("")

        add("Shared Parameters:")
        counts = self._count_dicts(self.parameter_definitions)
        add("  %-8s %d definition(s)" % ("CREATE", counts.get("CREATE", 0)))
        add("  %-8s %d definition(s)" % ("REUSE", counts.get("REUSE", 0)))
        if counts.get("CONFLICT"):
            add("  %-8s %d definition(s)" % ("CONFLICT", counts["CONFLICT"]))
        add("  file          : %s" % self.shared_parameter_file)
        add("  restores to   : %s" % (self.original_shared_parameter_file
                                      or "<none was set>"))
        add("")

        add("Parameter Bindings:")
        for action, count in sorted(self._tally(self.binding_requests).items()):
            add("  %-8s %d" % (action, count))
        add("")

        add("Existing Phase 7A elements:")
        add("  Floors matched : %d of %d" % (len(self.floor_matches),
                                             len(self.building.floors)
                                             if self.building else 0))
        for match in self.floor_matches:
            add("     UPDATE  floor id=%-9s index=%-2s matched by %s"
                % (match["element"].get("ElementId"),
                   match["floor"].floor_index, match["matchedBy"]))
        for floor in self.unmatched_floors:
            add("     ERROR   floor index=%s could not be matched"
                % floor.floor_index)
        add("  Levels updated : %d" % len(self.level_targets))
        add("")

        add("Project Information:")
        add("  UPDATE %d parameter(s)" % len(self.project_values))
        add("")

        add("Area Scheme:")
        if self.scheme is not None:
            add("  %-8s %s  (%s)" % (self.scheme.action, self.scheme.name,
                                     self.scheme.reason))
        else:
            add("  not resolved")
        add("")

        add("Area Plans:")
        for request in self.area_plan_requests:
            add("  %-7s %-24s level %s%s"
                % (request.action, request.name, request.level_name,
                   "  (%s)" % request.note if request.note else ""))
        add("")

        add("Area Boundaries:")
        for request in self.boundary_requests:
            add("  %-7s %-46s loop %8.2f m2%s"
                % (request.action, request.key, request.loop_area,
                   "  (%s)" % (request.error or request.note)
                   if (request.error or request.note) else ""))
        add("")

        add("Areas:")
        for request in self.area_requests:
            add("  %-7s %-10s %-30s expected %8.2f m2%s"
                % (request.action, request.number, request.name,
                   float(request.expected_area or 0.0),
                   "  (%s)" % (request.error or request.note)
                   if (request.error or request.note) else ""))
        add("")

        add("Schedules:")
        for request in self.schedule_requests:
            detail = ""
            if request.missing_fields:
                detail = "  (unavailable fields: %s)" % ", ".join(
                    request.missing_fields)
            add("  %-7s %-34s [%s]%s" % (request.action, request.name,
                                         request.spec.category, detail))
        add("")

        add("Expected GFA:")
        add("  Manifest : %.2f m2" % (self.totals.get("ManifestFloorPlateTotal") or 0.0))
        floors_total = self.totals.get("RevitFloorTotal")
        add("  Floors   : %s" % ("%.2f m2" % floors_total if floors_total
                                 is not None else "not measured yet"))
        areas_total = self.totals.get("RevitAreaTotal")
        add("  Areas    : %s" % ("%.2f m2" % areas_total if areas_total
                                 is not None else "not created yet"))
        add("")

        add("Warnings:")
        shown = list(self.warnings)
        if COORDINATE_WARNING not in shown:
            shown.insert(0, COORDINATE_WARNING)
        for warning in shown:
            add("  - %s" % warning)
        if self.blocking:
            add("")
            add("Blocking Errors:")
            for item in self.blocking:
                add("  - %s" % item)
        add("")
        add("Publish Ready: %s" % ("YES" if self.publish_ready else "NO"))
        return "\n".join(lines)

    def as_dict(self):
        return {
            "ProjectId": self.identity.get("projectId"),
            "Option": self.identity.get("option"),
            "Revision": self.identity.get("revision"),
            "BuildingId": self.building.building_id if self.building else None,
            "BuildingSourceId": self.building.source_id if self.building else None,
            "ManifestSha256": self.manifest_sha,
            "PublishMode": self.publish_mode,
            "SharedParameterFile": self.shared_parameter_file,
            "OriginalSharedParameterFile": self.original_shared_parameter_file,
            "ParameterDefinitions": list(self.parameter_definitions),
            "Bindings": [r.as_dict() for r in self.binding_requests],
            "FloorMatches": [{
                "FloorIndex": m["floor"].floor_index,
                "ElementId": m["element"].get("ElementId"),
                "MatchedBy": m["matchedBy"], "FloorKey": m["floorKey"],
            } for m in self.floor_matches],
            "UnmatchedFloors": [f.floor_index for f in self.unmatched_floors],
            "LevelTargets": list(self.level_targets),
            "ProjectInformation": list(self.project_values),
            "AreaScheme": self.scheme.as_dict() if self.scheme else None,
            "AreaPlans": [r.as_dict() for r in self.area_plan_requests],
            "Boundaries": [r.as_dict() for r in self.boundary_requests],
            "Areas": [r.as_dict() for r in self.area_requests],
            "Schedules": [r.as_dict() for r in self.schedule_requests],
            "Consistency": list(self.consistency),
            "Totals": dict(self.totals),
            "Warnings": list(self.warnings),
            "Blocking": list(self.blocking),
            "PublishReady": self.publish_ready,
            "Counts": self.counts(),
        }


def build_plan(building, identity, manifest, manifest_sha, publish_mode,
               observed, guids, shared_parameter_path,
               original_shared_parameter_file=None):
    """Compose the whole Phase 7B plan from what the Revit layer observed.

    `observed` carries only primitives, so this function stays Revit-free and
    unit testable.
    """
    from . import area_boundaries, area_plans, area_scheme, schedule_publisher

    plan = Phase7BPlan(building, identity, manifest_sha, publish_mode)
    plan.shared_parameter_file = shared_parameter_path
    plan.original_shared_parameter_file = original_shared_parameter_file

    if publish_mode not in PUBLISH_MODES:
        plan.blocking.append("Unknown publish mode %r." % publish_mode)
        return plan
    if building is None:
        plan.blocking.append("No building selected.")
        return plan

    # -- shared parameter definitions ------------------------------------
    existing_definitions = observed.get("definitions") or {}
    reusable, conflicts = shared_parameters.compare_existing(existing_definitions)
    for spec in shared_parameters.SCHEMA:
        action = "REUSE" if spec.name in reusable else "CREATE"
        if any(spec.name in c for c in conflicts):
            action = "CONFLICT"
        plan.parameter_definitions.append({
            "Name": spec.name, "Action": action,
            "Guid": guids.get(spec.name), "DataType": spec.data_type,
            "Categories": list(spec.categories),
        })
    plan.blocking.extend(conflicts)

    # -- bindings ---------------------------------------------------------
    plan.binding_requests = parameter_bindings.plan_bindings(
        observed.get("bindings") or {})

    # -- existing elements -------------------------------------------------
    matches, unmatched = parameter_bindings.match_floors(
        building, observed.get("floors") or [], observed.get("logFloorIds"))
    plan.floor_matches = matches
    plan.unmatched_floors = unmatched
    if unmatched:
        plan.blocking.append(
            "%d Phase 7A floor(s) could not be matched to manifest rows: %s. "
            "Phase 7B will not guess by element order."
            % (len(unmatched), ", ".join(str(f.floor_index) for f in unmatched)))
    plan.level_targets = list(observed.get("levels") or [])

    # -- project information ----------------------------------------------
    values = parameter_bindings.project_information_values(
        manifest, identity, manifest_sha)
    plan.project_values = parameter_bindings.project_information_report(values)

    # -- area scheme -------------------------------------------------------
    plan.scheme = area_scheme.select(observed.get("areaSchemes") or [],
                                     can_create=bool(observed.get("canCreateAreaScheme")))
    plan.warnings.extend(plan.scheme.warnings)
    plan.blocking.extend(plan.scheme.blocking)

    # -- area plans --------------------------------------------------------
    level_by_index = observed.get("levelByFloorIndex") or {}
    plan.area_plan_requests = area_plans.plan(
        building, level_by_index, plan.scheme, observed.get("areaPlans") or [])
    for request in plan.area_plan_requests:
        if request.action == "ERROR":
            plan.blocking.append("Area Plan %s: %s" % (request.name, request.error))

    # -- boundaries --------------------------------------------------------
    plan.boundary_requests = area_boundaries.plan(
        building, observed.get("footprintPoints") or [],
        plan.area_plan_requests, observed.get("boundaryKeys") or {})
    for request in plan.boundary_requests:
        if request.action == "ERROR":
            plan.blocking.append("Boundary %s: %s" % (request.key, request.error))

    # -- areas -------------------------------------------------------------
    plan.area_requests = area_publisher_plan(
        building, plan.boundary_requests, plan.area_plan_requests,
        observed.get("areaKeys") or {})
    for request in plan.area_requests:
        if request.action == "ERROR":
            plan.blocking.append("Area %s: %s" % (request.number, request.error))

    # -- schedules ---------------------------------------------------------
    specs = schedule_publisher.all_specs(
        building.building_id, plan.scheme.name if plan.scheme else None,
        observed.get("floorScheduleName"), observed.get("areaScheduleName"),
        observed.get("summaryScheduleName"))
    plan.schedule_requests = schedule_publisher.plan(
        specs, observed.get("schedules") or [],
        observed.get("scheduleCategoryValid"))
    available = observed.get("scheduleFields") or {}
    for request in plan.schedule_requests:
        if request.action == "SKIP":
            plan.warnings.append(
                "Schedule '%s' skipped: %s" % (request.name, request.note))
            continue
        applied, missing = schedule_publisher.resolve_fields(
            request.spec, available.get(request.spec.category))
        request.applied_fields = applied
        request.missing_fields = missing
        if missing:
            plan.warnings.append(
                "Schedule '%s' cannot include %s; the installed Revit does not "
                "offer %s for the %s category. The parameter is still written "
                "to the element."
                % (request.name, ", ".join(missing),
                   "them" if len(missing) > 1 else "it", request.spec.category))

    # -- consistency and totals -------------------------------------------
    floor_areas = observed.get("floorAreas") or {}
    plan.consistency = consistency_rows(building, plan.area_requests, floor_areas)
    summary = ((manifest.get("project") or {}).get("summary")) or {}
    plan.totals = totals(building, plan.area_requests, floor_areas,
                         summary.get("TotalPhysicalGFA"))
    for row in plan.consistency:
        if row["Status"] == BLOCKING:
            plan.blocking.append(
                "Floor index %s: manifest %.4f m2 versus Revit floor %s and "
                "Revit area %s exceeds the 10%% limit; this is a unit or "
                "scale problem, not a tolerance."
                % (row["FloorIndex"], row["ManifestArea"] or 0.0,
                   row["RevitFloorArea"], row["RevitAreaValue"]))
        elif row["Status"] == WARNING:
            plan.warnings.append(
                "Floor index %s area differs from the manifest by more than 1%%."
                % row["FloorIndex"])

    if plan.publish_mode == "Preview Only":
        plan.notes.append("Preview Only: nothing will be written to Revit.")
    return plan


# imported late to keep the module import graph shallow
from .area_publisher import consistency_rows, totals  # noqa: E402
from .area_publisher import plan as area_publisher_plan  # noqa: E402
