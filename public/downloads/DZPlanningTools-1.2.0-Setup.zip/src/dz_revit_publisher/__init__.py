"""DZ Planning Tools - Phase 7A Rhino.Inside.Revit publisher (proof of concept).

Scope of this package: read a completed Phase 6A export package, decide what
native Revit Levels and Floors *should* exist for one selected building, and
record what happened.

Everything in this package is deliberately free of RhinoCommon and the Revit
API so it can be unit tested outside Revit. The thin Revit-specific layer that
actually writes elements lives in the Grasshopper component script
`scripts/dz_revit_publisher_component.py`.

Phase 7A is a controlled connection and native-element proof of concept. It is
not the complete Revit publisher.
"""

__version__ = "1.0"
DEFINITION_PHASE = "7A"
SUPPORTED_SCHEMA = ("1.0",)

COORDINATE_MODE = "Internal Origin Alignment"

COORDINATE_WARNING = (
    "PHASE 7A USES INTERNAL ORIGIN ALIGNMENT. "
    "SHARED COORDINATES ARE NOT YET VERIFIED.")

TRACKING_PREFIX = "DZ_TEST_TRACKING"

PUBLISH_MODES = ("Preview Only", "Create New", "Update Existing")

PUBLISH_STATUSES = (
    "READY",
    "PREVIEWED",
    "VALIDATED",
    "PUBLISHED",
    "PUBLISHED WITH WARNINGS",
    "BLOCKED",
    "FAILED",
    "ROLLED BACK",
)

ELEMENT_ACTIONS = ("CREATE", "REUSE", "UPDATE", "SKIP", "ERROR")

__all__ = [
    "__version__", "DEFINITION_PHASE", "SUPPORTED_SCHEMA", "COORDINATE_MODE",
    "COORDINATE_WARNING", "TRACKING_PREFIX", "PUBLISH_MODES",
    "PUBLISH_STATUSES", "ELEMENT_ACTIONS",
]
