"""Phase 7B shared-parameter schema.

Free of the Revit API so the schema, its GUIDs and the shared-parameter file
content can be unit tested outside Revit.

Two rules govern this module:

* **GUIDs are stable.** They are derived deterministically from a fixed
  namespace and the parameter name, then persisted to
  ``config/dz_shared_parameters.json``. A rerun reuses them; a persisted GUID
  always wins over the derived one so a file edited by hand is respected.
* **Nothing office-wide is touched.** The definitions live in a project-local
  shared-parameter file. The Revit layer records the user's existing
  ``SharedParametersFilename``, points Revit at ours, then restores it.
"""

import io
import json
import os
import uuid

GROUP_NAME = "DZ Planning"

# Fixed namespace so uuid5 derivation is reproducible across machines and runs.
NAMESPACE = uuid.UUID("6d5a1f2e-7c3b-4f18-9a4d-0b2e7c9f1a55")

# Logical data types. The Revit layer maps these onto SpecTypeId for the
# installed version; nothing here imports Revit.
TEXT = "Text"
INTEGER = "Integer"
YESNO = "YesNo"
AREA = "Area"
NUMBER = "Number"
LENGTH = "Length"

SPEC_FOR = {
    TEXT: "SpecTypeId.String.Text",
    INTEGER: "SpecTypeId.Int.Integer",
    YESNO: "SpecTypeId.Boolean.YesNo",
    AREA: "SpecTypeId.Area",
    NUMBER: "SpecTypeId.Number",
    LENGTH: "SpecTypeId.Length",
}

# Category keys, mapped to BuiltInCategory by the Revit layer.
LEVELS = "Levels"
FLOORS = "Floors"
AREAS = "Areas"
PROJECT_INFO = "ProjectInformation"


class ParameterSpec(object):
    def __init__(self, name, data_type, categories, description=""):
        self.name = name
        self.data_type = data_type
        self.categories = tuple(categories)
        self.description = description
        self.instance = PROJECT_INFO not in categories

    @property
    def guid(self):
        return derived_guid(self.name)

    def as_dict(self):
        return {
            "name": self.name,
            "dataType": self.data_type,
            "spec": SPEC_FOR[self.data_type],
            "categories": list(self.categories),
            "instance": self.instance,
            "description": self.description,
            "guid": str(self.guid),
        }


def derived_guid(name):
    """Deterministic GUID for a parameter name."""
    return uuid.uuid5(NAMESPACE, "DZ_Planning::%s" % name)


IDENTITY_CATEGORIES = (LEVELS, FLOORS, AREAS)
ELEMENT_CATEGORIES = (FLOORS, AREAS)
# Project ID, Option and the manifest hash identify both the elements and the
# project as a whole, so they are one parameter bound to all four categories
# rather than a near-duplicate pair.
IDENTITY_AND_PROJECT = (LEVELS, FLOORS, AREAS, PROJECT_INFO)

# ---------------------------------------------------------------------------
# the schema
# ---------------------------------------------------------------------------

SCHEMA = [
    # identity, bound to Levels, Floors and Areas
    ParameterSpec("DZ_Source_ID", TEXT, IDENTITY_CATEGORIES,
                  "Stable DZ.SourceId of the source planning object."),
    ParameterSpec("DZ_Building_ID", TEXT, IDENTITY_CATEGORIES,
                  "Planning building identifier, e.g. B001."),
    ParameterSpec("DZ_Building_Name", TEXT, IDENTITY_CATEGORIES,
                  "Planning building name."),
    ParameterSpec("DZ_Project_ID", TEXT, IDENTITY_AND_PROJECT,
                  "Planning project identifier."),
    ParameterSpec("DZ_Option", TEXT, IDENTITY_AND_PROJECT,
                  "Planning option name."),
    ParameterSpec("DZ_Source_Revision", TEXT, IDENTITY_CATEGORIES,
                  "Export revision the element was published from."),
    ParameterSpec("DZ_Manifest_SHA256", TEXT, IDENTITY_AND_PROJECT,
                  "SHA-256 of the source Phase 6A manifest."),

    # element detail, bound to Floors and Areas only
    ParameterSpec("DZ_Program", TEXT, ELEMENT_CATEGORIES,
                  "Planning program, e.g. Residential."),
    ParameterSpec("DZ_Floor_Index", INTEGER, ELEMENT_CATEGORIES,
                  "1-based floor index from the Phase 6A export."),
    ParameterSpec("DZ_Floor_Key", TEXT, ELEMENT_CATEGORIES,
                  "{BuildingSourceId}:{FloorIndex}:{Elevation} identity key."),
    ParameterSpec("DZ_FSR_Included", YESNO, ELEMENT_CATEGORIES,
                  "Whether the floor counts towards FSR."),
    ParameterSpec("DZ_Physical_GFA", AREA, ELEMENT_CATEGORIES,
                  "Exported physical floor plate area."),
    ParameterSpec("DZ_FSR_GFA", AREA, ELEMENT_CATEGORIES,
                  "Exported FSR-included floor area."),

    # project summary, bound to Project Information
    ParameterSpec("DZ_Target_FSR", NUMBER, (PROJECT_INFO,),
                  "Target floor space ratio."),
    ParameterSpec("DZ_Actual_FSR", NUMBER, (PROJECT_INFO,),
                  "Actual floor space ratio."),
    ParameterSpec("DZ_Site_Area", AREA, (PROJECT_INFO,), "Site area."),
    ParameterSpec("DZ_Total_Physical_GFA", AREA, (PROJECT_INFO,),
                  "Total physical GFA."),
    ParameterSpec("DZ_Total_FSR_GFA", AREA, (PROJECT_INFO,),
                  "Total FSR included GFA."),
    ParameterSpec("DZ_Actual_Site_Coverage", NUMBER, (PROJECT_INFO,),
                  "Actual site coverage percentage."),
    ParameterSpec("DZ_Overall_Compliance_Status", TEXT, (PROJECT_INFO,),
                  "Overall compliance status from the export."),
    ParameterSpec("DZ_Export_Revision", TEXT, (PROJECT_INFO,),
                  "Export revision."),
    ParameterSpec("DZ_Export_Timestamp", TEXT, (PROJECT_INFO,),
                  "Export timestamp."),

    # -- Phase 7C: stable identity, change detection and lifecycle ---------
    # Elevation moves OUT of the identity key and into its own parameter, so
    # moving a floor updates that floor instead of creating a second one.
    ParameterSpec("DZ_Floor_Elevation", LENGTH, ELEMENT_CATEGORIES,
                  "Published floor elevation. Held separately from the "
                  "identity key so an elevation change is an update, not a "
                  "new floor."),
    ParameterSpec("DZ_Boundary_Hash", TEXT, ELEMENT_CATEGORIES,
                  "Normalised footprint hash: start point, direction and "
                  "vertex order independent."),
    ParameterSpec("DZ_Source_Snapshot", TEXT, ELEMENT_CATEGORIES,
                  "Hash of the full source snapshot for this element."),
    ParameterSpec("DZ_Publish_Status", TEXT, IDENTITY_CATEGORIES,
                  "Lifecycle status: PUBLISHED, UPDATED or OBSOLETE."),
]

# Written by Phase 7C only; Phase 7A/7B models will not have them until the
# identity migration stage runs.
PHASE_7C_PARAMETERS = ("DZ_Floor_Elevation", "DZ_Boundary_Hash",
                       "DZ_Source_Snapshot", "DZ_Publish_Status")

PUBLISH_STATUS_PUBLISHED = "PUBLISHED"
PUBLISH_STATUS_UPDATED = "UPDATED"
PUBLISH_STATUS_OBSOLETE = "OBSOLETE"

BY_NAME = dict((spec.name, spec) for spec in SCHEMA)


def for_category(category):
    return [spec for spec in SCHEMA if category in spec.categories]


def project_information_specs():
    return for_category(PROJECT_INFO)


# ---------------------------------------------------------------------------
# GUID registry
# ---------------------------------------------------------------------------

def load_registry(path):
    """Persisted GUIDs. A stored GUID always wins over the derived one."""
    if not path or not os.path.isfile(path):
        return {}
    with io.open(path, "r", encoding="utf-8") as handle:
        data = json.load(handle)
    return dict((k, v) for k, v in (data.get("parameters") or {}).items())


def resolve_guids(path):
    """{name: guid string} for the whole schema, honouring the registry."""
    stored = load_registry(path)
    resolved = {}
    for spec in SCHEMA:
        resolved[spec.name] = stored.get(spec.name) or str(spec.guid)
    return resolved


def save_registry(path, guids=None, notes=None):
    guids = guids or dict((s.name, str(s.guid)) for s in SCHEMA)
    payload = {
        "schemaVersion": "1.0",
        "phase": "7B",
        "group": GROUP_NAME,
        "note": notes or ("Stable shared-parameter GUIDs for the DZ Planning "
                          "group. These must not change: Revit matches shared "
                          "parameters by GUID, so editing one orphans every "
                          "value already written with it."),
        "parameters": dict(guids),
        "definitions": [spec.as_dict() for spec in SCHEMA],
    }
    folder = os.path.dirname(os.path.abspath(path))
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    with io.open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    return path


# ---------------------------------------------------------------------------
# shared-parameter file
# ---------------------------------------------------------------------------

# Revit's shared parameter file is a tab-separated text format. Writing it
# ourselves keeps the GUIDs under our control and avoids touching any existing
# office file.
DATATYPE_TOKEN = {
    TEXT: "TEXT",
    INTEGER: "INTEGER",
    YESNO: "YESNO",
    AREA: "AREA",
    NUMBER: "NUMBER",
    LENGTH: "LENGTH",
}

GROUP_ID = 1


def build_shared_parameter_file(guids=None):
    """Full text of a Revit shared-parameter file for the DZ schema."""
    guids = guids or dict((s.name, str(s.guid)) for s in SCHEMA)
    lines = [
        "# This is a Revit shared parameter file.",
        "# Do not edit manually.",
        "*META\tVERSION\tMINVERSION",
        "META\t2\t1",
        "*GROUP\tID\tNAME",
        "GROUP\t%d\t%s" % (GROUP_ID, GROUP_NAME),
        "*PARAM\tGUID\tNAME\tDATATYPE\tDATACATEGORY\tGROUP\tVISIBLE\tDESCRIPTION\tUSERMODIFIABLE\tHIDEWHENNOVALUE",
    ]
    for spec in SCHEMA:
        lines.append("PARAM\t%s\t%s\t%s\t\t%d\t1\t%s\t1\t0" % (
            guids[spec.name], spec.name, DATATYPE_TOKEN[spec.data_type],
            GROUP_ID, spec.description))
    return "\n".join(lines) + "\n"


def write_shared_parameter_file(path, guids=None):
    folder = os.path.dirname(os.path.abspath(path))
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    with io.open(path, "w", encoding="utf-8") as handle:
        handle.write(build_shared_parameter_file(guids))
    return path


def parse_shared_parameter_file(text):
    """Read back a shared-parameter file. Returns {name: (guid, datatype)}."""
    found = {}
    for line in (text or "").splitlines():
        if not line.startswith("PARAM\t"):
            continue
        parts = line.split("\t")
        if len(parts) < 4:
            continue
        found[parts[2]] = (parts[1], parts[3])
    return found


# ---------------------------------------------------------------------------
# conflict detection
# ---------------------------------------------------------------------------

def compare_existing(observed):
    """Compare the document's existing definitions with the schema.

    `observed` is {name: {"guid":..., "dataType":..., "categories":[...]}} as
    read from Revit. Returns (reusable, conflicts).
    """
    reusable, conflicts = [], []
    for spec in SCHEMA:
        current = (observed or {}).get(spec.name)
        if current is None:
            continue
        stored_guid = str(current.get("guid") or "").lower()
        wanted_guid = str(spec.guid).lower()
        if stored_guid and stored_guid != wanted_guid:
            conflicts.append(
                "%s already exists with GUID %s but the DZ schema expects %s. "
                "Revit matches shared parameters by GUID, so reusing it would "
                "silently attach DZ values to a different parameter."
                % (spec.name, current.get("guid"), spec.guid))
            continue
        stored_type = current.get("dataType")
        if stored_type and stored_type != spec.data_type:
            conflicts.append(
                "%s already exists as %s but the DZ schema requires %s."
                % (spec.name, stored_type, spec.data_type))
            continue
        reusable.append(spec.name)
    return reusable, conflicts
