"""Build the readable Publish Plan that must be inspected before publishing.

The plan decides every CREATE / REUSE / UPDATE / SKIP before a Revit
transaction is opened, so publishing becomes execution of an already-reviewed
decision rather than improvisation.
"""

from . import COORDINATE_MODE, COORDINATE_WARNING, PUBLISH_MODES
from . import naming
from .models import FloorRequest, LevelRequest
from .validation import ELEVATION_MATCH_TOLERANCE_M


class PublishPlan(object):
    def __init__(self, building, identity, floor_type=None,
                 publish_mode="Preview Only", coordinate_mode=COORDINATE_MODE):
        self.building = building
        self.identity = dict(identity or {})
        self.floor_type = floor_type
        self.publish_mode = publish_mode
        self.coordinate_mode = coordinate_mode
        self.levels = []
        self.floors = []
        self.warnings = []
        self.blocking = []
        self.notes = []
        self.tracking_method = None

    # -- summaries -------------------------------------------------------
    @property
    def publish_ready(self):
        return (not self.blocking
                and self.publish_mode in ("Create New", "Update Existing")
                and bool(self.floor_type))

    def counts(self):
        def tally(items):
            out = {}
            for item in items:
                out[item.action] = out.get(item.action, 0) + 1
            return out
        return {"levels": tally(self.levels), "floors": tally(self.floors)}

    def render(self):
        """The human-readable plan shown before anything is written."""
        building = self.building
        lines = []
        lines.append("PHASE 7A PUBLISH PLAN")
        lines.append("=" * 62)
        lines.append("Project         : %s" % self.identity.get("projectId"))
        lines.append("Option          : %s" % self.identity.get("option"))
        lines.append("Revision        : %s" % self.identity.get("revision"))
        if building is not None:
            lines.append("Building        : %s" % building.describe())
            lines.append("SourceId        : %s" % building.source_id)
        lines.append("Coordinate Mode : %s" % self.coordinate_mode)
        lines.append("Floor Type      : %s" % (self.floor_type or "NOT SELECTED"))
        lines.append("Publish Mode    : %s" % self.publish_mode)
        lines.append("")

        lines.append("Levels:")
        if self.levels:
            for level in self.levels:
                detail = ""
                if level.action == "REUSE" and level.existing_name:
                    detail = "  (existing '%s' id %s)" % (level.existing_name,
                                                          level.element_id)
                elif level.note:
                    detail = "  (%s)" % level.note
                lines.append("%-7s %-22s %8.3f m%s"
                             % (level.action, level.name,
                                float(level.elevation or 0.0), detail))
        else:
            lines.append("  none")
        lines.append("")

        lines.append("Floors:")
        if self.floors:
            for floor in self.floors:
                detail = ""
                if floor.element_id:
                    detail = "  (existing id %s)" % floor.element_id
                elif floor.note:
                    detail = "  (%s)" % floor.note
                lines.append("%-7s %-12s Level %-22s %9.2f m2%s"
                             % (floor.action, floor.mark, floor.level_name,
                                float(floor.plate_area or 0.0), detail))
        else:
            lines.append("  none")
        lines.append("")

        lines.append("Warnings:")
        warnings = list(self.warnings)
        if COORDINATE_WARNING not in warnings:
            warnings.insert(0, COORDINATE_WARNING)
        if self.tracking_method:
            warnings.append(self.tracking_method)
        for warning in warnings:
            lines.append("  - %s" % warning)
        if self.blocking:
            lines.append("")
            lines.append("Blocking:")
            for item in self.blocking:
                lines.append("  - %s" % item)
        lines.append("")
        lines.append("Publish Ready: %s" % ("YES" if self.publish_ready else "NO"))
        return "\n".join(lines)

    def as_dict(self):
        return {
            "ProjectId": self.identity.get("projectId"),
            "Option": self.identity.get("option"),
            "Revision": self.identity.get("revision"),
            "BuildingId": self.building.building_id if self.building else None,
            "BuildingName": self.building.building_name if self.building else None,
            "BuildingSourceId": self.building.source_id if self.building else None,
            "CoordinateMode": self.coordinate_mode,
            "FloorType": self.floor_type,
            "PublishMode": self.publish_mode,
            "Levels": [level.as_dict() for level in self.levels],
            "Floors": [floor.as_dict() for floor in self.floors],
            "Warnings": list(self.warnings),
            "Blocking": list(self.blocking),
            "TrackingMethod": self.tracking_method,
            "PublishReady": self.publish_ready,
            "Counts": self.counts(),
        }


def _match_existing_level(name, elevation, existing_levels):
    """Find a level to reuse, by name first then by elevation within tolerance."""
    if not existing_levels:
        return None, None
    for level in existing_levels:
        if str(level.get("Name")) == name:
            return level, "name"
    for level in existing_levels:
        current = level.get("Elevation")
        if current is None or elevation is None:
            continue
        if abs(float(current) - float(elevation)) <= ELEVATION_MATCH_TOLERANCE_M:
            return level, "elevation"
    return None, None


def build_plan(building, identity, context=None, floor_type=None,
               publish_mode="Preview Only", existing_floor_keys=None,
               tracking_method=None):
    """Decide every Level and Floor action before Revit is touched.

    `existing_floor_keys` maps a floor key to the ElementId of a Floor this
    workflow published earlier. That is what makes a second identical publish a
    no-op instead of a duplicate.
    """
    plan = PublishPlan(building, identity, floor_type, publish_mode)
    plan.tracking_method = tracking_method

    if publish_mode not in PUBLISH_MODES:
        plan.blocking.append("Unknown publish mode %r. Expected one of: %s"
                             % (publish_mode, ", ".join(PUBLISH_MODES)))
        return plan
    if building is None:
        plan.blocking.append("No building selected.")
        return plan

    existing_levels = list(context.levels) if context and context.levels else []
    existing_floor_keys = dict(existing_floor_keys or {})

    # -- levels ----------------------------------------------------------
    planned_elevations = []
    for floor in building.floors:
        elevation = floor.elevation
        name = naming.level_name(building.building_id, floor.level_name,
                                 floor.floor_index)

        collapsed = None
        for done_elevation, done_name in planned_elevations:
            if (elevation is not None and done_elevation is not None
                    and abs(float(elevation) - float(done_elevation))
                    <= ELEVATION_MATCH_TOLERANCE_M):
                collapsed = done_name
                break
        if collapsed:
            request = LevelRequest(name, elevation, floor.floor_index,
                                   action="SKIP")
            request.note = ("duplicate elevation, already planned as '%s'"
                            % collapsed)
            plan.levels.append(request)
            plan.warnings.append(
                "Floor index %s shares an elevation with level '%s'; no second "
                "level will be created." % (floor.floor_index, collapsed))
            continue

        match, how = _match_existing_level(name, elevation, existing_levels)
        if match is not None:
            request = LevelRequest(name, elevation, floor.floor_index,
                                   action="REUSE",
                                   element_id=match.get("Id"),
                                   existing_name=match.get("Name"))
            if how == "elevation" and str(match.get("Name")) != name:
                request.note = ("matched by elevation; existing level '%s' "
                                "keeps its name" % match.get("Name"))
                plan.warnings.append(
                    "Level name conflict avoided: requested '%s' at %.3f m "
                    "matches existing level '%s' by elevation. The existing "
                    "level is reused and is not renamed."
                    % (name, float(elevation or 0.0), match.get("Name")))
        else:
            request = LevelRequest(name, elevation, floor.floor_index,
                                   action="CREATE")
        plan.levels.append(request)
        planned_elevations.append((elevation, name))

    level_name_by_index = {}
    for request in plan.levels:
        if request.action == "SKIP":
            # reuse the level that occupies the same elevation
            for other in plan.levels:
                if other.action == "SKIP" or other.elevation is None:
                    continue
                if abs(float(other.elevation) - float(request.elevation or 0.0)) \
                        <= ELEVATION_MATCH_TOLERANCE_M:
                    level_name_by_index[request.floor_index] = other.name
                    break
        else:
            level_name_by_index[request.floor_index] = (
                request.existing_name if request.action == "REUSE"
                and request.existing_name else request.name)

    # -- floors ----------------------------------------------------------
    for floor in building.floors:
        try:
            key = floor.key()
        except ValueError as exc:
            request = FloorRequest(
                naming.floor_mark(building.building_id, floor.floor_index or 0),
                floor.floor_index, floor.elevation, "", "",
                floor.plate_area, action="ERROR")
            request.error = str(exc)
            plan.floors.append(request)
            plan.blocking.append("Floor key could not be built: %s" % exc)
            continue

        mark = naming.floor_mark(building.building_id, floor.floor_index)
        level_for_floor = level_name_by_index.get(floor.floor_index, "")
        existing_id = existing_floor_keys.get(key)

        if existing_id is not None:
            if publish_mode == "Update Existing":
                action, note = "UPDATE", "existing Phase 7A floor with this key"
            else:
                action, note = "SKIP", "already published with this key"
        else:
            action, note = "CREATE", None

        request = FloorRequest(mark, floor.floor_index, floor.elevation,
                               level_for_floor, key, floor.plate_area,
                               action=action, element_id=existing_id, note=note)
        plan.floors.append(request)

    if not floor_type:
        plan.blocking.append("No Floor Type selected.")
    if publish_mode == "Preview Only":
        plan.notes.append("Preview Only: nothing will be written to Revit.")

    return plan
