"""Publish log written into the selected Phase 6A export package.

Logs go to `<package>/revit_publish/` as JSON and CSV. Existing logs are never
overwritten: each run appends a timestamped entry to the history file and
refreshes the "latest" pair.
"""

import csv
import datetime
import io
import json
import os

from . import (COORDINATE_MODE, DEFINITION_PHASE, PUBLISH_STATUSES,
               __version__)

LOG_FOLDER = "revit_publish"
JSON_NAME = "phase07a_publish_log.json"
CSV_NAME = "phase07a_publish_log.csv"

CSV_COLUMNS = [
    "PublishTimestamp", "PublishStatus", "PublishMode", "ProjectId", "Option",
    "Revision", "BuildingId", "BuildingSourceId", "CoordinateMode", "FloorType",
    "ElementKind", "RequestedName", "RequestedElevation", "FloorIndex",
    "FloorKey", "Action", "ElementId", "ExpectedPlateArea", "PublishedArea",
    "AreaDifference", "AreaDifferenceRatio", "Note", "Error",
]


def iso_now():
    return datetime.datetime.now().replace(microsecond=0).isoformat()


def log_folder(package):
    return os.path.join(package, LOG_FOLDER)


def build_entry(status, plan, context, manifest_path, manifest_sha256,
                identity, geometry_source=None, unit_summary=None,
                validation=None, transaction_result=None, errors=None,
                warnings=None, tracking_method=None, publish_mode=None,
                geometry_facts=None):
    """Assemble one complete publish-log entry."""
    if status not in PUBLISH_STATUSES:
        status = "FAILED"

    levels = plan.levels if plan else []
    floors = plan.floors if plan else []

    def count(items, action):
        return len([i for i in items if i.action == action])

    building = plan.building if plan else None

    entry = {
        "PublishTimestamp": iso_now(),
        "PublisherVersion": __version__,
        "DefinitionPhase": DEFINITION_PHASE,
        "PublishStatus": status,
        "PublishMode": publish_mode or (plan.publish_mode if plan else None),
        "ManifestPath": manifest_path,
        "ManifestSha256": manifest_sha256,
        "RevitDocumentName": context.document_name if context else None,
        "RevitDocumentPath": context.document_path if context else None,
        "RevitVersion": context.revit_version if context else None,
        "RevitBuild": context.revit_build if context else None,
        "RhinoInsideRevitVersion": context.rir_version if context else None,
        "RhinoVersion": context.rhino_version if context else None,
        "ProjectId": identity.get("projectId") if identity else None,
        "Option": identity.get("option") if identity else None,
        "Revision": identity.get("revision") if identity else None,
        "BuildingId": building.building_id if building else None,
        "BuildingName": building.building_name if building else None,
        "BuildingSourceId": building.source_id if building else None,
        "CoordinateMode": plan.coordinate_mode if plan else COORDINATE_MODE,
        "FloorType": plan.floor_type if plan else None,
        "GeometrySource": geometry_source,
        "GeometryFacts": geometry_facts,
        "UnitConversion": list(unit_summary or []),
        "TrackingMethod": tracking_method,

        "LevelsRequested": len(levels),
        "LevelsCreated": count(levels, "CREATE"),
        "LevelsReused": count(levels, "REUSE"),
        "LevelsSkipped": count(levels, "SKIP"),
        "LevelsFailed": count(levels, "ERROR"),

        "FloorsRequested": len(floors),
        "FloorsCreated": count(floors, "CREATE"),
        "FloorsUpdated": count(floors, "UPDATE"),
        "FloorsSkipped": count(floors, "SKIP"),
        "FloorsFailed": count(floors, "ERROR"),

        "LevelElementIds": [l.element_id for l in levels if l.element_id],
        "FloorElementIds": [f.element_id for f in floors if f.element_id],

        "Levels": [level.as_dict() for level in levels],
        "Floors": [floor.as_dict() for floor in floors],

        "ValidationChecks": (validation or {}).get("checks", []),
        "TransactionResult": transaction_result,
        "Warnings": list(warnings or []),
        "Errors": list(errors or []),
    }
    return entry


def _csv_rows(entry):
    common = {
        "PublishTimestamp": entry.get("PublishTimestamp"),
        "PublishStatus": entry.get("PublishStatus"),
        "PublishMode": entry.get("PublishMode"),
        "ProjectId": entry.get("ProjectId"),
        "Option": entry.get("Option"),
        "Revision": entry.get("Revision"),
        "BuildingId": entry.get("BuildingId"),
        "BuildingSourceId": entry.get("BuildingSourceId"),
        "CoordinateMode": entry.get("CoordinateMode"),
        "FloorType": entry.get("FloorType"),
    }
    rows = []
    for level in entry.get("Levels", []):
        row = dict(common)
        row.update({
            "ElementKind": "Level",
            "RequestedName": level.get("RequestedName"),
            "RequestedElevation": level.get("RequestedElevation"),
            "FloorIndex": level.get("FloorIndex"),
            "Action": level.get("Action"),
            "ElementId": level.get("ElementId"),
            "Note": level.get("Note"),
            "Error": level.get("Error"),
        })
        rows.append(row)
    for floor in entry.get("Floors", []):
        row = dict(common)
        row.update({
            "ElementKind": "Floor",
            "RequestedName": floor.get("Mark"),
            "RequestedElevation": floor.get("Elevation"),
            "FloorIndex": floor.get("FloorIndex"),
            "FloorKey": floor.get("FloorKey"),
            "Action": floor.get("Action"),
            "ElementId": floor.get("ElementId"),
            "ExpectedPlateArea": floor.get("ExpectedPlateArea"),
            "PublishedArea": floor.get("PublishedArea"),
            "AreaDifference": floor.get("AreaDifference"),
            "AreaDifferenceRatio": floor.get("AreaDifferenceRatio"),
            "Note": floor.get("Note"),
            "Error": floor.get("Error"),
        })
        rows.append(row)
    if not rows:
        rows.append(dict(common, ElementKind="None"))
    return rows


def write(package, entry):
    """Write the JSON history and CSV log. Returns the two paths."""
    folder = log_folder(package)
    if not os.path.isdir(folder):
        os.makedirs(folder)

    json_path = os.path.join(folder, JSON_NAME)
    history = {"schemaVersion": "1.0", "phase": DEFINITION_PHASE, "entries": []}
    if os.path.isfile(json_path):
        try:
            with io.open(json_path, "r", encoding="utf-8") as handle:
                existing = json.load(handle)
            if isinstance(existing, dict) and isinstance(existing.get("entries"),
                                                         list):
                history = existing
        except Exception:
            # A corrupt log must not stop publishing; keep it as a sibling.
            backup = json_path + ".unreadable-%s" % datetime.datetime.now().strftime(
                "%Y%m%d_%H%M%S")
            try:
                os.rename(json_path, backup)
            except OSError:
                pass
    history.setdefault("entries", []).append(entry)
    history["latest"] = entry
    with io.open(json_path, "w", encoding="utf-8") as handle:
        json.dump(history, handle, ensure_ascii=False, indent=2)

    csv_path = os.path.join(folder, CSV_NAME)
    write_header = not os.path.isfile(csv_path)
    with io.open(csv_path, "a", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS,
                                extrasaction="ignore")
        if write_header:
            writer.writeheader()
        for row in _csv_rows(entry):
            writer.writerow({key: ("" if row.get(key) is None else row.get(key))
                             for key in CSV_COLUMNS})

    return json_path, csv_path


def read_history(package):
    json_path = os.path.join(log_folder(package), JSON_NAME)
    if not os.path.isfile(json_path):
        return {"entries": []}
    with io.open(json_path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def published_floor_keys(package, building_source_id=None,
                         document_name=None):
    """Floor keys this workflow has already published successfully.

    Used as a fallback duplicate guard when the Revit document cannot be
    queried. The authoritative check is always the live Revit query.
    """
    keys = {}
    history = read_history(package)
    for entry in history.get("entries", []):
        if entry.get("PublishStatus") not in ("PUBLISHED",
                                              "PUBLISHED WITH WARNINGS"):
            continue
        if (building_source_id
                and entry.get("BuildingSourceId") != building_source_id):
            continue
        if document_name and entry.get("RevitDocumentName") != document_name:
            continue
        for floor in entry.get("Floors", []):
            if floor.get("Action") in ("CREATE", "UPDATE") and floor.get("ElementId"):
                keys[floor.get("FloorKey")] = floor.get("ElementId")
    return keys
