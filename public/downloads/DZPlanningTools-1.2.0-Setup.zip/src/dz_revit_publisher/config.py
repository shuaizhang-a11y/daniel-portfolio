"""Resolved paths for the publish engine.

The Phase 7 component hard-coded these. They became overridable module
attributes in 8B, and in **8G the hard-coded developer path was removed
entirely**: the default root is now derived from this file's own location, so
the engine works wherever it is installed.

`executor.py` reads `SHARED_PARAMETER_FILE` directly at write time, which is
why these stay module attributes rather than becoming a passed object - the
protected engine is not changed by installability work.

`dz_planning_app.settings` is the authoritative resolution layer and calls
:func:`configure` at launch. This module deliberately does **not** import it:
the publisher must not depend on the application layer above it.
"""

import os


def _default_root():
    """The installation root, from this file's location.

    ``<root>/src/dz_revit_publisher/config.py`` -> ``<root>``. Never a literal
    path, so no installation inherits the machine it was built on.
    """
    here = os.path.abspath(__file__)
    return os.path.dirname(os.path.dirname(os.path.dirname(here)))


PROJECT_ROOT = _default_root()

EXPORTS_ROOT = os.path.join(PROJECT_ROOT, "Exports")
CONFIG_ROOT = os.path.join(PROJECT_ROOT, "config")
SHARED_PARAMETER_FILE = os.path.join(CONFIG_ROOT,
                                     "DZ_Planning_SharedParameters.txt")
SHARED_PARAMETER_REGISTRY = os.path.join(CONFIG_ROOT,
                                         "dz_shared_parameters.json")
DEFAULT_SOURCE_3DM = os.path.join(PROJECT_ROOT,
                                  "DZ_Planning_Phase05D_Parking_Source.3dm")


def configure(project_root=None, shared_parameter_file=None,
              shared_parameter_registry=None, exports_root=None,
              default_source_3dm=None):
    """Point the engine at a different installation. Used from 8G onward."""
    global PROJECT_ROOT, EXPORTS_ROOT, CONFIG_ROOT
    global SHARED_PARAMETER_FILE, SHARED_PARAMETER_REGISTRY, DEFAULT_SOURCE_3DM
    if project_root:
        PROJECT_ROOT = project_root
        EXPORTS_ROOT = os.path.join(project_root, "Exports")
        CONFIG_ROOT = os.path.join(project_root, "config")
        SHARED_PARAMETER_FILE = os.path.join(
            CONFIG_ROOT, "DZ_Planning_SharedParameters.txt")
        SHARED_PARAMETER_REGISTRY = os.path.join(
            CONFIG_ROOT, "dz_shared_parameters.json")
        DEFAULT_SOURCE_3DM = os.path.join(
            project_root, "DZ_Planning_Phase05D_Parking_Source.3dm")
    if shared_parameter_file:
        SHARED_PARAMETER_FILE = shared_parameter_file
    if shared_parameter_registry:
        SHARED_PARAMETER_REGISTRY = shared_parameter_registry
    if exports_root:
        EXPORTS_ROOT = exports_root
    if default_source_3dm:
        DEFAULT_SOURCE_3DM = default_source_3dm


def as_dict():
    return {
        "ProjectRoot": PROJECT_ROOT,
        "ExportsRoot": EXPORTS_ROOT,
        "ConfigRoot": CONFIG_ROOT,
        "SharedParameterFile": SHARED_PARAMETER_FILE,
        "SharedParameterRegistry": SHARED_PARAMETER_REGISTRY,
        "DefaultSource3dm": DEFAULT_SOURCE_3DM,
    }
