"""The Revit bridge: every Revit API call the publish engine makes.

Extracted verbatim from the validated Phase 7C component. The Revit assemblies
are loaded inside :meth:`Bridge.__init__`, and Rhino only inside
:func:`_rhino_version`, so this module imports cleanly with neither installed -
which is what keeps the offline suite runnable.
"""

from . import identity, shared_parameters, snapshot
from . import unit_conversion as uc
from .models import RevitContext
from .parameter_carry import ParameterCarryMixin


def _rhino_version():
    """Rhino is optional; the bridge still reports a context without it."""
    try:
        import Rhino
        return str(Rhino.RhinoApp.Version)
    except Exception:
        return None


class Bridge(ParameterCarryMixin):
    CATEGORY_MAP = {
        shared_parameters.LEVELS: "OST_Levels",
        shared_parameters.FLOORS: "OST_Floors",
        shared_parameters.AREAS: "OST_Areas",
        shared_parameters.PROJECT_INFO: "OST_ProjectInformation",
    }

    def __init__(self):
        self.available = False
        self.error = None
        self.DB = None
        self.doc = None
        self.app = None
        self.rir_version = None
        try:
            import clr
            clr.AddReference("RevitAPI")
            import Autodesk.Revit.DB as DB
            self.DB = DB
        except Exception as exc:
            self.error = ("Revit API not available (%s: %s)."
                          % (type(exc).__name__, exc))
            return
        try:
            import System
            import RhinoInside.Revit as RIR
            self.doc = RIR.Revit.ActiveDBDocument
            self.app = RIR.Revit.ActiveDBApplication
            self.rir_version = str(
                System.Reflection.Assembly.GetAssembly(RIR.Revit).GetName().Version)
        except Exception as exc:
            self.error = "Rhino.Inside.Revit not loaded (%s: %s)." % (
                type(exc).__name__, exc)
            return
        if self.doc is None:
            self.error = "No active Revit document."
            return
        self.available = True

    @staticmethod
    def _id(element_id):
        try:
            return element_id.IntegerValue
        except Exception:
            return int(element_id.Value)

    def invoke_in_host_context(self, action):
        try:
            import clr
            import System
            assemblies = [a for a in System.AppDomain.CurrentDomain.GetAssemblies()
                          if a.GetName().Name == "RhinoInside.Revit.External"]
            if not assemblies:
                return False, "RhinoInside.Revit.External not loaded."
            hosted = assemblies[0].GetType(
                "RhinoInside.Revit.External.UI.HostedApplication")
            active = hosted.GetProperty("Active").GetValue(None)
            interface = assemblies[0].GetType(
                "RhinoInside.Revit.External.UI.IHostedApplication")
            method = interface.GetMethod(
                "InvokeInHostContext",
                System.Array[System.Type]([clr.GetClrType(System.Action)]))
            method.Invoke(active,
                          System.Array[System.Object]([System.Action(action)]))
            return True, None
        except Exception as exc:
            return False, "%s: %s" % (type(exc).__name__, exc)

    def category(self, key):
        return self.doc.Settings.Categories.get_Item(
            getattr(self.DB.BuiltInCategory, self.CATEGORY_MAP[key]))

    def spec_for(self, data_type):
        DB = self.DB
        return {
            shared_parameters.TEXT: DB.SpecTypeId.String.Text,
            shared_parameters.INTEGER: DB.SpecTypeId.Int.Integer,
            shared_parameters.YESNO: DB.SpecTypeId.Boolean.YesNo,
            shared_parameters.AREA: DB.SpecTypeId.Area,
            shared_parameters.NUMBER: DB.SpecTypeId.Number,
            shared_parameters.LENGTH: DB.SpecTypeId.Length,
        }[data_type]

    # -- reading -----------------------------------------------------------
    def read(self, element, name):
        DB = self.DB
        parameter = element.LookupParameter(name)
        if parameter is None:
            return None
        try:
            storage = parameter.StorageType
            if storage == DB.StorageType.String:
                return parameter.AsString()
            if storage == DB.StorageType.Integer:
                return parameter.AsInteger()
            if storage == DB.StorageType.Double:
                return parameter.AsDouble()
        except Exception:
            return None
        return None

    def write(self, element, name, value, data_type):
        """Type-aware write. Returns (changed, previous, error)."""
        if value is None:
            return False, None, "value is null"
        parameter = element.LookupParameter(name)
        if parameter is None:
            return False, None, "parameter not bound"
        if parameter.IsReadOnly:
            return False, None, "read-only"
        DB = self.DB
        try:
            if data_type == shared_parameters.AREA:
                target = float(uc.square_metres_to_internal_area(float(value)))
                previous = parameter.AsDouble()
                if abs(previous - target) < 1e-9:
                    return False, previous, None
                parameter.Set(target)
            elif data_type == shared_parameters.LENGTH:
                target = float(uc.metres_to_internal(float(value)))
                previous = parameter.AsDouble()
                if abs(previous - target) < 1e-9:
                    return False, previous, None
                parameter.Set(target)
            elif data_type == shared_parameters.YESNO:
                target = 1 if bool(value) else 0
                previous = parameter.AsInteger()
                if previous == target:
                    return False, previous, None
                parameter.Set(target)
            elif data_type == shared_parameters.INTEGER:
                target = int(value)
                previous = parameter.AsInteger()
                if previous == target:
                    return False, previous, None
                parameter.Set(target)
            elif data_type == shared_parameters.NUMBER:
                target = float(value)
                previous = parameter.AsDouble()
                if abs(previous - target) < 1e-12:
                    return False, previous, None
                parameter.Set(target)
            else:
                target = str(value)
                previous = parameter.AsString()
                if previous == target:
                    return False, previous, None
                parameter.Set(target)
            return True, previous, None
        except Exception as exc:
            return False, None, "%s: %s" % (type(exc).__name__, exc)

    def apply(self, element, values, allowed):
        """Write a value map. Returns (changed_names, skipped)."""
        changed, skipped = [], []
        for name, value in values.items():
            if name not in allowed:
                continue
            spec = shared_parameters.BY_NAME.get(name)
            if spec is None:
                continue
            did, _previous, error = self.write(element, name, value,
                                               spec.data_type)
            if did:
                changed.append(name)
            elif error:
                skipped.append("%s (%s)" % (name, error))
        return changed, skipped

    def context(self):
        if not self.available:
            return RevitContext(available=False,
                                notes=[self.error] if self.error else [])
        DB, doc = self.DB, self.doc
        version = build = None
        try:
            version = str(self.app.VersionNumber)
            build = str(self.app.VersionBuild)
        except Exception:
            pass
        bound = []
        try:
            iterator = doc.ParameterBindings.ForwardIterator(); iterator.Reset()
            while iterator.MoveNext():
                bound.append(iterator.Key.Name)
        except Exception:
            pass
        return RevitContext(
            available=True, revit_version=version, revit_build=build,
            rir_version=self.rir_version,
            rhino_version=_rhino_version(),
            document_name=doc.Title, document_path=doc.PathName or None,
            is_writable=not doc.IsReadOnly, is_workshared=doc.IsWorkshared,
            is_family=doc.IsFamilyDocument, in_transaction=bool(doc.IsModifiable),
            shared_parameters=sorted(set(bound)))

    # Elements that ride along with a level but are not relocatable project
    # geometry: the Area Plan views DZ creates, and the area boundary lines
    # that belong to them. Neither carries a DZ parameter, so without this the
    # foreign-content guard would refuse every legitimate elevation change.
    LEVEL_HOST_IGNORED = ("OST_AreaSchemeLines", "OST_Views", "OST_Viewers",
                          "OST_Levels", "OST_Grids", "OST_SketchLines",
                          "OST_CLines")

    # Parameters that must never be copied onto a replacement element.

    # -- geometry ----------------------------------------------------------
    def curve_loop(self, points_metres, elevation_metres):
        """A closed Revit CurveLoop, in internal units, at one elevation."""
        DB = self.DB
        ring = snapshot.normalise_loop(points_metres)
        if len(ring) < 3:
            raise ValueError("A boundary needs at least three distinct points.")
        z = uc.metres_to_internal(elevation_metres or 0.0)
        vertices = [DB.XYZ(uc.metres_to_internal(x), uc.metres_to_internal(y), z)
                    for x, y in ring]
        loop = DB.CurveLoop()
        for index in range(len(vertices)):
            start = vertices[index]
            end = vertices[(index + 1) % len(vertices)]
            if start.DistanceTo(end) < uc.REVIT_SHORT_CURVE_TOLERANCE_FEET:
                raise ValueError(
                    "Boundary segment %d is shorter than Revit's short-curve "
                    "tolerance." % index)
            loop.Append(DB.Line.CreateBound(start, end))
        return loop, ring

    def loop_points(self, curves):
        """Metre-space points for a set of boundary curves, in ring order."""
        segments = []
        for curve in curves:
            a = curve.GetEndPoint(0)
            b = curve.GetEndPoint(1)
            segments.append(((uc.internal_to_metres(a.X), uc.internal_to_metres(a.Y)),
                             (uc.internal_to_metres(b.X), uc.internal_to_metres(b.Y))))
        if not segments:
            return None
        ordered = [segments[0][0], segments[0][1]]
        remaining = list(segments[1:])
        guard = len(remaining) + 1
        while remaining and guard:
            guard -= 1
            tail = ordered[-1]
            for candidate in list(remaining):
                for a, b in (candidate, (candidate[1], candidate[0])):
                    if abs(a[0] - tail[0]) < 1e-6 and abs(a[1] - tail[1]) < 1e-6:
                        ordered.append(b)
                        remaining.remove(candidate)
                        break
                else:
                    continue
                break
        if remaining:
            return None                      # not a single closed ring
        return ordered

    def boundary_loops(self, view):
        """DZ area-scheme lines in one view, grouped into closed loops."""
        DB, doc = self.DB, self.doc
        lines = DB.FilteredElementCollector(doc, view.Id)\
            .OfCategory(DB.BuiltInCategory.OST_AreaSchemeLines)\
            .WhereElementIsNotElementType().ToElements()
        pool = []
        for line in lines:
            try:
                pool.append((line, line.GeometryCurve))
            except Exception:
                continue
        loops = []
        while pool:
            seed = pool.pop(0)
            group = [seed]
            changed = True
            while changed:
                changed = False
                points = self.loop_points([c for _e, c in group])
                ends = set()
                for _e, curve in group:
                    for index in (0, 1):
                        p = curve.GetEndPoint(index)
                        ends.add((round(p.X, 6), round(p.Y, 6)))
                for candidate in list(pool):
                    curve = candidate[1]
                    hit = False
                    for index in (0, 1):
                        p = curve.GetEndPoint(index)
                        if (round(p.X, 6), round(p.Y, 6)) in ends:
                            hit = True
                    if hit:
                        group.append(candidate)
                        pool.remove(candidate)
                        changed = True
            points = self.loop_points([c for _e, c in group])
            loops.append({
                "elements": [e for e, _c in group],
                "points": points,
                "hash": snapshot.boundary_hash(points) if points else None,
                "count": len(group),
            })
        return loops

    def binding_is_current(self, existing, category_keys):
        """True when an identical instance binding is already in place.

        Re-inserting an identical binding still modifies the document, so an
        all-SKIP publish would dirty the model for no reason.
        """
        DB = self.DB
        if existing is None:
            return False
        try:
            if not isinstance(existing, DB.InstanceBinding):
                return False          # a type binding must be replaced
        except Exception:
            return False
        try:
            have = set(self._id(c.Id) for c in existing.Categories)
            want = set(self._id(self.category(k).Id) for k in category_keys)
        except Exception:
            return False
        return have == want

    def category_name(self, element):
        try:
            return element.Category.Name if element.Category else "(no category)"
        except Exception:
            return "(unknown)"

    def is_foreign_host(self, element, building_id):
        """True when moving the host level would relocate someone else's work."""
        DB = self.DB
        try:
            if isinstance(element, DB.View) or isinstance(element, DB.Level):
                return False
        except Exception:
            pass
        category = None
        try:
            category = element.Category
        except Exception:
            return False
        if category is None:
            return False                     # sketch and internal elements
        try:
            for token in self.LEVEL_HOST_IGNORED:
                builtin = getattr(DB.BuiltInCategory, token, None)
                if builtin is not None and \
                        self._id(category.Id) == int(builtin):
                    return False
        except Exception:
            pass
        try:
            if category.CategoryType != DB.CategoryType.Model:
                return False                 # annotation, view, analytical
        except Exception:
            pass
        return self.read(element, "DZ_Building_ID") != building_id

    # -- observation --------------------------------------------------------
    def observe_floors(self, building):
        DB, doc = self.DB, self.doc
        M2 = uc.SQ_METRES_PER_SQ_FOOT
        rows = []
        for floor in DB.FilteredElementCollector(doc).OfClass(DB.Floor)\
                .WhereElementIsNotElementType().ToElements():
            level = doc.GetElement(floor.LevelId)
            computed = floor.get_Parameter(DB.BuiltInParameter.HOST_AREA_COMPUTED)
            comments = floor.LookupParameter("Comments")
            gfa = self.read(floor, "DZ_Physical_GFA")
            elevation_param = self.read(floor, "DZ_Floor_Elevation")
            rows.append({
                "ElementId": self._id(floor.Id),
                "DZ_Floor_Key": self.read(floor, "DZ_Floor_Key"),
                "DZ_Source_ID": self.read(floor, "DZ_Source_ID"),
                "DZ_Building_ID": self.read(floor, "DZ_Building_ID"),
                "DZ_Floor_Index": self.read(floor, "DZ_Floor_Index"),
                # 0.0 is a real elevation (level 1 sits on it), so the test is
                # "is it stored at all", never "is it truthy".
                "DZ_Floor_Elevation": uc.internal_to_metres(elevation_param)
                if elevation_param is not None else None,
                "DZ_Physical_GFA": (gfa * M2) if gfa is not None else None,
                "DZ_Boundary_Hash": self.read(floor, "DZ_Boundary_Hash"),
                "DZ_Program": self.read(floor, "DZ_Program"),
                "DZ_Publish_Status": self.read(floor, "DZ_Publish_Status"),
                "DZ_FSR_Included": self.read(floor, "DZ_FSR_Included"),
                "DZ_Source_Revision": self.read(floor, "DZ_Source_Revision"),
                "DZ_Manifest_SHA256": self.read(floor, "DZ_Manifest_SHA256"),
                "Comments": comments.AsString() if comments else None,
                "Elevation": uc.internal_to_metres(level.Elevation) if level else None,
                "Area": computed.AsDouble() * M2 if computed else None,
                "LevelId": self._id(floor.LevelId) if floor.LevelId else None,
            })
        return rows

    def observe_areas(self):
        DB, doc = self.DB, self.doc
        M2 = uc.SQ_METRES_PER_SQ_FOOT
        rows = []
        for area in DB.FilteredElementCollector(doc)\
                .OfCategory(DB.BuiltInCategory.OST_Areas)\
                .WhereElementIsNotElementType().ToElements():
            rows.append({
                "ElementId": self._id(area.Id),
                "DZ_Floor_Key": self.read(area, "DZ_Floor_Key"),
                "DZ_Floor_Index": self.read(area, "DZ_Floor_Index"),
                "DZ_Building_ID": self.read(area, "DZ_Building_ID"),
                "DZ_Publish_Status": self.read(area, "DZ_Publish_Status"),
                "Area": area.Area * M2,
                "LevelId": self._id(area.LevelId) if area.LevelId else None,
            })
        return rows

    def observe_levels(self, building_id):
        DB, doc = self.DB, self.doc
        rows = []
        for level in DB.FilteredElementCollector(doc).OfClass(DB.Level).ToElements():
            rows.append({
                "ElementId": self._id(level.Id), "Name": level.Name,
                "Elevation": uc.internal_to_metres(level.Elevation),
                "DZ_Building_ID": self.read(level, "DZ_Building_ID"),
            })
        return rows
