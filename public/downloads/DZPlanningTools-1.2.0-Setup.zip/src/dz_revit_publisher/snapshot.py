"""Deterministic source snapshots and the normalised boundary hash.

The boundary hash must be stable against things that are not real changes and
sensitive to things that are. It is therefore computed from a *normalised*
loop:

* vertices are snapped to a 1 mm grid, so floating-point noise cannot alter it
* the closing duplicate vertex is dropped
* winding is forced counter-clockwise, so a reversed curve hashes the same
* the loop is rotated to start at its lexicographically smallest vertex, so a
  different curve start point hashes the same

Only the geometry itself decides the hash, never Rhino object ordering.
"""

import hashlib
import json

# 1 mm. Below this, a difference is noise rather than a design change.
GRID_M = 0.001
DECIMALS = 3


def _snap(value):
    if value is None:
        return 0.0
    snapped = round(float(value) / GRID_M) * GRID_M
    snapped = round(snapped, DECIMALS)
    return 0.0 if snapped == 0 else snapped


def _drop_closing_vertex(points):
    pts = [tuple(p) for p in (points or [])]
    if len(pts) > 1:
        first, last = pts[0], pts[-1]
        if all(abs(first[i] - last[i]) <= GRID_M / 2.0
               for i in range(min(len(first), len(last)))):
            pts = pts[:-1]
    return pts


def _signed_area(points):
    total = 0.0
    for index in range(len(points)):
        x1, y1 = points[index][0], points[index][1]
        x2, y2 = points[(index + 1) % len(points)][0], points[(index + 1) % len(points)][1]
        total += (x1 * y2) - (x2 * y1)
    return total / 2.0


def normalise_loop(points):
    """Canonical XY vertex list: snapped, unclosed, CCW, smallest-vertex first."""
    pts = _drop_closing_vertex(points)
    pts = [(_snap(p[0]), _snap(p[1])) for p in pts]
    if len(pts) < 3:
        return pts
    # collapse consecutive duplicates created by snapping
    deduped = [pts[0]]
    for point in pts[1:]:
        if point != deduped[-1]:
            deduped.append(point)
    if len(deduped) > 1 and deduped[0] == deduped[-1]:
        deduped = deduped[:-1]
    pts = deduped
    if len(pts) < 3:
        return pts
    if _signed_area(pts) < 0:                 # force counter-clockwise
        pts = list(reversed(pts))
    start = min(range(len(pts)), key=lambda i: pts[i])
    return pts[start:] + pts[:start]


def boundary_hash(points):
    """SHA-256 of the normalised loop. Empty loop hashes to None."""
    loop = normalise_loop(points)
    if len(loop) < 3:
        return None
    payload = ";".join("%.3f,%.3f" % (x, y) for x, y in loop)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# snapshots
# ---------------------------------------------------------------------------

SNAPSHOT_FIELDS = ("BuildingSourceId", "BuildingId", "FloorIndex", "Elevation",
                   "FloorPlateArea", "BoundaryHash", "Program",
                   "IncludeInFSR", "ManifestRevision", "ManifestSHA256")

# Fields that describe geometry rather than metadata. A change here means the
# element has to be rebuilt, not just re-parameterised.
GEOMETRY_FIELDS = ("BoundaryHash",)
ELEVATION_FIELDS = ("Elevation",)
# Revision and hash change on every export, so they must not by themselves
# make an otherwise identical floor look modified.
VOLATILE_FIELDS = ("ManifestRevision", "ManifestSHA256")


def build(building, floor, identity, manifest_sha, points):
    """Deterministic snapshot for one floor."""
    return {
        "BuildingSourceId": building.source_id,
        "BuildingId": building.building_id,
        "FloorIndex": floor.floor_index,
        "Elevation": _snap(floor.elevation),
        "FloorPlateArea": round(float(floor.plate_area or 0.0), 4),
        "BoundaryHash": boundary_hash(points),
        "Program": building.program,
        "IncludeInFSR": bool(floor.included_in_fsr)
        if floor.included_in_fsr is not None else None,
        "ManifestRevision": identity.get("revision"),
        "ManifestSHA256": manifest_sha,
    }


def snapshot_hash(snapshot):
    """Hash of the whole snapshot, for a cheap unchanged check."""
    if not snapshot:
        return None
    payload = json.dumps(dict((k, snapshot.get(k)) for k in SNAPSHOT_FIELDS),
                         sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def compare(previous, current, elevation_tolerance=GRID_M,
            area_tolerance_ratio=0.01):
    """Field-level differences between two snapshots.

    Returns a dict with the changed field names split by consequence.
    """
    previous = previous or {}
    current = current or {}
    changed = []
    for field in SNAPSHOT_FIELDS:
        old, new = previous.get(field), current.get(field)
        if field == "Elevation":
            if old is None or new is None:
                if old != new:
                    changed.append(field)
            elif abs(float(old) - float(new)) > elevation_tolerance:
                changed.append(field)
            continue
        if field == "FloorPlateArea":
            if old in (None, 0) or new is None:
                if old != new:
                    changed.append(field)
            elif abs(float(new) - float(old)) / float(old) > area_tolerance_ratio:
                changed.append(field)
            continue
        if old != new:
            changed.append(field)

    geometry = [f for f in changed if f in GEOMETRY_FIELDS]
    elevation = [f for f in changed if f in ELEVATION_FIELDS]
    volatile = [f for f in changed if f in VOLATILE_FIELDS]
    metadata = [f for f in changed
                if f not in GEOMETRY_FIELDS and f not in ELEVATION_FIELDS
                and f not in VOLATILE_FIELDS]
    return {
        "changed": changed,
        "geometry": geometry,
        "elevation": elevation,
        "metadata": metadata,
        "volatile": volatile,
        "substantive": bool(geometry or elevation or metadata),
    }


def has_baseline(previous):
    """True when the element already carries a Phase 7C snapshot.

    A Phase 7A/7B element has no ``DZ_Boundary_Hash`` and no
    ``DZ_Floor_Elevation``. Absent is not the same as different: treating a
    missing baseline as a geometry change would rebuild an unchanged model on
    the very first Phase 7C run.

    A parameter that is bound but never written reads back as an empty string
    rather than as absent, so blank counts as no baseline too.
    """
    previous = previous or {}
    stored = previous.get("BoundaryHash")
    return stored is not None and str(stored).strip() != ""


def from_element(row):
    """Rebuild a stored snapshot from the parameters read off an element."""
    if not row:
        return None
    return {
        "BuildingSourceId": row.get("DZ_Source_ID"),
        "BuildingId": row.get("DZ_Building_ID"),
        "FloorIndex": row.get("DZ_Floor_Index"),
        "Elevation": _snap(row.get("DZ_Floor_Elevation"))
        if row.get("DZ_Floor_Elevation") is not None else None,
        "FloorPlateArea": round(float(row.get("DZ_Physical_GFA") or 0.0), 4)
        if row.get("DZ_Physical_GFA") is not None else None,
        "BoundaryHash": row.get("DZ_Boundary_Hash"),
        "Program": row.get("DZ_Program"),
        "IncludeInFSR": bool(row.get("DZ_FSR_Included"))
        if row.get("DZ_FSR_Included") is not None else None,
        "ManifestRevision": row.get("DZ_Source_Revision"),
        "ManifestSHA256": row.get("DZ_Manifest_SHA256"),
    }
