"""Schedule specifications for Phase 7B.

The Revit layer turns these into ViewSchedules. Field availability is resolved
against the live document: a field that the installed Revit cannot schedule is
reported, never silently dropped and never replaced with an invented
placeholder.
"""

FLOOR_SCHEDULE = "DZ B001 Floor Schedule"
AREA_SCHEDULE = "DZ B001 GFA Area Schedule"
SUMMARY_SCHEDULE = "DZ Planning Summary"

FLOORS_CATEGORY = "Floors"
AREAS_CATEGORY = "Areas"
PROJECT_INFO_CATEGORY = "ProjectInformation"


class ScheduleSpec(object):
    def __init__(self, name, category, fields, filter_field=None,
                 filter_value=None, sort_field=None, total_fields=(),
                 grand_total=False, itemise=True, area_scheme=None):
        self.name = name
        self.category = category
        self.fields = list(fields)
        self.filter_field = filter_field
        self.filter_value = filter_value
        self.sort_field = sort_field
        self.total_fields = list(total_fields)
        self.grand_total = grand_total
        self.itemise = itemise
        self.area_scheme = area_scheme

    def as_dict(self):
        return {
            "Name": self.name, "Category": self.category,
            "Fields": list(self.fields), "FilterField": self.filter_field,
            "FilterValue": self.filter_value, "SortField": self.sort_field,
            "TotalFields": list(self.total_fields),
            "GrandTotal": self.grand_total, "Itemised": self.itemise,
            "AreaScheme": self.area_scheme,
        }


def floor_schedule(building_id, name=None):
    return ScheduleSpec(
        name or FLOOR_SCHEDULE, FLOORS_CATEGORY,
        ["Level", "Type", "Area",
         "DZ_Project_ID", "DZ_Option", "DZ_Building_ID", "DZ_Building_Name",
         "DZ_Program", "DZ_Floor_Index", "DZ_Floor_Key", "DZ_FSR_Included",
         "DZ_Physical_GFA", "DZ_FSR_GFA", "DZ_Source_Revision"],
        filter_field="DZ_Building_ID", filter_value=building_id,
        sort_field="DZ_Floor_Index",
        total_fields=["Area", "DZ_Physical_GFA", "DZ_FSR_GFA"],
        grand_total=True)


def area_schedule(building_id, scheme_name=None, name=None):
    return ScheduleSpec(
        name or AREA_SCHEDULE, AREAS_CATEGORY,
        ["Number", "Name", "Level", "Area",
         "DZ_Project_ID", "DZ_Option", "DZ_Building_ID", "DZ_Building_Name",
         "DZ_Program", "DZ_Floor_Index", "DZ_Floor_Key", "DZ_FSR_Included",
         "DZ_Physical_GFA", "DZ_FSR_GFA", "DZ_Source_Revision"],
        filter_field="DZ_Building_ID", filter_value=building_id,
        sort_field="DZ_Floor_Index",
        total_fields=["Area", "DZ_Physical_GFA", "DZ_FSR_GFA"],
        grand_total=True, area_scheme=scheme_name)


def summary_schedule(name=None):
    return ScheduleSpec(
        name or SUMMARY_SCHEDULE, PROJECT_INFO_CATEGORY,
        ["DZ_Project_ID", "DZ_Option", "DZ_Export_Revision",
         "DZ_Export_Timestamp", "DZ_Target_FSR", "DZ_Actual_FSR",
         "DZ_Site_Area", "DZ_Total_Physical_GFA", "DZ_Total_FSR_GFA",
         "DZ_Actual_Site_Coverage", "DZ_Overall_Compliance_Status",
         "DZ_Manifest_SHA256"],
        itemise=False)


def all_specs(building_id, scheme_name=None, floor_name=None, area_name=None,
              summary_name=None):
    return [floor_schedule(building_id, floor_name),
            area_schedule(building_id, scheme_name, area_name),
            summary_schedule(summary_name)]


class ScheduleRequest(object):
    def __init__(self, spec, action="CREATE", element_id=None, note=None):
        self.spec = spec
        self.action = action
        self.element_id = element_id
        self.note = note
        self.error = None
        self.missing_fields = []
        self.applied_fields = []
        self.row_count = None
        self.total_area = None

    @property
    def name(self):
        return self.spec.name

    def as_dict(self):
        data = self.spec.as_dict()
        data.update({
            "Action": self.action, "ElementId": self.element_id,
            "AppliedFields": list(self.applied_fields),
            "MissingFields": list(self.missing_fields),
            "RowCount": self.row_count, "TotalArea": self.total_area,
            "Note": self.note, "Error": self.error,
        })
        return data


UNSUPPORTED_NOTE = (
    "Revit reports this category cannot host a regular schedule "
    "(ViewSchedule.IsValidCategoryForSchedule is false). The parameter values "
    "are still written to the element; only the schedule view is skipped.")


def plan(specs, existing_schedules, category_valid=None):
    """Reuse an existing schedule of the same name, otherwise create it.

    `category_valid` maps a category key to whether the installed Revit will
    accept a regular schedule for it. A category Revit refuses is SKIPped with
    a reason rather than attempted - trying anyway raises inside the
    transaction and would roll back every other stage.
    """
    by_name = dict((str(s.get("Name")), s) for s in (existing_schedules or []))
    valid = dict(category_valid or {})
    requests = []
    for spec in specs:
        match = by_name.get(spec.name)
        if match is not None:
            request = ScheduleRequest(spec, "REUSE", match.get("Id"))
            request.note = "existing schedule of the same name reused"
        elif valid.get(spec.category) is False:
            request = ScheduleRequest(spec, "SKIP")
            request.note = UNSUPPORTED_NOTE
        else:
            request = ScheduleRequest(spec, "CREATE")
        requests.append(request)
    return requests


def resolve_fields(spec, available_field_names):
    """Split the wanted fields into those the document offers and those it does not.

    Revit only exposes schedulable fields through an existing ScheduleDefinition,
    and creating one needs a transaction. So at preview time the list is often
    genuinely unknown rather than empty. `None` means "cannot be determined yet"
    and every field is assumed available; an explicit empty list means the
    category really offers nothing.
    """
    if available_field_names is None:
        return list(spec.fields), []
    available = set(str(n) for n in available_field_names)
    applied, missing = [], []
    for field in spec.fields:
        (applied if field in available else missing).append(field)
    return applied, missing
