"""Plain data holders shared by the publisher.

No RhinoCommon, no Revit API. Geometry arrives as measured facts in a
`FootprintFacts`, produced by whichever layer actually read the curve.
"""

from . import naming


class BuildingRecord(object):
    """One building from the manifest, with its floor rows attached."""

    def __init__(self, data, floors):
        self.data = dict(data or {})
        self.floors = [FloorRecord(row) for row in (floors or [])]
        self.floors.sort(key=lambda row: (row.floor_index
                                          if row.floor_index is not None else 0))

    def _get(self, key):
        return self.data.get(key)

    @property
    def building_id(self):
        return self._get("BuildingId")

    @property
    def building_name(self):
        return self._get("BuildingName")

    @property
    def source_id(self):
        return self._get("SourceId")

    @property
    def rhino_object_guid(self):
        return self._get("RhinoObjectGuid")

    @property
    def program(self):
        return self._get("Program")

    @property
    def base_elevation(self):
        return self._get("BaseElevation")

    @property
    def top_elevation(self):
        return self._get("TopElevation")

    @property
    def floor_height(self):
        return self._get("FloorHeight")

    @property
    def floor_count(self):
        return self._get("FloorCount")

    @property
    def footprint_area(self):
        return self._get("FootprintArea")

    def describe(self):
        return "%s - %s (%s)" % (self.building_id or "?",
                                 self.building_name or "unnamed",
                                 self.program or "no program")


class FloorRecord(object):
    """One generated floor row from the manifest."""

    def __init__(self, data):
        self.data = dict(data or {})

    def _get(self, key):
        return self.data.get(key)

    @property
    def building_id(self):
        return self._get("BuildingId")

    @property
    def building_source_id(self):
        return self._get("BuildingSourceId")

    @property
    def floor_index(self):
        value = self._get("FloorIndex")
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @property
    def level_name(self):
        return self._get("LevelName")

    @property
    def elevation(self):
        return self._get("Elevation")

    @property
    def floor_to_floor(self):
        return self._get("FloorToFloorHeight")

    @property
    def plate_area(self):
        return self._get("FloorPlateArea")

    @property
    def included_in_fsr(self):
        return self._get("IncludedInFSR")

    def key(self):
        return naming.floor_key(self.building_source_id, self.floor_index,
                                self.elevation)


class FootprintFacts(object):
    """Measured properties of a candidate footprint curve.

    Deliberately a bag of primitives so validation can be unit tested with no
    geometry library present.
    """

    def __init__(self, source_id=None, object_guid=None, geometry_type=None,
                 is_closed=None, is_planar=None, area=None, plane_z=None,
                 self_intersections=None, minimum_segment=None,
                 point_count=None, points=None, origin=None,
                 simplified=False, simplification_note=None,
                 duplicate_matches=1):
        self.source_id = source_id
        self.object_guid = object_guid
        self.geometry_type = geometry_type
        self.is_closed = is_closed
        self.is_planar = is_planar
        self.area = area
        self.plane_z = plane_z
        self.self_intersections = self_intersections
        self.minimum_segment = minimum_segment
        self.point_count = point_count
        self.points = list(points or [])
        self.origin = origin
        self.simplified = simplified
        self.simplification_note = simplification_note
        self.duplicate_matches = duplicate_matches

    def as_dict(self):
        return {
            "SourceId": self.source_id,
            "RhinoObjectGuid": self.object_guid,
            "GeometryType": self.geometry_type,
            "Closed": self.is_closed,
            "Planar": self.is_planar,
            "Area": self.area,
            "PlaneZ": self.plane_z,
            "SelfIntersections": self.self_intersections,
            "MinimumSegment": self.minimum_segment,
            "PointCount": self.point_count,
            "Origin": self.origin,
            "Simplified": self.simplified,
            "SimplificationNote": self.simplification_note,
            "DuplicateMatches": self.duplicate_matches,
        }


class LevelRequest(object):
    """One Level the plan intends to create or reuse."""

    def __init__(self, name, elevation, floor_index=None, action="CREATE",
                 element_id=None, existing_name=None, note=None):
        self.name = name
        self.elevation = elevation
        self.floor_index = floor_index
        self.action = action
        self.element_id = element_id
        self.existing_name = existing_name
        self.note = note
        self.error = None

    def as_dict(self):
        return {
            "RequestedName": self.name,
            "RequestedElevation": self.elevation,
            "FloorIndex": self.floor_index,
            "Action": self.action,
            "ElementId": self.element_id,
            "MatchedExistingName": self.existing_name,
            "Note": self.note,
            "Error": self.error,
        }


class FloorRequest(object):
    """One Floor the plan intends to create, update or skip."""

    def __init__(self, mark, floor_index, elevation, level_name, floor_key,
                 plate_area=None, action="CREATE", element_id=None, note=None):
        self.mark = mark
        self.floor_index = floor_index
        self.elevation = elevation
        self.level_name = level_name
        self.floor_key = floor_key
        self.plate_area = plate_area
        self.action = action
        self.element_id = element_id
        self.note = note
        self.error = None
        self.published_area = None
        self.area_difference = None
        self.area_difference_ratio = None

    def as_dict(self):
        return {
            "Mark": self.mark,
            "FloorIndex": self.floor_index,
            "Elevation": self.elevation,
            "LevelName": self.level_name,
            "FloorKey": self.floor_key,
            "ExpectedPlateArea": self.plate_area,
            "PublishedArea": self.published_area,
            "AreaDifference": self.area_difference,
            "AreaDifferenceRatio": self.area_difference_ratio,
            "Action": self.action,
            "ElementId": self.element_id,
            "Note": self.note,
            "Error": self.error,
        }


class RevitContext(object):
    """What the Revit layer observed about the host session.

    Held as primitives so the plan and log can be produced and tested without
    Revit present.
    """

    def __init__(self, available=False, revit_version=None,
                 revit_build=None, rir_version=None, rhino_version=None,
                 document_name=None, document_path=None, is_writable=None,
                 is_workshared=None, is_family=None, in_transaction=None,
                 length_unit=None, floor_types=None, levels=None,
                 project_location=None, shared_parameters=None, notes=None):
        self.available = available
        self.revit_version = revit_version
        self.revit_build = revit_build
        self.rir_version = rir_version
        self.rhino_version = rhino_version
        self.document_name = document_name
        self.document_path = document_path
        self.is_writable = is_writable
        self.is_workshared = is_workshared
        self.is_family = is_family
        self.in_transaction = in_transaction
        self.length_unit = length_unit
        self.floor_types = list(floor_types or [])
        self.levels = list(levels or [])          # [{"Name":..,"Elevation":..,"Id":..}]
        self.project_location = project_location
        self.shared_parameters = list(shared_parameters or [])
        self.notes = list(notes or [])

    def as_dict(self):
        return {
            "Available": self.available,
            "RevitVersion": self.revit_version,
            "RevitBuild": self.revit_build,
            "RhinoInsideRevitVersion": self.rir_version,
            "RhinoVersion": self.rhino_version,
            "DocumentName": self.document_name,
            "DocumentPath": self.document_path,
            "Writable": self.is_writable,
            "Workshared": self.is_workshared,
            "IsFamilyDocument": self.is_family,
            "InActiveTransaction": self.in_transaction,
            "LengthUnit": self.length_unit,
            "FloorTypeCount": len(self.floor_types),
            "LevelCount": len(self.levels),
            "ProjectLocation": self.project_location,
            "SharedParametersPresent": self.shared_parameters,
            "Notes": self.notes,
        }
