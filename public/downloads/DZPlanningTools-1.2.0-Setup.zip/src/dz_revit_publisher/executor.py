"""The nine staged transactions, inside one TransactionGroup.

Extracted verbatim from the validated Phase 7C component. Frozen behaviour:
stage ordering, ownership pre-flight, rollback semantics, strict idempotency,
Result and StageResult meanings, old/new ElementId reporting.

The Revit API is reached only through the injected bridge, so this module has no
Revit import at all.
"""

from . import change_detection as cd
from . import identity, shared_parameters, snapshot
from . import unit_conversion as uc
from . import config
from . import validation as val

STAGE_NAMES = [
    "Identity migration", "Parameter updates", "Level and elevation updates",
    "Floor create and geometry replacement", "Area plans and boundaries",
    "Native Areas", "Obsolete handling", "Project data and schedules",
    "Final validation",
]


class Stage(object):
    def __init__(self, number, name):
        self.number = number
        self.name = name
        self.status = "PENDING"
        self.detail = []
        self.error = None

    def as_dict(self):
        return {"Stage": self.number, "Name": self.name, "Status": self.status,
                "Detail": list(self.detail), "Error": self.error}


FLOOR_PARAMS = [s.name for s in shared_parameters.SCHEMA
                if shared_parameters.FLOORS in s.categories]
AREA_PARAMS = [s.name for s in shared_parameters.SCHEMA
               if shared_parameters.AREAS in s.categories]
LEVEL_PARAMS = [s.name for s in shared_parameters.SCHEMA
                if shared_parameters.LEVELS in s.categories]
PROJECT_PARAMS = [s.name for s in shared_parameters.SCHEMA
                  if shared_parameters.PROJECT_INFO in s.categories]


def element_values(building, floor, ident, manifest_sha, snap, stable_key):
    """Formal Phase 7C values for a floor or its Area."""
    plate = floor.plate_area
    included = floor.included_in_fsr
    return {
        "DZ_Source_ID": building.source_id,
        "DZ_Building_ID": building.building_id,
        "DZ_Building_Name": building.building_name,
        "DZ_Project_ID": ident.get("projectId"),
        "DZ_Option": ident.get("option"),
        "DZ_Source_Revision": ident.get("revision"),
        "DZ_Manifest_SHA256": manifest_sha,
        "DZ_Program": building.program,
        "DZ_Floor_Index": floor.floor_index,
        "DZ_Floor_Key": stable_key,
        "DZ_FSR_Included": included,
        "DZ_Physical_GFA": plate,
        "DZ_FSR_GFA": (plate if included else 0.0) if included is not None else None,
        "DZ_Floor_Elevation": floor.elevation,
        "DZ_Boundary_Hash": snap.get("BoundaryHash"),
        "DZ_Source_Snapshot": snapshot.snapshot_hash(snap),
        "DZ_Publish_Status": shared_parameters.PUBLISH_STATUS_PUBLISHED,
    }


def execute(bridge, plan, building, ident, manifest, manifest_sha, guids,
            footprint_points, fail_at_stage=None):
    """Run the nine stages inside one TransactionGroup.

    ``footprint_points`` is the source boundary in metres; stages 4-6
    rebuild geometry from it.
    """
    DB, doc, app = bridge.DB, bridge.doc, bridge.app
    import System
    try:
        from System.Collections.Generic import List as NetList
    except Exception:
        NetList = None          # offline harness: a plain list marshals fine

    warnings, errors = [], []
    stages = [Stage(i, n) for i, n in enumerate(STAGE_NAMES, start=1)]
    by_number = dict((s.number, s) for s in stages)
    state = {"result": "not started"}
    results = {"identityMigrated": 0, "parametersUpdated": 0,
               "bindingsWritten": 0, "projectValuesUpdated": 0,
               "levelsUpdated": 0, "levelParametersUpdated": 0,
               "floorsGeometryEditedInPlace": 0,
               "floorOldElementIds": [], "floorNewElementIds": [],
               "boundarySetsDeleted": 0, "boundarySetsCreated": 0,
               "areasReassociated": 0,
               "areaOldElementIds": [], "areaNewElementIds": [],
               "parametersNotTransferred": [],
               "rollbackOccurred": False,
               "floorsCreated": 0, "floorsReplaced": 0,
               "boundariesReplaced": 0, "areasCreated": 0, "areasReplaced": 0,
               "obsoleteMarked": 0, "obsoleteDeleted": 0, "skipped": 0}
    validation_notes = []
    original_sp = None

    def fail_here(number):
        if fail_at_stage and int(fail_at_stage) == number:
            raise RuntimeError("Deliberate failure injected at stage %d." % number)

    def work():
        group = DB.TransactionGroup(doc, "DZ Phase 7C Upsert")
        group.Start()
        try:
            # -- stage 1: bindings + identity migration -------------------
            stage = by_number[1]
            transaction = DB.Transaction(doc, "DZ 7C Identity Migration")
            transaction.Start()
            try:
                spfile = app.OpenSharedParameterFile()
                if spfile is None:
                    raise ValueError("DZ shared parameter file unreadable: %s"
                                     % config.SHARED_PARAMETER_FILE)
                group_def = None
                for candidate in spfile.Groups:
                    if candidate.Name == shared_parameters.GROUP_NAME:
                        group_def = candidate; break
                if group_def is None:
                    group_def = spfile.Groups.Create(shared_parameters.GROUP_NAME)
                bound = reused = 0
                for spec in shared_parameters.SCHEMA:
                    definition = None
                    for candidate in group_def.Definitions:
                        if candidate.Name == spec.name:
                            definition = candidate; break
                    if definition is None:
                        options = DB.ExternalDefinitionCreationOptions(
                            spec.name, bridge.spec_for(spec.data_type))
                        options.GUID = System.Guid(guids[spec.name])
                        options.Description = spec.description
                        definition = group_def.Definitions.Create(options)
                    existing = doc.ParameterBindings.get_Item(definition)
                    if bridge.binding_is_current(existing, spec.categories):
                        reused += 1
                        continue     # identical binding: re-inserting would
                                     # modify the document for no reason
                    categories = app.Create.NewCategorySet()
                    for key in spec.categories:
                        categories.Insert(bridge.category(key))
                    binding = app.Create.NewInstanceBinding(categories)
                    if existing is None:
                        doc.ParameterBindings.Insert(definition, binding,
                                                     DB.GroupTypeId.Data)
                    else:
                        doc.ParameterBindings.ReInsert(definition, binding,
                                                       DB.GroupTypeId.Data)
                    bound += 1
                results["bindingsWritten"] = bound
                stage.detail.append("parameter bindings written %d, reused %d"
                                    % (bound, reused))

                # Ownership must be settled before stage 2 writes anything:
                # stage 2 sets DZ_Building_ID, which would otherwise re-brand a
                # foreign element as ours and disarm every later guard.
                area_owner = {}
                for row in bridge.observe_areas():
                    key = identity.migrate_key(row.get("DZ_Floor_Key"))
                    if key:
                        area_owner[key] = row["ElementId"]
                trespass = []
                for change in plan.changes:
                    if change.action == cd.SKIP or not change.element_id:
                        continue
                    candidates = [("Floor", change.element_id)]
                    paired = area_owner.get(change.stable_key)
                    if paired:
                        candidates.append(("Area", paired))
                    for kind, element_id in candidates:
                        element = doc.GetElement(DB.ElementId(element_id))
                        if element is None:
                            continue
                        if bridge.is_foreign_host(element, building.building_id):
                            trespass.append(
                                "%s %s (floor %s) carries DZ_Building_ID %r, not "
                                "%r" % (kind, element_id, change.floor_index,
                                        bridge.read(element, "DZ_Building_ID"),
                                        building.building_id))
                if trespass:
                    raise ValueError(
                        "Refusing to modify element(s) that are not DZ %s "
                        "content: %s" % (building.building_id, "; ".join(trespass)))
                stage.detail.append("ownership verified for %d element(s)"
                                    % (len(plan.changes) + len(area_owner)))

                migrated = 0
                for change in plan.changes:
                    if change.needs_migration and change.element_id:
                        migrated += 1
                stage.detail.append("elements needing identity migration %d" % migrated)
                results["identityMigrated"] = migrated
                fail_here(1)
                transaction.Commit(); stage.status = "OK"
            except Exception as exc:
                transaction.RollBack(); stage.status = "FAILED"
                stage.error = "%s: %s" % (type(exc).__name__, exc); raise

            # -- stage 2: parameter updates -------------------------------
            stage = by_number[2]
            transaction = DB.Transaction(doc, "DZ 7C Parameter Updates")
            transaction.Start()
            try:
                area_by_key = {}
                for row in bridge.observe_areas():
                    key = identity.migrate_key(row.get("DZ_Floor_Key"))
                    if key:
                        area_by_key[key] = row["ElementId"]
                updated = 0
                for change in plan.changes:
                    if change.action == cd.SKIP:
                        results["skipped"] += 1
                        continue
                    if change.action not in (cd.UPDATE_PARAMETERS,
                                             cd.UPDATE_ELEVATION,
                                             cd.UPDATE_GEOMETRY):
                        continue
                    floor = [f for f in building.floors
                             if f.floor_index == change.floor_index][0]
                    values = element_values(building, floor, ident, manifest_sha,
                                            change.current, change.stable_key)
                    element = doc.GetElement(DB.ElementId(change.element_id))
                    if element is not None:
                        changed, skipped = bridge.apply(element, values, FLOOR_PARAMS)
                        if changed:
                            updated += 1
                        if skipped:
                            warnings.append("Floor %s: %s" % (change.element_id,
                                                              "; ".join(skipped)))
                    area_id = area_by_key.get(change.stable_key)
                    if area_id is None:
                        legacy = "%s:%d:%.6f" % (building.source_id,
                                                 change.floor_index,
                                                 floor.elevation or 0.0)
                        area_id = area_by_key.get(identity.migrate_key(legacy))
                    if area_id:
                        area = doc.GetElement(DB.ElementId(area_id))
                        if area is not None:
                            bridge.apply(area, values, AREA_PARAMS)
                results["parametersUpdated"] = updated
                stage.detail.append("elements with parameter changes %d" % updated)
                stage.detail.append("unchanged elements skipped %d" % results["skipped"])
                fail_here(2)
                transaction.Commit(); stage.status = "OK"
            except Exception as exc:
                transaction.RollBack(); stage.status = "FAILED"
                stage.error = "%s: %s" % (type(exc).__name__, exc); raise

            # -- stage 3: level identity + elevation ----------------------
            stage = by_number[3]
            transaction = DB.Transaction(doc, "DZ 7C Levels")
            transaction.Start()
            try:
                level_values = {
                    "DZ_Source_ID": building.source_id,
                    "DZ_Building_ID": building.building_id,
                    "DZ_Building_Name": building.building_name,
                    "DZ_Project_ID": ident.get("projectId"),
                    "DZ_Option": ident.get("option"),
                    "DZ_Source_Revision": ident.get("revision"),
                    "DZ_Manifest_SHA256": manifest_sha,
                    "DZ_Publish_Status": shared_parameters.PUBLISH_STATUS_PUBLISHED,
                }
                touched = 0
                elevations = dict((f.floor_index, f.elevation)
                                  for f in building.floors)
                for row in bridge.observe_levels(building.building_id):
                    element = doc.GetElement(DB.ElementId(row["ElementId"]))
                    if element is None:
                        continue
                    if row.get("DZ_Building_ID") not in (None, building.building_id):
                        continue
                    matches_source = any(
                        abs((row["Elevation"] or 0.0) - (e or 0.0)) < 1e-4
                        for e in elevations.values())
                    if not matches_source and row.get("DZ_Building_ID") is None:
                        continue          # unrelated project level: leave alone
                    changed, _skipped = bridge.apply(element, level_values,
                                                     LEVEL_PARAMS)
                    if changed:
                        touched += 1
                moved = 0
                for change in plan.changes:
                    if change.action != cd.UPDATE_ELEVATION:
                        continue
                    floor = [f for f in building.floors
                             if f.floor_index == change.floor_index][0]
                    element = doc.GetElement(DB.ElementId(change.element_id))
                    level = doc.GetElement(element.LevelId) if element else None
                    if level is None:
                        raise ValueError("No host level for floor %s"
                                         % change.floor_index)
                    hosted = DB.FilteredElementCollector(doc)\
                        .WhereElementIsNotElementType()\
                        .WherePasses(DB.ElementLevelFilter(level.Id)).ToElements()
                    foreign = [e for e in hosted
                               if bridge.is_foreign_host(e, building.building_id)]
                    if foreign:
                        raise ValueError(
                            "Level %s hosts %d element(s) that are not DZ %s "
                            "content; moving it would relocate unrelated project "
                            "geometry. Resolve manually. First few: %s"
                            % (level.Name, len(foreign), building.building_id,
                               ", ".join("%s (%s)" % (bridge._id(e.Id),
                                                      bridge.category_name(e))
                                         for e in foreign[:5])))
                    level.Elevation = uc.metres_to_internal(floor.elevation)
                    moved += 1
                # levelsUpdated counts elevation moves - the write that actually
                # relocates geometry. Parameter touches are reported separately
                # so an idempotent run reads zero on both.
                results["levelsUpdated"] = moved
                results["levelParametersUpdated"] = touched
                stage.detail.append("levels parameterised %d, elevations moved %d"
                                    % (touched, moved))
                fail_here(3)
                transaction.Commit(); stage.status = "OK"
            except Exception as exc:
                transaction.RollBack(); stage.status = "FAILED"
                stage.error = "%s: %s" % (type(exc).__name__, exc); raise

            # -- stage 4: floor geometry ----------------------------------
            stage = by_number[4]
            geometry_changes = [c for c in plan.changes
                                if c.action in (cd.CREATE, cd.UPDATE_GEOMETRY)]
            floor_map = {}          # stable key -> (old id, new id)
            if not geometry_changes:
                stage.status = "OK"; stage.detail.append("nothing to do")
                fail_here(4)
            else:
                transaction = DB.Transaction(doc, "DZ 7C Floor Geometry")
                transaction.Start()
                try:
                    edited = replaced = 0
                    for change in geometry_changes:
                        floor = [f for f in building.floors
                                 if f.floor_index == change.floor_index][0]
                        old = doc.GetElement(DB.ElementId(change.element_id)) \
                            if change.element_id else None
                        if old is None:
                            raise ValueError(
                                "Floor %s has no existing element; CREATE is not "
                                "supported by this stage." % change.floor_index)
                        if bridge.is_foreign_host(old, building.building_id):
                            raise ValueError(
                                "Floor %s (element %s) is not DZ %s content; "
                                "refusing to replace it."
                                % (change.floor_index, change.element_id,
                                   building.building_id))
                        level_id = old.LevelId
                        type_id = old.GetTypeId()
                        offset = None
                        try:
                            p = old.get_Parameter(
                                DB.BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM)
                            offset = p.AsDouble() if p else None
                        except Exception:
                            offset = None
                        carried = {}
                        for name in list(FLOOR_PARAMS) + ["Comments", "Mark"]:
                            value = bridge.read(old, name)
                            if value is not None:
                                carried[name] = value

                        loop, ring = bridge.curve_loop(footprint_points,
                                                      floor.elevation)
                        if NetList is not None:
                            loops = NetList[DB.CurveLoop]()
                            loops.Add(loop)
                        else:
                            loops = [loop]
                        new = DB.Floor.Create(doc, loops, type_id, level_id)
                        if new is None:
                            raise ValueError("Revit refused to create the floor "
                                             "for index %s." % change.floor_index)
                        if offset is not None:
                            try:
                                p = new.get_Parameter(
                                    DB.BuiltInParameter.FLOOR_HEIGHTABOVELEVEL_PARAM)
                                if p is not None and not p.IsReadOnly:
                                    p.Set(offset)
                            except Exception:
                                pass
                        # carry project data across before the old element goes
                        carried_names, lost = bridge.carry_parameters(old, new)
                        for note in lost:
                            if note not in results["parametersNotTransferred"]:
                                results["parametersNotTransferred"].append(note)
                        old_id = bridge._id(old.Id)
                        new_id = bridge._id(new.Id)
                        doc.Delete(old.Id)
                        replaced += 1
                        results["floorOldElementIds"].append(old_id)
                        results["floorNewElementIds"].append(new_id)
                        floor_map[change.stable_key] = (old_id, new_id)
                        # keep the replaced id visible: the log must never imply
                        # the element survived
                        change.previous_element_id = old_id
                        change.new_element_id = new_id
                        change.element["ElementId"] = new_id
                        for name, value in carried.items():
                            spec = shared_parameters.BY_NAME.get(name)
                            if spec is None:
                                bridge.write(new, name, value,
                                             shared_parameters.TEXT)
                            else:
                                target = new.LookupParameter(name)
                                if target is not None and not target.IsReadOnly:
                                    try:
                                        target.Set(value)
                                    except Exception:
                                        pass
                        stage.detail.append(
                            "floor %s replaced %s -> %s"
                            % (change.floor_index, old_id, new_id))
                    doc.Regenerate()
                    # nothing may survive alongside its replacement
                    for change in geometry_changes:
                        old_id, new_id = floor_map[change.stable_key]
                        if doc.GetElement(DB.ElementId(old_id)) is not None:
                            raise ValueError(
                                "Old floor %s still exists after replacement."
                                % old_id)
                    results["floorsGeometryEditedInPlace"] = edited
                    results["floorsReplaced"] = replaced
                    stage.detail.append("edited in place %d, replaced %d"
                                        % (edited, replaced))
                    warnings.append(
                        "Stage 4 used controlled replacement: Revit's in-place "
                        "sketch edit (SketchEditScope) has not been validated "
                        "for this project, so floor ElementIds change. Old and "
                        "new ids are recorded in floorOldElementIds and "
                        "floorNewElementIds.")
                    fail_here(4)
                    transaction.Commit(); stage.status = "OK"
                except Exception as exc:
                    transaction.RollBack(); stage.status = "FAILED"
                    stage.error = "%s: %s" % (type(exc).__name__, exc); raise

            # -- stage 5: area boundaries ---------------------------------
            stage = by_number[5]
            boundary_changes = [c for c in plan.changes
                                if c.boundary_action in (cd.BOUNDARY_RECREATE, cd.CREATE)]
            if not boundary_changes:
                stage.status = "OK"; stage.detail.append("nothing to do")
                fail_here(5)
            else:
                transaction = DB.Transaction(doc, "DZ 7C Area Boundaries")
                transaction.Start()
                try:
                    views = {}
                    for view in DB.FilteredElementCollector(doc)\
                            .OfClass(DB.ViewPlan).ToElements():
                        if view.ViewType == DB.ViewType.AreaPlan and not view.IsTemplate:
                            level = view.GenLevel
                            if level is not None:
                                views.setdefault(bridge._id(level.Id), view)
                    deleted = created = 0
                    for change in boundary_changes:
                        floor = [f for f in building.floors
                                 if f.floor_index == change.floor_index][0]
                        element = doc.GetElement(DB.ElementId(change.element_id))
                        view = views.get(bridge._id(element.LevelId))
                        if view is None:
                            raise ValueError(
                                "No Area Plan hosts floor %s; boundaries cannot "
                                "be rebuilt." % change.floor_index)
                        previous_hash = (change.previous or {}).get("BoundaryHash")
                        loops = bridge.boundary_loops(view)
                        mine = [l for l in loops
                                if previous_hash and l["hash"] == previous_hash]
                        if not mine:
                            raise ValueError(
                                "No DZ boundary loop in %s matches the recorded "
                                "hash %s; refusing to guess which lines are ours."
                                % (view.Name, str(previous_hash)[:12]))
                        if len(mine) > 1:
                            raise ValueError(
                                "%d boundary loops in %s share the recorded hash; "
                                "resolve manually." % (len(mine), view.Name))
                        foreign = len(loops) - len(mine)
                        for line in mine[0]["elements"]:
                            doc.Delete(line.Id)
                        deleted += 1
                        results["boundarySetsDeleted"] += 1

                        _loop, ring = bridge.curve_loop(footprint_points,
                                                        floor.elevation)
                        plane = DB.Plane.CreateByNormalAndOrigin(
                            DB.XYZ.BasisZ,
                            DB.XYZ(0, 0, uc.metres_to_internal(floor.elevation)))
                        sketch = DB.SketchPlane.Create(doc, plane)
                        made = []
                        for index in range(len(ring)):
                            a = ring[index]
                            b = ring[(index + 1) % len(ring)]
                            line = DB.Line.CreateBound(
                                DB.XYZ(uc.metres_to_internal(a[0]),
                                       uc.metres_to_internal(a[1]),
                                       uc.metres_to_internal(floor.elevation)),
                                DB.XYZ(uc.metres_to_internal(b[0]),
                                       uc.metres_to_internal(b[1]),
                                       uc.metres_to_internal(floor.elevation)))
                            made.append(doc.Create.NewAreaBoundaryLine(
                                sketch, line, view))
                        created += 1
                        results["boundarySetsCreated"] += 1
                        stage.detail.append(
                            "floor %s: %d line(s) removed, %d created, %d foreign "
                            "loop(s) untouched"
                            % (change.floor_index, len(mine[0]["elements"]),
                               len(made), foreign))
                    doc.Regenerate()
                    for change in boundary_changes:
                        element = doc.GetElement(DB.ElementId(change.element_id))
                        view = views.get(bridge._id(element.LevelId))
                        loops = bridge.boundary_loops(view)
                        wanted = (change.current or {}).get("BoundaryHash")
                        matching = [l for l in loops if l["hash"] == wanted]
                        if len(matching) != 1:
                            raise ValueError(
                                "Floor %s: expected exactly one boundary loop "
                                "hashing to %s in %s, found %d."
                                % (change.floor_index, str(wanted)[:12],
                                   view.Name, len(matching)))
                        if matching[0]["points"] is None:
                            raise ValueError("Floor %s: boundary loop is not "
                                             "closed." % change.floor_index)
                        if matching[0]["count"] != len(
                                snapshot.normalise_loop(footprint_points)):
                            raise ValueError(
                                "Floor %s: boundary has %d segments, expected %d."
                                % (change.floor_index, matching[0]["count"],
                                   len(snapshot.normalise_loop(footprint_points))))
                    stage.detail.append("boundary sets deleted %d, created %d"
                                        % (deleted, created))
                    fail_here(5)
                    transaction.Commit(); stage.status = "OK"
                except Exception as exc:
                    transaction.RollBack(); stage.status = "FAILED"
                    stage.error = "%s: %s" % (type(exc).__name__, exc); raise

            # -- stage 6: areas -------------------------------------------
            stage = by_number[6]
            area_changes = [c for c in plan.changes
                            if c.area_action in (cd.AREA_REASSOCIATE, cd.CREATE)]
            if not area_changes:
                stage.status = "OK"; stage.detail.append("nothing to do")
                fail_here(6)
            else:
                transaction = DB.Transaction(doc, "DZ 7C Areas")
                transaction.Start()
                try:
                    area_rows = {}
                    for row in bridge.observe_areas():
                        key = identity.migrate_key(row.get("DZ_Floor_Key"))
                        if key:
                            area_rows[key] = row["ElementId"]
                    views = {}
                    for view in DB.FilteredElementCollector(doc)\
                            .OfClass(DB.ViewPlan).ToElements():
                        if view.ViewType == DB.ViewType.AreaPlan and not view.IsTemplate:
                            level = view.GenLevel
                            if level is not None:
                                views.setdefault(bridge._id(level.Id), view)
                    ring = snapshot.normalise_loop(footprint_points)
                    cx = sum(p[0] for p in ring) / float(len(ring))
                    cy = sum(p[1] for p in ring) / float(len(ring))
                    reassociated = replaced_areas = 0
                    for change in area_changes:
                        floor = [f for f in building.floors
                                 if f.floor_index == change.floor_index][0]
                        element = doc.GetElement(DB.ElementId(change.element_id))
                        view = views.get(bridge._id(element.LevelId))
                        area_id = area_rows.get(change.stable_key)
                        area = doc.GetElement(DB.ElementId(area_id)) if area_id else None
                        if area is None:
                            raise ValueError(
                                "Floor %s has no tracked Area to update."
                                % change.floor_index)
                        if bridge.is_foreign_host(area, building.building_id):
                            raise ValueError(
                                "Area %s is not DZ %s content; refusing to "
                                "replace it." % (area_id, building.building_id))
                        target = DB.UV(uc.metres_to_internal(cx),
                                       uc.metres_to_internal(cy))
                        moved = False
                        try:
                            location = area.Location
                            if location is not None and hasattr(location, "Point"):
                                z = location.Point.Z
                                location.Point = DB.XYZ(
                                    uc.metres_to_internal(cx),
                                    uc.metres_to_internal(cy), z)
                                moved = True
                        except Exception:
                            moved = False
                        if moved:
                            reassociated += 1
                            results["areasReassociated"] += 1
                            stage.detail.append("floor %s: area %s re-associated"
                                                % (change.floor_index, area_id))
                        else:
                            carried = dict((n, bridge.read(area, n))
                                           for n in AREA_PARAMS)
                            new_area = doc.Create.NewArea(view, target)
                            if new_area is None:
                                raise ValueError(
                                    "Revit refused to place an Area for floor %s."
                                    % change.floor_index)
                            doc.Delete(area.Id)
                            new_id = bridge._id(new_area.Id)
                            results["areaOldElementIds"].append(area_id)
                            results["areaNewElementIds"].append(new_id)
                            replaced_areas += 1
                            results["areasReplaced"] += 1
                            for name, value in carried.items():
                                if value is None:
                                    continue
                                spec = shared_parameters.BY_NAME.get(name)
                                if spec is not None:
                                    bridge.write(new_area, name, value,
                                                 spec.data_type)
                            stage.detail.append(
                                "floor %s: area %s -> %s"
                                % (change.floor_index, area_id, new_id))
                    doc.Regenerate()
                    for row in bridge.observe_areas():
                        if not row["Area"] or row["Area"] <= 0:
                            raise ValueError(
                                "Area %s is unplaced or unenclosed after the "
                                "boundary rebuild." % row["ElementId"])
                    stage.detail.append("areas re-associated %d, replaced %d"
                                        % (reassociated, replaced_areas))
                    fail_here(6)
                    transaction.Commit(); stage.status = "OK"
                except Exception as exc:
                    transaction.RollBack(); stage.status = "FAILED"
                    stage.error = "%s: %s" % (type(exc).__name__, exc); raise

            # -- stage 7: obsolete ----------------------------------------
            for number, label in ((7, "obsolete handling"),):
                stage = by_number[number]
                relevant = list(plan.obsolete)
                if not relevant:
                    stage.status = "OK"
                    stage.detail.append("nothing to do")
                    fail_here(number)
                    continue
                if number == 7:
                    transaction = DB.Transaction(doc, "DZ 7C Obsolete")
                    transaction.Start()
                    try:
                        area_by_key = {}
                        for row in bridge.observe_areas():
                            key = identity.migrate_key(row.get("DZ_Floor_Key"))
                            if key:
                                area_by_key[key] = row["ElementId"]
                        marked = 0
                        for change in plan.obsolete:
                            targets = [change.element_id]
                            paired = area_by_key.get(
                                identity.migrate_key(change.stable_key)
                                if change.stable_key else None)
                            if paired:
                                targets.append(paired)
                            for element_id in targets:
                                element = doc.GetElement(DB.ElementId(element_id))
                                if element is None:
                                    continue
                                did, _p, _e = bridge.write(
                                    element, "DZ_Publish_Status",
                                    shared_parameters.PUBLISH_STATUS_OBSOLETE,
                                    shared_parameters.TEXT)
                                if did and element_id == change.element_id:
                                    marked += 1
                        results["obsoleteMarked"] = marked
                        stage.detail.append("obsolete marked %d (action %s)"
                                            % (marked, plan.obsolete_action))
                        if plan.obsolete_action == cd.DELETE:
                            if not plan.confirm_delete:
                                raise ValueError("Delete requested without "
                                                 "Confirm Delete Obsolete.")
                            ids = []
                            for change in plan.obsolete:
                                ids.append(change.element_id)
                                paired = area_by_key.get(
                                    identity.migrate_key(change.stable_key)
                                    if change.stable_key else None)
                                if paired:
                                    ids.append(paired)
                            warnings.append("Deleting obsolete elements: %s"
                                            % ", ".join(str(i) for i in ids))
                            for element_id in ids:
                                doc.Delete(DB.ElementId(element_id))
                            results["obsoleteDeleted"] = len(ids)
                        fail_here(number)
                        transaction.Commit(); stage.status = "OK"
                    except Exception as exc:
                        transaction.RollBack(); stage.status = "FAILED"
                        stage.error = "%s: %s" % (type(exc).__name__, exc); raise
                    continue

            # -- stage 8: project info + schedules ------------------------
            stage = by_number[8]
            transaction = DB.Transaction(doc, "DZ 7C Project Data")
            transaction.Start()
            try:
                summary = ((manifest.get("project") or {}).get("summary")) or {}
                metadata = manifest.get("exportMetadata") or {}
                project_values = {
                    "DZ_Project_ID": ident.get("projectId"),
                    "DZ_Option": ident.get("option"),
                    "DZ_Export_Revision": ident.get("revision"),
                    "DZ_Export_Timestamp": metadata.get("ExportTimestamp"),
                    "DZ_Manifest_SHA256": manifest_sha,
                    "DZ_Target_FSR": summary.get("TargetFSR"),
                    "DZ_Actual_FSR": summary.get("ActualFSR"),
                    "DZ_Site_Area": summary.get("SiteArea"),
                    "DZ_Total_Physical_GFA": summary.get("TotalPhysicalGFA"),
                    "DZ_Total_FSR_GFA": summary.get("FSRIncludedGFA"),
                    "DZ_Actual_Site_Coverage": summary.get("ActualSiteCoverage"),
                    "DZ_Overall_Compliance_Status":
                        summary.get("OverallComplianceStatus"),
                }
                changed, skipped = bridge.apply(doc.ProjectInformation,
                                                project_values, PROJECT_PARAMS)
                results["projectValuesUpdated"] = len(changed)
                stage.detail.append("project values changed %d" % len(changed))
                existing = [s.Name for s in DB.FilteredElementCollector(doc)
                            .OfClass(DB.ViewSchedule).ToElements()
                            if not s.IsTemplate and s.Name.startswith("DZ ")]
                stage.detail.append("schedules reused: %s" % ", ".join(existing))
                warnings.append(
                    "DZ Planning Summary remains SKIP: Project Information is "
                    "not a valid category for a regular Revit schedule.")
                fail_here(8)
                transaction.Commit(); stage.status = "OK"
            except Exception as exc:
                transaction.RollBack(); stage.status = "FAILED"
                stage.error = "%s: %s" % (type(exc).__name__, exc); raise

            # -- stage 9: final validation --------------------------------
            stage = by_number[9]
            # Regenerate is a document modification, so it needs its own
            # transaction even though validation itself only reads.
            transaction = DB.Transaction(doc, "DZ 7C Final Validation")
            transaction.Start()
            try:
                doc.Regenerate()
                floors = bridge.observe_floors(building)
                areas = bridge.observe_areas()
                keys = [f["DZ_Floor_Key"] for f in floors if f["DZ_Floor_Key"]]
                if len(keys) != len(set(keys)):
                    raise ValueError("Duplicate DZ_Floor_Key after publish: %s"
                                     % keys)
                legacy = [k for k in keys if identity.is_legacy_key(k)]
                if legacy:
                    raise ValueError("Legacy floor keys still present: %s" % legacy)
                boundary_lines = DB.FilteredElementCollector(doc)\
                    .OfCategory(DB.BuiltInCategory.OST_AreaSchemeLines)\
                    .WhereElementIsNotElementType().GetElementCount()
                plans = [v for v in DB.FilteredElementCollector(doc)
                         .OfClass(DB.ViewPlan).ToElements()
                         if v.ViewType == DB.ViewType.AreaPlan and not v.IsTemplate]
                unplaced = [a for a in areas if not a["Area"] or a["Area"] <= 0]
                if unplaced:
                    raise ValueError("%d Area(s) are unplaced or unenclosed."
                                     % len(unplaced))
                # Obsolete areas are retained deliberately, so they must not be
                # counted against the current source total.
                live = [a for a in areas
                        if a.get("DZ_Publish_Status")
                        != shared_parameters.PUBLISH_STATUS_OBSOLETE]
                total = sum(a["Area"] for a in live)
                live_floors = [f for f in floors
                               if f.get("DZ_Publish_Status")
                               != shared_parameters.PUBLISH_STATUS_OBSOLETE]
                floor_total = sum(f["Area"] or 0.0 for f in live_floors)
                # Areas are derived from the same boundaries as the Floors, so a
                # divergence means the boundary rebuild left them inconsistent.
                if floor_total:
                    drift = abs(total - floor_total) / floor_total
                    if drift > val.AREA_TOLERANCE_RATIO:
                        raise ValueError(
                            "Total Area %.4f m2 does not match total Floor area "
                            "%.4f m2 (%.2f%%); the Areas did not follow the "
                            "boundary rebuild." % (total, floor_total, drift * 100.0))
                expected_total = sum(f.plate_area or 0.0 for f in building.floors)
                if expected_total:
                    ratio = abs(total - expected_total) / expected_total
                    if ratio > val.AREA_BLOCKING_RATIO:
                        raise ValueError(
                            "Total Area %.4f m2 differs from the source %.4f m2 "
                            "by %.2f%%." % (total, expected_total, ratio * 100.0))
                validation_notes.extend([
                    "Floors: %d (%d live), unique stable keys: %d"
                    % (len(floors), len(live_floors), len(set(keys))),
                    "Legacy keys remaining: 0",
                    "Areas: %d (%d live), total %.4f m2 (floors %.4f m2)"
                    % (len(areas), len(live), total, floor_total),
                    "Area Plans: %d" % len(plans),
                    "Area boundary lines: %d" % boundary_lines,
                    "Unplaced areas: 0",
                ])
                stage.detail.extend(validation_notes)
                fail_here(9)
                transaction.Commit(); stage.status = "OK"
            except Exception as exc:
                transaction.RollBack(); stage.status = "FAILED"
                stage.error = "%s: %s" % (type(exc).__name__, exc); raise

            group.Assimilate()
            state["result"] = "assimilated"
        except Exception as exc:
            errors.append("%s: %s" % (type(exc).__name__, exc))
            try:
                group.RollBack(); state["result"] = "rolled back"
            except Exception as rollback_exc:
                state["result"] = "rollback failed: %s" % rollback_exc
            for stage in stages:
                if stage.status == "PENDING":
                    stage.status = "NOT REACHED"
            for key in results:
                results[key] = [] if isinstance(results[key], list) else 0
            results["rollbackOccurred"] = True

    try:
        original_sp = app.SharedParametersFilename
    except Exception:
        original_sp = None
    try:
        app.SharedParametersFilename = config.SHARED_PARAMETER_FILE
        ok, context_error = bridge.invoke_in_host_context(work)
        if not ok:
            errors.append("Could not enter the Revit API context: %s" % context_error)
    finally:
        try:
            if original_sp is not None:
                app.SharedParametersFilename = original_sp
        except Exception as exc:
            errors.append("Could not restore the shared parameter file: %s" % exc)
    return (state["result"], stages, results, validation_notes, warnings,
            errors, original_sp)
