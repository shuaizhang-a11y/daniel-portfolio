"""Deterministic parameter carry-over for controlled element replacement.

Extracted verbatim from the validated Phase 7C component as a mixin, so the
methods keep their exact bodies and their ``self`` semantics. Identity is
resolved by shared GUID, then BuiltInParameter id, and only then by an
unambiguous display name with a matching storage type.

No Revit import at module level: the Revit API arrives through ``self.DB``.
"""

from . import shared_parameters


class ParameterCarryMixin(object):
    # IfcGUID is a per-element identity; the rest are set structurally when the
    # element is created, or are written through the formal Phase 7C path.
    EXCLUDED_NAMES = ("IfcGUID", "IfcGUID Element")
    EXCLUDED_BUILTIN = ("IFC_GUID", "LEVEL_PARAM", "SCHEDULE_LEVEL_PARAM",
                        "ELEM_FAMILY_PARAM", "ELEM_TYPE_PARAM",
                        "ELEM_FAMILY_AND_TYPE_PARAM", "HOST_ID_PARAM",
                        "ELEM_PARTITION_PARAM")
    #: ElementId parameters approved to carry across, by BuiltInParameter name.
    ELEMENTID_ALLOWED = ("PHASE_CREATED", "PHASE_DEMOLISHED")

    def _builtin_ids(self, tokens):
        DB = self.DB
        found = {}
        for token in tokens:
            builtin = getattr(DB.BuiltInParameter, token, None)
            if builtin is None:
                continue
            try:
                found[int(builtin)] = token
            except Exception:
                continue
        return found

    @staticmethod
    def _param_id(parameter):
        try:
            pid = parameter.Id
        except Exception:
            return None
        try:
            return pid.IntegerValue
        except Exception:
            try:
                return int(pid.Value)
            except Exception:
                return None

    @staticmethod
    def _param_guid(parameter):
        try:
            if parameter.IsShared:
                return str(parameter.GUID)
        except Exception:
            pass
        return None

    def parameter_identity(self, parameter):
        """(kind, key, label) - how this parameter is matched across elements."""
        guid = self._param_guid(parameter)
        if guid:
            return ("shared", guid, "shared GUID %s" % guid)
        pid = self._param_id(parameter)
        if pid is not None and pid < 0:
            return ("builtin", pid, "BuiltInParameter id %d" % pid)
        return ("name", None, "project/family parameter")

    def carry_parameters(self, old, new):
        """Copy writable instance parameters using deterministic identity.

        Shared parameters match by GUID, built-ins by ParameterId, and anything
        else only by an unambiguous name with an identical storage type. Every
        omission is recorded with its identity, name, storage type and reason.
        """
        DB = self.DB
        copied, skipped = [], []
        excluded_builtin = self._builtin_ids(self.EXCLUDED_BUILTIN)
        allowed_eid = self._builtin_ids(self.ELEMENTID_ALLOWED)
        dz_names = set(shared_parameters.BY_NAME)

        def name_of(parameter):
            try:
                return parameter.Definition.Name
            except Exception:
                return "(unnamed)"

        def note(parameter, name, reason):
            kind, _key, label = self.parameter_identity(parameter)
            skipped.append({
                "Identity": label, "Kind": kind, "Name": name,
                "StorageType": str(getattr(parameter, "StorageType", "unknown")),
                "Reason": reason,
            })

        source_params = list(old.Parameters)
        target_params = list(new.Parameters)
        source_names, target_names = {}, {}
        for parameter in source_params:
            key = name_of(parameter)
            source_names[key] = source_names.get(key, 0) + 1
        for parameter in target_params:
            key = name_of(parameter)
            target_names[key] = target_names.get(key, 0) + 1

        target_by_guid, target_by_id = {}, {}
        for parameter in target_params:
            guid = self._param_guid(parameter)
            if guid:
                target_by_guid[guid] = parameter
            pid = self._param_id(parameter)
            if pid is not None and pid < 0:
                target_by_id[pid] = parameter

        for parameter in source_params:
            name = name_of(parameter)
            kind, key, _label = self.parameter_identity(parameter)

            if parameter.IsReadOnly:
                continue                       # derived from geometry or type
            if name in self.EXCLUDED_NAMES:
                note(parameter, name, "per-element identity, never duplicated")
                continue
            if name in dz_names:
                continue                       # written by the Phase 7C path
            if kind == "builtin" and key in excluded_builtin:
                note(parameter, name,
                     "%s is set structurally at creation" % excluded_builtin[key])
                continue

            # -- resolve the matching target parameter ---------------------
            target = None
            if kind == "shared":
                target = target_by_guid.get(key)
                if target is None:
                    note(parameter, name,
                         "no shared parameter with this GUID on the new element")
                    continue
            elif kind == "builtin":
                target = target_by_id.get(key)
                if target is None:
                    note(parameter, name,
                         "no built-in parameter with this ParameterId on the "
                         "new element")
                    continue
            else:
                if source_names.get(name, 0) != 1:
                    note(parameter, name,
                         "ambiguous: %d source parameters share this name"
                         % source_names.get(name, 0))
                    continue
                if target_names.get(name, 0) != 1:
                    note(parameter, name,
                         "ambiguous: %d target parameters share this name"
                         % target_names.get(name, 0))
                    continue
                target = new.LookupParameter(name)
                if target is None:
                    note(parameter, name, "not present on the new element")
                    continue

            if target.IsReadOnly:
                note(parameter, name, "read-only on the new element")
                continue
            if str(target.StorageType) != str(parameter.StorageType):
                note(parameter, name,
                     "storage type differs (source %s, target %s)"
                     % (parameter.StorageType, target.StorageType))
                continue

            # -- transfer --------------------------------------------------
            try:
                storage = parameter.StorageType
                if storage == DB.StorageType.ElementId:
                    if not (kind == "builtin" and key in allowed_eid):
                        note(parameter, name,
                             "ElementId transfer is not approved for this "
                             "parameter")
                        continue
                    value = parameter.AsElementId()
                    if value is None or self._id(value) <= 0:
                        continue
                    if self.doc.GetElement(value) is None:
                        note(parameter, name,
                             "referenced element %s does not exist"
                             % self._id(value))
                        continue
                    if self._id(target.AsElementId()) != self._id(value):
                        target.Set(value)
                elif storage == DB.StorageType.String:
                    value = parameter.AsString()
                    if value is None:
                        continue
                    if target.AsString() != value:
                        target.Set(value)
                elif storage == DB.StorageType.Integer:
                    value = parameter.AsInteger()
                    if target.AsInteger() != value:
                        target.Set(value)
                elif storage == DB.StorageType.Double:
                    value = parameter.AsDouble()
                    if abs((target.AsDouble() or 0.0) - value) > 1e-12:
                        target.Set(value)
                else:
                    note(parameter, name, "unsupported storage type")
                    continue
                copied.append(name)
            except Exception as exc:
                note(parameter, name, "write failed: %s" % type(exc).__name__)
        return copied, skipped
