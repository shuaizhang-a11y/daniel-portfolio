"""The Phase 7C Change Plan: a readable account of every intended action."""

from . import COORDINATE_WARNING
from .change_detection import (BLOCKED, CONFLICT, CREATE, DELETE, MARK_ONLY,
                               OBSOLETE, SKIP, counts, worst_action)

PUBLISH_MODES = ("Preview Only", "Create or Update", "Update Existing Only")


class ChangePlan(object):
    def __init__(self, building, identity_info, manifest_sha, publish_mode,
                 obsolete_action=MARK_ONLY, confirm_delete=False):
        self.building = building
        self.identity = dict(identity_info or {})
        self.manifest_sha = manifest_sha
        self.publish_mode = publish_mode
        self.obsolete_action = obsolete_action
        self.confirm_delete = confirm_delete
        self.changes = []
        self.obsolete = []
        self.conflicts = []
        self.blocking = []
        self.warnings = []
        self.migration = []
        self.rvt_path = None
        self.source_model_hash = None

    @property
    def plan_valid(self):
        """Nothing blocks this plan.

        Deliberately separate from ``publish_ready``: a Preview Only run can be
        completely clean and still, correctly, refuse to write anything.
        """
        return not self.blocking and self.publish_mode in PUBLISH_MODES

    @property
    def publish_ready(self):
        if self.blocking or self.publish_mode not in PUBLISH_MODES:
            return False
        if self.publish_mode == "Preview Only":
            return False
        if self.publish_mode == "Update Existing Only":
            if any(c.action == CREATE for c in self.changes):
                return False
        return True

    def counts(self):
        return counts(self.changes, self.obsolete)

    def expected(self):
        tally = self.counts()
        return {
            "created": tally.get(CREATE, 0),
            "updated": sum(v for k, v in tally.items() if k.startswith("UPDATE")),
            "skipped": tally.get(SKIP, 0),
            "obsolete": tally.get(OBSOLETE, 0),
            "conflicts": tally.get(CONFLICT, 0) + tally.get(BLOCKED, 0),
        }

    def render(self):
        lines = []
        add = lines.append
        add("PHASE 7C CHANGE PLAN")
        add("=" * 70)
        add("Project          : %s" % self.identity.get("projectId"))
        add("Option           : %s" % self.identity.get("option"))
        add("Revision         : %s" % self.identity.get("revision"))
        if self.building is not None:
            add("Building         : %s" % self.building.describe())
            add("SourceId         : %s" % self.building.source_id)
        add("Manifest SHA-256 : %s" % self.manifest_sha)
        add("Revit model      : %s" % (self.rvt_path or "(unsaved)"))
        add("Publish Mode     : %s" % self.publish_mode)
        add("Obsolete Action  : %s%s" % (self.obsolete_action,
                                         "  (delete confirmed)"
                                         if self.confirm_delete else ""))
        add("")

        if self.migration:
            add("Identity migration:")
            for row in self.migration:
                add("  floor %-3s element %-9s  %s -> %s"
                    % (row.get("FloorIndex"), row.get("ElementId"),
                       row.get("MatchedBy"), row.get("StableKey")))
            add("")

        for change in self.changes:
            add("%s Floor %02d" % (self.building.building_id if self.building
                                   else "?", change.floor_index or 0))
            add("  Level      : %s" % change.level_action)
            add("  Floor      : %s" % change.floor_action)
            add("  Area Plan  : %s" % change.area_plan_action)
            add("  Boundary   : %s" % change.boundary_action)
            add("  Area       : %s" % change.area_action)
            add("  Status     : %s%s" % (change.action,
                                         "  (element %s)" % change.element_id
                                         if change.element_id else ""))
            detail = change.describe()
            if detail:
                add("  Detail     : %s" % detail)
            expected_old = (change.previous or {}).get("FloorPlateArea")
            expected_new = (change.current or {}).get("FloorPlateArea")
            if (expected_old is not None and expected_new is not None
                    and expected_old != expected_new):
                add("  Expected area: %.2f m2 -> %.2f m2"
                    % (float(expected_old), float(expected_new)))
            for warning in change.warnings:
                add("  ! %s" % warning)
            add("")

        if self.obsolete:
            add("Obsolete elements:")
            for change in self.obsolete:
                add("  element %-9s key %-40s action %s"
                    % (change.element_id, change.stable_key, change.floor_action))
            add("")

        expected = self.expected()
        add("Expected counts:")
        add("  created  : %d" % expected["created"])
        add("  updated  : %d" % expected["updated"])
        add("  skipped  : %d" % expected["skipped"])
        add("  obsolete : %d" % expected["obsolete"])
        add("  conflicts: %d" % expected["conflicts"])
        add("")

        add("Warnings:")
        shown = list(self.warnings)
        if COORDINATE_WARNING not in shown:
            shown.insert(0, COORDINATE_WARNING)
        for warning in shown:
            add("  - %s" % warning)
        if self.conflicts:
            add("")
            add("Conflict report:")
            for conflict in self.conflicts:
                add("  - %s" % conflict)
        if self.blocking:
            add("")
            add("Blocking:")
            for item in self.blocking:
                add("  - %s" % item)
        add("")
        add("Plan Valid   : %s%s" % (
            "YES" if self.plan_valid else "NO",
            "  (nothing blocks this plan)" if self.plan_valid else ""))
        add("Publish Ready: %s%s" % (
            "YES" if self.publish_ready else "NO",
            "  (Preview Only never writes)"
            if self.plan_valid and not self.publish_ready
            and self.publish_mode == "Preview Only" else ""))
        return "\n".join(lines)

    def as_dict(self):
        return {
            "ProjectId": self.identity.get("projectId"),
            "Option": self.identity.get("option"),
            "Revision": self.identity.get("revision"),
            "BuildingId": self.building.building_id if self.building else None,
            "BuildingSourceId": self.building.source_id if self.building else None,
            "ManifestSha256": self.manifest_sha,
            "SourceModelHash": self.source_model_hash,
            "RevitModelPath": self.rvt_path,
            "PublishMode": self.publish_mode,
            "ObsoleteAction": self.obsolete_action,
            "ConfirmDelete": self.confirm_delete,
            "Migration": list(self.migration),
            "Changes": [c.as_dict() for c in self.changes],
            "Obsolete": [c.as_dict() for c in self.obsolete],
            "Conflicts": list(self.conflicts),
            "Blocking": list(self.blocking),
            "Warnings": list(self.warnings),
            "Counts": self.counts(),
            "Expected": self.expected(),
            "WorstAction": worst_action(self.changes, self.obsolete),
            "PlanValid": self.plan_valid,
            "PublishReady": self.publish_ready,
        }
