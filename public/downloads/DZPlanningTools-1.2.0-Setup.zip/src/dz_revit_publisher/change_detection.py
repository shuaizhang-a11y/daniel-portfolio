"""Phase 7C change classification.

Every tracked floor is classified before any Revit write, so publishing is the
execution of a reviewed decision. Nothing here touches Revit.
"""

from . import identity, snapshot

CREATE = "CREATE"
SKIP = "SKIP"
UPDATE_PARAMETERS = "UPDATE PARAMETERS"
UPDATE_ELEVATION = "UPDATE ELEVATION"
UPDATE_GEOMETRY = "UPDATE GEOMETRY"
OBSOLETE = "OBSOLETE"
CONFLICT = "CONFLICT"
BLOCKED = "BLOCKED"

# Worst-first, so a floor needing both a metadata and a geometry change is
# reported as the geometry change it really is.
SEVERITY = {SKIP: 0, UPDATE_PARAMETERS: 1, UPDATE_ELEVATION: 2,
            UPDATE_GEOMETRY: 3, CREATE: 4, OBSOLETE: 5, CONFLICT: 6,
            BLOCKED: 7}

# Sub-element intents. These are contracts with the executor, so they say
# exactly what will happen to the element - including whether its ElementId
# survives - rather than a vague "recreate".
FLOOR_REPLACE = "REPLACE (controlled, new ElementId)"
BOUNDARY_RECREATE = "RECREATE DZ LOOP"
AREA_REASSOCIATE = "REASSOCIATE IN PLACE (fallback: controlled replace)"

MARK_ONLY = "Mark Only"
ARCHIVE = "Archive"
DELETE = "Delete"
OBSOLETE_ACTIONS = (MARK_ONLY, ARCHIVE, DELETE)


class FloorChange(object):
    def __init__(self, floor_index, stable_key, action, element=None,
                 current=None, previous=None, difference=None):
        self.floor_index = floor_index
        self.stable_key = stable_key
        self.action = action
        self.element = element or {}
        self.current = current or {}
        self.previous = previous or {}
        self.difference = difference or {}
        self.matched_by = None
        self.needs_migration = False
        #: set by the executor when the element is replaced
        self.previous_element_id = None
        self.new_element_id = None
        self.warnings = []
        self.error = None
        # sub-element intents, filled by the planner
        self.level_action = SKIP
        self.floor_action = SKIP
        self.area_plan_action = "REUSE"
        self.boundary_action = SKIP
        self.area_action = SKIP

    @property
    def element_id(self):
        return self.element.get("ElementId")

    def describe(self):
        bits = []
        if self.difference.get("no_baseline"):
            return ("no Phase 7C baseline recorded; identity, elevation and "
                    "boundary hash will be written for the first time")
        if self.previous and self.current:
            if "Elevation" in self.difference.get("elevation", []):
                old = self.previous.get("Elevation")
                new = self.current.get("Elevation")
                if old is None:
                    bits.append("elevation not previously recorded -> %.3f m"
                                % float(new or 0.0))
                else:
                    bits.append("elevation %.3f m -> %.3f m"
                                % (float(old), float(new or 0.0)))
            if self.difference.get("geometry"):
                bits.append("boundary hash changed")
            for field in self.difference.get("metadata", []):
                bits.append("%s %r -> %r" % (field, self.previous.get(field),
                                             self.current.get(field)))
        return "; ".join(bits)

    def as_dict(self):
        return {
            "FloorIndex": self.floor_index,
            "StableKey": self.stable_key,
            "Action": self.action,
            "ElementId": self.element_id,
            "PreviousElementId": self.previous_element_id,
            "NewElementId": self.new_element_id,
            "MatchedBy": self.matched_by,
            "NeedsMigration": self.needs_migration,
            "PreviousSnapshot": dict(self.previous),
            "CurrentSnapshot": dict(self.current),
            "Difference": dict(self.difference),
            "LevelAction": self.level_action,
            "FloorAction": self.floor_action,
            "AreaPlanAction": self.area_plan_action,
            "BoundaryAction": self.boundary_action,
            "AreaAction": self.area_action,
            "Detail": self.describe(),
            "Warnings": list(self.warnings),
            "Error": self.error,
        }


def classify(building, identity_info, manifest_sha, footprint_points,
             observed_floors, log_ids=None, obsolete_action=MARK_ONLY):
    """Classify every source floor and every tracked element.

    Returns (changes, obsolete_changes, conflicts, warnings).
    """
    matches, unmatched, conflicts = identity.match_elements(
        building, observed_floors, log_ids)
    warnings = []

    by_index = dict((m.floor.floor_index, m) for m in matches)
    changes = []

    for floor in building.floors:
        stable = identity.stable_floor_key(building.source_id, floor.floor_index)
        current = snapshot.build(building, floor, identity_info, manifest_sha,
                                 footprint_points)
        match = by_index.get(floor.floor_index)

        if match is None:
            change = FloorChange(floor.floor_index, stable, CREATE,
                                 current=current)
            change.level_action = CREATE
            change.floor_action = CREATE
            change.area_plan_action = CREATE
            change.boundary_action = CREATE
            change.area_action = CREATE
            changes.append(change)
            continue

        previous = snapshot.from_element(match.element)
        difference = snapshot.compare(previous, current)
        change = FloorChange(floor.floor_index, stable, SKIP, match.element,
                             current, previous, difference)
        change.matched_by = match.matched_by
        change.needs_migration = match.needs_migration
        change.warnings.extend(identity.validate_secondary(match))

        if match.needs_migration:
            change.warnings.append(
                "Element %s still carries %s; Phase 7C will write the stable "
                "identity." % (match.element.get("ElementId"), match.matched_by))

        if not snapshot.has_baseline(previous):
            # First Phase 7C pass over a Phase 7A/7B element: there is no stored
            # snapshot to diff against, so geometry is validated against the
            # element's measured area rather than assumed to have changed.
            change.action = UPDATE_PARAMETERS
            change.floor_action = UPDATE_PARAMETERS
            change.area_action = UPDATE_PARAMETERS
            change.needs_migration = True
            # Diffing against an absent baseline reads as "elevation not
            # recorded" and "hash changed", which describes a change that did
            # not happen. Say what is actually true instead.
            change.difference = {"changed": [], "geometry": [], "elevation": [],
                                 "metadata": [], "volatile": [],
                                 "substantive": False, "no_baseline": True}
            change.warnings.append(
                "Element %s carries no Phase 7C snapshot yet; identity and "
                "snapshot will be written. Geometry is validated against the "
                "measured area, not rebuilt."
                % (match.element.get("ElementId")))
            measured = match.element.get("Area")
            expected = floor.plate_area
            if measured is not None and expected:
                ratio = abs(float(measured) - float(expected)) / float(expected)
                if ratio > 0.01:
                    change.action = UPDATE_GEOMETRY
                    change.floor_action = FLOOR_REPLACE
                    change.boundary_action = BOUNDARY_RECREATE
                    change.area_action = AREA_REASSOCIATE
                    change.warnings.append(
                        "Measured area %.4f m2 differs from the source %.4f m2 "
                        "by %.2f%%; geometry really has changed."
                        % (float(measured), float(expected), ratio * 100.0))
            changes.append(change)
            continue

        if difference["geometry"]:
            change.action = UPDATE_GEOMETRY
            change.floor_action = FLOOR_REPLACE
            change.boundary_action = BOUNDARY_RECREATE
            change.area_action = AREA_REASSOCIATE
        elif difference["elevation"]:
            change.action = UPDATE_ELEVATION
            change.level_action = "UPDATE ELEVATION"
            change.floor_action = "UPDATE HOST LEVEL"
            change.area_action = "UPDATE LEVEL ASSOCIATION"
        elif difference["metadata"] or match.needs_migration:
            change.action = UPDATE_PARAMETERS
            change.floor_action = UPDATE_PARAMETERS
            change.area_action = UPDATE_PARAMETERS
        else:
            change.action = SKIP
            if difference["volatile"]:
                change.warnings.append(
                    "Only the export revision or manifest hash changed for "
                    "floor %s; treated as SKIP." % floor.floor_index)
        changes.append(change)

    # -- obsolete: tracked elements with no matching source floor ----------
    matched_ids = set(m.element.get("ElementId") for m in matches)
    source_keys = set(identity.stable_floor_key(building.source_id, f.floor_index)
                      for f in building.floors)
    obsolete = []
    for row in observed_floors or []:
        element_id = row.get("ElementId")
        if element_id in matched_ids:
            continue
        key = row.get("DZ_Floor_Key")
        migrated = identity.migrate_key(key) if key else None
        if migrated is None and row.get("DZ_Building_ID") != building.building_id:
            continue                      # not ours; leave it alone
        if migrated and migrated in source_keys:
            continue
        change = FloorChange(row.get("DZ_Floor_Index"), migrated or key,
                             OBSOLETE, row, previous=snapshot.from_element(row))
        change.level_action = SKIP
        change.floor_action = obsolete_action
        change.area_plan_action = SKIP
        change.boundary_action = SKIP
        change.area_action = obsolete_action
        change.warnings.append(
            "No source floor matches this tracked element. Action: %s."
            % obsolete_action)
        obsolete.append(change)

    for floor in unmatched:
        # unmatched but present in the source: that is a CREATE, already handled
        pass

    return changes, obsolete, conflicts, warnings


def counts(changes, obsolete=None):
    tally = {}
    for change in list(changes) + list(obsolete or []):
        tally[change.action] = tally.get(change.action, 0) + 1
    return tally


def worst_action(changes, obsolete=None):
    worst = SKIP
    for change in list(changes) + list(obsolete or []):
        if SEVERITY.get(change.action, 0) > SEVERITY.get(worst, 0):
            worst = change.action
    return worst


def blocking_conflicts(conflicts, changes=None, obsolete=None,
                       obsolete_action=MARK_ONLY, confirm_delete=False):
    """Everything that must stop a publish."""
    blocking = list(conflicts or [])
    for change in list(changes or []) + list(obsolete or []):
        if change.action in (CONFLICT, BLOCKED):
            blocking.append("Floor %s: %s" % (change.floor_index,
                                              change.error or change.action))
    if obsolete and obsolete_action == DELETE and not confirm_delete:
        blocking.append(
            "Obsolete Element Action is Delete but Confirm Delete Obsolete is "
            "false. %d element(s) would be deleted: %s. Deletion needs a second "
            "explicit confirmation."
            % (len(obsolete), ", ".join(str(o.element_id) for o in obsolete)))
    return blocking
