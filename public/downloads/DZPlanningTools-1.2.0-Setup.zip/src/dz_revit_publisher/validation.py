"""Phase 7A validation. Blocking issues stop the publish before any transaction.

None of this touches Rhino or Revit. Geometry arrives already measured as a
`FootprintFacts`, and the Revit session arrives as a `RevitContext`.
"""

import math

from . import SUPPORTED_SCHEMA
from .manifest_loader import REQUIRED_SECTIONS
from .unit_conversion import (UnsupportedUnitError, assert_source_units,
                              effective_short_curve_tolerance_metres)

# A published Revit floor is allowed to differ from the exported plate area by
# this fraction before it is reported. Rectangular footprints should match far
# more closely; the allowance exists for curve conversion, not for sloppiness.
AREA_TOLERANCE_RATIO = 0.01
# Beyond this the difference is not a tolerance question. An area that is out by
# more than 10% almost always means the source geometry is in different units
# than the manifest, and publishing it would produce grossly wrong elements, so
# it blocks rather than warns.
AREA_BLOCKING_RATIO = 0.10
# Two elevations closer than this are the same level as far as Revit is concerned.
ELEVATION_MATCH_TOLERANCE_M = 0.001


class Result(object):
    def __init__(self):
        self.blocking = []
        self.warnings = []
        self.checks = []

    @property
    def ok(self):
        return not self.blocking

    def block(self, message):
        self.blocking.append(message)

    def warn(self, message):
        self.warnings.append(message)

    def check(self, label, passed, detail=""):
        self.checks.append({"Check": label,
                            "Result": "PASS" if passed else "FAIL",
                            "Detail": detail})
        return passed

    def extend(self, other):
        self.blocking.extend(other.blocking)
        self.warnings.extend(other.warnings)
        self.checks.extend(other.checks)
        return self


def _finite(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return False
    return not (math.isnan(number) or math.isinf(number))


# ---------------------------------------------------------------------------
# manifest
# ---------------------------------------------------------------------------

def validate_manifest(manifest):
    result = Result()
    if not isinstance(manifest, dict):
        result.block("Manifest root is not a JSON object.")
        return result

    missing = [key for key in REQUIRED_SECTIONS if key not in manifest]
    if missing:
        result.block("Manifest is missing required sections: %s"
                     % ", ".join(missing))
    result.check("Required manifest sections", not missing,
                 "missing: %s" % ", ".join(missing) if missing
                 else "%d/%d" % (len(REQUIRED_SECTIONS), len(REQUIRED_SECTIONS)))
    if missing:
        return result

    schema = str(manifest.get("schemaVersion") or "")
    supported = schema in SUPPORTED_SCHEMA
    if not supported:
        result.block("Unsupported schemaVersion %r. Supported: %s"
                     % (schema, ", ".join(SUPPORTED_SCHEMA)))
    result.check("Schema version supported", supported, schema or "(absent)")

    if not isinstance(manifest.get("buildings"), list) or not manifest["buildings"]:
        result.block("Manifest contains no buildings.")
    if not isinstance(manifest.get("floors"), list) or not manifest["floors"]:
        result.block("Manifest contains no floor rows. Phase 7A will not invent "
                     "floors; re-run the Phase 6A export.")
    result.check("Buildings and floors present",
                 bool(manifest.get("buildings")) and bool(manifest.get("floors")),
                 "buildings=%d floors=%d" % (len(manifest.get("buildings") or []),
                                             len(manifest.get("floors") or [])))

    metadata = manifest.get("exportMetadata") or {}
    units = metadata.get("RhinoModelUnits")
    try:
        assert_source_units(units)
        result.check("Source units are metres", True, str(units))
    except UnsupportedUnitError as exc:
        result.block(str(exc))
        result.check("Source units are metres", False, str(units))

    return result


# ---------------------------------------------------------------------------
# building selection
# ---------------------------------------------------------------------------

def validate_building(building, all_buildings):
    """A building is publishable only if identity, floors and areas are sound."""
    result = Result()
    if building is None:
        result.block("No building was selected.")
        return result

    has_source = bool(building.source_id)
    if not has_source:
        result.block("Building %s has no DZ.SourceId; Phase 7A refuses to "
                     "publish untracked geometry." % building.building_id)
    result.check("Building SourceId present", has_source,
                 str(building.source_id))

    ids = [b.building_id for b in all_buildings if b.building_id]
    unique = ids.count(building.building_id) == 1
    if not unique:
        result.block("BuildingId %r appears %d times in the manifest."
                     % (building.building_id, ids.count(building.building_id)))
    result.check("BuildingId unique", unique, str(building.building_id))

    source_ids = [b.source_id for b in all_buildings if b.source_id]
    source_unique = (not building.source_id
                     or source_ids.count(building.source_id) == 1)
    if not source_unique:
        result.block("SourceId %s is not unique across manifest buildings."
                     % building.source_id)
    result.check("Building SourceId unique", source_unique,
                 str(building.source_id))

    floors = building.floors
    if not floors:
        result.block("Building %s has no floor rows." % building.building_id)
    result.check("Floor rows present", bool(floors), "%d row(s)" % len(floors))
    if not floors:
        return result

    bad_elevation = [f.floor_index for f in floors if not _finite(f.elevation)]
    if bad_elevation:
        result.block("Non-finite elevation on floor index %s"
                     % ", ".join(str(i) for i in bad_elevation))
    result.check("Elevations finite", not bad_elevation,
                 "%d floor(s) checked" % len(floors))

    bad_area = [f.floor_index for f in floors
                if not _finite(f.plate_area) or float(f.plate_area or 0) <= 0]
    if bad_area:
        result.block("Non-positive floor plate area on floor index %s"
                     % ", ".join(str(i) for i in bad_area))
    result.check("Floor plate areas positive", not bad_area,
                 "%d floor(s) checked" % len(floors))

    bad_index = [f for f in floors if f.floor_index is None]
    if bad_index:
        result.block("%d floor row(s) have no usable FloorIndex." % len(bad_index))
    result.check("Floor indices usable", not bad_index,
                 "%d floor(s)" % len(floors))

    mismatched = [f.floor_index for f in floors
                  if f.building_source_id and building.source_id
                  and f.building_source_id != building.source_id]
    if mismatched:
        result.block("Floor rows %s reference a different BuildingSourceId."
                     % ", ".join(str(i) for i in mismatched))
    result.check("Floor rows match building SourceId", not mismatched,
                 str(building.source_id))

    keys = []
    for floor in floors:
        try:
            keys.append(floor.key())
        except ValueError as exc:
            result.block("Floor key could not be built: %s" % exc)
    duplicates = sorted(set(k for k in keys if keys.count(k) > 1))
    if duplicates:
        result.block("Duplicate floor keys within the building: %s"
                     % ", ".join(duplicates))
    result.check("Floor keys unique", not duplicates, "%d key(s)" % len(keys))

    return result


def first_valid_building(buildings):
    """The first building that passes validation, for the controlled test."""
    for building in buildings:
        if validate_building(building, buildings).ok:
            return building
    return None


# ---------------------------------------------------------------------------
# geometry
# ---------------------------------------------------------------------------

def validate_footprint(facts, building, rhino_tolerance_metres=None):
    """Check a measured footprint is publishable as a Revit floor boundary."""
    result = Result()
    if facts is None:
        result.block("No footprint geometry was matched for building %s "
                     "(SourceId %s). Phase 7A will not reconstruct a boundary "
                     "from area values."
                     % (building.building_id if building else "?",
                        building.source_id if building else "?"))
        result.check("Footprint matched", False, "no geometry")
        return result

    matched = bool(facts.source_id) and facts.source_id == (
        building.source_id if building else None)
    if not matched:
        result.block("Footprint SourceId %r does not match building SourceId %r."
                     % (facts.source_id,
                        building.source_id if building else None))
    result.check("Footprint matched by SourceId", matched, str(facts.source_id))

    unique = (facts.duplicate_matches or 0) == 1
    if not unique:
        result.block("SourceId %s matched %d objects; the duplicate must be "
                     "resolved before publishing."
                     % (facts.source_id, facts.duplicate_matches))
    result.check("Single geometry match", unique,
                 "%s match(es)" % facts.duplicate_matches)

    if not facts.is_closed:
        result.block("Footprint curve is not closed.")
    result.check("Footprint closed", bool(facts.is_closed), str(facts.is_closed))

    if not facts.is_planar:
        result.block("Footprint curve is not planar.")
    result.check("Footprint planar", bool(facts.is_planar), str(facts.is_planar))

    area_ok = _finite(facts.area) and float(facts.area or 0) > 0
    if not area_ok:
        result.block("Footprint has no usable area.")
    result.check("Footprint area positive", area_ok,
                 "%s m2" % facts.area)

    crossings = facts.self_intersections
    clean = crossings in (0, None)
    if not clean:
        result.block("Footprint curve self-intersects (%s crossing(s))." % crossings)
    result.check("No self-intersections", clean, str(crossings))

    limit = effective_short_curve_tolerance_metres(rhino_tolerance_metres)
    if facts.minimum_segment is not None and facts.minimum_segment < limit:
        result.block("Footprint contains a segment of %.6f m, below the "
                     "effective Revit limit of %.6f m."
                     % (facts.minimum_segment, limit))
    result.check("No segments below Revit tolerance",
                 facts.minimum_segment is None or facts.minimum_segment >= limit,
                 "min segment %s m, limit %.6f m" % (facts.minimum_segment, limit))

    if facts.point_count is not None and facts.point_count < 4:
        result.block("Footprint has too few points (%s) to form a closed loop."
                     % facts.point_count)

    if building is not None and _finite(building.footprint_area) and area_ok:
        expected = float(building.footprint_area)
        actual = float(facts.area)
        if expected:
            ratio = abs(actual - expected) / expected
            within = ratio <= AREA_TOLERANCE_RATIO
            if ratio > AREA_BLOCKING_RATIO:
                result.block(
                    "Matched footprint area %.4f m2 differs from the exported "
                    "FootprintArea %.4f m2 by %.2f%%. A difference this large "
                    "is a unit or scale mismatch, not a tolerance. Publishing "
                    "is blocked. Check the source document's unit system."
                    % (actual, expected, ratio * 100.0))
            elif not within:
                result.warn("Matched footprint area %.4f m2 differs from the "
                            "exported FootprintArea %.4f m2 by %.2f%%."
                            % (actual, expected, ratio * 100.0))
            result.check("Footprint area matches manifest", within,
                         "%.4f vs %.4f m2" % (actual, expected))

    if facts.simplified:
        result.warn("Footprint geometry was simplified for Revit: %s"
                    % (facts.simplification_note or "no detail recorded"))

    return result


# ---------------------------------------------------------------------------
# Revit session
# ---------------------------------------------------------------------------

def validate_revit_context(context, floor_type_name=None):
    result = Result()
    if context is None or not context.available:
        result.block("Rhino.Inside.Revit is not available in this session. "
                     "Start Revit, load Rhino.Inside.Revit, then open this "
                     "definition in Grasshopper inside Revit.")
        result.check("Rhino.Inside.Revit available", False, "not detected")
        return result
    result.check("Rhino.Inside.Revit available", True,
                 str(context.rir_version or "version unknown"))

    if not context.document_name:
        result.block("No active Revit document. Open a blank or designated "
                     "Revit test model before publishing.")
    result.check("Active Revit document", bool(context.document_name),
                 str(context.document_name))

    if context.is_family:
        result.block("The active document is a family document. Phase 7A "
                     "publishes into a project document only.")

    if context.is_writable is False:
        result.block("The active Revit document is not writable.")
    result.check("Document writable", context.is_writable is not False,
                 str(context.is_writable))

    if context.in_transaction:
        result.block("A Revit transaction is already open. Phase 7A will not "
                     "nest inside an existing transaction.")
    result.check("No open transaction", not context.in_transaction,
                 str(context.in_transaction))

    if context.is_workshared:
        result.warn("The active document is workshared. Phase 7A was designed "
                    "for a standalone test model; confirm worksets before "
                    "publishing.")

    if not context.floor_types:
        result.block("The Revit document has no Floor Types available.")
    result.check("Floor types available", bool(context.floor_types),
                 "%d type(s)" % len(context.floor_types))

    if floor_type_name:
        names = [str(n) for n in context.floor_types]
        present = str(floor_type_name) in names
        if not present:
            result.block("Floor Type %r was not found in the document. "
                         "Available: %s" % (floor_type_name,
                                            ", ".join(names[:12]) or "none"))
        result.check("Requested floor type present", present,
                     str(floor_type_name))
    elif context.floor_types:
        result.warn("No Floor Type was specified; the first available type "
                    "will be used: %s" % context.floor_types[0])

    missing_shared = [name for name in
                      ("DZ_Source_ID", "DZ_Building_ID", "DZ_Floor_Key")
                      if name not in (context.shared_parameters or [])]
    if missing_shared:
        result.warn("DZ shared parameters are not bound in this document (%s). "
                    "Phase 7A uses temporary DZ_TEST_TRACKING values in a "
                    "writable text parameter instead. Formal shared-parameter "
                    "binding is Phase 7B/7C work."
                    % ", ".join(missing_shared))

    return result
