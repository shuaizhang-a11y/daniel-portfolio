"""Area Scheme selection for Phase 7B.

Revit 2025 exposes no ``AreaScheme.Create``: area schemes can only be authored
through the Revit UI. That was verified against the installed API rather than
assumed, and it is why the preferred scheme cannot simply be created.

Selection order, matching the brief:

1. reuse an existing scheme named ``DZ Planning GFA``
2. create it, if the installed API ever gains support
3. otherwise fall back to an existing Gross Building scheme
4. never silently use Rentable
"""

PREFERRED_NAME = "DZ Planning GFA"
GROSS_BUILDING = "Gross Building"
RENTABLE = "Rentable"


class SchemeSelection(object):
    def __init__(self, name=None, element_id=None, action="REUSE",
                 reason=None, warnings=None, blocking=None):
        self.name = name
        self.element_id = element_id
        self.action = action
        self.reason = reason
        self.warnings = list(warnings or [])
        self.blocking = list(blocking or [])

    @property
    def ok(self):
        return not self.blocking and self.name is not None

    def as_dict(self):
        return {"AreaSchemeName": self.name, "ElementId": self.element_id,
                "Action": self.action, "Reason": self.reason,
                "Warnings": list(self.warnings), "Blocking": list(self.blocking)}


def select(available, can_create=False, allow_rentable=False):
    """Choose the Area Scheme.

    `available` items: {"Name": str, "Id": int}.
    """
    available = list(available or [])
    by_name = dict((str(s.get("Name")), s) for s in available)

    if PREFERRED_NAME in by_name:
        scheme = by_name[PREFERRED_NAME]
        return SchemeSelection(
            PREFERRED_NAME, scheme.get("Id"), "REUSE",
            "Existing '%s' scheme reused." % PREFERRED_NAME)

    if can_create:
        return SchemeSelection(
            PREFERRED_NAME, None, "CREATE",
            "The installed API supports Area Scheme creation.")

    gross = [s for s in available if GROSS_BUILDING.lower() in str(s.get("Name")).lower()]
    if gross:
        scheme = gross[0]
        return SchemeSelection(
            str(scheme.get("Name")), scheme.get("Id"), "REUSE",
            "Revit 2025 exposes no AreaScheme.Create, so the preferred "
            "'%s' scheme could not be created. Falling back to the existing "
            "Gross Building scheme." % PREFERRED_NAME,
            warnings=["Area Scheme '%s' could not be created: the installed "
                      "Revit API provides no way to create one. Areas are "
                      "published into the existing '%s' scheme instead. Create "
                      "'%s' manually in Revit if you want a dedicated scheme, "
                      "and this run will reuse it."
                      % (PREFERRED_NAME, scheme.get("Name"), PREFERRED_NAME)])

    if allow_rentable:
        rentable = [s for s in available
                    if RENTABLE.lower() in str(s.get("Name")).lower()]
        if rentable:
            scheme = rentable[0]
            return SchemeSelection(
                str(scheme.get("Name")), scheme.get("Id"), "REUSE",
                "Explicitly allowed Rentable fallback.",
                warnings=["Using the Rentable area scheme. GFA reporting "
                          "normally belongs in a Gross Building scheme."])

    if available:
        names = ", ".join(str(s.get("Name")) for s in available)
        return SchemeSelection(
            None, None, "ERROR", None,
            blocking=["No usable Area Scheme. '%s' does not exist, the "
                      "installed Revit API cannot create it, and no Gross "
                      "Building scheme was found. Available: %s. Create '%s' "
                      "in Revit, then run again."
                      % (PREFERRED_NAME, names, PREFERRED_NAME)])

    return SchemeSelection(
        None, None, "ERROR", None,
        blocking=["The document contains no Area Schemes at all."])
