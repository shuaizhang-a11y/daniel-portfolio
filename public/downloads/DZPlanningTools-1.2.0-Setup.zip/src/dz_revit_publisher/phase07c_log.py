"""Phase 7C change-plan and publish logging.

Three files, written alongside the Phase 7A and 7B logs so earlier evidence
stays exactly as it was verified:

    revit_publish/phase07c_change_plan.json   the latest plan, overwritten
    revit_publish/phase07c_publish_log.json   append-only history
    revit_publish/phase07c_publish_log.csv    one row per element action
"""

import csv
import datetime
import io
import json
import os

from . import PUBLISH_STATUSES, __version__

LOG_FOLDER = "revit_publish"
PLAN_NAME = "phase07c_change_plan.json"
JSON_NAME = "phase07c_publish_log.json"
CSV_NAME = "phase07c_publish_log.csv"

CSV_COLUMNS = [
    "PublishTimestamp", "UserClickTimestamp", "PublishStatus", "PublishMode",
    "ObsoleteAction", "ProjectId", "Option", "Revision", "BuildingId",
    "BuildingSourceId", "Stage", "ItemKind", "FloorIndex", "StableKey",
    "PreviousKey", "Action", "OldElementId", "NewElementId", "PreviousValue",
    "NewValue", "Note", "Error",
]


def iso_now():
    return datetime.datetime.now().replace(microsecond=0).isoformat()


def log_folder(package):
    folder = os.path.join(package, LOG_FOLDER)
    if not os.path.isdir(folder):
        os.makedirs(folder)
    return folder


def write_change_plan(package, plan_dict):
    """The plan is a snapshot of intent, so it is replaced each run."""
    path = os.path.join(log_folder(package), PLAN_NAME)
    payload = {"schemaVersion": "1.0", "phase": "7C",
               "generated": iso_now(), "plan": plan_dict}
    with io.open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, default=str)
    return path


def build_entry(status, plan, context, manifest_path, manifest_sha,
                source_model_hash, rvt_path, rvt_sha=None,
                transaction_result=None, stage_results=None, results=None,
                warnings=None, errors=None, user_click=None,
                final_validation=None):
    if status not in PUBLISH_STATUSES:
        status = "FAILED"
    building = plan.building if plan else None
    results = results or {}
    return {
        "PublishTimestamp": iso_now(),
        "UserClickTimestamp": user_click,
        "PublisherVersion": __version__,
        "DefinitionPhase": "7C",
        "PublishStatus": status,
        "PublishMode": plan.publish_mode if plan else None,
        "ObsoleteAction": plan.obsolete_action if plan else None,
        "ConfirmDelete": plan.confirm_delete if plan else None,

        "BaselineRvtPath": rvt_path,
        "BaselineRvtSha256": rvt_sha,
        "ManifestPath": manifest_path,
        "ManifestSha256": manifest_sha,
        "SourceModelHash": source_model_hash,

        "RevitDocumentName": context.document_name if context else None,
        "RevitVersion": context.revit_version if context else None,
        "RhinoInsideRevitVersion": context.rir_version if context else None,

        "ProjectId": plan.identity.get("projectId") if plan else None,
        "Option": plan.identity.get("option") if plan else None,
        "Revision": plan.identity.get("revision") if plan else None,
        "BuildingId": building.building_id if building else None,
        "BuildingSourceId": building.source_id if building else None,

        "Counts": plan.counts() if plan else {},
        "Expected": plan.expected() if plan else {},
        "Results": dict(results),
        "Plan": plan.as_dict() if plan else None,
        "StageResults": list(stage_results or []),
        "FinalValidation": list(final_validation or []),
        "TransactionResult": transaction_result,
        "Warnings": list(warnings or []),
        "Errors": list(errors or []),
    }


def _rows(entry):
    common = {
        "PublishTimestamp": entry.get("PublishTimestamp"),
        "UserClickTimestamp": entry.get("UserClickTimestamp"),
        "PublishStatus": entry.get("PublishStatus"),
        "PublishMode": entry.get("PublishMode"),
        "ObsoleteAction": entry.get("ObsoleteAction"),
        "ProjectId": entry.get("ProjectId"),
        "Option": entry.get("Option"),
        "Revision": entry.get("Revision"),
        "BuildingId": entry.get("BuildingId"),
        "BuildingSourceId": entry.get("BuildingSourceId"),
    }
    plan = entry.get("Plan") or {}
    rows = []
    for row in plan.get("Migration", []):
        rows.append(dict(common, Stage="IdentityMigration", ItemKind="Floor",
                         FloorIndex=row.get("FloorIndex"),
                         StableKey=row.get("StableKey"),
                         PreviousKey=row.get("ExistingKey"),
                         Action="MIGRATE", OldElementId=row.get("ElementId"),
                         NewElementId=row.get("ElementId"),
                         Note=row.get("MatchedBy")))
    for group, kind in ((plan.get("Changes", []), "Floor"),
                        (plan.get("Obsolete", []), "Obsolete")):
        for row in group:
            previous = row.get("PreviousSnapshot") or {}
            current = row.get("CurrentSnapshot") or {}
            rows.append(dict(
                common, Stage="Change", ItemKind=kind,
                FloorIndex=row.get("FloorIndex"),
                StableKey=row.get("StableKey"),
                Action=row.get("Action"),
                OldElementId=(row.get("PreviousElementId")
                              or row.get("ElementId")),
                NewElementId=(row.get("NewElementId") or row.get("ElementId")),
                PreviousValue="elev=%s hash=%s" % (previous.get("Elevation"),
                                                   str(previous.get("BoundaryHash"))[:12]),
                NewValue="elev=%s hash=%s" % (current.get("Elevation"),
                                              str(current.get("BoundaryHash"))[:12]),
                Note=row.get("Detail"), Error=row.get("Error")))
    for name, detail in (entry.get("Results") or {}).items():
        rows.append(dict(common, Stage="Result", ItemKind=name,
                         Action=str(detail)))
    for stage in entry.get("StageResults") or []:
        rows.append(dict(common, Stage="Stage%s" % stage.get("Stage"),
                         ItemKind=stage.get("Name"),
                         Action=stage.get("Status"),
                         Note="; ".join(stage.get("Detail") or []),
                         Error=stage.get("Error")))
    if not rows:
        rows.append(dict(common, Stage="None", ItemKind="None"))
    return rows


def write(package, entry):
    folder = log_folder(package)
    json_path = os.path.join(folder, JSON_NAME)
    history = {"schemaVersion": "1.0", "phase": "7C", "entries": []}
    if os.path.isfile(json_path):
        try:
            with io.open(json_path, "r", encoding="utf-8") as handle:
                existing = json.load(handle)
            if isinstance(existing, dict) and isinstance(existing.get("entries"), list):
                history = existing
        except Exception:
            backup = json_path + ".unreadable-%s" % datetime.datetime.now().strftime(
                "%Y%m%d_%H%M%S")
            try:
                os.rename(json_path, backup)
            except OSError:
                pass
    history.setdefault("entries", []).append(entry)
    history["latest"] = entry
    with io.open(json_path, "w", encoding="utf-8") as handle:
        json.dump(history, handle, ensure_ascii=False, indent=2, default=str)

    csv_path = os.path.join(folder, CSV_NAME)
    write_header = not os.path.isfile(csv_path)
    with io.open(csv_path, "a", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS,
                                extrasaction="ignore")
        if write_header:
            writer.writeheader()
        for row in _rows(entry):
            writer.writerow({key: ("" if row.get(key) is None else row.get(key))
                             for key in CSV_COLUMNS})
    return json_path, csv_path


def read_history(package):
    path = os.path.join(package, LOG_FOLDER, JSON_NAME)
    if not os.path.isfile(path):
        return {"entries": []}
    with io.open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)
