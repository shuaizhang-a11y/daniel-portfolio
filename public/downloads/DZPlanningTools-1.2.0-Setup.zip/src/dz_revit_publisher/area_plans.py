"""Area Plan naming and CREATE / REUSE decisions for Phase 7B."""

from . import naming

SUFFIX = "GFA"


def area_plan_name(building_id, level_name_text=None, floor_index=None):
    """`DZ-{BuildingId}-{LevelName}-GFA`, e.g. DZ-B001-L01-GFA.

    The level part follows the Phase 7A level naming so the two stay in step,
    including the 1-based floor index convention.
    """
    base = naming.level_name(building_id, level_name_text, floor_index)
    return "%s-%s" % (base, SUFFIX)


class AreaPlanRequest(object):
    def __init__(self, name, floor_index, level_name, level_id,
                 scheme_name=None, action="CREATE", element_id=None,
                 note=None):
        self.name = name
        self.floor_index = floor_index
        self.level_name = level_name
        self.level_id = level_id
        self.scheme_name = scheme_name
        self.action = action
        self.element_id = element_id
        self.note = note
        self.error = None

    def as_dict(self):
        return {
            "RequestedName": self.name, "FloorIndex": self.floor_index,
            "LevelName": self.level_name, "LevelId": self.level_id,
            "AreaScheme": self.scheme_name, "Action": self.action,
            "ElementId": self.element_id, "Note": self.note,
            "Error": self.error,
        }


def plan(building, level_by_index, scheme, existing_plans):
    """Decide one Area Plan per published level.

    `level_by_index` maps floor index to {"Name","Id"} of the hosting Revit
    level. `existing_plans` items: {"Name","Id","LevelId","AreaSchemeId"}.
    An existing plan is reused when it targets the same level and scheme, so a
    plan is never duplicated and unrelated views are never renamed.
    """
    existing = list(existing_plans or [])
    requests = []
    for floor in building.floors:
        index = floor.floor_index
        level = level_by_index.get(index) or {}
        name = area_plan_name(building.building_id, floor.level_name, index)

        match = None
        for view in existing:
            same_level = (level.get("Id") is not None
                          and view.get("LevelId") == level.get("Id"))
            same_scheme = (scheme.element_id is None
                           or view.get("AreaSchemeId") == scheme.element_id)
            if same_level and same_scheme:
                match = view
                break
        if match is None:
            for view in existing:
                if str(view.get("Name")) == name:
                    match = view
                    break

        if match is not None:
            request = AreaPlanRequest(name, index, level.get("Name"),
                                      level.get("Id"), scheme.name, "REUSE",
                                      match.get("Id"))
            if str(match.get("Name")) != name:
                request.note = ("existing view '%s' already covers this level "
                                "and scheme; it is reused and not renamed"
                                % match.get("Name"))
        else:
            request = AreaPlanRequest(name, index, level.get("Name"),
                                      level.get("Id"), scheme.name, "CREATE")
            if level.get("Id") is None:
                request.action = "ERROR"
                request.error = ("No Revit level is known for floor index %s."
                                 % index)
        requests.append(request)
    return requests
