"""Phase 7C formal identity and migration from the Phase 7A/7B key format.

The Phase 7A/7B floor key was ``{BuildingSourceId}:{FloorIndex}:{Elevation}``.
Baking elevation into the identity means moving a floor produces a *different*
key, so an elevation edit would create a second floor instead of updating the
first. Phase 7C therefore uses a stable key:

    {BuildingSourceId}:{FloorIndex}

with elevation carried separately in ``DZ_Floor_Elevation``.

Revit ElementIds are never treated as identity - the Phase 7B crash recovery
reassigned every id while the model was otherwise unchanged, which is exactly
the failure mode this guards against.
"""

import re

STABLE_KEY_PARTS = 2
LEGACY_KEY_PARTS = 3


def stable_floor_key(building_source_id, floor_index):
    """`{BuildingSourceId}:{FloorIndex}` - permanent, elevation independent."""
    if not building_source_id:
        raise ValueError("A building SourceId is required for a floor key.")
    if floor_index is None:
        raise ValueError("A floor index is required for a floor key.")
    return "%s:%d" % (str(building_source_id).strip(), int(floor_index))


def parse_stable_key(key):
    """(source_id, floor_index) or None."""
    if not key:
        return None
    parts = str(key).split(":")
    if len(parts) != STABLE_KEY_PARTS:
        return None
    try:
        return parts[0], int(parts[1])
    except (TypeError, ValueError):
        return None


def is_legacy_key(key):
    """True for the Phase 7A/7B three-part key that embeds elevation."""
    if not key:
        return False
    return len(str(key).split(":")) == LEGACY_KEY_PARTS


def parse_legacy_key(key):
    """(source_id, floor_index, elevation) from a Phase 7A/7B key, or None."""
    if not key:
        return None
    parts = str(key).split(":")
    if len(parts) != LEGACY_KEY_PARTS:
        return None
    try:
        return parts[0], int(parts[1]), float(parts[2])
    except (TypeError, ValueError):
        return None


def migrate_key(key):
    """Convert a legacy key to the stable form. Stable keys pass through."""
    if not key:
        return None
    if parse_stable_key(key):
        return key
    legacy = parse_legacy_key(key)
    if legacy is None:
        return None
    return stable_floor_key(legacy[0], legacy[1])


TRACKING_PREFIX = "DZ_TEST_TRACKING"
_KEY_IN_COMMENT = re.compile(r"key=([^|]+)")


def key_from_comment(text):
    """Recover a floor key from the Phase 7A Comments fallback."""
    if not text or not str(text).startswith(TRACKING_PREFIX):
        return None
    match = _KEY_IN_COMMENT.search(str(text))
    return match.group(1).strip() if match else None


# ---------------------------------------------------------------------------
# migration matching
# ---------------------------------------------------------------------------

MATCH_STABLE = "stable DZ_Floor_Key"
MATCH_LEGACY = "legacy DZ_Floor_Key (migrated)"
MATCH_COMMENT = "Phase 7A Comments tracking (migration fallback)"
MATCH_LOG = "Phase 7A/7B publish log ElementId"
MATCH_INDEX = "building id and floor index"
MATCH_SECONDARY = "elevation and area (secondary validation)"


class MigrationMatch(object):
    def __init__(self, floor, element, matched_by, existing_key=None,
                 needs_migration=False):
        self.floor = floor
        self.element = element
        self.matched_by = matched_by
        self.existing_key = existing_key
        self.needs_migration = needs_migration

    def as_dict(self):
        return {
            "FloorIndex": self.floor.floor_index,
            "ElementId": (self.element or {}).get("ElementId"),
            "MatchedBy": self.matched_by,
            "ExistingKey": self.existing_key,
            "StableKey": stable_floor_key(self.floor.building_source_id,
                                          self.floor.floor_index),
            "NeedsMigration": self.needs_migration,
        }


def match_elements(building, observed, log_ids=None, elevation_tolerance=1e-4,
                   area_tolerance_ratio=0.01):
    """Match manifest floors to existing Revit elements by identity.

    Priority, highest first:
      1. stable DZ_Floor_Key
      2. legacy DZ_Floor_Key (needs migration)
      3. Phase 7A DZ_TEST_TRACKING comment (migration fallback only)
      4. publish-log ElementId
      5. building id plus floor index
    Elevation and area are used only as secondary validation, never as the
    primary match, because both legitimately change between revisions.

    Returns (matches, unmatched_floors, conflicts).
    """
    observed = list(observed or [])
    log_ids = list(log_ids or [])
    conflicts = []

    by_stable, by_legacy, by_comment, by_id, by_index = {}, {}, {}, {}, {}
    for row in observed:
        element_id = row.get("ElementId")
        by_id[element_id] = row

        key = row.get("DZ_Floor_Key")
        if key:
            if parse_stable_key(key):
                if key in by_stable:
                    conflicts.append(
                        "Duplicate stable DZ_Floor_Key %r on elements %s and %s."
                        % (key, by_stable[key].get("ElementId"), element_id))
                by_stable[key] = row
            elif is_legacy_key(key):
                migrated = migrate_key(key)
                if migrated in by_legacy:
                    conflicts.append(
                        "Duplicate legacy DZ_Floor_Key %r on elements %s and %s."
                        % (key, by_legacy[migrated].get("ElementId"), element_id))
                by_legacy[migrated] = row

        comment_key = key_from_comment(row.get("Comments"))
        if comment_key:
            migrated = migrate_key(comment_key)
            if migrated:
                by_comment.setdefault(migrated, row)

        index = row.get("DZ_Floor_Index")
        bid = row.get("DZ_Building_ID")
        if index is not None and bid:
            slot = "%s:%s" % (bid, index)
            if slot in by_index:
                conflicts.append(
                    "Two elements claim building %s floor index %s: %s and %s."
                    % (bid, index, by_index[slot].get("ElementId"), element_id))
            by_index[slot] = row

        if bid and building.building_id and bid != building.building_id:
            conflicts.append(
                "Element %s carries DZ_Building_ID %r but is being matched "
                "against building %r." % (element_id, bid, building.building_id))

    matches, unmatched = [], []
    used = set()
    for position, floor in enumerate(building.floors):
        stable = stable_floor_key(building.source_id, floor.floor_index)
        row, how, existing, migrate = None, None, None, False

        if stable in by_stable:
            row, how, existing = by_stable[stable], MATCH_STABLE, stable
        elif stable in by_legacy:
            row = by_legacy[stable]
            how, existing, migrate = MATCH_LEGACY, row.get("DZ_Floor_Key"), True
        elif stable in by_comment:
            row = by_comment[stable]
            how, existing, migrate = MATCH_COMMENT, row.get("Comments"), True
        elif position < len(log_ids) and log_ids[position] in by_id:
            row = by_id[log_ids[position]]
            how, migrate = MATCH_LOG, True
        else:
            slot = "%s:%s" % (building.building_id, floor.floor_index)
            if slot in by_index:
                row, how, migrate = by_index[slot], MATCH_INDEX, True

        if row is None:
            unmatched.append(floor)
            continue
        element_id = row.get("ElementId")
        if element_id in used:
            conflicts.append(
                "Element %s matched more than one source floor; identity is "
                "ambiguous." % element_id)
            continue
        used.add(element_id)
        matches.append(MigrationMatch(floor, row, how, existing, migrate))

    return matches, unmatched, conflicts


def validate_secondary(match, elevation_tolerance=1e-4,
                       area_tolerance_ratio=0.01):
    """Cross-check a match against elevation and area. Returns warnings."""
    warnings = []
    floor, element = match.floor, match.element or {}
    elevation = element.get("Elevation")
    if elevation is not None and floor.elevation is not None:
        delta = abs(float(elevation) - float(floor.elevation))
        if delta > elevation_tolerance:
            warnings.append(
                "Floor index %s matched element %s whose elevation is %.4f m "
                "against a source elevation of %.4f m; this will be handled as "
                "an elevation update."
                % (floor.floor_index, element.get("ElementId"),
                   float(elevation), float(floor.elevation)))
    area = element.get("Area")
    if area is not None and floor.plate_area:
        ratio = abs(float(area) - float(floor.plate_area)) / float(floor.plate_area)
        if ratio > area_tolerance_ratio:
            warnings.append(
                "Floor index %s matched element %s whose area is %.4f m2 "
                "against a source area of %.4f m2 (%.2f%%)."
                % (floor.floor_index, element.get("ElementId"), float(area),
                   float(floor.plate_area), ratio * 100.0))
    return warnings
