"""Area boundary loops and the interior point each native Area is placed at.

Pure geometry on a list of (x, y, z) tuples in metres, so it is unit testable
without Rhino or Revit. The Revit layer converts the result to internal units.

The footprint arriving here has already been normalised to metres by the
Phase 7A geometry reader, which is what prevents the millimetre scale error
found during Phase 7A from reappearing.
"""

BOUNDARY_SUFFIX = "AREA-BOUNDARY"
CLOSE_TOLERANCE_M = 1e-6


def boundary_key(building_source_id, floor_index):
    """`{BuildingSourceId}:{FloorIndex}:AREA-BOUNDARY` - stable per level."""
    if not building_source_id:
        raise ValueError("A building SourceId is required for a boundary key.")
    return "%s:%d:%s" % (str(building_source_id).strip(), int(floor_index),
                         BOUNDARY_SUFFIX)


def close_loop(points, tolerance=CLOSE_TOLERANCE_M):
    """Drop a duplicated closing vertex; the loop is implicitly closed."""
    pts = [tuple(p) for p in (points or [])]
    if len(pts) > 1:
        first, last = pts[0], pts[-1]
        span = max(abs(first[i] - last[i]) for i in range(min(len(first), len(last))))
        if span <= tolerance:
            pts = pts[:-1]
    return pts


def signed_area(points):
    """Shoelace signed area in the XY plane. Positive is counter-clockwise."""
    pts = close_loop(points)
    if len(pts) < 3:
        return 0.0
    total = 0.0
    for index in range(len(pts)):
        x1, y1 = pts[index][0], pts[index][1]
        x2, y2 = pts[(index + 1) % len(pts)][0], pts[(index + 1) % len(pts)][1]
        total += (x1 * y2) - (x2 * y1)
    return total / 2.0


def polygon_area(points):
    return abs(signed_area(points))


def centroid(points):
    """Area centroid in XY. Falls back to the vertex average for slivers."""
    pts = close_loop(points)
    if not pts:
        return None
    if len(pts) < 3:
        return (sum(p[0] for p in pts) / len(pts),
                sum(p[1] for p in pts) / len(pts))
    area = signed_area(pts)
    if abs(area) < 1e-12:
        return (sum(p[0] for p in pts) / len(pts),
                sum(p[1] for p in pts) / len(pts))
    cx = cy = 0.0
    for index in range(len(pts)):
        x1, y1 = pts[index][0], pts[index][1]
        x2, y2 = pts[(index + 1) % len(pts)][0], pts[(index + 1) % len(pts)][1]
        cross = (x1 * y2) - (x2 * y1)
        cx += (x1 + x2) * cross
        cy += (y1 + y2) * cross
    factor = 1.0 / (6.0 * area)
    return (cx * factor, cy * factor)


def point_in_polygon(point, points):
    """Ray-casting containment test in XY."""
    pts = close_loop(points)
    if len(pts) < 3 or point is None:
        return False
    x, y = point[0], point[1]
    inside = False
    for index in range(len(pts)):
        x1, y1 = pts[index][0], pts[index][1]
        x2, y2 = pts[(index + 1) % len(pts)][0], pts[(index + 1) % len(pts)][1]
        if (y1 > y) != (y2 > y):
            if y2 != y1:
                crossing = x1 + (y - y1) * (x2 - x1) / (y2 - y1)
                if crossing > x:
                    inside = not inside
    return inside


def interior_point(points):
    """A point guaranteed to be inside the loop, for placing the Area.

    The centroid works for convex footprints. For a concave one it can fall
    outside, so the fallback samples a grid across the bounding box and takes
    the interior point furthest from the edges - Revit rejects an Area seed
    that is not properly enclosed.
    """
    pts = close_loop(points)
    if len(pts) < 3:
        return None
    middle = centroid(pts)
    if middle and point_in_polygon(middle, pts):
        return middle

    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    steps = 24
    best, best_score = None, -1.0
    for i in range(1, steps):
        for j in range(1, steps):
            candidate = (min_x + (max_x - min_x) * i / float(steps),
                         min_y + (max_y - min_y) * j / float(steps))
            if not point_in_polygon(candidate, pts):
                continue
            score = min(_distance_to_segment(candidate, pts[k],
                                             pts[(k + 1) % len(pts)])
                        for k in range(len(pts)))
            if score > best_score:
                best, best_score = candidate, score
    return best


def _distance_to_segment(point, a, b):
    px, py = point[0], point[1]
    ax, ay = a[0], a[1]
    bx, by = b[0], b[1]
    dx, dy = bx - ax, by - ay
    if dx == 0 and dy == 0:
        return ((px - ax) ** 2 + (py - ay) ** 2) ** 0.5
    t = ((px - ax) * dx + (py - ay) * dy) / float(dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    nx, ny = ax + t * dx, ay + t * dy
    return ((px - nx) ** 2 + (py - ny) ** 2) ** 0.5


def validate_loop(points, expected_area=None, tolerance_ratio=0.01):
    """Check a loop is usable as an Area boundary. Returns (ok, issues)."""
    issues = []
    pts = close_loop(points)
    if len(pts) < 3:
        issues.append("A boundary loop needs at least three distinct points; "
                      "got %d." % len(pts))
        return False, issues

    area = polygon_area(pts)
    if area <= 0:
        issues.append("Boundary loop encloses no area.")

    for index in range(len(pts)):
        a = pts[index]
        b = pts[(index + 1) % len(pts)]
        length = ((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2) ** 0.5
        if length < 1e-6:
            issues.append("Boundary segment %d is degenerate (%.9f m)."
                          % (index, length))

    zs = set(round(p[2], 6) for p in pts if len(p) > 2)
    if len(zs) > 1:
        issues.append("Boundary loop is not planar in Z: %s" % sorted(zs))

    if interior_point(pts) is None:
        issues.append("No interior point could be found for Area placement.")

    if expected_area:
        ratio = abs(area - float(expected_area)) / float(expected_area)
        if ratio > tolerance_ratio:
            issues.append("Boundary loop area %.4f m2 differs from the "
                          "expected %.4f m2 by %.2f%%."
                          % (area, float(expected_area), ratio * 100.0))
    return not issues, issues


class BoundaryRequest(object):
    def __init__(self, key, floor_index, elevation, view_name, points,
                 expected_area=None, action="CREATE", note=None):
        self.key = key
        self.floor_index = floor_index
        self.elevation = elevation
        self.view_name = view_name
        self.points = list(points or [])
        self.expected_area = expected_area
        self.action = action
        self.note = note
        self.error = None
        self.curve_ids = []
        self.loop_area = polygon_area(self.points)
        self.seed = interior_point(self.points)

    def as_dict(self):
        return {
            "BoundaryKey": self.key, "FloorIndex": self.floor_index,
            "Elevation": self.elevation, "ViewName": self.view_name,
            "PointCount": len(close_loop(self.points)),
            "LoopArea": self.loop_area, "ExpectedArea": self.expected_area,
            "SeedPoint": list(self.seed) if self.seed else None,
            "Action": self.action, "CurveElementIds": list(self.curve_ids),
            "Note": self.note, "Error": self.error,
        }


def plan(building, footprint_points, plan_requests, existing_boundary_keys=None):
    """One boundary loop per Area Plan, reusing any already published."""
    existing = dict(existing_boundary_keys or {})
    by_index = dict((r.floor_index, r) for r in plan_requests)
    requests = []
    for floor in building.floors:
        index = floor.floor_index
        view = by_index.get(index)
        key = boundary_key(building.source_id, index)
        points = [(p[0], p[1], floor.elevation or 0.0)
                  for p in close_loop(footprint_points)]
        request = BoundaryRequest(key, index, floor.elevation,
                                  view.name if view else None, points,
                                  floor.plate_area)
        if key in existing:
            request.action = "REUSE"
            request.curve_ids = list(existing[key])
            request.note = "boundary set already published for this key"
        else:
            ok, issues = validate_loop(points, floor.plate_area)
            if not ok:
                request.action = "ERROR"
                request.error = "; ".join(issues)
        requests.append(request)
    return requests
