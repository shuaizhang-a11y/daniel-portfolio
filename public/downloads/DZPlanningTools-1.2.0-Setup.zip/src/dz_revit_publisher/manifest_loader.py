"""Locate, load and index a Phase 6A export package for Phase 7A.

Package selection uses the `exportTimestamp` recorded inside each manifest, not
the filesystem modification time - the same rule Phase 6B uses.
"""

import datetime
import hashlib
import io
import json
import os

from .models import BuildingRecord

MANIFEST_NAME = "project_manifest.json"

REQUIRED_SECTIONS = (
    "schemaVersion", "project", "site", "buildings", "floors",
    "sourceObjects", "exportMetadata",
)


from .datetime_compat import parse_iso_datetime


class ManifestNotFound(Exception):
    def __init__(self, message, searched=None):
        Exception.__init__(self, message)
        self.searched = list(searched or [])


class ManifestInvalid(Exception):
    pass


def parse_timestamp(text, field="exportMetadata.ExportTimestamp"):
    """An export timestamp, or None when it cannot be read.

    Delegates to :mod:`dz_revit_publisher.datetime_compat`; there is one
    parser in the project. `fromisoformat` is not used: it does not exist
    under IronPython 2.7, and the AttributeError it raises there is not
    caught by `except ValueError`.
    """
    return parse_iso_datetime(text, field, default=None)


def calculate_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def find_manifests(root):
    found = []
    if not os.path.isdir(root):
        return found
    for dirpath, _dirnames, filenames in os.walk(root):
        if MANIFEST_NAME in filenames:
            found.append(os.path.join(dirpath, MANIFEST_NAME))
    return sorted(found)


def read_manifest(path):
    with io.open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def select_latest(root):
    """(path, manifest, info) for the newest package by manifest timestamp."""
    candidates = find_manifests(root)
    if not candidates:
        raise ManifestNotFound("No %s found under %s" % (MANIFEST_NAME, root),
                               searched=[root])
    scored, problems = [], []
    for path in candidates:
        try:
            manifest = read_manifest(path)
        except Exception as exc:
            problems.append("%s: unreadable (%s: %s)"
                            % (path, type(exc).__name__, exc))
            continue
        stamp = parse_timestamp(
            (manifest.get("exportMetadata") or {}).get("ExportTimestamp"))
        if stamp is None:
            problems.append("%s: no readable exportMetadata.ExportTimestamp" % path)
            continue
        scored.append((stamp, path, manifest))
    if not scored:
        raise ManifestNotFound(
            "Found %d manifest file(s) but none carried a usable "
            "exportMetadata.ExportTimestamp." % len(candidates),
            searched=candidates + problems)
    scored.sort(key=lambda item: item[0])
    stamp, path, manifest = scored[-1]
    return path, manifest, {
        "candidates": candidates,
        "problems": problems,
        "selectedTimestamp": stamp.isoformat(),
        "considered": len(scored),
    }


def load(explicit_path=None, search_root=None):
    if explicit_path:
        if not os.path.isfile(explicit_path):
            raise ManifestNotFound("Manifest not found: %s" % explicit_path,
                                   searched=[explicit_path])
        try:
            manifest = read_manifest(explicit_path)
        except ValueError as exc:
            raise ManifestInvalid("Manifest is not valid JSON: %s (%s)"
                                  % (explicit_path, exc))
        stamp = parse_timestamp(
            (manifest.get("exportMetadata") or {}).get("ExportTimestamp"))
        return explicit_path, manifest, {
            "candidates": [explicit_path], "problems": [],
            "selectedTimestamp": stamp.isoformat() if stamp else None,
            "considered": 1,
        }
    if not search_root:
        raise ManifestNotFound("No manifest path and no search root supplied.")
    return select_latest(search_root)


def package_folder(manifest_path):
    return os.path.dirname(os.path.abspath(manifest_path))


# ---------------------------------------------------------------------------
# indexing
# ---------------------------------------------------------------------------

def floors_by_building(manifest):
    index = {}
    for row in (manifest.get("floors") or []):
        index.setdefault(row.get("BuildingId"), []).append(row)
    return index


def building_records(manifest):
    """Every building as a BuildingRecord with its floor rows attached."""
    index = floors_by_building(manifest)
    records = []
    for row in (manifest.get("buildings") or []):
        records.append(BuildingRecord(row, index.get(row.get("BuildingId"), [])))
    return records


def get_building(manifest, building_id=None):
    """Find a building by id, or return None when it does not exist."""
    records = building_records(manifest)
    if building_id:
        wanted = str(building_id).strip()
        for record in records:
            if str(record.building_id or "").strip() == wanted:
                return record
        return None
    return None


def source_object_index(manifest):
    """SourceId -> source object row, plus the ids that appear more than once."""
    index, duplicates = {}, set()
    for row in (manifest.get("sourceObjects") or []):
        source_id = row.get("SourceId")
        if not source_id:
            continue
        if source_id in index:
            duplicates.add(source_id)
        index[source_id] = row
    return index, duplicates


def project_identity(manifest):
    project = manifest.get("project") or {}
    metadata = manifest.get("exportMetadata") or {}
    return {
        "projectId": project.get("projectId") or metadata.get("ProjectId"),
        "projectName": project.get("projectName") or metadata.get("ProjectName"),
        "option": project.get("option") or metadata.get("Option"),
        "revision": project.get("revision") or metadata.get("Revision"),
        "schemaVersion": manifest.get("schemaVersion"),
        "definitionPhase": metadata.get("DefinitionPhase"),
        "exportTimestamp": metadata.get("ExportTimestamp"),
        "rhinoUnits": metadata.get("RhinoModelUnits"),
        "rhinoTolerance": metadata.get("RhinoAbsoluteTolerance"),
        "rhinoFileName": metadata.get("RhinoFileName"),
        "grasshopperFileName": metadata.get("GrasshopperFileName"),
        "siteSourceId": metadata.get("SiteSourceId"),
    }
