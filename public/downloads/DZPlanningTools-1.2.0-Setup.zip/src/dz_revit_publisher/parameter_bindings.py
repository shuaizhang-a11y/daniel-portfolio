"""Phase 7B parameter-binding plan and the values written to each element.

Revit-free: the Revit layer supplies what it observed, this module decides what
should happen and why.
"""

from . import naming
from .shared_parameters import (AREAS, FLOORS, LEVELS, PROJECT_INFO, SCHEMA,
                                for_category)

CATEGORY_ORDER = (LEVELS, FLOORS, AREAS, PROJECT_INFO)


class BindingRequest(object):
    def __init__(self, name, categories, action="CREATE", note=None):
        self.name = name
        self.categories = list(categories)
        self.action = action
        self.note = note
        self.error = None

    def as_dict(self):
        return {"Parameter": self.name, "Categories": list(self.categories),
                "Action": self.action, "Note": self.note, "Error": self.error}


def plan_bindings(existing_bindings):
    """Decide CREATE / REUSE / EXTEND for every schema parameter.

    `existing_bindings` is {parameter name: [category keys already bound]}.
    """
    existing_bindings = dict(existing_bindings or {})
    requests = []
    for spec in SCHEMA:
        wanted = list(spec.categories)
        current = existing_bindings.get(spec.name)
        if current is None:
            requests.append(BindingRequest(spec.name, wanted, "CREATE"))
            continue
        missing = [c for c in wanted if c not in current]
        if missing:
            request = BindingRequest(spec.name, wanted, "EXTEND")
            request.note = ("already bound to %s; adding %s"
                            % (", ".join(current) or "nothing",
                               ", ".join(missing)))
            requests.append(request)
        else:
            request = BindingRequest(spec.name, wanted, "REUSE")
            request.note = "already bound to every required category"
            requests.append(request)
    return requests


def binding_counts(requests):
    counts = {}
    for request in requests:
        counts[request.action] = counts.get(request.action, 0) + 1
    return counts


# ---------------------------------------------------------------------------
# element values
# ---------------------------------------------------------------------------

def floor_values(building, floor, identity, manifest_sha):
    """Formal DZ parameter values for one published floor.

    Every value comes from the manifest. Nothing is measured from Revit.
    """
    plate = floor.plate_area
    included = floor.included_in_fsr
    if included is None:
        fsr_area = None
    else:
        fsr_area = plate if included else 0.0
    return {
        "DZ_Source_ID": building.source_id,
        "DZ_Building_ID": building.building_id,
        "DZ_Building_Name": building.building_name,
        "DZ_Project_ID": identity.get("projectId"),
        "DZ_Option": identity.get("option"),
        "DZ_Source_Revision": identity.get("revision"),
        "DZ_Manifest_SHA256": manifest_sha,
        "DZ_Program": building.program,
        "DZ_Floor_Index": floor.floor_index,
        "DZ_Floor_Key": floor.key(),
        "DZ_FSR_Included": included,
        "DZ_Physical_GFA": plate,
        "DZ_FSR_GFA": fsr_area,
    }


def level_values(building, identity, manifest_sha):
    """Identity-only values for a published level."""
    return {
        "DZ_Source_ID": building.source_id,
        "DZ_Building_ID": building.building_id,
        "DZ_Building_Name": building.building_name,
        "DZ_Project_ID": identity.get("projectId"),
        "DZ_Option": identity.get("option"),
        "DZ_Source_Revision": identity.get("revision"),
        "DZ_Manifest_SHA256": manifest_sha,
    }


def area_values(building, floor, identity, manifest_sha):
    """Areas carry the same identity as their floor."""
    values = floor_values(building, floor, identity, manifest_sha)
    return values


# ---------------------------------------------------------------------------
# project information
# ---------------------------------------------------------------------------

# Each project parameter records exactly which manifest field it came from, so
# the log can prove nothing was recalculated inside Revit.
PROJECT_FIELD_SOURCE = {
    "DZ_Project_ID": "project.projectId",
    "DZ_Option": "project.option",
    "DZ_Export_Revision": "project.revision",
    "DZ_Export_Timestamp": "exportMetadata.ExportTimestamp",
    "DZ_Manifest_SHA256": "(sha256 of the manifest file)",
    "DZ_Target_FSR": "project.summary.TargetFSR",
    "DZ_Actual_FSR": "project.summary.ActualFSR",
    "DZ_Site_Area": "project.summary.SiteArea",
    "DZ_Total_Physical_GFA": "project.summary.TotalPhysicalGFA",
    "DZ_Total_FSR_GFA": "project.summary.FSRIncludedGFA",
    "DZ_Actual_Site_Coverage": "project.summary.ActualSiteCoverage",
    "DZ_Overall_Compliance_Status": "project.summary.OverallComplianceStatus",
}


def project_information_values(manifest, identity, manifest_sha):
    summary = ((manifest.get("project") or {}).get("summary")) or {}
    metadata = manifest.get("exportMetadata") or {}
    values = {
        "DZ_Project_ID": identity.get("projectId"),
        "DZ_Option": identity.get("option"),
        "DZ_Export_Revision": identity.get("revision"),
        "DZ_Export_Timestamp": metadata.get("ExportTimestamp"),
        "DZ_Manifest_SHA256": manifest_sha,
        "DZ_Target_FSR": summary.get("TargetFSR"),
        "DZ_Actual_FSR": summary.get("ActualFSR"),
        "DZ_Site_Area": summary.get("SiteArea"),
        "DZ_Total_Physical_GFA": summary.get("TotalPhysicalGFA"),
        "DZ_Total_FSR_GFA": summary.get("FSRIncludedGFA"),
        "DZ_Actual_Site_Coverage": summary.get("ActualSiteCoverage"),
        "DZ_Overall_Compliance_Status": summary.get("OverallComplianceStatus"),
    }
    return values


def project_information_report(values):
    rows = []
    for spec in for_category(PROJECT_INFO):
        rows.append({
            "Parameter": spec.name,
            "Value": values.get(spec.name),
            "DataType": spec.data_type,
            "ManifestField": PROJECT_FIELD_SOURCE.get(spec.name, "unmapped"),
        })
    return rows


# ---------------------------------------------------------------------------
# matching existing Phase 7A elements
# ---------------------------------------------------------------------------

def match_floors(building, observed_floors, log_floor_ids=None):
    """Match manifest floor rows to the published Revit floors.

    Matching is by identity, never by element order. Priority:
    1. the DZ_Floor_Key shared parameter, when it is already written
    2. the Phase 7A DZ_TEST_TRACKING key in Comments
    3. the ElementId recorded in the Phase 7A publish log
    4. building id plus floor index plus elevation

    `observed_floors` items: {"ElementId", "Comments", "DZ_Floor_Key",
    "LevelName", "Elevation", "Area"}.
    """
    log_floor_ids = list(log_floor_ids or [])
    by_formal, by_tracking, by_id = {}, {}, {}
    for row in observed_floors or []:
        element_id = row.get("ElementId")
        by_id[element_id] = row
        formal = row.get("DZ_Floor_Key")
        if formal:
            by_formal[formal] = row
        key = naming.extract_floor_key(row.get("Comments"))
        if key:
            by_tracking[key] = row

    matches, unmatched = [], []
    for index, floor in enumerate(building.floors):
        key = floor.key()
        row, how = None, None
        if key in by_formal:
            row, how = by_formal[key], "DZ_Floor_Key parameter"
        elif key in by_tracking:
            row, how = by_tracking[key], "Phase 7A tracking key"
        elif index < len(log_floor_ids) and log_floor_ids[index] in by_id:
            row, how = by_id[log_floor_ids[index]], "Phase 7A publish log ElementId"
        else:
            for candidate in observed_floors or []:
                elevation = candidate.get("Elevation")
                if (elevation is not None and floor.elevation is not None
                        and abs(float(elevation) - float(floor.elevation)) < 1e-4):
                    row, how = candidate, "building id, floor index and elevation"
                    break
        if row is None:
            unmatched.append(floor)
        else:
            matches.append({"floor": floor, "element": row, "matchedBy": how,
                            "floorKey": key})
    return matches, unmatched
