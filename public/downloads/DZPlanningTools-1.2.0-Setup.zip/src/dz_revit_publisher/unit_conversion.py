"""Explicit unit handling between the Rhino planning model and Revit.

The Phase 6A planning model is authored in **metres**. Revit's internal length
unit is **decimal feet**, and its internal area unit is **square feet**. Those
are the only two conversions Phase 7A needs.

Every conversion goes through the named constants below. There are no unexplained
inline conversion numbers anywhere in this package.

The international foot is defined exactly as 0.3048 metres, so the conversion is
exact rather than approximate. `verify_against_revit_api` lets the Revit layer
cross-check these values against `UnitUtils` on the installed Revit version, so a
silent divergence would be caught rather than assumed away.
"""

METRES_PER_FOOT = 0.3048          # exact, by international definition
FEET_PER_METRE = 1.0 / METRES_PER_FOOT
SQ_METRES_PER_SQ_FOOT = METRES_PER_FOOT * METRES_PER_FOOT
SQ_FEET_PER_SQ_METRE = 1.0 / SQ_METRES_PER_SQ_FOOT

REVIT_INTERNAL_LENGTH_UNIT = "decimal feet"
REVIT_INTERNAL_AREA_UNIT = "square feet"
SOURCE_LENGTH_UNIT = "metres"
SOURCE_AREA_UNIT = "square metres"

# Revit's own short-curve tolerance is 1/32 inch, expressed in internal feet.
REVIT_SHORT_CURVE_TOLERANCE_FEET = 1.0 / 32.0 / 12.0
REVIT_SHORT_CURVE_TOLERANCE_METRES = REVIT_SHORT_CURVE_TOLERANCE_FEET * METRES_PER_FOOT

SUPPORTED_SOURCE_UNITS = {
    "m": 1.0,
    "meter": 1.0,
    "meters": 1.0,
    "metre": 1.0,
    "metres": 1.0,
}


class UnsupportedUnitError(Exception):
    """Raised when the source model is not authored in metres."""


def assert_source_units(unit_text):
    """Confirm the manifest was authored in metres.

    Phase 7A deliberately refuses to guess at other unit systems rather than
    silently applying a wrong scale factor.
    """
    token = str(unit_text or "").strip().lower()
    if token not in SUPPORTED_SOURCE_UNITS:
        raise UnsupportedUnitError(
            "Phase 7A supports metre-based planning models only. The manifest "
            "reports Rhino model units %r. Convert the model or extend "
            "unit_conversion.SUPPORTED_SOURCE_UNITS deliberately." % unit_text)
    return True


def metres_to_internal(value):
    """Metres -> Revit internal length (decimal feet)."""
    if value is None:
        return None
    return float(value) * FEET_PER_METRE


def internal_to_metres(value):
    """Revit internal length (decimal feet) -> metres."""
    if value is None:
        return None
    return float(value) * METRES_PER_FOOT


def square_metres_to_internal_area(value):
    """Square metres -> Revit internal area (square feet)."""
    if value is None:
        return None
    return float(value) * SQ_FEET_PER_SQ_METRE


def internal_area_to_square_metres(value):
    """Revit internal area (square feet) -> square metres."""
    if value is None:
        return None
    return float(value) * SQ_METRES_PER_SQ_FOOT


def elevation_to_internal(value):
    """Elevations are lengths; kept separate for readable call sites."""
    return metres_to_internal(value)


def point_to_internal(point):
    """(x, y, z) in metres -> tuple in Revit internal feet.

    Phase 7A uses Internal Origin Alignment, so no translation or rotation is
    applied: only the unit scale changes.
    """
    if point is None:
        return None
    x, y, z = point[0], point[1], point[2] if len(point) > 2 else 0.0
    return (metres_to_internal(x), metres_to_internal(y), metres_to_internal(z))


def points_to_internal(points):
    return [point_to_internal(p) for p in (points or [])]


def tolerance_to_internal(value):
    """Convert a Rhino tolerance in metres to Revit internal feet."""
    return metres_to_internal(value)


def effective_short_curve_tolerance_metres(rhino_tolerance_metres):
    """The stricter of the Rhino document tolerance and Revit's own limit.

    A segment shorter than this cannot be published as a Revit curve, so the
    larger of the two thresholds is the one that actually governs.
    """
    rhino = float(rhino_tolerance_metres or 0.0)
    return max(rhino, REVIT_SHORT_CURVE_TOLERANCE_METRES)


def area_difference(expected_square_metres, actual_square_metres):
    """Absolute and relative difference between two areas in square metres."""
    if expected_square_metres is None or actual_square_metres is None:
        return None, None
    absolute = float(actual_square_metres) - float(expected_square_metres)
    if not expected_square_metres:
        return absolute, None
    return absolute, absolute / float(expected_square_metres)


def summary(source_units, rhino_tolerance_metres=None):
    """Human-readable conversion summary for the publish plan and log."""
    lines = [
        "Source units            : %s" % SOURCE_LENGTH_UNIT,
        "Manifest reports        : %s" % source_units,
        "Revit internal length   : %s" % REVIT_INTERNAL_LENGTH_UNIT,
        "Revit internal area     : %s" % REVIT_INTERNAL_AREA_UNIT,
        "Metres per foot         : %.4f (exact)" % METRES_PER_FOOT,
        "1 m  -> internal        : %.9f ft" % metres_to_internal(1.0),
        "1 m2 -> internal        : %.9f sq ft" % square_metres_to_internal_area(1.0),
    ]
    if rhino_tolerance_metres is not None:
        effective = effective_short_curve_tolerance_metres(rhino_tolerance_metres)
        lines.append("Rhino tolerance         : %.6f m" % float(rhino_tolerance_metres))
        lines.append("Revit short-curve limit : %.6f m" % REVIT_SHORT_CURVE_TOLERANCE_METRES)
        lines.append("Effective segment limit : %.6f m" % effective)
    return lines


def verify_against_revit_api(convert_to_internal):
    """Cross-check our constants against the installed Revit API.

    `convert_to_internal` is a callable supplied by the Revit layer that turns
    a value in metres into Revit internal units using `UnitUtils`. Returns
    (ok, detail) so a mismatch is reported rather than silently trusted.
    """
    try:
        api_value = float(convert_to_internal(1.0))
    except Exception as exc:
        return False, "Revit API conversion unavailable: %s: %s" % (
            type(exc).__name__, exc)
    ours = metres_to_internal(1.0)
    delta = abs(api_value - ours)
    if delta > 1e-9:
        return False, ("Unit mismatch: Revit API says 1 m = %.12f internal, "
                       "this package says %.12f (delta %.3e)."
                       % (api_value, ours, delta))
    return True, ("Verified against Revit API: 1 m = %.9f internal units."
                  % api_value)
