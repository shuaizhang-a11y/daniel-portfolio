"""Deterministic names and identity keys for published Revit elements.

Naming has to be stable across runs: duplicate prevention in Phase 7A depends
on regenerating exactly the same floor key from the same manifest row.
"""

import re

LEVEL_PREFIX = "DZ"
TRACKING_PREFIX = "DZ_TEST_TRACKING"

# Revit rejects these characters in element names.
ILLEGAL_NAME_CHARS = r'\:{}[]|;<>?`~'
_ILLEGAL_RE = re.compile("[" + re.escape(ILLEGAL_NAME_CHARS) + "]")

# Elevations are rounded to this many decimal places (metres) before they are
# used in a key, so floating-point noise cannot produce two different keys for
# the same floor.
KEY_ELEVATION_DECIMALS = 6


def sanitise_name(text, fallback="UNNAMED"):
    """Strip characters Revit will not accept in an element name."""
    value = "" if text is None else str(text)
    value = _ILLEGAL_RE.sub("-", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value or fallback


def level_name(building_id, level_name_text=None, floor_index=None):
    """`DZ-{BuildingId}-{LevelName}`, falling back to `DZ-{BuildingId}-L{nn}`.

    The Phase 6A floor-index convention is 1-based, so the first generated
    floor is `L01`, not `L00`.
    """
    building = sanitise_name(building_id, "BLDG")
    suffix = sanitise_name(level_name_text, "") if level_name_text else ""
    if not suffix:
        if floor_index is None:
            raise ValueError(
                "level_name needs either a level name or a floor index.")
        suffix = "L%02d" % int(floor_index)
    return "%s-%s-%s" % (LEVEL_PREFIX, building, suffix)


def floor_mark(building_id, floor_index):
    """Readable mark for a published floor, e.g. `B001-F01`."""
    return "%s-F%02d" % (sanitise_name(building_id, "BLDG"), int(floor_index))


def format_elevation_key(elevation_metres):
    """Elevation rendered deterministically for use inside a key."""
    if elevation_metres is None:
        raise ValueError("Elevation is required to build a floor key.")
    value = round(float(elevation_metres), KEY_ELEVATION_DECIMALS)
    if value == 0:
        value = 0.0  # collapse -0.0
    return ("%%.%df" % KEY_ELEVATION_DECIMALS) % value


def floor_key(building_source_id, floor_index, elevation_metres):
    """`{BuildingSourceId}:{FloorIndex}:{Elevation}` - the duplicate-prevention key."""
    if not building_source_id:
        raise ValueError("A building SourceId is required to build a floor key.")
    return "%s:%d:%s" % (str(building_source_id).strip(), int(floor_index),
                         format_elevation_key(elevation_metres))


def parse_floor_key(key):
    """Inverse of `floor_key`. Returns (source_id, floor_index, elevation)."""
    if not key:
        return None
    parts = str(key).split(":")
    if len(parts) != 3:
        return None
    try:
        return parts[0], int(parts[1]), float(parts[2])
    except (TypeError, ValueError):
        return None


def tracking_value(floor_key_text, project_id=None, option=None, revision=None,
                   building_id=None, source_id=None):
    """Temporary Phase 7A tracking string.

    Written into an existing writable text parameter (normally `Comments`) only
    when the DZ shared parameters are absent. The prefix makes every value this
    phase wrote unmistakable and easy to find or remove later.
    """
    fields = [TRACKING_PREFIX, "key=%s" % floor_key_text]
    for label, value in (("project", project_id), ("option", option),
                         ("rev", revision), ("building", building_id),
                         ("source", source_id)):
        if value:
            fields.append("%s=%s" % (label, value))
    return "|".join(fields)


def extract_floor_key(tracking_text):
    """Recover the floor key from a tracking string, or None."""
    if not tracking_text:
        return None
    text = str(tracking_text)
    if not text.startswith(TRACKING_PREFIX):
        return None
    for field in text.split("|"):
        if field.startswith("key="):
            return field[4:]
    return None


def is_dz_tracked(text):
    return bool(text) and str(text).startswith(TRACKING_PREFIX)


# Preferred shared parameters. Phase 7A reads them when they already exist and
# never creates them; formal binding is Phase 7B/7C work.
SHARED_PARAMETERS = (
    "DZ_Source_ID",
    "DZ_Building_ID",
    "DZ_Floor_Key",
    "DZ_Project_ID",
    "DZ_Option",
    "DZ_Source_Revision",
)

FALLBACK_PARAMETER = "Comments"


def shared_parameter_values(source_id, building_id, floor_key_text, project_id,
                            option, revision):
    """Values for the preferred shared parameters, keyed by parameter name."""
    return {
        "DZ_Source_ID": source_id,
        "DZ_Building_ID": building_id,
        "DZ_Floor_Key": floor_key_text,
        "DZ_Project_ID": project_id,
        "DZ_Option": option,
        "DZ_Source_Revision": revision,
    }
